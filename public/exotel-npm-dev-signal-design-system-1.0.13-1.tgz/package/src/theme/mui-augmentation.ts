/**
 * MUI module augmentation for Exotel Design System (palette, typography variants,
 * Chip/Button/TextField/InputBase overrides).
 */
import "@mui/material/styles";
import type { CSSProperties } from "react";

interface SurfaceElevations {
  elevation0: string;
  elevation1: string;
  elevation2: string;
  elevation3: string;
  elevation4: string;
  elevation5: string;
  elevation6: string;
  elevation7: string;
  elevation8: string;
  elevation9: string;
  elevation10: string;
  elevation11: string;
  elevation12: string;
  elevation13: string;
  elevation14: string;
  elevation15: string;
  elevation16: string;
  elevation17: string;
  elevation18: string;
  elevation19: string;
  elevation20: string;
  elevation21: string;
  elevation22: string;
  elevation23: string;
  elevation24: string;
}

interface CustomPalette {
  highlight: string;
}

declare module "@mui/material/styles" {
  interface Palette {
    surface: SurfaceElevations;
    custom: CustomPalette;
    appLauncher?: {
      trialChip?: {
        bg: string;
        text: string;
      };
    };
  }

  interface PaletteOptions {
    surface?: Partial<SurfaceElevations>;
    custom?: Partial<CustomPalette>;
    appLauncher?: {
      trialChip?: {
        bg: string;
        text: string;
      };
    };
  }

  interface Theme {
    appLauncher?: {
      trialChip?: {
        bg: string;
        text: string;
      };
    };
  }

  interface ColorSystemOptions {
    appLauncher?: {
      trialChip?: {
        bg: string;
        text: string;
      };
    };
  }

  interface ThemeVars {
    surface: SurfaceElevations;
    custom: CustomPalette;
    appLauncher?: {
      trialChip?: {
        bg: string;
        text: string;
      };
    };
  }

  interface TypographyVariants {
    fontWeightSemiBold: number;
    title1: CSSProperties;
    title2: CSSProperties;
    title3: CSSProperties;
    label1: CSSProperties;
    label2: CSSProperties;
    label3: CSSProperties;
    body3: CSSProperties;
  }

  interface TypographyVariantsOptions {
    fontWeightSemiBold: number;
    title1: CSSProperties;
    title2: CSSProperties;
    title3: CSSProperties;
    label1: CSSProperties;
    label2: CSSProperties;
    label3: CSSProperties;
    body3: CSSProperties;
  }
}

declare module "@mui/material/Typography" {
  interface TypographyPropsVariantOverrides {
    fontWeightSemiBold: true;
    title1: true;
    title2: true;
    title3: true;
    label1: true;
    label2: true;
    label3: true;
    body3: true;
  }
}

declare module "@mui/material/Chip" {
  interface ChipPropsVariantOverrides {
    filter: true;
    tonal: true;
  }
}

declare module "@mui/material/Button" {
  interface ButtonPropsSizeOverrides {
    extraLarge: true;
  }
}

declare module "@mui/material/TextField" {
  interface TextFieldPropsSizeOverrides {
    large: true;
  }
}

declare module "@mui/material/InputBase" {
  interface InputBasePropsSizeOverrides {
    large: true;
  }
}
