/**
 * EnhancedTextField Component
 *
 * Exports the Exotel EnhancedTextField component that wraps MUI's TextField.
 */

export { EnhancedTextField } from './EnhancedTextField';
export type { EnhancedTextFieldProps } from './EnhancedTextField';
