/**
 * EnhancedTextField Component
 *
 * Exotel-approved text field component that wraps MUI's TextField.
 * Provides consistent styling and behavior across Exotel applications.
 *
 * Usage:
 * ```tsx
 * import { EnhancedTextField } from '@exotel/design-system';
 *
 * <EnhancedTextField label="Email" variant="outlined" />
 * ```
 */

import MuiTextField, { type TextFieldProps as MuiTextFieldProps } from '@mui/material/TextField';
import { forwardRef } from 'react';
import { FieldWrapper } from '../FieldLabel';

/**
 * EnhancedTextField component props
 * Re-exports MUI TextFieldProps while hiding MUI-specific naming
 */
export interface EnhancedTextFieldProps
  extends Omit<MuiTextFieldProps, 'ref' | 'variant' | 'size'> {
  /**
   * Controls whether the label is rendered
   */
  showLabel?: boolean;
  /**
   * The label content
   */
  label?: React.ReactNode;
  /**
   * The helper text content
   */
  helperText?: React.ReactNode;
  /**
   * The size of the input
   */
  size?: 'small' | 'medium' | 'large';
}

/**
 * EnhancedTextField component
 *
 * Wraps MUI's TextField component with Exotel-specific defaults and styling.
 * All MUI TextField props are supported.
 */
export const EnhancedTextField = forwardRef<HTMLDivElement, EnhancedTextFieldProps>(
  (props, ref) => {
    const { showLabel = true, label, helperText, id, name, size = 'medium', sx, ...rest } = props;
    const inputId = id ?? name;

    const baseSx = {
      '& .MuiFormHelperText-root': {
        textAlign: 'left',
        marginLeft: 0,
      },
    };
    const mergedSx = Array.isArray(sx) ? [baseSx, ...sx] : sx ? [baseSx, sx] : baseSx;

    return (
      <FieldWrapper label={showLabel ? label : undefined} htmlFor={inputId}>
        <MuiTextField
          ref={ref}
          helperText={helperText}
          id={id}
          name={name}
          size={size}
          sx={mergedSx}
          {...rest}
        />
      </FieldWrapper>
    );
  }
);

EnhancedTextField.displayName = 'EnhancedTextField';
