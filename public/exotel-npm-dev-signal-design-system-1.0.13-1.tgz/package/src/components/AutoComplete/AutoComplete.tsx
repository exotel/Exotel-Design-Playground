/**
 * Autocomplete Component
 *
 * Exotel-approved autocomplete component that wraps MUI's Autocomplete.
 * Only supports the outlined variant and renders an external label
 * above the input, consistent with EnhancedTextField.
 */

import MuiAutocomplete, { type AutocompleteProps as MuiAutocompleteProps } from '@mui/material/Autocomplete';
import { forwardRef } from 'react';
import { EnhancedTextField } from '../EnhancedTextField';
import { FieldWrapper } from '../FieldLabel';
import { Checkbox } from '../Checkbox';
import { Chip } from '../Chip';

type BaseProps = Omit<MuiAutocompleteProps<any, any, any, any>, 'ref' | 'renderInput' | 'size'>;

export type AutocompleteProps = BaseProps & {
  /**
   * The label content displayed above the input.
   */
  label?: React.ReactNode;
  /**
   * The size of the component.
   * @default 'medium'
   */
  size?: 'small' | 'medium' | 'large';
};

export const Autocomplete = forwardRef<HTMLDivElement, AutocompleteProps>(
  (props, ref) => {
    const { label, id, multiple, size = 'medium', ...rest } = props;

    const renderOption: AutocompleteProps['renderOption'] = (props, option, { selected }) => {
      const { key, ...optionProps } = props;

      return (
        <li key={key} {...optionProps}>
          <Checkbox checked={selected} sx={{ mr: 1 }} />
          {option?.label}
        </li>
      );
    };

    const renderValue: AutocompleteProps['renderValue'] = (value: any[], getTagProps: any) =>
      value.map((option: any, index: number) => (
        <Chip label={option.label} {...getTagProps({ index })} />
      )
    );

    return (
      <FieldWrapper label={label} htmlFor={id}>
        <MuiAutocomplete
          ref={ref}
          id={id}
          disableCloseOnSelect={multiple}
          renderInput={(params) => (
            <EnhancedTextField
              {...params}
              size={size}
              sx={multiple && {
                '& .MuiInputBase-root': {
                  height: 'unset',
                  minHeight: 'unset',
                  maxHeight: 'unset'
                }
              }}
            />
          )}
          renderOption={multiple ? renderOption : undefined}
          renderValue={multiple ? renderValue : undefined}
          multiple={multiple}
          {...rest}
        />
      </FieldWrapper>
    );
  }
);

Autocomplete.displayName = 'Autocomplete';
