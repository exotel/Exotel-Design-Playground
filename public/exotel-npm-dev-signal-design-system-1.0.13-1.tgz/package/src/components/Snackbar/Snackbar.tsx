/**
 * Snackbar Component
 * 
 * Exotel-approved snackbar component that wraps MUI's Snackbar.
 */

import MuiSnackbar, { type SnackbarProps as MuiSnackbarProps } from '@mui/material/Snackbar';
import { forwardRef } from 'react';

export interface SnackbarProps extends Omit<MuiSnackbarProps, 'ref'> {
  children?: React.ReactNode;
}

export const Snackbar = forwardRef<HTMLDivElement, SnackbarProps>(
  (props, ref) => <MuiSnackbar ref={ref} {...props} />
);

Snackbar.displayName = 'Snackbar';
