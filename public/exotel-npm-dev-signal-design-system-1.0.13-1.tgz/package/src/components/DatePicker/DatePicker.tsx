/**
 * DatePicker Component
 *
 * Exotel-approved date picker component that wraps MUI X DatePicker.
 * Relies on the LocalizationProvider in ExotelThemeProvider.
 */

import { DatePicker as MuiDatePicker, type DatePickerProps as MuiDatePickerProps } from '@mui/x-date-pickers/DatePicker';
import { forwardRef, useMemo } from 'react';
import { FieldWrapper } from '../FieldLabel';

export interface DatePickerProps extends Omit<MuiDatePickerProps, 'ref'> {
  /** The size of the picker input. Matches EnhancedTextField sizes. */
  size?: 'small' | 'medium' | 'large';
}

export const DatePicker = forwardRef<HTMLDivElement, DatePickerProps>(
  (props, ref) => {
    const { label, size = 'medium', slotProps, ...rest } = props;

    const mergedSlotProps = useMemo(() => ({
      ...slotProps,
      textField: {
        size,
        ...(slotProps?.textField as object),
      },
    }), [size, slotProps]);

    return (
      <FieldWrapper label={label}>
        <MuiDatePicker ref={ref} slotProps={mergedSlotProps} {...rest} />
      </FieldWrapper>
    );
  }
);

DatePicker.displayName = 'DatePicker';
