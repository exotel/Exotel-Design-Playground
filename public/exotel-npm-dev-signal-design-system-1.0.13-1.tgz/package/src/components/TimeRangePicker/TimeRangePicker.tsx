/**
 * TimeRangePicker Component
 *
 * Exotel-approved time range picker component that wraps MUI X TimeRangePicker (pro).
 * Relies on the LocalizationProvider in ExotelThemeProvider.
 */

import { TimeRangePicker as MuiTimeRangePicker, type TimeRangePickerProps as MuiTimeRangePickerProps } from '@mui/x-date-pickers-pro/TimeRangePicker';
import { forwardRef, useMemo } from 'react';
import { FieldWrapper } from '../FieldLabel';

export interface TimeRangePickerProps extends Omit<MuiTimeRangePickerProps, 'ref'> {
  /** External label rendered above the picker. */
  label?: React.ReactNode;
  /** The size of the picker input. Matches EnhancedTextField sizes. */
  size?: 'small' | 'medium' | 'large';
}

export const TimeRangePicker = forwardRef<HTMLDivElement, TimeRangePickerProps>(
  (props, ref) => {
    const { label, size = 'medium', slotProps, ...rest } = props;

    const mergedSlotProps = useMemo(() => ({
      ...slotProps,
      textField: {
        size,
        ...(slotProps?.textField as object),
      },
    }), [size, slotProps]);

    return (
      <FieldWrapper label={label}>
        <MuiTimeRangePicker ref={ref} slotProps={mergedSlotProps as MuiTimeRangePickerProps['slotProps']} {...rest} />
      </FieldWrapper>
    );
  }
);

TimeRangePicker.displayName = 'TimeRangePicker';
