/**
 * DateTimePicker Component
 *
 * Exotel-approved date-time picker component that wraps MUI X DateTimePicker.
 * Relies on the LocalizationProvider in ExotelThemeProvider.
 */

import { DateTimePicker as MuiDateTimePicker, type DateTimePickerProps as MuiDateTimePickerProps } from '@mui/x-date-pickers/DateTimePicker';
import { forwardRef, useMemo } from 'react';
import { FieldWrapper } from '../FieldLabel';

export interface DateTimePickerProps extends Omit<MuiDateTimePickerProps, 'ref'> {
  /** The size of the picker input. Matches EnhancedTextField sizes. */
  size?: 'small' | 'medium' | 'large';
}

export const DateTimePicker = forwardRef<HTMLDivElement, DateTimePickerProps>(
  (props, ref) => {
    const { label, size = 'medium', slotProps, ...rest } = props;

    const mergedSlotProps = useMemo(() => ({
      ...slotProps,
      textField: {
        size,
        ...(slotProps?.textField as object),
      },
    }), [size, slotProps]);

    return (
      <FieldWrapper label={label}>
        <MuiDateTimePicker ref={ref} slotProps={mergedSlotProps} {...rest} />
      </FieldWrapper>
    );
  }
);

DateTimePicker.displayName = 'DateTimePicker';
