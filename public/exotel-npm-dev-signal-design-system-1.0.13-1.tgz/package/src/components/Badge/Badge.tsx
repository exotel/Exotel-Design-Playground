/**
 * Badge Component
 *
 * Exotel-approved badge component that wraps MUI's Badge.
 * Supports a custom `tonal` variant (Signal Design System): light tint background
 * with saturated foreground text, per Figma Badge component spec.
 */

import MuiBadge, { type BadgeProps as MuiBadgeProps } from '@mui/material/Badge';
import { alpha, type SxProps, type Theme } from '@mui/material/styles';
import { forwardRef } from 'react';

type PaletteColorName = 'primary' | 'secondary' | 'error' | 'info' | 'success' | 'warning';

function tonalBadgeSx(theme: Theme, color: MuiBadgeProps['color']): object {
  const isDark = theme.palette.mode === 'dark';
  const bgAlpha = isDark ? 0.16 : 0.12;

  const baseBadge = {
    fontWeight: theme.typography.fontWeightMedium,
    fontSize: '0.75rem',
    lineHeight: '20px',
  };

  if (!color || color === 'default') {
    return {
      '& .MuiBadge-badge': {
        ...baseBadge,
        backgroundColor: isDark ? theme.palette.grey[700] : theme.palette.grey[200],
        color: isDark ? theme.palette.grey[100] : theme.palette.grey[800],
      },
    };
  }

  const palette = theme.palette[color as PaletteColorName];
  return {
    '& .MuiBadge-badge': {
      ...baseBadge,
      backgroundColor: alpha(palette.main, bgAlpha),
      color: palette.main,
    },
  };
}

export interface BadgeProps extends Omit<MuiBadgeProps, 'ref' | 'variant'> {
  /**
   * MUI `standard` and `dot`, plus Exotel `tonal` (tinted surface + hue-matched label text).
   */
  variant?: 'standard' | 'dot' | 'tonal';
}

function mergeSx(
  tonal: boolean,
  badgeColor: MuiBadgeProps['color'],
  userSx: SxProps<Theme> | undefined,
): SxProps<Theme> {
  return (theme: Theme) => {
    const tonalStyles = tonal ? tonalBadgeSx(theme, badgeColor) : {};
    const resolved =
      typeof userSx === 'function' ? userSx(theme) : userSx;
    if (Array.isArray(resolved)) {
      return [tonalStyles, ...resolved];
    }
    return { ...tonalStyles, ...resolved };
  };
}

export const Badge = forwardRef<HTMLDivElement, BadgeProps>(
  ({ variant = 'standard', color = 'default', sx, ...props }, ref) => {
    const tonal = variant === 'tonal';
    const muiVariant = tonal ? 'standard' : variant;

    return (
      <MuiBadge
        ref={ref}
        variant={muiVariant}
        color={tonal ? 'default' : color}
        {...(tonal ? { 'data-variant': 'tonal' as const } : {})}
        {...props}
        sx={mergeSx(tonal, color, sx)}
      />
    );
  },
);

Badge.displayName = 'Badge';
