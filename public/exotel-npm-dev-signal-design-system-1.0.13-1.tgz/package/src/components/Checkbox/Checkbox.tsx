/**
 * Checkbox Component
 * 
 * Exotel-approved checkbox component that wraps MUI's Checkbox.
 * Provides consistent styling and behavior across Exotel applications.
 * 
 * Usage:
 * ```tsx
 * import { Checkbox } from '@exotel/design-system';
 * 
 * <Checkbox checked={isChecked} onChange={handleChange} />
 * ```
 */

import MuiCheckbox, { type CheckboxProps as MuiCheckboxProps } from '@mui/material/Checkbox';
import { forwardRef } from 'react';

/**
 * Checkbox component props
 * Re-exports MUI CheckboxProps while hiding MUI-specific naming
 */
export interface CheckboxProps extends Omit<MuiCheckboxProps, 'ref'> {
  /**
   * If true, the component is checked
   */
  checked?: boolean;
  /**
   * If true, the component is disabled
   */
  disabled?: boolean;
  /**
   * Callback fired when the state is changed
   */
  onChange?: (event: React.ChangeEvent<HTMLInputElement>, checked: boolean) => void;
}

/**
 * Checkbox component
 * 
 * Wraps MUI's Checkbox component with Exotel-specific defaults and styling.
 * All MUI Checkbox props are supported.
 */
export const Checkbox = forwardRef<HTMLButtonElement, CheckboxProps>(
  (props, ref) => {
    return <MuiCheckbox ref={ref} {...props} />;
  }
);

Checkbox.displayName = 'Checkbox';
