/**
 * Chip Component
 *
 * Exotel-approved chip component that wraps MUI's Chip.
 * Supports a custom `tonal` variant (Signal Design System): tinted background
 * with hue-matched label, icons, and delete control — aligned with Badge `tonal`.
 */

import MuiChip, { type ChipProps as MuiChipProps } from '@mui/material/Chip';
import { alpha, type SxProps, type Theme } from '@mui/material/styles';
import { forwardRef } from 'react';
import { Icon } from '../Icon';

type PaletteColorName = 'primary' | 'secondary' | 'error' | 'info' | 'success' | 'warning';

function tonalChipSx(theme: Theme, chipColor: MuiChipProps['color']): object {
  const isDark = theme.palette.mode === 'dark';
  const bgAlpha = isDark ? 0.16 : 0.12;

  if (!chipColor || chipColor === 'default') {
    const labelColor = isDark ? theme.palette.grey[100] : theme.palette.grey[800];
    const bg = isDark ? theme.palette.grey[700] : theme.palette.grey[200];
    return {
      backgroundColor: bg,
      color: labelColor,
      '& .MuiChip-icon': { color: labelColor },
      '& .MuiChip-deleteIcon': { color: labelColor },
    };
  }

  const palette = theme.palette[chipColor as PaletteColorName];
  const main = palette.main;
  return {
    backgroundColor: alpha(main, bgAlpha),
    color: main,
    '& .MuiChip-icon': { color: main },
    '& .MuiChip-deleteIcon': { color: main },
  };
}

function mergeChipSx(
  tonal: boolean,
  chipColor: MuiChipProps['color'],
  userSx: SxProps<Theme> | undefined,
): SxProps<Theme> | undefined {
  if (!tonal && userSx === undefined) {
    return undefined;
  }
  const sxFn = (theme: Theme) => {
    const tonalStyles = tonal ? tonalChipSx(theme, chipColor) : {};
    const resolved = typeof userSx === 'function' ? userSx(theme) : userSx;
    if (Array.isArray(resolved)) {
      return [tonalStyles, ...resolved] as SxProps<Theme>;
    }
    return { ...tonalStyles, ...resolved };
  };
  return sxFn as SxProps<Theme>;
}

export interface ChipProps extends Omit<MuiChipProps, 'ref' | 'variant'> {
  label?: React.ReactNode;
  /** Includes `tonal` (Signal DS); also augmented on `@mui/material/Chip`. */
  variant?: MuiChipProps['variant'] | 'tonal';
}

export const Chip = forwardRef<HTMLDivElement, ChipProps>(
  ({ variant = 'filled', color = 'default', sx, ...props }, ref) => {
    const tonal = variant === 'tonal';
    const muiVariant: MuiChipProps['variant'] = tonal ? 'filled' : variant;

    return (
      <MuiChip
        {...props}
        ref={ref}
        variant={muiVariant}
        color={tonal ? 'default' : color}
        {...(tonal ? { 'data-variant': 'tonal' as const } : {})}
        deleteIcon={<Icon name="x" size="xs" weight="bold" />}
        sx={mergeChipSx(tonal, color, sx)}
      />
    );
  },
);

Chip.displayName = 'Chip';
