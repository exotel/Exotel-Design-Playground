import { forwardRef } from 'react';
import Drawer from '@mui/material/Drawer';
import Box from '@mui/material/Box';
import { GridPanel, type GridPanelProps } from '@mui/x-data-grid/components/panel';
import { useDataGridCompactToolbar } from './DataGridCompactToolbarContext';

/**
 * Below 756px: preference panels (columns, filters) use a bottom `Drawer`.
 * At 756px and up: default MUI X `GridPanel` (popper).
 */
export const DataGridResponsivePanel = forwardRef<HTMLDivElement, GridPanelProps>(
  function DataGridResponsivePanel(props, ref) {
    const compactToolbar = useDataGridCompactToolbar();
    const { open, onClose, children, id } = props;

    if (compactToolbar) {
      return (
        <Drawer
          ref={ref}
          id={id}
          anchor="bottom"
          open={open}
          onClose={() => onClose?.()}
          slotProps={{
            backdrop: { sx: { backgroundColor: 'rgba(0, 0, 0, 0.5)' } },
          }}
          PaperProps={{
            sx: {
              maxHeight: '85vh',
              borderRadius: '16px 16px 0 0',
              overflow: 'hidden',
            },
          }}
        >
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              maxHeight: '85vh',
              overflow: 'auto',
              p: 1,
            }}
            onKeyDown={(e) => {
              if (e.key === 'Escape') onClose?.();
            }}
          >
            {children}
          </Box>
        </Drawer>
      );
    }

    return <GridPanel ref={ref} {...props} />;
  }
);

DataGridResponsivePanel.displayName = 'DataGridResponsivePanel';
