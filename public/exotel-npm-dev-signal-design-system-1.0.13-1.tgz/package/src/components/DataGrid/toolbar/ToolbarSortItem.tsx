import * as React from 'react';
import {
  useGridApiContext,
  useGridSelector,
  gridSortModelSelector,
  gridColumnDefinitionsSelector,
  type GridSortDirection,
  ToolbarButton
} from '@mui/x-data-grid-pro';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import ListItemIcon from '@mui/material/ListItemIcon';
import Typography from '@mui/material/Typography';
import Badge from '@mui/material/Badge';
import { useTheme } from '@mui/material/styles';
import Grid from '@mui/material/Grid';
import Popover from '@mui/material/Popover';
import Drawer from '@mui/material/Drawer';
import Tooltip from '@mui/material/Tooltip';
import { Icon } from '../../Icon';
import { EnhancedTextField } from '../../EnhancedTextField';
import { useDataGridCompactToolbar } from '../DataGridCompactToolbarContext';


export function ToolbarSortItem() {
  const compactToolbar = useDataGridCompactToolbar();
  const [open, setOpen] = React.useState(false);
  const [anchorEl, setAnchorEl] = React.useState<HTMLElement | null>(null);
  const apiRef = useGridApiContext();
  const fields = useGridSelector(apiRef, gridColumnDefinitionsSelector);
  const sortModel = useGridSelector(apiRef, gridSortModelSelector);
  const sortableFields = fields.filter((field) => field.sortable);
  const sortCount = sortModel.length;
  const theme = useTheme();
  const [searchText, setSearchText] = React.useState('');
  const [highlightedField, setHighlightedField] = React.useState<string | null>(
    null
  );

  const groupedFields = React.useMemo(() => {
    const groups: Record<string, typeof sortableFields> = {
      'Frequently Used': [],
      Others: []
    };
    const filteredFields = sortableFields.filter(field => 
        !searchText ||
        field.headerName?.toLowerCase().includes(searchText.toLowerCase()) ||
        field.field.toLowerCase().includes(searchText.toLowerCase()) ||
      (field as any).description?.toLowerCase().includes(searchText.toLowerCase())
    );

    filteredFields.forEach((field) => {
      const category = (field as any).category || '';

      if (category && category !== '') {
        if (!groups[category]) {
          groups[category] = [];
        }
        groups[category].push(field);
      } else {
        groups['Others'].push(field);
      }
    });
    return Object.fromEntries(
      Object.entries(groups).filter(([_, fields]) => fields.length > 0)
    );
  }, [sortableFields, searchText]);

  const handleSortChange = (field: string, sort: GridSortDirection) => {
    apiRef.current.sortColumn(field, sort, true);
  };

  const handleOpen = (event: React.MouseEvent<HTMLButtonElement>) => {
    setOpen(true);
    setAnchorEl(event.currentTarget);
    setSearchText('');
  };

  const handleClose = () => {
    setOpen(false);
    setAnchorEl(null);
    setHighlightedField(null);
  };

  const handleSearch = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchText(event.target.value);
  };

  const renderSortField = (field: any) => {
    const fieldIndexInSortModel = sortModel.findIndex(
      (sort) => sort.field === field.field,
    );
    const fieldInSortModel = sortModel[fieldIndexInSortModel];
    let nextSort: GridSortDirection = 'asc';

    if (fieldInSortModel) {
      nextSort = fieldInSortModel.sort === 'asc' ? 'desc' : null;
    }

    const isHighlighted = highlightedField === field.field;

    // TODO: i18n should be added
    const nextActionText = !fieldInSortModel
      ? 'Sort A-Z'
      : fieldInSortModel.sort === 'asc'
        ? 'Sort Z-A'
        : 'Remove Sort';

    return (
      <ListItem
        key={field.field}
        disablePadding
        onMouseEnter={() => setHighlightedField(field.field)}
        onMouseLeave={() => setHighlightedField(null)}
      >
        <ListItemButton
          onClick={() => handleSortChange(field.field, nextSort)}
          sx={{
            ...(fieldInSortModel && {
              bgcolor: 'custom.highlight',
              '&:hover': {
                bgcolor: 'custom.highlight'
              }
            })
          }}
        >
          <ListItemIcon sx={{ minWidth: 36 }}>
            {fieldInSortModel ? (
              <Badge
                badgeContent={sortCount > 1 ? fieldIndexInSortModel + 1 : null}
                color="primary"
                sx={{
                  '& .MuiBadge-badge': {
                    right: -5,
                    top: 3,
                    border: `2px solid ${theme.palette.background.paper}`,
                    padding: '0 4px',
                  },
                }}
              >
                {fieldInSortModel.sort === 'asc' ? (
                  <Icon size='sm' name="arrow-up" />
                ) : (
                  <Icon size='sm' name="arrow-down" />
                )}
              </Badge>
            ) : null}
          </ListItemIcon>
          <ListItemText
            primary={field.headerName || field.field}
            slotProps={{
              primary: {
                fontWeight: fieldInSortModel ? 600 : 500,
                variant: "body2"
              }
            }}
          />

          {isHighlighted && (
            <Typography
              variant="caption"
              color="text.secondary"
              sx={{
                px: 0.5,
                py: 0.25,
                borderRadius: 1.5,
                display: 'flex',
                alignItems: 'center',
                gap: 0.25,
                height: 20,
                ml: 0.5,
              }}
            >
              {!fieldInSortModel && <Icon size='xs' name="arrow-up" />}
              {fieldInSortModel?.sort === 'asc' && (
                <Icon size='xs' name="arrow-down" />
              )}
              {nextActionText}
            </Typography>
          )}
        </ListItemButton>
      </ListItem>
    );
  };

  const sortContent = (
    <Grid>
      <Grid sx={{ px: 1, py: 1, zIndex: 10 }}>
        <EnhancedTextField
          placeholder="Search"
          value={searchText}
          size="small"
          onChange={handleSearch}
          fullWidth
          slotProps={{
            input: {
              startAdornment: <Icon name="magnifying-glass" size="sm" />,
            },
          }}
        />
      </Grid>

      <Grid sx={{ px: 1 }}>
        {Object.keys(groupedFields).length === 0 && (
          <Typography
            variant="body2"
            align="center"
            sx={{ py: 2, color: 'text.secondary' }} // TODO: i18n should be added
          >
            No columns match search
          </Typography>
        )}
      </Grid>

      <List sx={{ pt: 0, width: '100%', px: 1 }}>
        {Object.entries(groupedFields).map(([category, fields]) => (
          <React.Fragment key={category || 'default'}>
            {fields.length > 0 && (
              <Typography
                variant="body2"
                sx={{
                  backgroundColor: 'surface.elevation0',
                  padding: '8px 16px',
                  borderRadius: '8px 8px 0 0'
                }}
              >
                {category}
              </Typography>
            )}
            {fields.map(renderSortField)}
          </React.Fragment>
        ))}
      </List>
    </Grid>
  );

  const sortPopover = (
    <Popover
      open={open}
      anchorEl={anchorEl}
      onClose={handleClose}
      anchorOrigin={{
        vertical: 'bottom',
        horizontal: 'right',
      }}
      transformOrigin={{
        vertical: 'top',
        horizontal: 'right',
      }}
      PaperProps={{
        sx: {
          minWidth: 300,
          maxWidth: '90vw',
          maxHeight: '80vh',
          borderRadius: '8px',
          overflow: 'hidden',
        }
      }}
    >
      <Grid sx={{ display: 'flex', flexDirection: 'column', maxHeight: '80vh' }}>
        <Grid sx={{ flexGrow: 1, overflow: 'auto', maxHeight: '70vh' }}>
          {sortContent}
        </Grid>
      </Grid>
    </Popover>
  );

  const sortBottomSheet = (
    <Drawer
      anchor="bottom"
      open={open}
      onClose={handleClose}
      PaperProps={{
        sx: {
          maxHeight: '85vh',
          borderRadius: '16px 16px 0 0',
          overflow: 'hidden',
        },
      }}
    >
      <Grid sx={{ display: 'flex', flexDirection: 'column', maxHeight: '85vh' }}>
        <Grid sx={{ flexGrow: 1, overflow: 'auto' }}>{sortContent}</Grid>
      </Grid>
    </Drawer>
  );

  return (
    <React.Fragment> 
      {/* TODO: i18n should be added */}
      <Tooltip title={sortCount > 0 ? `Sorted by ${sortCount} columns` : 'Sort data'}>
        <ToolbarButton
          onClick={handleOpen}
          size='small'
          className={`${sortCount > 0 ? 'Mui-active' : ''}`}
        >
          <Badge
            badgeContent={sortCount}
            color="primary"
            invisible={sortCount === 0}
            sx={{
              '& .MuiBadge-badge': {
                fontSize: 10,
                height: 16,
                minWidth: 16,
                padding: 0
              }
            }}
          >
            <Icon name="arrows-down-up" size="sm" />
          </Badge>
        </ToolbarButton>
      </Tooltip>
      {open && (compactToolbar ? sortBottomSheet : sortPopover)}
    </React.Fragment>
  );
}