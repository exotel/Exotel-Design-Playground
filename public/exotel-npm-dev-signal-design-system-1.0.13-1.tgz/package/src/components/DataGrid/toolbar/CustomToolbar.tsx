import {
  Toolbar,
  useGridApiContext,
  useGridSelector,
  type GridToolbarProps,
  gridRowSelectionIdsSelector,
  ColumnsPanelTrigger,
  type GridRowId,
} from '@mui/x-data-grid-pro';
import { memo, forwardRef } from 'react';
import Lottie from 'lottie-react';
import { Box } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import { AppliedFilters, type AppliedFilter } from '../../AppliedFilters';
import { Icon } from '../../Icon';
import refreshAnimationData from '../../../assets/icons8-refresh.json';
import { IconButton } from '../../IconButton';
import { Tooltip } from '../../Tooltip';
import { Button } from '../../Button';
import { ToolbarSortItem } from './ToolbarSortItem';
import { ToolbarFilterField } from './ToolbarFilterField';
import type {
  BulkDeleteConfig,
  FilterRecords,
  FilterValue,
  ToolbarButtonConfig,
  ToolbarFilterConfig,
} from '../types';

const RefreshButton = forwardRef<HTMLButtonElement, { onClick?: () => void; loading?: boolean }>(
  function RefreshButton({ onClick, loading, ...rest }, ref) {
    return (
      <IconButton
        ref={ref}
        onClick={onClick}
        size="small"
        aria-label="Refresh"
        sx={{
          '& path': {
            fill: 'currentColor !important',
            stroke: 'currentColor !important',
          }
        }}
        {...rest}
      >
        <Lottie
          className='lottie-refresh-icon'
          animationData={refreshAnimationData}
          loop={loading}
          autoplay={loading}
          style={{ width: 20, height: 20 }}
          key={loading ? 'loading' : 'idle'}
        />
      </IconButton>
    );
  }
);

export interface CustomToolbarProps extends Partial<GridToolbarProps> {
  customButtons?: ToolbarButtonConfig[];
  customFilters?: ToolbarFilterConfig[];
  appliedFilters?: AppliedFilter[];
  showAppliedFilters?: boolean;
  maxVisibleAppliedFilters?: number;
  bulkDeleteConfig?: BulkDeleteConfig;
  filterValues?: FilterRecords;
  hideSort?: boolean;
  onFilterValuesChange?: (id: string, value: FilterValue) => void;
  onClearAllFilters?: () => void;
  onRefresh?: () => void;
  loading?: boolean;
}

export const CustomToolbar = memo(function CustomToolbar({
  customButtons,
  customFilters,
  appliedFilters,
  showAppliedFilters = true,
  maxVisibleAppliedFilters = 4,
  bulkDeleteConfig,
  filterValues = {},
  hideSort = false,
  onFilterValuesChange,
  onClearAllFilters,
  onRefresh,
  loading,
}: CustomToolbarProps) {
  const apiRef = useGridApiContext();
  const rowSelectionIds = useGridSelector(apiRef, gridRowSelectionIdsSelector);
  const theme = useTheme();

  const selectedIds = Array.from(rowSelectionIds.keys());
  const selectedCount = selectedIds.length;
  const showBulkDelete = Boolean(bulkDeleteConfig) && selectedCount > 0;

  const handleChangeFilter = (value: FilterValue, filter: ToolbarFilterConfig) => {
    onFilterValuesChange?.(filter.id, value);
    filter?.onChange?.(value);
  };

  const handleFilterRemove = (filterId: string) => {
    const initialValue = customFilters?.find((f) => f.id === filterId)?.initialValue;
    onFilterValuesChange?.(filterId, initialValue);
  };

  return (
    <Toolbar>
      <Box display="flex" flexWrap="wrap-reverse" alignItems="center" gap={1} py={1.5}>
        <Box display="flex" alignItems="center" flexWrap="wrap" gap={1} sx={{ flex: '1 1 auto' }}>
          {showBulkDelete ? (
            <>
              <Button
                color="error"
                variant="text"
                size="small"
                startIconProps={{ name: 'trash' }}
                disabled={bulkDeleteConfig?.disabled}
                onClick={() => bulkDeleteConfig?.onDelete(selectedIds)}
              >
                {typeof bulkDeleteConfig?.label === 'function'
                  ? bulkDeleteConfig.label(selectedCount)
                  : bulkDeleteConfig?.label || `Delete ${selectedCount} Rows`}
              </Button>
              <Button
                variant="text"
                size="small"
                startIconProps={{ name: 'x', weight: 'bold', color: theme.vars?.palette.primary.main, size: 'sm' }}
                onClick={() => apiRef.current?.setRowSelectionModel({ type: 'include', ids: new Set<GridRowId>() })}
              >
                Discard
              </Button>
            </>
          ) : (
            <>
              {customFilters?.map((filter) => (
                <ToolbarFilterField
                  key={filter.id}
                  filter={filter}
                  filterValues={filterValues}
                  onFilterChange={handleChangeFilter}
                />
              ))}
            </>
          )}
        </Box>

        <Box display="flex" alignItems="center" gap={0.25} sx={{ flexShrink: 0 }}>
          {customButtons?.map((button) => {
            const ButtonComponent = (
              <IconButton
                key={button.id}
                onClick={button.onClick}
                disabled={button.disabled}
                color={button.color || 'default'}
                size="small"
                aria-label={button.label}
              >
                {button.icon}
              </IconButton>
            );

            return button.tooltip ? (
              <Tooltip key={button.id} title={button.tooltip}>
                {ButtonComponent}
              </Tooltip>
            ) : (
              ButtonComponent
            );
          })}

          {/* TODO: i18n should be added */}
          <Tooltip title="Refresh">
            <RefreshButton onClick={onRefresh} loading={loading} />
          </Tooltip>
          {/* TODO: i18n should be added */}
          <Tooltip title="Columns">
            <ColumnsPanelTrigger render={<IconButton size="small"><Icon name="layout" size="sm" /></IconButton>} />
          </Tooltip>
          {!hideSort && <ToolbarSortItem />}
        </Box>
      </Box>
      {appliedFilters && appliedFilters.length > 0 && showAppliedFilters && (
        <AppliedFilters
          filters={appliedFilters}
          onRemove={handleFilterRemove}
          onClearAll={onClearAllFilters ?? (() => { })}
          maxVisible={maxVisibleAppliedFilters}
          show={showAppliedFilters}
        />
      )}
    </Toolbar>
  );
});

CustomToolbar.displayName = 'CustomToolbar';
