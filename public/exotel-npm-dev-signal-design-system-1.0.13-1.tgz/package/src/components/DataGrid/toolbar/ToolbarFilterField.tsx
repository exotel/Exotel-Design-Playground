import { useState } from 'react';
import Drawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import { InputAdornment, MenuItem } from '@mui/material';
import { MultiSelect } from '../../MultiSelect';
import { EnhancedTextField } from '../../EnhancedTextField';
import { Icon } from '../../Icon';
import type { FilterRecords, FilterValue, ToolbarFilterConfig } from '../types';
import { DateRangeToolbarFilter } from './DateRangeToolbarFilter';
import { useDataGridCompactToolbar } from '../DataGridCompactToolbarContext';

export interface ToolbarFilterFieldProps {
  filter: ToolbarFilterConfig;
  filterValues: FilterRecords;
  onFilterChange: (value: FilterValue, filter: ToolbarFilterConfig) => void;
}

type CommonFieldProps = {
  disabled?: boolean;
  size: 'small';
  sx: { minWidth?: number | string };
};

/**
 * Select filter: same chip/select appearance; below 756px options open in a bottom Drawer,
 * otherwise the standard MUI Menu dropdown.
 */
function ToolbarSelectFilter({
  filter,
  filterValues,
  onFilterChange,
  commonProps,
  compactToolbar,
}: {
  filter: ToolbarFilterConfig;
  filterValues: FilterRecords;
  onFilterChange: (value: FilterValue, filter: ToolbarFilterConfig) => void;
  commonProps: CommonFieldProps;
  compactToolbar: boolean;
}) {
  const [drawerOpen, setDrawerOpen] = useState(false);

  if (compactToolbar) {
    return (
      <>
        <EnhancedTextField
          {...commonProps}
          id={filter.id}
          key={filter.id}
          showLabel={false}
          select
          value={filterValues[filter.id] ?? ''}
          slotProps={{
            select: {
              displayEmpty: true,
              renderValue: () => filter.label,
              open: false,
              SelectDisplayProps: {
                onMouseDown: (event: React.MouseEvent<HTMLDivElement>) => {
                  event.preventDefault();
                  if (!filter.disabled) {
                    setDrawerOpen(true);
                  }
                },
              },
            },
            input: {
              startAdornment: filter.iconName ? (
                <InputAdornment position="start">
                  <Icon name={filter.iconName} size="sm" />
                </InputAdornment>
              ) : undefined,
              sx: {
                '& .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'var(--mui-palette-Chip-defaultBorder)',
                },
                '& .MuiInputAdornment-root': {
                  marginRight: 'unset',
                },
              },
            },
          }}
          onChange={(e) => {
            onFilterChange(e.target.value, filter);
          }}
        >
          {filter.options?.map((option) => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </EnhancedTextField>
        <Drawer
          anchor="bottom"
          open={drawerOpen}
          onClose={() => setDrawerOpen(false)}
          PaperProps={{
            sx: {
              borderRadius: '16px 16px 0 0',
              maxHeight: '70vh',
            },
          }}
        >
          <List dense sx={{ py: 1, px: 2 }}>
            {filter.options?.map((option) => (
              <ListItemButton
                key={option.value}
                selected={(filterValues[filter.id] as string | undefined) === option.value}
                onClick={() => {
                  onFilterChange(option.value, filter);
                  setDrawerOpen(false);
                }}
              >
                <ListItemText primary={option.label} />
              </ListItemButton>
            ))}
          </List>
        </Drawer>
      </>
    );
  }

  return (
    <EnhancedTextField
      {...commonProps}
      id={filter.id}
      key={filter.id}
      showLabel={false}
      select
      value={filterValues[filter.id] ?? ''}
      slotProps={{
        select: {
          displayEmpty: true,
          renderValue: () => filter.label,
          MenuProps: {
            anchorOrigin: {
              vertical: 'bottom',
              horizontal: 'left',
            },
            transformOrigin: {
              vertical: 'top',
              horizontal: 'left',
            },
          },
        },
        input: {
          startAdornment: filter.iconName ? (
            <InputAdornment position="start">
              <Icon name={filter.iconName} size="sm" />
            </InputAdornment>
          ) : undefined,
          sx: {
            '& .MuiOutlinedInput-notchedOutline': {
              borderColor: 'var(--mui-palette-Chip-defaultBorder)',
            },
            '& .MuiInputAdornment-root': {
              marginRight: 'unset',
            },
          },
        },
      }}
      onChange={(e) => {
        onFilterChange(e.target.value, filter);
      }}
    >
      {filter.options?.map((option) => (
        <MenuItem key={option.value} value={option.value}>
          {option.label}
        </MenuItem>
      ))}
    </EnhancedTextField>
  );
}

export function ToolbarFilterField({ filter, filterValues, onFilterChange }: ToolbarFilterFieldProps) {
  const compactToolbar = useDataGridCompactToolbar();

  const commonProps = {
    disabled: filter.disabled,
    size: 'small' as const,
    sx: { minWidth: filter.width }
  };

  switch (filter.type) {
    case 'select':
      return (
        <ToolbarSelectFilter
          filter={filter}
          filterValues={filterValues}
          onFilterChange={onFilterChange}
          commonProps={commonProps}
          compactToolbar={compactToolbar}
        />
      );

    case 'multi-select':
      return (
        <MultiSelect
          key={filter.id}
          useBottomSheet={compactToolbar}
          label={filter.label}
          iconName={filter.iconName}
          options={filter.multiSelectOptions || []}
          value={(filterValues[filter.id] as string[]) ?? []}
          onChange={(values) => {
            onFilterChange(values, filter);
          }}
          placeholder={filter.placeholder}
          disabled={filter.disabled}
          width={filter.width}
          showSelectAll={filter.showSelectAll !== false}
          clearable={filter.clearable !== false}
          maxDisplayItems={filter.maxDisplayItems}
          showSelectedValuesInTrigger={false}
        />
      );

    case 'date-range':
      return (
        <DateRangeToolbarFilter
          key={filter.id}
          filter={filter}
          value={filterValues[filter.id]}
          onFilterChange={onFilterChange}
        />
      );

    default:
      return null;
  }
}
