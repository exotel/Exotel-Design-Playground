export const menuItemSx = {
  px: 2,
  py: 1,
  minHeight: 40,
  '&:hover': { bgcolor: 'action.hover' },
} as const;

export const avatarSizeMap = {
  small: 32,
  medium: 40,
  large: 48,
} as const;
