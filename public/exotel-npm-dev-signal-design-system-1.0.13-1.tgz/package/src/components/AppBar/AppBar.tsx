import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import MuiAppBar, { type AppBarProps as MuiAppBarProps } from '@mui/material/AppBar';
import { forwardRef } from 'react';
import { AppLauncher } from '../AppLauncher';
import type { AppLauncherProps } from '../AppLauncher/types';
import { AvatarMenu } from '../AvatarMenu';
import type { AvatarMenuProps } from '../AvatarMenu/types';
import { Icon } from '../Icon';
import { IconButton } from '../IconButton';

export interface AppBarProps extends Omit<MuiAppBarProps, 'ref'> {
  /** Props forwarded directly to the AppLauncher component */
  appLauncherProps: AppLauncherProps;
  /** Props forwarded directly to the AvatarMenu (user menu to the right of notifications) */
  avatarMenuProps: AvatarMenuProps;
  /**
   * Brand logo — either a URL string (renders as <img>) or a React node
   * (renders as-is, e.g. an inline <svg>).
   */
  brandLogo: string | React.ReactNode;
  /** Alt text used when brandLogo is a URL string. */
  brandLogoAlt?: string;
  /**
   * Style applied to the brand logo container
   */
  brandLogoStyle?: React.CSSProperties;
  /** Called when the notification bell is clicked. */
  onNotificationClick?: React.MouseEventHandler<HTMLButtonElement>;
}

export const AppBar = forwardRef<HTMLDivElement, AppBarProps>(
  (
    {
      appLauncherProps,
      avatarMenuProps,
      brandLogo,
      brandLogoAlt = 'Brand logo',
      brandLogoStyle,
      onNotificationClick,
      ...rest
    },
    ref,
  ) => {
    const logoNode =
      typeof brandLogo === 'string' ? (
        <Box
          component="img"
          src={brandLogo}
          alt={brandLogoAlt}
          sx={{ width: '96px', height: '24px', ...brandLogoStyle }}
        />
      ) : (
        brandLogo
      );

    return (
      <MuiAppBar
        ref={ref}
        position="static"
        sx={(theme) => ({
            backgroundColor: theme => `${theme.vars?.palette?.surface?.elevation1} !important`,
            backgroundImage: 'none',
            borderBottom: `1px solid ${theme.palette.divider}`,
        })}
        {...rest}
      >
        <Toolbar sx={{ padding: '0 10px' }}>
          {/* Left section: app launcher + brand logo */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, flexGrow: 1 }}>
            <AppLauncher {...appLauncherProps} />
            {logoNode}
          </Box>

          {/* Right section: notification + avatar menu */}
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
            <IconButton
              aria-label="Notifications"
              onClick={onNotificationClick}
              sx={{ color: 'text.secondary' }}
            >
              <Icon name="bell-ringing" size="md" color="currentColor" />
            </IconButton>
            <AvatarMenu {...avatarMenuProps} />
          </Box>
        </Toolbar>
      </MuiAppBar>
    );
  },
);

AppBar.displayName = 'AppBar';
