import { Divider } from "../../Divider";
import { List, ListSubheader } from "../../List";
import { useNavigationContext } from "../navigationContext";
// import { NavItem, type NavItemProps } from "./NavItem";
import { NavItem, type NavItemProps } from "./NavItem";

export interface NavSectionProps {
    label?: string;
    items: Omit<NavItemProps, 'level'>[];
    level?: number;
}

export const NavSection = ({
    level = 1,
    label,
    items,
}: NavSectionProps) => {
    const { sidebarExpanded } = useNavigationContext();

    if (level > 3) throw new Error('NavSection level cannot be greater than 3');

    const showSubheader = Boolean(label) && sidebarExpanded;

    return (
        <List
            sx={{
                marginLeft: (theme) => theme.spacing(level - 1),
            }}
            component="section"
            subheader={
                <>
                    <Divider
                        sx={{
                            'section:first-of-type > &': {
                                display: 'none',
                            },
                        }}
                    />
                    {showSubheader && (
                        <ListSubheader
                            disableSticky
                            sx={{
                                fontSize: 11,
                                fontWeight: 500,
                                lineHeight: 1.5,
                                color: 'text.secondary',
                                marginBlock: (theme) => theme.spacing(1.5),
                                padding: 0
                            }}
                        >
                            {label}
                        </ListSubheader>
                    )}
                </>
            }
        >
            {items.map((item) => (
                <NavItem level={level} key={item.id} {...item} />
            ))}
        </List>
    )
};
