import { Box } from "../../Box";
import { NavCustomise } from "./NavCustomise";


export const NavFooter = () => {

    return (
        <Box component="footer" sx={{ paddingTop: 1, paddingInline: '12px' }}>
            <NavCustomise />
        </Box>
    )
};
