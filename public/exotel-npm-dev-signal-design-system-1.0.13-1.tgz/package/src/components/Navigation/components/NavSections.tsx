import { Box } from "../../Box";
import { NavSection, type NavSectionProps } from "./NavSection";

export interface NavSectionsProps {
    sections: NavSectionProps[];
}

export const NavSections = ({
    sections,
}: NavSectionsProps) => {
    return (
        <Box sx={{ flex: 1, overflow: 'auto', marginTop: 0.5, paddingInline: '12px' }}>
            {sections.filter((section) => section.items?.length).map((section, index) => (
                <NavSection key={`${section.label ?? 'section'}-${index}`} {...section} level={1} />
            ))}
        </Box>
    )
}
