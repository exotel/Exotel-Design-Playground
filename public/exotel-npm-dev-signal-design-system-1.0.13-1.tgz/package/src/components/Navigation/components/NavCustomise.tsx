import { useEffect, useMemo, useState } from "react";
import { Icon } from "../../Icon"
import { type NavItemProps } from "./NavItem"
import { StructuredDialog } from "../../Dialog";
import { InputAdornment, useTheme } from "@mui/material";
import { EnhancedTextField as TextField } from "../../EnhancedTextField";
import { Checkbox } from "../../Checkbox";
import { Button } from "../../Button";
import { useNavigationContext } from "../navigationContext";
import { buildDisplayConfig, type DisplayConfig } from "../utils";
import { DragDropContext, Draggable, Droppable, type DropResult } from "@hello-pangea/dnd";
import MenuList from "@mui/material/MenuList";
import MenuItem from "@mui/material/MenuItem";
import { ListItemIcon, ListItemText, ListSubheader } from "../../List";
import { NavSection, type NavSectionProps } from "./NavSection";

interface FlattenedNavItem {
    id: string;
    label: string;
}

interface FlattenedSection {
    label?: string;
    items: FlattenedNavItem[];
}

export const NavCustomise = () => {
    const { sections, displayConfig, setDisplayConfig, setSections, pinnedItems } = useNavigationContext();
    const [isOpen, setIsOpen] = useState(false);
    const [search, setSearch] = useState('');
    const [draftConfig, setDraftConfig] = useState<DisplayConfig>({});
    const [draftSections, setDraftSections] = useState<NavSectionProps[]>([]);
    const [initialSections, setInitialSections] = useState<NavSectionProps[]>([]);

    const theme = useTheme();

    const handleClick = () => {
        setIsOpen(!isOpen);
    };

    useEffect(() => {
        if (isOpen) {
            setDraftConfig(displayConfig);
            setSearch('');
            setDraftSections(sections);
            setInitialSections(sections);
        }
    }, [isOpen, displayConfig, sections]);

    const flattenedSections = useMemo<FlattenedSection[]>(() => {
        const mapItems = (items: Omit<NavItemProps, 'level'>[]): FlattenedNavItem[] => {
            return items.map((item) => ({
                id: item.id,
                label: item.label,
            }));
        };
        return draftSections.map((section) => ({
            label: section.label,
            items: mapItems(section.items),
        }));
    }, [draftSections]);

    const filteredSections = useMemo(() => {
        const query = search.trim().toLowerCase();
        if (!query) {
            return flattenedSections;
        }
        return flattenedSections
            .map((section) => ({
                ...section,
                items: section.items.filter((item) => item.label.toLowerCase().includes(query)),
            }))
            .filter((section) => section.items.length > 0);
    }, [flattenedSections, search]);

    const handleToggle = (id: string) => {
        setDraftConfig((prev) => ({
            ...prev,
            [id]: prev[id] === false,
        }));
    };

    const handleReset = () => {
        setDraftConfig(buildDisplayConfig(initialSections));
        setDraftSections(initialSections);
    };

    const handleApply = () => {
        setDisplayConfig(draftConfig);
        setSections(draftSections);
        setIsOpen(false);
    };

    const handleCancel = () => {
        setIsOpen(false);
    };

    const handleDragEnd = (result: DropResult) => {
        const { destination, source } = result;
        if (!destination) {
            return;
        }
        if (destination.droppableId !== source.droppableId) {
            return;
        }
        if (destination.index === source.index) {
            return;
        }
        const sectionIndex = Number(source.droppableId.replace('section-', ''));
        if (Number.isNaN(sectionIndex)) {
            return;
        }
        setDraftSections((prev) => {
            const next = prev.map((section, index) =>
                index === sectionIndex ? { ...section, items: [...section.items] } : section
            );
            const items = next[sectionIndex]?.items;
            if (!items) {
                return prev;
            }
            const [moved] = items.splice(source.index, 1);
            items.splice(destination.index, 0, moved);
            next[sectionIndex] = { ...next[sectionIndex], items };
            return next;
        });
    };

    const renderList = () => (
        <DragDropContext onDragEnd={handleDragEnd}>
            {filteredSections.map((section, sectionIndex) => (
                <Droppable key={`${section.label ?? 'section'}-${sectionIndex}`} droppableId={`section-${sectionIndex}`}>
                    {(droppableProvided) => (
                        <MenuList
                            ref={droppableProvided.innerRef}
                            {...droppableProvided.droppableProps}
                            sx={{
                                marginTop: 0.5,
                                padding: 0
                            }}
                        >
                            {section.label && (
                                <ListSubheader
                                    disableSticky
                                    sx={{
                                        fontSize: 11,
                                        fontWeight: 500,
                                        lineHeight: 1.5,
                                        color: 'text.secondary',
                                        marginBlock: theme.spacing(2, 1),
                                        padding: 0
                                    }}
                                >
                                    {section.label}
                                </ListSubheader>
                            )}
                            {section.items.map((item, itemIndex) => {
                                const isChecked = draftConfig[item.id] !== false;
                                return (
                                    <Draggable
                                        key={item.id}
                                        draggableId={item.id}
                                        index={itemIndex}
                                        isDragDisabled={Boolean(search.trim())}
                                    >
                                        {(draggableProvided) => (
                                            <MenuItem
                                                ref={draggableProvided.innerRef}
                                                {...draggableProvided.draggableProps}
                                                style={draggableProvided.draggableProps.style}
                                            >
                                                {!Boolean(search) && (
                                                    <ListItemIcon {...draggableProvided.dragHandleProps}>
                                                        <Icon name="dots-six-vertical" size="sm" />
                                                    </ListItemIcon>
                                                )}
                                                <Checkbox
                                                    checked={isChecked}
                                                    size="small"
                                                    sx={{
                                                        padding: 0,
                                                        marginRight: '12px'
                                                    }}
                                                    onChange={() => handleToggle(item.id)}
                                                />
                                                <ListItemText
                                                    primary={item.label}
                                                />
                                            </MenuItem>
                                        )}
                                    </Draggable>
                                );
                            })}
                            {droppableProvided.placeholder}
                        </MenuList>
                    )}
                </Droppable>
            ))}
        </DragDropContext>
    )

    return (
        <>
            <NavSection
                level={1}
                items={[
                    ...pinnedItems,
                    {
                        id: 'customise-sidebar',
                        iconName: 'sliders-horizontal',
                        label: 'Customise Sidebar',
                        openNewPage: false,
                        showPin: false,
                        onClick: handleClick,
                    }
                ]}
            />
            <StructuredDialog
                open={isOpen}
                onClose={handleCancel}
                title="Customise Sidebar"
                showFooter
                footerContent={
                    <>
                        <Button variant="outlined" color="error" onClick={handleReset}>
                            Reset
                        </Button>
                        <Button variant="outlined" onClick={handleCancel}>
                            Cancel
                        </Button>
                        <Button variant="contained" onClick={handleApply}>
                            Apply
                        </Button>
                    </>
                }
            >
                <TextField
                    value={search}
                    size="small"
                    placeholder="Search"
                    onChange={(e) => setSearch(e.target.value)}
                    slotProps={{
                        input: {
                            startAdornment: (
                                <InputAdornment position="start">
                                    <Icon name="magnifying-glass" color="lightgrey" />
                                </InputAdornment>
                            ),
                        },
                    }}
                />
                {renderList()}
            </StructuredDialog>
        </>
    )
}
