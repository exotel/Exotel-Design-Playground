/**
 * Tabs Component
 * 
 * Exotel-approved tabs component that wraps MUI's Tabs.
 */

import MuiTabs, { type TabsProps as MuiTabsProps } from '@mui/material/Tabs';
import { forwardRef } from 'react';

export interface TabsProps extends Omit<MuiTabsProps, 'ref'> {
  children?: React.ReactNode;
  value?: string | number;
  onChange?: (event: React.SyntheticEvent, newValue: string | number) => void;
}

export const Tabs = forwardRef<HTMLDivElement, TabsProps>(
  (props, ref) => <MuiTabs ref={ref} {...props} />
);

Tabs.displayName = 'Tabs';
