/**
 * Icon Component
 * 
 * Exotel-approved icon component that wraps Phosphor Icons.
 * Provides a consistent, string-based API for using icons across Exotel applications.
 * 
 * Usage:
 * ```tsx
 * import { Icon } from '@exotel/design-system';
 * 
 * <Icon name="phone" />
 * <Icon name="warning" weight="bold" />
 * <Icon name="check-circle" size="sm" />
 * ```
 */

import { forwardRef } from 'react';
import type { IconProps as PhosphorIconProps, IconWeight } from 'phosphor-react';
import { iconRegistry, type IconName } from './iconRegistry';

/**
 * Icon size tokens
 */
export type IconSize = 'xs' | 'sm' | 'md' | 'lg';

/**
 * Icon weight options
 */
export type IconWeightOption = 'regular' | 'bold' | 'fill' | 'light';

/**
 * Size mapping from tokens to pixels
 */
const sizeMap: Record<IconSize, number> = {
  xs: 16,
  sm: 20,
  md: 24,
  lg: 32,
};

/**
 * Weight mapping from tokens to Phosphor weights
 */
const weightMap: Record<IconWeightOption, IconWeight> = {
  regular: 'regular',
  bold: 'bold',
  fill: 'fill',
  light: 'thin',
};

export interface IconProps extends Omit<PhosphorIconProps, 'size' | 'weight' | 'ref'> {
  /**
   * The name of the icon to display
   */
  name: IconName;
  /**
   * Size of the icon
   * @default 'md'
   */
  size?: IconSize | number;
  /**
   * Weight/style of the icon
   * @default 'regular'
   */
  weight?: IconWeightOption;
  /**
   * Color of the icon. Defaults to theme text color.
   */
  color?: string;
}

/**
 * Icon component
 * 
 * Renders Phosphor icons using a string-based name API.
 * All Phosphor icon props are supported via prop spreading.
 */
export const Icon = forwardRef<SVGSVGElement, IconProps>(
  ({ name, size = 'md', weight = 'regular', color, ...props }, ref) => {
    
    // Get the icon component from registry
    const IconComponent = iconRegistry[name];
    
    if (!IconComponent) {
      console.warn(`Icon "${name}" not found in registry. Available icons: ${Object.keys(iconRegistry).join(', ')}`);
      return null;
    }
    
    // Convert size token to number if needed
    const iconSize = typeof size === 'string' ? sizeMap[size] : size;
    
    // Special handling for circle-fill: always use fill weight
    // For other icons, convert weight token to Phosphor weight
    const iconWeight = weightMap[weight];
    
    // If no color is specified, use 'currentColor' to inherit from parent
    // This allows icons to inherit color from parent elements (e.g., IconButton)
    const iconColor = color ?? 'currentColor';
    
    return (
      <IconComponent
        ref={ref}
        size={iconSize}
        weight={iconWeight}
        color={iconColor}
        {...props}
      />
    );
  }
);

Icon.displayName = 'Icon';
