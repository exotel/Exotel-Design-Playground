/**
 * Icon Registry
 * 
 * Maps icon names (strings) to Phosphor icon components.
 * This registry is tree-shake friendly - unused icons won't be bundled.
 * 
 * To add a new icon:
 * 1. Import it from 'phosphor-react'
 * 2. Add it to the IconName type
 * 3. Add it to the iconMap object
 */

import {
  // Common icons
  Phone,
  Warning,
  CheckCircle,
  XCircle,
  Info,
  Question,
  House,
  // Navigation
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  ArrowDown,
  ArrowUpRight,
  CaretLeft,
  CaretRight,
  CaretUp,
  CaretDown,
  // Actions
  Trash,
  PencilSimple as Edit,
  Plus,
  Minus,
  X,
  Check,
  Download,
  Copy,
  Share,
  DotsThreeVertical as MoreVertical,
  // Communication
  Envelope,
  Envelope as Mail,
  Bell,
  Chat,
  Headset,
  PaperPlaneTilt as PaperPlane,
  Tray as Inbox,
  // UI
  List as Menu,
  List,
  MagnifyingGlass as Search,
  FunnelSimple as Filter,
  Calendar,
  Gear,
  Gear as Settings,
  ChartBar,
  Columns,
  ArrowsDownUp as Sort,
  ChartLine,
  Gauge,
  FileText,
  User,
  Lock,
  LockOpen as Unlock,
  Eye,
  EyeSlash,
  AddressBook,
  SquaresFour,
  // Status
  Circle,
  PushPin,
  PushPinSlash,
  ArrowSquareOut,
  SlidersHorizontal,
  DotsSixVertical,
  Layout,
  ArrowsClockwise,
  BellRinging,
  SignOut,
  // Note: CircleFill uses Circle with weight="fill"
  // Add more icons as needed
} from 'phosphor-react';

/**
 * Icon name type - all available icon names
 * Add new icon names here as you add them to the registry
 */
export type IconName =
  | 'phone'
  | 'warning'
  | 'check-circle'
  | 'x-circle'
  | 'info'
  | 'question'
  | 'house'
  | 'arrow-left'
  | 'arrow-right'
  | 'arrow-up'
  | 'arrow-down'
  | 'arrow-up-right'
  | 'chevron-left'
  | 'chevron-right'
  | 'chevron-up'
  | 'chevron-down'
  | 'trash'
  | 'edit'
  | 'plus'
  | 'minus'
  | 'x'
  | 'check'
  | 'download'
  | 'copy'
  | 'share'
  | 'more-vertical'
  | 'mail'
  | 'envelope'
  | 'bell'
  | 'chat'
  | 'headset'
  | 'paper-plane'
  | 'inbox'
  | 'menu'
  | 'list'
  | 'columns'
  | 'sort'
  | 'search'
  | 'filter'
  | 'calendar'
  | 'settings'
  | 'gear'
  | 'chart-bar'
  | 'chart-line'
  | 'gauge'
  | 'file-text'
  | 'user'
  | 'lock'
  | 'unlock'
  | 'eye'
  | 'eye-slash'
  | 'address-book'
  | 'squares-four'
  | 'circle'
  | 'circle-fill'
  | 'push-pin'
  | 'push-pin-slash'
  | 'arrow-square-out'
  | 'sliders-horizontal'
  | 'dots-six-vertical'
  | 'layout'
  | 'arrows-clockwise'
  | 'bell-ringing'
  | 'sign-out'
/**
 * Icon registry mapping
 * Maps string names to Phosphor icon components
 */
export const iconRegistry: Record<IconName, React.ComponentType<any>> = {
  'phone': Phone,
  'warning': Warning,
  'check-circle': CheckCircle,
  'x-circle': XCircle,
  'info': Info,
  'question': Question,
  'house': House,
  'arrow-left': ArrowLeft,
  'arrow-right': ArrowRight,
  'arrow-up': ArrowUp,
  'arrow-down': ArrowDown,
  'arrow-up-right': ArrowUpRight,
  'chevron-left': CaretLeft,
  'chevron-right': CaretRight,
  'chevron-up': CaretUp,
  'chevron-down': CaretDown,
  'trash': Trash,
  'edit': Edit,
  'plus': Plus,
  'minus': Minus,
  'x': X,
  'check': Check,
  'download': Download,
  'copy': Copy,
  'share': Share,
  'more-vertical': MoreVertical,
  'mail': Mail,
  'envelope': Envelope,
  'bell': Bell,
  'chat': Chat,
  'headset': Headset,
  'paper-plane': PaperPlane,
  'inbox': Inbox,
  'menu': Menu,
  'list': List,
  'columns': Columns,
  'sort': Sort,
  'search': Search,
  'filter': Filter,
  'calendar': Calendar,
  'settings': Settings,
  'gear': Gear,
  'chart-bar': ChartBar,
  'chart-line': ChartLine,
  'gauge': Gauge,
  'file-text': FileText,
  'user': User,
  'lock': Lock,
  'unlock': Unlock,
  'eye': Eye,
  'eye-slash': EyeSlash,
  'address-book': AddressBook,
  'squares-four': SquaresFour,
  'circle': Circle,
  'circle-fill': Circle, // Uses Circle with weight="fill"
  'push-pin': PushPin,
  'push-pin-slash': PushPinSlash,
  'arrow-square-out': ArrowSquareOut,
  'sliders-horizontal': SlidersHorizontal,
  'dots-six-vertical': DotsSixVertical,
  'layout': Layout,
  'arrows-clockwise': ArrowsClockwise,
  'bell-ringing': BellRinging,
  'sign-out': SignOut,
};

/** All icon names for use in Storybook controls and similar UIs */
export const ICON_NAMES = Object.keys(iconRegistry) as IconName[];
