/**
 * FieldWrapper Component
 *
 * Shared wrapper that renders an external label above any field component.
 * Used by EnhancedTextField, Autocomplete, and all date/time pickers.
 */

import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';

export interface FieldWrapperProps {
  /** The label content. When falsy the label row is omitted. */
  label?: React.ReactNode;
  /** Associates the label with an input via its id. */
  htmlFor?: string;
  /** The field component(s) rendered below the label. */
  children: React.ReactNode;
}

export function FieldWrapper({ label, htmlFor, children }: FieldWrapperProps) {
  return (
    <Stack spacing={0.5}>
      {label && (
        <Typography color="text.secondary" component="label" htmlFor={htmlFor} variant="body2">
          {label}
        </Typography>
      )}
      {children}
    </Stack>
  );
}
