/**
 * ThemeProvider Component Stories
 * 
 * Stories demonstrating the ExotelThemeProvider component.
 * Note: All stories are automatically wrapped with ExotelThemeProvider
 * via the preview decorator, but this story shows how to use it explicitly.
 */

import type { Meta, StoryObj } from '@storybook/react';
import { ExotelThemeProvider, Button, Card, useFont } from '../../components';
import type { FontKey } from '../../components';
import { FONT_OPTIONS } from '../../theme';
import { Typography, ToggleButtonGroup, ToggleButton, Box, Stack } from '@mui/material';

const meta: Meta<typeof ExotelThemeProvider> = {
  title: 'UI Components/ThemeProvider',
  component: ExotelThemeProvider,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component: 'ExotelThemeProvider automatically sets up MUI\'s ThemeProvider with the Exotel theme and includes CssBaseline. All stories are automatically wrapped with this provider.',
      },
    },
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof ExotelThemeProvider>;

/**
 * Theme provider in action
 * 
 * This demonstrates that the theme is applied correctly.
 * All components use the Exotel theme colors and styling.
 */
export const WithTheme: Story = {
  render: () => (
    <ExotelThemeProvider>
      <Card sx={{ padding: 3, minWidth: 400 }}>
        <Typography variant="h5" gutterBottom>
          Exotel Theme Applied
        </Typography>
        <Typography variant="body1" paragraph>
          This card and all components below are using the Exotel design system theme.
        </Typography>
        <div style={{ display: 'flex', gap: '8px', marginTop: '16px' }}>
          <Button variant="contained" color="primary">
            Primary
          </Button>
          <Button variant="contained" color="secondary">
            Secondary
          </Button>
          <Button variant="outlined" color="primary">
            Outlined
          </Button>
        </div>
      </Card>
    </ExotelThemeProvider>
  ),
};

/**
 * Theme colors demonstration
 * 
 * Shows all available theme colors from the Exotel design system.
 */
export const ThemeColors: Story = {
  render: () => (
    <ExotelThemeProvider>
      <Card sx={{ padding: 3, minWidth: 500 }}>
        <Typography variant="h5" gutterBottom>
          Theme Colors
        </Typography>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginTop: '16px' }}>
          <Button variant="contained" color="primary" fullWidth>
            Primary
          </Button>
          <Button variant="contained" color="secondary" fullWidth>
            Secondary
          </Button>
          <Button variant="contained" color="success" fullWidth>
            Success
          </Button>
          <Button variant="contained" color="error" fullWidth>
            Error
          </Button>
          <Button variant="contained" color="info" fullWidth>
            Info
          </Button>
          <Button variant="contained" color="warning" fullWidth>
            Warning
          </Button>
        </div>
      </Card>
    </ExotelThemeProvider>
  ),
};

// ---------------------------------------------------------------------------
// Font Switcher story — runtime font toggle
// ---------------------------------------------------------------------------

const sampleText =
  "The quick brown fox jumps over the lazy dog. 0123456789 !@#$%";

function FontSwitcherDemo() {
  const { fontKey, setFont } = useFont();
  const fontKeys = Object.keys(FONT_OPTIONS) as FontKey[];

  return (
    <Card sx={{ p: 3, minWidth: 560 }}>
      <Stack spacing={3}>
        <Box>
          <Typography variant="title2" gutterBottom mr={2}>
            Active font
          </Typography>
          <ToggleButtonGroup
            value={fontKey}
            exclusive
            onChange={(_e, value: FontKey | null) => {
              if (value) setFont(value);
            }}
            size="small"
          >
            {fontKeys.map((key) => (
              <ToggleButton key={key} value={key}>
                {FONT_OPTIONS[key].family}
              </ToggleButton>
            ))}
          </ToggleButtonGroup>
        </Box>

        <Box>
          <Typography variant="h4" gutterBottom>
            Heading 4
          </Typography>
          <Typography variant="h5" gutterBottom>
            Heading 5
          </Typography>
          <Typography variant="h6" gutterBottom>
            Heading 6
          </Typography>
          <Typography variant="body1" gutterBottom>
            Body 1 — {sampleText}
          </Typography>
          <Typography variant="body2" gutterBottom>
            Body 2 — {sampleText}
          </Typography>
          <Typography variant="caption" display="block" gutterBottom>
            Caption — {sampleText}
          </Typography>
        </Box>

        <Box sx={{ display: "flex", gap: 1 }}>
          <Button variant="contained">Contained</Button>
          <Button variant="outlined">Outlined</Button>
          <Button variant="text">Text</Button>
        </Box>
      </Stack>
    </Card>
  );
}

/**
 * Runtime font switching
 *
 * Toggle between **Noto Sans** and **IBM Plex Sans** at runtime.
 * The choice is persisted in `localStorage` and survives page refreshes.
 */
export const FontSwitcher: Story = {
  render: () => (
    <ExotelThemeProvider>
      <FontSwitcherDemo />
    </ExotelThemeProvider>
  ),
};
