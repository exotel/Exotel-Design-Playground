import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import dayjs, { type Dayjs } from 'dayjs';
import { DatePicker, type DatePickerProps } from '../../components';

const meta: Meta<typeof DatePicker> = {
  title: 'Date & Time Pickers/DatePicker',
  component: DatePicker,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          "Exotel-approved date picker that wraps MUI X DatePicker. Includes a built-in LocalizationProvider with dayjs so consumers don't need to add one.",
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
      description: 'The size of the picker input',
      table: {
        type: { summary: "'small' | 'medium' | 'large'" },
        defaultValue: { summary: "'medium'" },
      },
    },
    label: {
      control: 'text',
      description: 'External label rendered above the picker',
      table: { type: { summary: 'ReactNode' } },
    },
    disabled: {
      control: 'boolean',
      description: 'If true, the picker is disabled',
      table: { type: { summary: 'boolean' }, defaultValue: { summary: 'false' } },
    },
    readOnly: {
      control: 'boolean',
      description: 'If true, the picker is read-only',
      table: { type: { summary: 'boolean' }, defaultValue: { summary: 'false' } },
    },
    disableFuture: {
      control: 'boolean',
      description: 'If true, future dates are disabled',
      table: { type: { summary: 'boolean' }, defaultValue: { summary: 'false' } },
    },
    disablePast: {
      control: 'boolean',
      description: 'If true, past dates are disabled',
      table: { type: { summary: 'boolean' }, defaultValue: { summary: 'false' } },
    },
  },
};

export default meta;
type Story = StoryObj<typeof DatePicker>;

/**
 * Basic date picker with a label.
 */
export const Basic: Story = {
  render: () => <DatePicker label="Select date" />,
};

/**
 * All three sizes — small (32px), medium (40px), and large (50px) — matching EnhancedTextField.
 */
export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16, width: 300 }}>
      <DatePicker label="Small" size="small" />
      <DatePicker label="Medium" size="medium" />
      <DatePicker label="Large" size="large" />
    </div>
  ),
};

/**
 * Controlled date picker with React state.
 */
export const Controlled: Story = {
  render: () => {
    const [value, setValue] = useState<Dayjs | null>(dayjs());
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16, width: 300 }}>
        <DatePicker label="Date" value={value} onChange={(newValue) => setValue(newValue)} />
        <div style={{ fontSize: 14, color: '#666' }}>
          Selected: {value ? value.format('MMMM D, YYYY') : 'None'}
        </div>
      </div>
    );
  },
};

/**
 * Without an external label.
 */
export const WithoutLabel: Story = {
  render: () => <DatePicker />,
};

/**
 * Date picker in disabled state.
 */
export const Disabled: Story = {
  render: () => <DatePicker label="Disabled" disabled defaultValue={dayjs()} />,
};

/**
 * Read-only date picker.
 */
export const ReadOnly: Story = {
  render: () => <DatePicker label="Read only" readOnly defaultValue={dayjs()} />,
};

/**
 * Only future dates are selectable.
 */
export const DisablePast: Story = {
  render: () => <DatePicker label="Future dates only" disablePast />,
};

/**
 * Only past dates are selectable.
 */
export const DisableFuture: Story = {
  render: () => <DatePicker label="Past dates only" disableFuture />,
};

/**
 * Custom date range using minDate and maxDate.
 */
export const MinMaxDate: Story = {
  render: () => (
    <DatePicker
      label="This month only"
      minDate={dayjs().startOf('month')}
      maxDate={dayjs().endOf('month')}
    />
  ),
};

/**
 * Month and year views only (no day picker).
 */
export const MonthYearOnly: Story = {
  render: () => (
    <DatePicker label="Select month" views={['month', 'year']} openTo="month" />
  ),
};

/**
 * Year picker only.
 */
export const YearOnly: Story = {
  render: () => <DatePicker label="Select year" views={['year']} openTo="year" />,
};

/**
 * Custom format display.
 */
export const CustomFormat: Story = {
  render: () => <DatePicker label="DD/MM/YYYY format" format="DD/MM/YYYY" />,
};

/**
 * Default action bar with Clear, Cancel, Today, and Accept actions.
 */
export const ActionBar: Story = {
  render: () => (
    <DatePicker
      label="With action bar"
      slotProps={{
        actionBar: {
          actions: ['clear', 'cancel', 'today', 'accept'],
        },
      }}
    />
  ),
};


/**
 * Interactive playground with all controls.
 */
export const Interactive: Story = {
  args: {
    label: 'Pick a date',
    size: 'medium',
    disabled: false,
    readOnly: false,
    disableFuture: false,
    disablePast: false,
  },
  render: (args: DatePickerProps) => <DatePicker {...args} />,
};
