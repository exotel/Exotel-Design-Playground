/**
 * Checkbox Component Stories
 * 
 * Stories for the Exotel Checkbox component that wraps MUI's Checkbox.
 */

import type { Meta, StoryObj } from '@storybook/react';
import { Checkbox } from '../../components';
import { FormControlLabel, FormGroup } from '@mui/material';
import { useState } from 'react';

const meta: Meta<typeof Checkbox> = {
  title: 'UI Components/Checkbox',
  component: Checkbox,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component: 'Exotel-approved checkbox component that wraps MUI\'s Checkbox. Provides consistent styling and behavior across Exotel applications.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    color: {
      control: 'select',
      options: ['default', 'primary', 'secondary', 'error', 'info', 'success', 'warning'],
      description: 'The color of the component',
      table: {
        type: { summary: "'default' | 'primary' | 'secondary' | 'error' | 'info' | 'success' | 'warning'" },
        defaultValue: { summary: "'primary'" },
      },
    },
    size: {
      control: 'select',
      options: ['small', 'medium'],
      description: 'The size of the component',
      table: {
        type: { summary: "'small' | 'medium'" },
        defaultValue: { summary: "'medium'" },
      },
    },
    disabled: {
      control: 'boolean',
      description: 'If true, the component is disabled',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    indeterminate: {
      control: 'boolean',
      description: 'If true, the component appears indeterminate',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    checked: {
      control: 'boolean',
      description: 'If true, the component is checked',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Checkbox>;

/**
 * Basic checkbox
 */
export const Basic: Story = {
  render: () => {
    const [checked, setChecked] = useState(false);
    return (
      <Checkbox
        checked={checked}
        onChange={(e) => setChecked(e.target.checked)}
      />
    );
  },
};

/**
 * Checked state
 */
export const Checked: Story = {
  args: {
    checked: true,
  },
};

/**
 * Unchecked state
 */
export const Unchecked: Story = {
  args: {
    checked: false,
  },
};

/**
 * Different colors
 */
export const Colors: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
      <Checkbox defaultChecked color="default" />
      <Checkbox defaultChecked color="primary" />
      <Checkbox defaultChecked color="secondary" />
      <Checkbox defaultChecked color="success" />
      <Checkbox defaultChecked color="error" />
      <Checkbox defaultChecked color="info" />
      <Checkbox defaultChecked color="warning" />
    </div>
  ),
};

/**
 * Different sizes
 */
export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
      <Checkbox defaultChecked size="small" />
      <Checkbox defaultChecked size="medium" />
    </div>
  ),
};

/**
 * Disabled state
 */
export const Disabled: Story = {
  render: () => (
    <FormGroup>
      <FormControlLabel disabled control={<Checkbox />} label="Unchecked" />
      <FormControlLabel disabled control={<Checkbox defaultChecked />} label="Checked" />
      <FormControlLabel disabled control={<Checkbox indeterminate />} label="Indeterminate" />
    </FormGroup>
  ),
};

/**
 * Indeterminate state
 */
export const Indeterminate: Story = {
  args: {
    indeterminate: true,
  },
};

/**
 * With label using FormControlLabel
 */
export const WithLabel: Story = {
  args: {
    size: 'medium',
  },
  render: (args) => (
    <FormGroup>
      <FormControlLabel control={<Checkbox defaultChecked size={args.size} />} label="Accept terms and conditions" />
      <FormControlLabel required control={<Checkbox size={args.size} />} label="Required" />
      <FormControlLabel disabled control={<Checkbox size={args.size} />} label="Disabled" />
    </FormGroup>
  ),
};

/**
 * Interactive checkbox with all controls
 */
export const Interactive: Story = {
  args: {
    checked: false,
    color: 'primary',
    size: 'medium',
    disabled: false,
    indeterminate: false,
  },
  render: (args) => {
    const [checked, setChecked] = useState(args.checked);
    return (
      <Checkbox
        {...args}
        checked={checked}
        onChange={(e) => setChecked(e.target.checked)}
      />
    );
  },
};
