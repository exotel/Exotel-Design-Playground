import type { Meta, StoryObj } from '@storybook/react';
import React from 'react';
import { Alert, IconButton, Icon } from '../../components';

const meta: Meta<typeof Alert> = {
  title: 'UI Components/Alert',
  component: Alert,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component: 'Exotel-approved alert component that wraps MUI\'s Alert. Used to display important messages to users.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    severity: {
      control: 'select',
      options: ['error', 'warning', 'info', 'success'],
      description: 'The severity of the alert',
      table: {
        type: { summary: "'error' | 'warning' | 'info' | 'success'" },
        defaultValue: { summary: "'success'" },
      },
    },
    variant: {
      control: 'select',
      options: ['standard', 'filled', 'outlined'],
      description: 'The variant to use',
      table: {
        type: { summary: "'standard' | 'filled' | 'outlined'" },
        defaultValue: { summary: "'standard'" },
      },
    },
    onClose: {
      action: 'closed',
      description: 'Callback fired when the component requests to be closed',
      table: {
        type: { summary: 'function' },
      },
    },
    children: {
      control: 'text',
      description: 'The content of the alert',
    },
  },
};

export default meta;
type Story = StoryObj<typeof Alert>;

/**
 * Success alert
 */
export const Success: Story = {
  args: {
    severity: 'success',
    children: 'This is a success alert!',
  },
};

/**
 * Error alert
 */
export const Error: Story = {
  args: {
    severity: 'error',
    children: 'This is an error alert!',
  },
};

/**
 * Warning alert
 */
export const Warning: Story = {
  args: {
    severity: 'warning',
    children: 'This is a warning alert!',
  },
};

/**
 * Info alert
 */
export const Info: Story = {
  args: {
    severity: 'info',
    children: 'This is an info alert!',
  },
};

/**
 * Different variants
 */
export const Variants: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', width: '400px' }}>
      <Alert severity="success" variant="standard">Standard variant</Alert>
      <Alert severity="success" variant="filled">Filled variant</Alert>
      <Alert severity="success" variant="outlined">Outlined variant</Alert>
    </div>
  ),
};

/**
 * Dismissible alert
 */
export const Dismissible: Story = {
  render: () => {
    const [open, setOpen] = React.useState(true);
    if (!open) return <button onClick={() => setOpen(true)}>Show Alert</button>;
    return (
      <Alert severity="info" onClose={() => setOpen(false)}>
        This alert can be dismissed
      </Alert>
    );
  },
};

/**
 * Alert with action
 */
export const WithAction: Story = {
  render: () => (
    <Alert
      severity="warning"
      action={
        <IconButton size="small" onClick={() => {}}>
          <Icon name="x" size="sm" />
        </IconButton>
      }
    >
      This alert has a custom action button
    </Alert>
  ),
};

/**
 * Interactive alert with all controls
 */
export const Interactive: Story = {
  args: {
    severity: 'success',
    variant: 'standard',
    children: 'This is an alert message',
  },
};
