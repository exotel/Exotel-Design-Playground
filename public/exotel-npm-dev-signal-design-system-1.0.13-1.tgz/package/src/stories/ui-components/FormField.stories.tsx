/**
 * FormField Component Stories
 * 
 * Stories for the Exotel FormField component with external labels.
 */

import type { Meta, StoryObj } from '@storybook/react';
import { FormField, Icon } from '../../components';
import { EnhancedTextField as TextField} from '../../components';
import { Box } from '@mui/material';

const meta: Meta<typeof FormField> = {
  title: 'UI Components/FormField',
  component: FormField,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'Exotel form field component with external labels. Replaces floating label pattern with stable, external label positioning. Supports three sizes: small (32px), medium (40px), and large (44px).',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
      description: 'The size of the input. Large: 44px height. Medium: 40px height. Small: 32px height.',
      table: {
        type: { summary: "'small' | 'medium' | 'large'" },
        defaultValue: { summary: "'medium'" },
      },
    },
    disabled: {
      control: 'boolean',
      description: 'If true, the component is disabled',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    required: {
      control: 'boolean',
      description: 'If true, the label is displayed as required',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    error: {
      control: 'boolean',
      description: 'If true, the field is displayed in an error state',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    fullWidth: {
      control: 'boolean',
      description: 'If true, the input will take the full width of its container',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof FormField>;

/**
 * Basic FormField
 */
export const Basic: Story = {
  args: {
    label: 'Email',
    placeholder: 'Enter your email',
  },
};

/**
 * All three sizes
 */
export const Sizes: Story = {
  render: () => (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3, width: 300 }}>
      <FormField label="Small" size="small" placeholder="Small input" />
      <FormField label="Medium" size="medium" placeholder="Medium input" />
      <FormField label="Large" size="large" placeholder="Large input" />
    </Box>
  ),
};

/**
 * With helper text
 */
export const WithHelperText: Story = {
  args: {
    label: 'Email',
    placeholder: 'Enter your email',
    helperText: "We'll never share your email",
  },
};

/**
 * Required field
 */
export const Required: Story = {
  args: {
    label: 'Email',
    placeholder: 'Enter your email',
    required: true,
    helperText: 'This field is required',
  },
};

/**
 * Error state
 */
export const Error: Story = {
  args: {
    label: 'Email',
    placeholder: 'Enter your email',
    error: true,
    helperText: 'Please enter a valid email address',
    defaultValue: 'invalid-email',
  },
};

/**
 * Disabled state
 */
export const Disabled: Story = {
  args: {
    label: 'Email',
    placeholder: 'Enter your email',
    disabled: true,
    defaultValue: 'disabled@example.com',
  },
};

/**
 * Number input
 */
export const NumberInput: Story = {
  args: {
    label: 'Quantity',
    type: 'number',
    defaultValue: '0',
    inputProps: { min: 0, max: 100 },
    helperText: 'Enter a number between 0 and 100',
  },
};

/**
 * Search input
 */
export const SearchInput: Story = {
  render: () => (
    <Box sx={{ width: 300 }}>
      <FormField
        label="Search"
        type="search"
        placeholder="Search..."
        startAdornment={<Icon name="search" size="sm" style={{ color: 'inherit' }} />}
      />
    </Box>
  ),
};

/**
 * Password input
 */
export const PasswordInput: Story = {
  args: {
    label: 'Password',
    type: 'password',
    placeholder: 'Enter your password',
    helperText: 'Must be at least 8 characters',
  },
};

/**
 * With start adornment
 */
export const WithStartAdornment: Story = {
  render: () => (
    <Box sx={{ width: 300 }}>
      <FormField
        label="Amount"
        placeholder="0.00"
        startAdornment="$"
      />
    </Box>
  ),
};

/**
 * With end adornment
 */
export const WithEndAdornment: Story = {
  render: () => (
    <Box sx={{ width: 300 }}>
      <FormField
        label="Weight"
        placeholder="0"
        endAdornment="kg"
      />
    </Box>
  ),
};

/**
 * All states together
 */
export const AllStates: Story = {
  render: () => (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3, width: 300 }}>
      <FormField label="Normal" placeholder="Enter text" />
      <FormField label="With Value" defaultValue="Some text" />
      <FormField label="Error" error helperText="Error message" />
      <FormField label="Disabled" disabled defaultValue="Disabled value" />
      <FormField label="Required" required helperText="This field is required" />
      <FormField label="With Helper" helperText="Helper text" />
    </Box>
  ),
};

/**
 * Comparison: FormField vs TextField
 */
export const Comparison: Story = {
  render: () => (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 4, width: 300 }}>
      <Box>
        <Box sx={{ mb: 2, fontWeight: 500 }}>FormField (External Label)</Box>
        <FormField
          label="Email"
          placeholder="Enter your email"
          helperText="External label pattern"
        />
      </Box>
      <Box>
        <Box sx={{ mb: 2, fontWeight: 500 }}>TextField (Floating Label)</Box>
        <TextField
          label="Email"
          placeholder="Enter your email"
          helperText="Floating label pattern"
        />
      </Box>
    </Box>
  ),
};
