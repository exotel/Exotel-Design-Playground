import type { Meta, StoryObj } from '@storybook/react';
import { Stack, Paper, Button } from '../../components';

const meta: Meta<typeof Stack> = {
  title: 'UI Components/Stack',
  component: Stack,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component: 'Exotel-approved stack component that wraps MUI\'s Stack. Provides a flexible container for arranging items vertically or horizontally.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    direction: {
      control: 'select',
      options: ['row', 'row-reverse', 'column', 'column-reverse'],
      description: 'Defines the flex-direction style property',
      table: {
        type: { summary: "'row' | 'row-reverse' | 'column' | 'column-reverse'" },
        defaultValue: { summary: "'column'" },
      },
    },
    spacing: {
      control: { type: 'number', min: 0, max: 10, step: 1 },
      description: 'Defines the space between immediate children',
      table: {
        type: { summary: 'number' },
        defaultValue: { summary: '0' },
      },
    },
    alignItems: {
      control: 'select',
      options: ['stretch', 'center', 'flex-start', 'flex-end', 'baseline'],
      description: 'Defines the align-items style property',
      table: {
        type: { summary: "'stretch' | 'center' | 'flex-start' | 'flex-end' | 'baseline'" },
        defaultValue: { summary: "'stretch'" },
      },
    },
    justifyContent: {
      control: 'select',
      options: ['flex-start', 'center', 'flex-end', 'space-between', 'space-around', 'space-evenly'],
      description: 'Defines the justify-content style property',
      table: {
        type: { summary: "'flex-start' | 'center' | 'flex-end' | 'space-between' | 'space-around' | 'space-evenly'" },
        defaultValue: { summary: "'flex-start'" },
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Stack>;

/**
 * Basic vertical stack
 */
export const Basic: Story = {
  render: () => (
    <Stack spacing={2}>
      <Paper sx={{ p: 2 }}>Item 1</Paper>
      <Paper sx={{ p: 2 }}>Item 2</Paper>
      <Paper sx={{ p: 2 }}>Item 3</Paper>
    </Stack>
  ),
};

/**
 * Horizontal stack
 */
export const Horizontal: Story = {
  render: () => (
    <Stack direction="row" spacing={2}>
      <Button variant="contained">Button 1</Button>
      <Button variant="contained">Button 2</Button>
      <Button variant="contained">Button 3</Button>
    </Stack>
  ),
};

/**
 * Different spacing
 */
export const Spacing: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {[0, 1, 2, 4].map((spacing) => (
        <div key={spacing}>
          <div style={{ marginBottom: '8px', fontSize: '12px' }}>Spacing: {spacing}</div>
          <Stack direction="row" spacing={spacing}>
            <Paper sx={{ p: 2 }}>Item 1</Paper>
            <Paper sx={{ p: 2 }}>Item 2</Paper>
            <Paper sx={{ p: 2 }}>Item 3</Paper>
          </Stack>
        </div>
      ))}
    </div>
  ),
};

/**
 * Alignment options
 */
export const Alignment: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      <div>
        <div style={{ marginBottom: '8px', fontSize: '12px' }}>alignItems: center</div>
        <Stack direction="row" spacing={2} alignItems="center" sx={{ height: 100, border: '1px dashed #ccc' }}>
          <Paper sx={{ p: 2, height: 40 }}>Item 1</Paper>
          <Paper sx={{ p: 2, height: 60 }}>Item 2</Paper>
          <Paper sx={{ p: 2, height: 80 }}>Item 3</Paper>
        </Stack>
      </div>
      <div>
        <div style={{ marginBottom: '8px', fontSize: '12px' }}>justifyContent: space-between</div>
        <Stack direction="row" spacing={2} justifyContent="space-between" sx={{ width: 400, border: '1px dashed #ccc', p: 1 }}>
          <Button variant="contained">Button 1</Button>
          <Button variant="contained">Button 2</Button>
          <Button variant="contained">Button 3</Button>
        </Stack>
      </div>
    </div>
  ),
};

/**
 * Interactive stack with all controls
 */
export const Interactive: Story = {
  args: {
    direction: 'column',
    spacing: 2,
    alignItems: 'stretch',
    justifyContent: 'flex-start',
  },
  render: (args) => (
    <Stack {...args} sx={{ minWidth: 300 }}>
      <Paper sx={{ p: 2 }}>Item 1</Paper>
      <Paper sx={{ p: 2 }}>Item 2</Paper>
      <Paper sx={{ p: 2 }}>Item 3</Paper>
    </Stack>
  ),
};
