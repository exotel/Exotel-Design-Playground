import type { Meta, StoryObj } from '@storybook/react-vite';
import { Markdown } from '@storybook/addon-docs/blocks';
import content from '../../../docs/MIGRATIONS.md?raw';

const meta: Meta = {
  title: 'Documentation/Migration Guide',
  tags: ['autodocs'],
  parameters: {
    docs: {
      page: () => <Markdown>{content}</Markdown>,
    },
  },
};

export default meta;

export const Guide: StoryObj = {
  tags: ['!dev', '!test'],
  render: () => <div />,
};
