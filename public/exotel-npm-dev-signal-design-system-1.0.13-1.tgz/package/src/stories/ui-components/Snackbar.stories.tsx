import type { Meta, StoryObj } from '@storybook/react';
import { Snackbar, Alert } from '../../components';
import { useState } from 'react';

const meta: Meta<typeof Snackbar> = {
  title: 'UI Components/Snackbar',
  component: Snackbar,
  parameters: { layout: 'centered' },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof Snackbar>;

export const Basic: Story = {
  render: () => {
    const [open, setOpen] = useState(true);
    return (
      <Snackbar open={open} autoHideDuration={6000} onClose={() => setOpen(false)}>
        <Alert severity="success" onClose={() => setOpen(false)}>
          This is a success message!
        </Alert>
      </Snackbar>
    );
  },
};
