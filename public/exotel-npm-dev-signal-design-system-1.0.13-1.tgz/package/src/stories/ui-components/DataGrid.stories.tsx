/**
 * DataGrid Component Stories
 */

import type { Meta, StoryObj } from '@storybook/react';
import { DataGrid, type DataGridColDef, type ToolbarButtonConfig, type ToolbarFilterConfig, type DateRangeValue, type FilterRecords } from '../../components/DataGrid';
import type { MultiSelectOption } from '../../components/MultiSelect';
import { Icon } from '../../components/Icon';
import { IconButton } from '../../components/IconButton';
import { Tooltip } from '../../components/Tooltip';
import type { GridListViewColDef, GridRenderCellParams, GridRowsProp } from '@mui/x-data-grid';
import { useMediaQuery } from '@mui/material';
import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { Stack, Typography } from '../../components';
import type { GridSortModel } from '@mui/x-data-grid-pro';
import dayjs from 'dayjs';

const meta: Meta<typeof DataGrid> = {
  title: 'UI Components/DataGrid',
  component: DataGrid,
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component: `
### DataGrid

A thin abstraction layer over MUI X DataGridPro that provides a consistent API while preserving full access to the underlying component's capabilities.

**Responsive toolbar (below 756px width):** filter selects, multi-select, date range, **Manage columns**, and **Sort** use **bottom drawers**; at **756px and wider** they use standard dropdowns/popovers.

**API Documentation:**
For the complete list of available props, refer to the [MUI DataGridPro API](https://mui.com/x/api/data-grid/data-grid-pro/)
        `,
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    customToolbarFilters: {
      control: 'object',
      table: { type: { summary: 'ToolbarFilterConfig[]' }, category: 'Wrapper-Specific Props' },
    },
    showAppliedFilters: {
      control: 'boolean',
      table: { type: { summary: 'boolean' }, category: 'Wrapper-Specific Props' },
    },
    maxVisibleAppliedFilters: {
      control: 'number',
      table: { type: { summary: 'number' }, category: 'Wrapper-Specific Props' },
    },
    tableHeader: {
      control: 'object',
      table: { type: { summary: 'DataGridTableHeaderProps' }, category: 'Wrapper-Specific Props' },
    },
    rows: { control: 'object' },
    columns: { control: 'object' },
    pagination: { control: 'boolean', table: { category: 'Core Component Props' } },
    checkboxSelection: { control: 'boolean', table: { category: 'Core Component Props' } },
    density: {
      control: 'select',
      options: ['compact', 'standard', 'comfortable'],
      table: { category: 'Core Component Props' },
    },
    loading: { control: 'boolean', table: { category: 'Core Component Props' } },
  },
};

export default meta;
type Story = StoryObj<typeof DataGrid>;

const sampleRows: GridRowsProp = [
  { id: 1, name: 'Sarah Connor', email: 'sarah.connor@example.com', role: 'Admin', status: 'Active', joinDate: '2026-01-23', disposition: 'open' },
  { id: 2, name: 'Kyle Reese', email: 'kyle.reese@example.com', role: 'Manager', status: 'Active', joinDate: '2026-01-23', disposition: 'schedule.callback' },
  { id: 3, name: 'Ellen Ripley', email: 'ellen.ripley@example.com', role: 'User', status: 'Active', joinDate: '2026-01-22', disposition: 'callback' },
  { id: 4, name: 'Han Solo', email: 'han.solo@example.com', role: 'User', status: 'Active', joinDate: '2026-01-22', disposition: 'schedule.callback' },
  { id: 5, name: 'Leia Organa', email: 'leia.organa@example.com', role: 'Admin', status: 'Active', joinDate: '2026-01-21', disposition: 'open' },
  { id: 6, name: 'Luke Skywalker', email: 'luke.skywalker@example.com', role: 'Manager', status: 'Active', joinDate: '2026-01-21', disposition: 'callback' },
  { id: 7, name: 'Obi-Wan Kenobi', email: 'obiwan.kenobi@example.com', role: 'User', status: 'Active', joinDate: '2026-01-20', disposition: 'open' },
  { id: 8, name: 'Anakin Skywalker', email: 'anakin.skywalker@example.com', role: 'User', status: 'Inactive', joinDate: '2026-01-20', disposition: 'schedule.callback' },
  { id: 9, name: 'Tony Stark', email: 'tony.stark@example.com', role: 'Admin', status: 'Active', joinDate: '2026-01-19', disposition: 'callback' },
  { id: 10, name: 'Bruce Banner', email: 'bruce.banner@example.com', role: 'User', status: 'Active', joinDate: '2026-01-18', disposition: 'schedule.callback' },
  { id: 11, name: 'Natasha Romanoff', email: 'natasha.romanoff@example.com', role: 'Manager', status: 'Active', joinDate: '2026-01-17', disposition: 'open' },
  { id: 12, name: 'Steve Rogers', email: 'steve.rogers@example.com', role: 'Admin', status: 'Active', joinDate: '2026-01-16', disposition: 'callback' },
  { id: 13, name: 'Thor Odinson', email: 'thor.odinson@example.com', role: 'User', status: 'Active', joinDate: '2026-01-15', disposition: 'open' },
  { id: 14, name: 'Peter Parker', email: 'peter.parker@example.com', role: 'User', status: 'Active', joinDate: '2026-01-14', disposition: 'schedule.callback' },
  { id: 15, name: 'Wanda Maximoff', email: 'wanda.maximoff@example.com', role: 'Manager', status: 'Active', joinDate: '2026-01-13', disposition: 'callback' },
  { id: 16, name: 'John Doe', email: 'john.doe@example.com', role: 'Admin', status: 'Active', joinDate: '2023-01-15', disposition: 'schedule.callback' },
  { id: 17, name: 'Jane Smith', email: 'jane.smith@example.com', role: 'User', status: 'Active', joinDate: '2023-02-20', disposition: 'open' },
  { id: 18, name: 'Bob Johnson', email: 'bob.johnson@example.com', role: 'User', status: 'Inactive', joinDate: '2023-03-10', disposition: 'callback' },
  { id: 19, name: 'Alice Williams', email: 'alice.williams@example.com', role: 'Manager', status: 'Active', joinDate: '2023-04-05', disposition: 'open' },
  { id: 20, name: 'Charlie Brown', email: 'charlie.brown@example.com', role: 'User', status: 'Active', joinDate: '2023-05-12', disposition: 'schedule.callback' },
];

const sampleColumns: DataGridColDef[] = [
  { field: 'id', headerName: 'ID', width: 90, iconName: 'hash' },
  { field: 'name', headerName: 'Name', width: 200, iconName: 'user' },
  { field: 'email', headerName: 'Email', width: 250, iconName: 'envelope-simple' },
  { field: 'role', headerName: 'Role', width: 150, iconName: 'shield-check' },
  { field: 'status', headerName: 'Status', width: 120, iconName: 'check-circle' },
  { field: 'joinDate', headerName: 'Join Date', width: 150, iconName: 'calendar-blank' },
  { field: 'disposition', headerName: 'Disposition', width: 180, iconName: 'tag' },
];

const dispositionOptions: MultiSelectOption[] = [
  { id: 'system-defined', label: 'System Defined', value: 'system-defined', isGroup: true },
  { id: 'schedule-callback', label: 'schedule.callback', value: 'schedule.callback', parentId: 'system-defined' },
  { id: 'callback', label: 'Callback', value: 'callback', parentId: 'system-defined' },
  { id: 'status-group', label: 'Status', value: 'status-group', isGroup: true },
  { id: 'open', label: 'Open', value: 'open', parentId: 'status-group' },
  { id: 'closed', label: 'Closed', value: 'closed', parentId: 'status-group' },
];

// ──────────────────────────────────────────────────────────
// Non-filter stories
// ──────────────────────────────────────────────────────────

export const Minimal: Story = {
  render: (args) => (
    <div style={{ height: 400, width: '100%' }}>
      <DataGrid {...args} />
    </div>
  ),
  args: {
    rows: sampleRows,
    columns: sampleColumns,
    tableHeader: { title: 'Team Members' },
  },
};

export const WithPagination: Story = {
  render: (args) => (
    <div style={{ height: 400, width: '100%' }}>
      <DataGrid {...args} />
    </div>
  ),
  args: {
    rows: sampleRows,
    columns: sampleColumns,
    initialState: { pagination: { paginationModel: { page: 0, pageSize: 5 } } },
    pageSizeOptions: [5, 10, 25],
  },
};

export const WithCheckboxSelection: Story = {
  render: (args) => (
    <div style={{ height: 400, width: '100%' }}>
      <DataGrid {...args} />
    </div>
  ),
  args: {
    rows: sampleRows,
    columns: sampleColumns,
    checkboxSelection: true,
    initialState: { pagination: { paginationModel: { page: 0, pageSize: 5 } } },
    bulkDeleteConfig: {
      onDelete: (ids) => alert(`Delete ${ids.length} rows`),
      label: (count) => `Delete ${count} Rows`,
    },
  },
};

export const EmptyState: Story = {
  render: (args) => (
    <div style={{ height: 800, width: '100%' }}>
      <DataGrid {...args} />
    </div>
  ),
  args: {
    rows: [],
    columns: sampleColumns,
    tableHeader: { title: 'Message Details' },
    emptyStateMessage: 'No messages available',
  },
};

export const ErrorState: Story = {
  render: (args) => (
    <div style={{ height: 800, width: '100%' }}>
      <DataGrid
        {...args}
        onRefresh={() => alert('Refreshing...')}
      />
    </div>
  ),
  args: {
    rows: sampleRows,
    columns: sampleColumns,
    tableHeader: { title: 'SMS Campaigns' },
    error: true,
  },
};

export const LoadingState: Story = {
  render: (args) => (
    <div style={{ height: 400, width: '100%' }}>
      <DataGrid {...args} />
    </div>
  ),
  args: {
    rows: [],
    columns: sampleColumns,
    loading: true,
  },
};

export const WithCustomButtons: Story = {
  render: (args) => (
    <div style={{ height: 600, width: '100%' }}>
      <DataGrid {...args} />
    </div>
  ),
  args: {
    rows: sampleRows,
    columns: sampleColumns,
    initialState: { pagination: { paginationModel: { page: 0, pageSize: 5 } } },
    customToolbarButtons: [
      { id: 'add', icon: <Icon name="plus" size={20} />, label: 'Add New', tooltip: 'Add new row', onClick: () => alert('Add'), color: 'primary' },
      { id: 'delete', icon: <Icon name="trash" size={20} />, label: 'Delete', tooltip: 'Delete', onClick: () => alert('Delete'), color: 'error' },
    ] as ToolbarButtonConfig[],
  },
};

export const WithBulkDelete: Story = {
  render: (args) => {
    const [filterValues, setFilterValues] = useState<FilterRecords>({ status: 'all' });
    const filteredRows = sampleRows.filter((row) => {
      return (filterValues.status as string) === 'all' || row.status === filterValues.status;
    });
    return (
      <div style={{ height: 600, width: '100%' }}>
        <DataGrid
          {...args}
          rows={filteredRows}
          customToolbarFilters={[{
            id: 'status', type: 'select', label: 'Status', initialValue: 'all',
            options: [{ value: 'all', label: 'All Status' }, { value: 'Active', label: 'Active' }, { value: 'Inactive', label: 'Inactive' }],
          }] as ToolbarFilterConfig[]}
          onToolbarFiltersChange={setFilterValues}
          showAppliedFilters
          bulkDeleteConfig={{
            onDelete: (ids) => alert(`Delete ${ids.length} rows`),
            label: (count) => `Delete ${count} Rows`,
          }}
        />
      </div>
    );
  },
  args: {
    columns: sampleColumns,
    checkboxSelection: true,
    initialState: { pagination: { paginationModel: { page: 0, pageSize: 5 } } },
  },
};

/**
 * Same toolbar, filters, and bulk delete as **With Bulk Delete**, plus
 * [Data Grid list view](https://mui.com/x/react-data-grid/list-view/) below 756px width.
 */
export const ListView: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'Resize the preview **under 756px** to switch to list layout and bottom-drawer toolbars; wider viewports use the grid and dropdown menus.',
      },
    },
  },
  render: (args) => {
    const [filterValues, setFilterValues] = useState<FilterRecords>({ status: 'all' });
    const isListView = useMediaQuery('(max-width:755px)');

    const listViewColumn = useMemo<GridListViewColDef>(
      () => ({
        field: 'listColumn',
        renderCell: (params: GridRenderCellParams) => (
          <Stack direction="column" spacing={0.5} sx={{ py: 0.5, width: '100%' }}>
            <Typography variant="title2">{params.row.name}</Typography>
            <Typography variant="body2" color="text.secondary">
              {params.row.email}
            </Typography>
            <Typography variant="label2" color="text.secondary">
              {params.row.role} · {params.row.status}
            </Typography>
          </Stack>
        ),
      }),
      []
    );

    const filteredRows = sampleRows.filter((row) => {
      return (filterValues.status as string) === 'all' || row.status === filterValues.status;
    });

    return (
      <div style={{ height: 600, width: '100%' }}>
        <DataGrid
          {...args}
          rows={filteredRows}
          listView={isListView}
          listViewColumn={listViewColumn}
          rowHeight={isListView ? 96 : undefined}
          customToolbarFilters={[
            {
              id: 'status',
              type: 'select',
              label: 'Status',
              initialValue: 'all',
              options: [
                { value: 'all', label: 'All Status' },
                { value: 'Active', label: 'Active' },
                { value: 'Inactive', label: 'Inactive' },
              ],
            },
          ] as ToolbarFilterConfig[]}
          onToolbarFiltersChange={setFilterValues}
          showAppliedFilters
          bulkDeleteConfig={{
            onDelete: (ids) => alert(`Delete ${ids.length} rows`),
            label: (count) => `Delete ${count} Rows`,
          }}
        />
      </div>
    );
  },
  args: {
    columns: sampleColumns,
    checkboxSelection: true,
    initialState: { pagination: { paginationModel: { page: 0, pageSize: 5 } } },
  },
};

export const WithoutToolbar: Story = {
  render: (args) => (
    <div style={{ height: 400, width: '100%' }}>
      <DataGrid {...args} />
    </div>
  ),
  args: {
    rows: sampleRows,
    columns: sampleColumns,
    showToolbar: false,
  },
};

/**
 * Basic search with title, no filters or custom buttons.
 */
export const WithBasicSearch: Story = {
  render: (args) => {
    const [search, setSearch] = useState('');
    const filteredRows = sampleRows.filter((row) => {
      if (!search) return true;
      const term = search.toLowerCase();
      return (
        row.name.toLowerCase().includes(term) ||
        row.email.toLowerCase().includes(term) ||
        row.role.toLowerCase().includes(term)
      );
    });

    return (
      <div style={{ height: 600, width: '100%' }}>
        <DataGrid
          {...args}
          rows={filteredRows}
          tableHeader={{
            title: 'Team Members',
            showSearch: true,
            searchType: 'basic',
            onBasicSearch: setSearch,
          }}
        />
      </div>
    );
  },
  args: {
    columns: sampleColumns,
    initialState: { pagination: { paginationModel: { page: 0, pageSize: 10 } } },
    pageSizeOptions: [5, 10, 25],
  },
};

// ──────────────────────────────────────────────────────────
// Filter stories (all with Applied Filters)
// ──────────────────────────────────────────────────────────

/**
 * Date range filter with Applied Filters bar.
 */
export const WithDateRangeFilter: Story = {
  render: (args) => {
    const defaultRange: DateRangeValue = {
      startDate: dayjs().subtract(14, 'day').startOf('day'),
      endDate: dayjs().endOf('day'),
    };
    const [filterValues, setFilterValues] = useState<FilterRecords>({
      dateRange: defaultRange,
    });

    const filteredRows = sampleRows.filter((row) => {
      const dateRange = filterValues.dateRange as DateRangeValue | undefined;
      if (dateRange?.startDate && dateRange?.endDate) {
        const rowDate = dayjs(row.joinDate);
        if (!(rowDate.isAfter(dateRange.startDate) || rowDate.isSame(dateRange.startDate, 'day'))) return false;
        if (!(rowDate.isBefore(dateRange.endDate) || rowDate.isSame(dateRange.endDate, 'day'))) return false;
      }
      return true;
    });

    return (
      <div style={{ height: 680, width: '100%' }}>
        <DataGrid
          {...args}
          rows={filteredRows}
          tableHeader={{ title: 'Team Members' }}
          showAppliedFilters
          maxVisibleAppliedFilters={4}
          customToolbarFilters={[
            {
              id: 'dateRange',
              type: 'date-range',
              label: 'Join date range',
              initialValue: defaultRange,
            },
          ] as ToolbarFilterConfig[]}
          onToolbarFiltersChange={setFilterValues}
        />
      </div>
    );
  },
  args: {
    columns: sampleColumns,
    initialState: { pagination: { paginationModel: { page: 0, pageSize: 10 } } },
    pageSizeOptions: [5, 10, 25],
  },
};

/**
 * Select and multi-select filters with Applied Filters bar.
 */
export const WithSelectAndMultiSelectFilter: Story = {
  render: (args) => {
    const initialDisposition = ['callback', 'open'];
    const [filterValues, setFilterValues] = useState<FilterRecords>({
      status: 'Active',
      role: 'Admin',
      disposition: initialDisposition,
    });

    const filteredRows = sampleRows.filter((row) => {
      const status = filterValues.status as string;
      const role = filterValues.role as string;
      const disposition = (filterValues.disposition as string[]) ?? [];
      if (status && status !== 'all' && row.status !== status) return false;
      if (role && role !== 'all' && row.role !== role) return false;
      if (disposition.length > 0 && !disposition.includes(row.disposition)) return false;
      return true;
    });

    return (
      <div style={{ height: 680, width: '100%' }}>
        <DataGrid
          {...args}
          rows={filteredRows}
          tableHeader={{ title: 'Team Members' }}
          showAppliedFilters
          maxVisibleAppliedFilters={4}
          customToolbarFilters={[
            {
              id: 'status',
              type: 'select',
              label: 'Status',
              iconName: 'check-circle',
              initialValue: 'Active',
              options: [
                { value: 'all', label: 'All status' },
                { value: 'Active', label: 'Active' },
                { value: 'Inactive', label: 'Inactive' },
              ],
            },
            {
              id: 'role',
              type: 'select',
              label: 'Role',
              iconName: 'shield-check',
              initialValue: 'Admin',
              options: [
                { value: 'all', label: 'All roles' },
                { value: 'Admin', label: 'Admin' },
                { value: 'User', label: 'User' },
                { value: 'Manager', label: 'Manager' },
              ],
            },
            {
              id: 'disposition',
              type: 'multi-select',
              label: 'Disposition',
              iconName: 'tag',
              initialValue: initialDisposition,
              multiSelectOptions: dispositionOptions,
              placeholder: 'Select dispositions',
            },
          ] as ToolbarFilterConfig[]}
          onToolbarFiltersChange={setFilterValues}
        />
      </div>
    );
  },
  args: {
    columns: sampleColumns,
    initialState: { pagination: { paginationModel: { page: 0, pageSize: 10 } } },
    pageSizeOptions: [5, 10, 25],
  },
};

/**
 * All filter types (select, text, date, date-range, multi-select) with Applied Filters bar.
 */
export const WithAllFilters: Story = {
  render: (args) => {
    const defaultRange: DateRangeValue = {
      startDate: dayjs().subtract(30, 'day').startOf('day'),
      endDate: dayjs().endOf('day'),
    };
    const initialDisposition = ['schedule.callback'];
    const [filterValues, setFilterValues] = useState<FilterRecords>({
      status: 'Active',
      role: 'all',
      dateRange: defaultRange,
      disposition: initialDisposition,
    });

    const filteredRows = sampleRows.filter((row) => {
      const status = filterValues.status as string;
      if (status && status !== 'all' && row.status !== status) return false;

      const role = filterValues.role as string;
      if (role && role !== 'all' && row.role !== role) return false;

      const dateRange = filterValues.dateRange as DateRangeValue | undefined;
      if (dateRange?.startDate && dateRange?.endDate) {
        const rowDate = dayjs(row.joinDate);
        if (!(rowDate.isAfter(dateRange.startDate) || rowDate.isSame(dateRange.startDate, 'day'))) return false;
        if (!(rowDate.isBefore(dateRange.endDate) || rowDate.isSame(dateRange.endDate, 'day'))) return false;
      }

      const disposition = (filterValues.disposition as string[]) ?? [];
      if (disposition.length > 0 && !disposition.includes(row.disposition)) return false;

      return true;
    });

    return (
      <div style={{ height: 720, width: '100%' }}>
        <DataGrid
          {...args}
          rows={filteredRows}
          tableHeader={{ title: 'Team Members' }}
          showAppliedFilters
          maxVisibleAppliedFilters={4}
          customToolbarFilters={[
            {
              id: 'status',
              type: 'select',
              label: 'Status',
              iconName: 'check-circle',
              initialValue: 'Active',
              options: [
                { value: 'all', label: 'All status' },
                { value: 'Active', label: 'Active' },
                { value: 'Inactive', label: 'Inactive' },
              ],
            },
            {
              id: 'role',
              type: 'select',
              label: 'Role',
              iconName: 'shield-check',
              initialValue: 'all',
              options: [
                { value: 'all', label: 'All roles' },
                { value: 'Admin', label: 'Admin' },
                { value: 'User', label: 'User' },
                { value: 'Manager', label: 'Manager' },
              ],
            },
            {
              id: 'dateRange',
              type: 'date-range',
              label: 'Join date range',
              initialValue: defaultRange,
            },
            {
              id: 'disposition',
              type: 'multi-select',
              label: 'Disposition',
              iconName: 'tag',
              initialValue: initialDisposition,
              multiSelectOptions: dispositionOptions,
              placeholder: 'Disposition',
            },
          ] as ToolbarFilterConfig[]}
          onToolbarFiltersChange={setFilterValues}
        />
      </div>
    );
  },
  args: {
    columns: sampleColumns,
    initialState: { pagination: { paginationModel: { page: 0, pageSize: 10 } } },
    pageSizeOptions: [5, 10, 25],
  },
};

/**
 * Multiple select filters with enough active values to show the "+N More" overflow button.
 */
export const WithMultipleSelectFilters: Story = {
  render: (args) => {
    const [filterValues, setFilterValues] = useState<FilterRecords>({
      status: 'Active',
      role: 'Admin',
      team: 'Engineering',
      department: 'Product',
      location: 'Remote',
      priority: 'High',
    });

    const filteredRows = sampleRows.filter((row) => {
      const status = filterValues.status as string;
      if (status && status !== 'all' && row.status !== status) return false;
      const role = filterValues.role as string;
      if (role && role !== 'all' && row.role !== role) return false;
      return true;
    });

    return (
      <div style={{ height: 680, width: '100%' }}>
        <DataGrid
          {...args}
          rows={filteredRows}
          tableHeader={{ title: 'Team Members' }}
          showAppliedFilters
          maxVisibleAppliedFilters={3}
          customToolbarFilters={[
            {
              id: 'status',
              type: 'select',
              label: 'Status',
              initialValue: 'Active',
              options: [
                { value: 'all', label: 'All status' },
                { value: 'Active', label: 'Active' },
                { value: 'Inactive', label: 'Inactive' },
              ],
            },
            {
              id: 'role',
              type: 'select',
              label: 'Role',
              initialValue: 'Admin',
              options: [
                { value: 'all', label: 'All roles' },
                { value: 'Admin', label: 'Admin' },
                { value: 'User', label: 'User' },
                { value: 'Manager', label: 'Manager' },
              ],
            },
            {
              id: 'team',
              type: 'select',
              label: 'Team',
              initialValue: 'Engineering',
              options: [
                { value: 'all', label: 'All teams' },
                { value: 'Engineering', label: 'Engineering' },
                { value: 'Design', label: 'Design' },
                { value: 'Marketing', label: 'Marketing' },
              ],
            },
            {
              id: 'department',
              type: 'select',
              label: 'Department',
              initialValue: 'Product',
              options: [
                { value: 'all', label: 'All departments' },
                { value: 'Product', label: 'Product' },
                { value: 'Sales', label: 'Sales' },
                { value: 'Support', label: 'Support' },
              ],
            },
            {
              id: 'location',
              type: 'select',
              label: 'Location',
              initialValue: 'Remote',
              options: [
                { value: 'all', label: 'All locations' },
                { value: 'Remote', label: 'Remote' },
                { value: 'Office', label: 'Office' },
                { value: 'Hybrid', label: 'Hybrid' },
              ],
            },
            {
              id: 'priority',
              type: 'select',
              label: 'Priority',
              initialValue: 'High',
              options: [
                { value: 'all', label: 'All priorities' },
                { value: 'High', label: 'High' },
                { value: 'Medium', label: 'Medium' },
                { value: 'Low', label: 'Low' },
              ],
            },
          ] as ToolbarFilterConfig[]}
          onToolbarFiltersChange={setFilterValues}
        />
      </div>
    );
  },
  args: {
    columns: sampleColumns,
    initialState: { pagination: { paginationModel: { page: 0, pageSize: 10 } } },
    pageSizeOptions: [5, 10, 25],
  },
};

// ──────────────────────────────────────────────────────────
// TableHeader integration stories
// ──────────────────────────────────────────────────────────

/**
 * Uses `tableHeader` to render PageHeader with title, subtitle,
 * search, and action buttons above the toolbar.
 */
export const WithTableHeader: Story = {
  render: (args) => {
    const [search, setSearch] = useState('');
    const filteredRows = sampleRows.filter((row) => {
      if (!search) return true;
      const term = search.toLowerCase();
      return (
        row.name.toLowerCase().includes(term) ||
        row.email.toLowerCase().includes(term) ||
        row.role.toLowerCase().includes(term)
      );
    });

    return (
      <div style={{ height: 600, width: '100%' }}>
        <DataGrid
          {...args}
          rows={filteredRows}
          tableHeader={{
            title: 'Team Members',
            subtitle: 'Manage your team members and their roles',
            showSearch: true,
            searchType: 'basic',
            onBasicSearch: setSearch,
            actions: [
              { id: 'export', children: 'Export', variant: 'outlined' },
              { id: 'add', children: 'Add Member', variant: 'contained', startIconProps: { name: 'plus' } },
            ],
          }}
        />
      </div>
    );
  },
  args: {
    columns: sampleColumns,
    initialState: { pagination: { paginationModel: { page: 0, pageSize: 10 } } },
    pageSizeOptions: [5, 10, 25],
  },
};

// ──────────────────────────────────────────────────────────
// Server-side story
// ──────────────────────────────────────────────────────────

const FAKE_DELAY_MS = 800;

type RowData = (typeof sampleRows)[number];

interface ServerFetchResult {
  rows: RowData[];
  totalRows: number;
}

function fakeServerFetch(
  allRows: readonly RowData[],
  filters: FilterRecords,
  sort: GridSortModel,
  page: number,
  pageSize: number
): Promise<ServerFetchResult> {
  return new Promise((resolve) => {
    setTimeout(() => {
      let rows = [...allRows];

      const status = filters.status as string | undefined;
      if (status && status !== 'all') {
        rows = rows.filter((r) => r.status === status);
      }

      const role = filters.role as string | undefined;
      if (role && role !== 'all') {
        rows = rows.filter((r) => r.role === role);
      }

      if (sort.length > 0) {
        const { field, sort: dir } = sort[0];
        rows.sort((a, b) => {
          const aVal = a[field] as string;
          const bVal = b[field] as string;
          const cmp = aVal < bVal ? -1 : aVal > bVal ? 1 : 0;
          return dir === 'desc' ? -cmp : cmp;
        });
      }

      const totalRows = rows.length;
      const start = page * pageSize;
      const paginatedRows = rows.slice(start, start + pageSize);

      resolve({ rows: paginatedRows, totalRows });
    }, FAKE_DELAY_MS);
  });
}

/**
 * Server-side filters, sorting, and pagination with a loading delay.
 *
 * Every filter change, sort change, page change, or refresh triggers a fake
 * server call (~800 ms). The grid shows a loader while data is being fetched.
 * Pagination is fully server-driven with configurable rows per page.
 */
export const ServerSide: Story = {
  render: (args) => {
    const [rows, setRows] = useState<RowData[]>([]);
    const [loading, setLoading] = useState(true);
    const [rowCount, setRowCount] = useState(0);
    const [sortModel, setSortModel] = useState<GridSortModel>([]);
    const [paginationModel, setPaginationModel] = useState({ page: 0, pageSize: 10 });
    const filtersRef = useRef<FilterRecords>({
      status: 'Active',
      role: 'all',
    });

    const fetchData = useCallback(
      (filters: FilterRecords, sort: GridSortModel, page: number, pageSize: number) => {
        setLoading(true);
        fakeServerFetch(sampleRows, filters, sort, page, pageSize).then((result) => {
          setRows(result.rows);
          setRowCount(result.totalRows);
          setLoading(false);
        });
      },
      []
    );

    useEffect(() => {
      fetchData(filtersRef.current, sortModel, paginationModel.page, paginationModel.pageSize);
    }, []);

    const handleFiltersChange = useCallback(
      (newFilters: FilterRecords) => {
        filtersRef.current = newFilters;
        setPaginationModel((prev) => ({ ...prev, page: 0 }));
        fetchData(newFilters, sortModel, 0, paginationModel.pageSize);
      },
      [sortModel, paginationModel.pageSize, fetchData]
    );

    const handleSortModelChange = useCallback(
      (newSort: GridSortModel) => {
        setSortModel(newSort);
        setPaginationModel((prev) => ({ ...prev, page: 0 }));
        fetchData(filtersRef.current, newSort, 0, paginationModel.pageSize);
      },
      [paginationModel.pageSize, fetchData]
    );

    const handlePaginationModelChange = useCallback(
      (newModel: typeof paginationModel) => {
        setPaginationModel(newModel);
        fetchData(filtersRef.current, sortModel, newModel.page, newModel.pageSize);
      },
      [sortModel, fetchData]
    );

    const handleRefresh = useCallback(() => {
      fetchData(filtersRef.current, sortModel, paginationModel.page, paginationModel.pageSize);
    }, [sortModel, paginationModel, fetchData]);

    return (
      <div style={{ height: 720, width: '100%' }}>
        <DataGrid
          {...args}
          rows={rows}
          loading={loading}
          rowCount={rowCount}
          paginationMode="server"
          paginationModel={paginationModel}
          onPaginationModelChange={handlePaginationModelChange}
          pageSizeOptions={[5, 10, 25]}
          tableHeader={{ title: 'Message Details' }}
          showAppliedFilters
          maxVisibleAppliedFilters={4}
          sortModel={sortModel}
          onSortModelChange={handleSortModelChange}
          onRefresh={handleRefresh}
          customToolbarFilters={
            [
              {
                id: 'status',
                type: 'select',
                label: 'Status',
                initialValue: 'Active',
                options: [
                  { value: 'all', label: 'All status' },
                  { value: 'Active', label: 'Active' },
                  { value: 'Inactive', label: 'Inactive' },
                ],
              },
              {
                id: 'role',
                type: 'select',
                label: 'Role',
                initialValue: 'all',
                options: [
                  { value: 'all', label: 'All roles' },
                  { value: 'Admin', label: 'Admin' },
                  { value: 'User', label: 'User' },
                  { value: 'Manager', label: 'Manager' },
                ],
              },
            ] as ToolbarFilterConfig[]
          }
          onToolbarFiltersChange={handleFiltersChange}
        />
      </div>
    );
  },
  args: {
    columns: sampleColumns,
    pagination: true,
  },
};

// ──────────────────────────────────────────────────────────
// Actions column story
// ──────────────────────────────────────────────────────────

const columnsWithActions: DataGridColDef[] = [
  ...(sampleColumns.slice(0, 6)),
  {
    field: 'actions',
    headerName: 'Actions',
    width: 120,
    sortable: false,
    disableColumnMenu: true,
    renderCell: (params) => (
      <Stack height='100%' direction="row" spacing={0.5} alignItems="center">
        <Tooltip title="Edit">
          <IconButton
            size="small"
            color="primary"
            onClick={() => alert(`Edit row ${params.row.id}: ${params.row.name}`)}
          >
            <Icon name="pencil-simple" size="sm" />
          </IconButton>
        </Tooltip>
        <Tooltip title="Delete">
          <IconButton
            size="small"
            color="error"
            onClick={() => alert(`Delete row ${params.row.id}: ${params.row.name}`)}
          >
            <Icon name="trash" size="sm" />
          </IconButton>
        </Tooltip>
      </Stack>
    ),
  },
];

/**
 * DataGrid with Edit and Delete action buttons in the last column.
 */
export const WithActions: Story = {
  render: (args) => (
    <div style={{ height: 600, width: '100%' }}>
      <DataGrid {...args} />
    </div>
  ),
  args: {
    rows: sampleRows,
    columns: columnsWithActions,
    tableHeader: { title: 'Team Members' },
    initialState: { pagination: { paginationModel: { page: 0, pageSize: 10 } } },
    pageSizeOptions: [5, 10, 25],
  },
};

// ──────────────────────────────────────────────────────────
// Mobile / List-view story
// ──────────────────────────────────────────────────────────

/**
 * Mobile list-view layout using ListCell.
 * Set the Storybook viewport to a small screen (e.g. iPhone) to see list mode.
 */
export const MobileListView: Story = {
  parameters: {
    viewport: { defaultViewport: 'mobile1' },
  },
  render: (args) => (
    <div style={{ height: 600, width: '100%' }}>
      <DataGrid {...args} />
    </div>
  ),
  args: {
    rows: sampleRows,
    columns: sampleColumns,
    tableHeader: { title: 'Team Members' },
    listCellConfig: {
      primaryField: 'name',
      secondaryField: 'joinDate',
      iconName: 'phone',
      excludeFields: ['id', 'email'],
    },
    initialState: { pagination: { paginationModel: { page: 0, pageSize: 10 } } },
    pageSizeOptions: [5, 10, 25],
  },
};
