import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { Drawer, Button, Typography, Box, EnhancedTextField as TextField, Radio, FormControl } from '../../components';
import { Divider, RadioGroup, FormControlLabel } from '@mui/material';

const meta: Meta<typeof Drawer> = {
  title: 'UI Components/Drawer',
  component: Drawer,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component: 'Exotel-approved drawer component with structured Header/Body/Footer layout. Provides a sliding panel from the edge of the screen with a fixed header, scrollable body, and fixed footer.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    anchor: {
      control: 'select',
      options: ['left', 'right', 'top', 'bottom'],
      description: 'Side from which the drawer will appear',
      table: {
        type: { summary: "'left' | 'right' | 'top' | 'bottom'" },
        defaultValue: { summary: "'right'" },
      },
    },
    variant: {
      control: 'select',
      options: ['permanent', 'persistent', 'temporary'],
      description: 'The variant to use',
      table: {
        type: { summary: "'permanent' | 'persistent' | 'temporary'" },
        defaultValue: { summary: "'temporary'" },
      },
    },
    open: {
      control: 'boolean',
      description: 'If true, the drawer is open',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    title: {
      control: 'text',
      description: 'Title displayed in the header',
    },
    showCloseButton: {
      control: 'boolean',
      description: 'Whether to show the close button in the header',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'true' },
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Drawer>;

/**
 * Basic Drawer with header, body, and footer
 */
export const Basic: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    return (
      <Box>
        <Button onClick={() => setOpen(true)}>Open Drawer</Button>
        <Drawer
          anchor="right"
          open={open}
          onClose={() => setOpen(false)}
          title="Create Email Settings"
          footerActions={
            <>
              <Button variant="outlined" color="error" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button variant="contained" onClick={() => setOpen(false)}>
                Create Configuration
              </Button>
            </>
          }
        >
          <Typography variant="body2" sx={{ mb: 2 }}>
            This is the body content of the drawer. You can add any content here,
            such as forms, lists, or other components.
          </Typography>
        </Drawer>
      </Box>
    );
  },
};

/**
 * Drawer with long, scrollable body
 */
export const ScrollableBody: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    return (
      <Box>
        <Button onClick={() => setOpen(true)}>Open Scrollable Drawer</Button>
        <Drawer
          anchor="right"
          open={open}
          onClose={() => setOpen(false)}
          title="Long Content Example"
          footerActions={
            <>
              <Button variant="outlined" color="error" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button variant="contained" onClick={() => setOpen(false)}>
                Save
              </Button>
            </>
          }
        >
          {Array.from({ length: 50 }, (_, i) => (
            <Typography key={i} variant="body2" sx={{ mb: 2 }}>
              This is paragraph {i + 1}. The body section should scroll when
              content overflows, while the header and footer remain fixed.
            </Typography>
          ))}
        </Drawer>
      </Box>
    );
  },
};

/**
 * Drawer with form content (matching Figma design)
 */
export const WithForm: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    const [value, setValue] = useState('smtp');
    return (
      <Box>
        <Button onClick={() => setOpen(true)}>Open Form Drawer</Button>
        <Drawer
          anchor="right"
          open={open}
          onClose={() => setOpen(false)}
          title="Create Email Settings"
          footerActions={
            <>
              <Button variant="outlined" color="error" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button variant="contained" onClick={() => setOpen(false)}>
                Create Configuration
              </Button>
            </>
          }
        >
          {/* Basic Information Section */}
          <Box sx={{ mb: 4 }}>
            <Typography variant="h6" sx={{ mb: 1 }}>
              Basic Information
            </Typography>
            <Typography variant="body3" color="text.secondary" sx={{ mb: 2 }}>
              Enter the core information to define and identify your Email Settings
            </Typography>
            <TextField
              fullWidth
              label="Entity Name"
              required
              placeholder="Entity Name*"
              sx={{ mb: 2 }}
            />
          </Box>

          <Divider sx={{ mb: 4 }} />

          {/* SMTP Server Settings Section */}
          <Box sx={{ mb: 4 }}>
            <Typography variant="h6" sx={{ mb: 1 }}>
              SMTP Server Settings
            </Typography>
            <Typography variant="body3" color="text.secondary" sx={{ mb: 2 }}>
              Provided by your email service eg: smtp.example.com
            </Typography>
            <TextField
              fullWidth
              label="SMTP Host"
              placeholder="SMTP Host"
              sx={{ mb: 2 }}
            />
            <Typography variant="body3" color="text.secondary" sx={{ mb: 2, ml: 1 }}>
              Provided by your email service eg: smtp.example.com
            </Typography>
            <TextField
              fullWidth
              label="Port"
              placeholder="Port"
              sx={{ mb: 2 }}
            />
            <Typography variant="body3" color="text.secondary" sx={{ mb: 2, ml: 1 }}>
              eg: 587
            </Typography>
            <FormControl sx={{ mb: 2 }}>
              <RadioGroup
                value={value}
                onChange={(e) => setValue(e.target.value)}
                row
              >
                <FormControlLabel value="smtp" control={<Radio />} label="SMTP" />
                <FormControlLabel value="smtps" control={<Radio />} label="SMTPS" />
              </RadioGroup>
            </FormControl>
            <Typography variant="body3" color="text.secondary" sx={{ ml: 1 }}>
              Note: Choose SMTPS if your server requires SSL/TLS
            </Typography>
          </Box>

          <Divider sx={{ mb: 4 }} />

          {/* Authentication Credentials Section */}
          <Box>
            <Typography variant="h6" sx={{ mb: 1 }}>
              Authentication Credentials
            </Typography>
            <Typography variant="body3" color="text.secondary" sx={{ mb: 2 }}>
              Enter the credentials used to authenticate with your email server
            </Typography>
            <TextField
              fullWidth
              label="Username"
              required
              placeholder="Username*"
              sx={{ mb: 2 }}
            />
            <TextField
              fullWidth
              label="Password"
              type="password"
              required
              placeholder="Password*"
            />
          </Box>
        </Drawer>
      </Box>
    );
  },
};

/**
 * Drawer with different footer button combinations
 */
export const FooterVariations: Story = {
  render: () => {
    const [open1, setOpen1] = useState(false);
    const [open2, setOpen2] = useState(false);
    const [open3, setOpen3] = useState(false);
    return (
      <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
        <Button onClick={() => setOpen1(true)}>Primary Only</Button>
        <Button onClick={() => setOpen2(true)}>Cancel + Primary</Button>
        <Button onClick={() => setOpen3(true)}>Multiple Actions</Button>

        {/* Primary action only */}
        <Drawer
          anchor="right"
          open={open1}
          onClose={() => setOpen1(false)}
          title="Primary Action Only"
          footerActions={
            <Button variant="contained" onClick={() => setOpen1(false)}>
              Save
            </Button>
          }
        >
          <Typography variant="body2">
            This drawer has only a primary action button in the footer.
          </Typography>
        </Drawer>

        {/* Cancel + Primary */}
        <Drawer
          anchor="right"
          open={open2}
          onClose={() => setOpen2(false)}
          title="Cancel + Primary"
          footerActions={
            <>
              <Button variant="outlined" onClick={() => setOpen2(false)}>
                Cancel
              </Button>
              <Button variant="contained" onClick={() => setOpen2(false)}>
                Create
              </Button>
            </>
          }
        >
          <Typography variant="body2">
            This drawer has both cancel and primary action buttons.
          </Typography>
        </Drawer>

        {/* Multiple actions */}
        <Drawer
          anchor="right"
          open={open3}
          onClose={() => setOpen3(false)}
          title="Multiple Actions"
          footerActions={
            <>
              <Button variant="text" onClick={() => setOpen3(false)}>
                Reset
              </Button>
              <Button variant="outlined" onClick={() => setOpen3(false)}>
                Cancel
              </Button>
              <Button variant="contained" onClick={() => setOpen3(false)}>
                Save & Continue
              </Button>
            </>
          }
        >
          <Typography variant="body2">
            This drawer has multiple action buttons in the footer.
          </Typography>
        </Drawer>
      </Box>
    );
  },
};

/**
 * Drawer without close button
 */
export const WithoutCloseButton: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    return (
      <Box>
        <Button onClick={() => setOpen(true)}>Open Drawer (No Close Button)</Button>
        <Drawer
          anchor="right"
          open={open}
          onClose={() => setOpen(false)}
          title="No Close Button"
          showCloseButton={false}
          footerActions={
            <Button variant="contained" onClick={() => setOpen(false)}>
              Close
            </Button>
          }
        >
          <Typography variant="body2">
            This drawer does not show a close button in the header. Users must use
            the footer action or click outside to close.
          </Typography>
        </Drawer>
      </Box>
    );
  },
};

/**
 * Drawer with custom header content
 */
export const CustomHeader: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    return (
      <Box>
        <Button onClick={() => setOpen(true)}>Open Custom Header Drawer</Button>
        <Drawer
          anchor="right"
          open={open}
          onClose={() => setOpen(false)}
          headerContent={
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                minHeight: 64,
                padding: 2,
                borderBottom: 1,
                borderColor: 'divider',
              }}
            >
              <Typography variant="h6">Custom Header</Typography>
              <Button variant="text" size="small" onClick={() => setOpen(false)}>
                Close
              </Button>
            </Box>
          }
          footerActions={
            <Button variant="contained" onClick={() => setOpen(false)}>
              Done
            </Button>
          }
        >
          <Typography variant="body2">
            This drawer uses a custom header instead of the default title + close button.
          </Typography>
        </Drawer>
      </Box>
    );
  },
};

/**
 * Left anchor drawer
 */
export const LeftAnchor: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    return (
      <Box>
        <Button onClick={() => setOpen(true)}>Open Left Drawer</Button>
        <Drawer
          anchor="left"
          open={open}
          onClose={() => setOpen(false)}
          title="Left Anchor"
          footerActions={
            <>
              <Button variant="outlined" color="error" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button variant="contained" onClick={() => setOpen(false)}>
                Apply
              </Button>
            </>
          }
        >
          <Typography variant="body2">
            This drawer slides in from the left side.
          </Typography>
        </Drawer>
      </Box>
    );
  },
};
