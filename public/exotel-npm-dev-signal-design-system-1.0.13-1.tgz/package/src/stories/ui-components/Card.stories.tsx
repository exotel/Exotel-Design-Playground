/**
 * Card Component Stories
 * 
 * Stories for the Exotel Card component that wraps MUI's Card.
 */

import type { Meta, StoryObj } from '@storybook/react';
import { Card } from '../../components';
import { Typography } from '@mui/material'; // Using MUI Typography for story content only

const meta: Meta<typeof Card> = {
  title: 'UI Components/Card',
  component: Card,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component: 'Exotel-approved card component that wraps MUI\'s Card. Provides consistent styling and behavior across Exotel applications.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    variant: {
      control: 'select',
      options: ['elevation', 'outlined'],
      description: 'The variant to use',
      table: {
        type: { summary: "'elevation' | 'outlined'" },
        defaultValue: { summary: "'elevation'" },
      },
    },
    elevation: {
      control: { type: 'number', min: 0, max: 24, step: 1 },
      description: 'Shadow depth, corresponds to dp in the spec',
      table: {
        type: { summary: 'number' },
        defaultValue: { summary: '1' },
      },
    },
    square: {
      control: 'boolean',
      description: 'If true, rounded corners are disabled',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Card>;

/**
 * Basic card
 */
export const Basic: Story = {
  render: () => (
    <Card sx={{ minWidth: 275, padding: 2 }}>
      <Typography variant="h6" component="div">
        Card Title
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
        This is a basic card component with some content.
      </Typography>
    </Card>
  ),
};

/**
 * Different elevations
 */
export const Elevations: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
      {[0, 1, 2, 4, 8, 16].map((elevation) => (
        <Card key={elevation} elevation={elevation} sx={{ padding: 2, minWidth: 200 }}>
          <Typography variant="h6">Elevation {elevation}</Typography>
          <Typography variant="body2" color="text.secondary">
            Card with elevation {elevation}
          </Typography>
        </Card>
      ))}
    </div>
  ),
};

/**
 * Outlined variant
 */
export const Outlined: Story = {
  render: () => (
    <Card variant="outlined" sx={{ minWidth: 275, padding: 2 }}>
      <Typography variant="h6" component="div">
        Outlined Card
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
        This card uses the outlined variant instead of elevation.
      </Typography>
    </Card>
  ),
};

/**
 * Card with more content
 */
export const WithContent: Story = {
  render: () => (
    <Card sx={{ maxWidth: 400, padding: 2 }}>
      <Typography variant="h5" component="div" gutterBottom>
        Card Title
      </Typography>
      <Typography variant="body1" paragraph>
        This is a card with more detailed content. It can contain paragraphs,
        lists, images, and any other content you need.
      </Typography>
      <Typography variant="body2" color="text.secondary">
        Additional information or metadata can go here.
      </Typography>
    </Card>
  ),
};

/**
 * Interactive card with all controls
 */
export const Interactive: Story = {
  args: {
    variant: 'elevation',
    elevation: 1,
    square: false,
  },
  render: (args) => (
    <Card {...args} sx={{ minWidth: 300, padding: 2 }}>
      <Typography variant="h6" component="div">
        Interactive Card
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
        Use the controls to change variant, elevation, and square properties.
      </Typography>
    </Card>
  ),
};
