import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import {
  Accordion,
  AccordionSummary,
  AccordionDetails,
  AccordionActions,
  Typography,
  Button,
  Fade,
  type AccordionProps,
} from '../../components';

const meta: Meta<typeof Accordion> = {
  title: 'UI Components/Accordion',
  component: Accordion,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          "Exotel-approved accordion component that wraps MUI's Accordion. Lets users show and hide sections of related content on a page.",
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    defaultExpanded: {
      control: 'boolean',
      description: 'If true, expands the accordion by default',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    disabled: {
      control: 'boolean',
      description: 'If true, the component is disabled',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    disableGutters: {
      control: 'boolean',
      description: 'If true, removes extra padding',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    square: {
      control: 'boolean',
      description: 'If true, rounded corners are disabled',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    expanded: {
      control: 'boolean',
      description: 'If true, expands the accordion (controlled mode)',
      table: {
        type: { summary: 'boolean' },
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Accordion>;

/**
 * Basic accordion with summary and details.
 */
export const Basic: Story = {
  render: () => (
    <div>
      <Accordion>
        <AccordionSummary>
          <Typography>Accordion 1</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            malesuada lacus ex, sit amet blandit leo lobortis eget.
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion>
        <AccordionSummary>
          <Typography>Accordion 2</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            Donec placerat, lectus sed mattis semper, neque lectus feugiat
            lectus, varius pulvinar diam eros in elit.
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion>
        <AccordionSummary>
          <Typography>Accordion 3</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            Nunc vitae orci ultricies, auctor nunc in, volutpat nisl. Integer
            sit amet egestas eros, vitae egestas augue.
          </Typography>
        </AccordionDetails>
      </Accordion>
    </div>
  ),
};

/**
 * Accordion expanded by default using the `defaultExpanded` prop.
 */
export const ExpandedByDefault: Story = {
  render: () => (
    <div>
      <Accordion defaultExpanded>
        <AccordionSummary>
          <Typography>Expanded by default</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            This accordion is expanded by default. Lorem ipsum dolor sit amet,
            consectetur adipiscing elit.
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion>
        <AccordionSummary>
          <Typography>Collapsed</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            Suspendisse malesuada lacus ex, sit amet blandit leo lobortis eget.
          </Typography>
        </AccordionDetails>
      </Accordion>
    </div>
  ),
};

/**
 * A disabled accordion cannot be expanded or collapsed by the user.
 */
export const Disabled: Story = {
  render: () => (
    <div>
      <Accordion>
        <AccordionSummary>
          <Typography>Enabled accordion</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion disabled>
        <AccordionSummary>
          <Typography>Disabled accordion</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>This content is not reachable.</Typography>
        </AccordionDetails>
      </Accordion>
    </div>
  ),
};

/**
 * Controlled accordion where expand/collapse state is managed by React state.
 */
export const Controlled: Story = {
  render: () => {
    const [expanded, setExpanded] = useState<string | false>(false);

    const handleChange =
      (panel: string) => (_event: React.SyntheticEvent, isExpanded: boolean) => {
        setExpanded(isExpanded ? panel : false);
      };

    return (
      <div>
        <Accordion expanded={expanded === 'panel1'} onChange={handleChange('panel1')}>
          <AccordionSummary>
            <Typography sx={{ width: '33%', flexShrink: 0 }}>General settings</Typography>
            <Typography sx={{ color: 'text.secondary' }}>I am an accordion</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Nulla facilisi. Phasellus sollicitudin nulla et quam mattis
              feugiat. Aliquam eget maximus est, id dignissim quam.
            </Typography>
          </AccordionDetails>
        </Accordion>
        <Accordion expanded={expanded === 'panel2'} onChange={handleChange('panel2')}>
          <AccordionSummary>
            <Typography sx={{ width: '33%', flexShrink: 0 }}>Users</Typography>
            <Typography sx={{ color: 'text.secondary' }}>
              You are currently not an owner
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Donec placerat, lectus sed mattis semper, neque lectus feugiat
              lectus, varius pulvinar diam eros in elit.
            </Typography>
          </AccordionDetails>
        </Accordion>
        <Accordion expanded={expanded === 'panel3'} onChange={handleChange('panel3')}>
          <AccordionSummary>
            <Typography sx={{ width: '33%', flexShrink: 0 }}>Advanced settings</Typography>
            <Typography sx={{ color: 'text.secondary' }}>
              Filtering has been entirely disabled
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Nunc vitae orci ultricies, auctor nunc in, volutpat nisl. Integer
              sit amet egestas eros, vitae egestas augue.
            </Typography>
          </AccordionDetails>
        </Accordion>
      </div>
    );
  },
};

/**
 * Accordion with action buttons using the `AccordionActions` component.
 */
export const WithActions: Story = {
  render: () => (
    <div>
      <Accordion>
        <AccordionSummary>
          <Typography>Accordion with actions</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            malesuada lacus ex, sit amet blandit leo lobortis eget.
          </Typography>
        </AccordionDetails>
        <AccordionActions>
          <Button size="small">Cancel</Button>
          <Button size="small" variant="contained">
            Agree
          </Button>
        </AccordionActions>
      </Accordion>
    </div>
  ),
};

/**
 * Custom transition using Fade instead of the default Collapse.
 */
export const CustomTransition: Story = {
  render: () => {
    const [expanded, setExpanded] = useState(false);

    return (
      <div>
        <Accordion
          expanded={expanded}
          onChange={(_event, isExpanded) => setExpanded(isExpanded)}
          slots={{ transition: Fade as any }}
          slotProps={{ transition: { timeout: 400 } }}
          sx={[
            !expanded && {
              '& .MuiAccordion-region': { height: 0 },
              '& .MuiAccordionDetails-root': { display: 'none' },
            },
          ]}
        >
          <AccordionSummary>
            <Typography>Custom transition using Fade</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
              Suspendisse malesuada lacus ex, sit amet blandit leo lobortis
              eget.
            </Typography>
          </AccordionDetails>
        </Accordion>
        <Accordion>
          <AccordionSummary>
            <Typography>Default transition using Collapse</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Donec placerat, lectus sed mattis semper, neque lectus feugiat
              lectus, varius pulvinar diam eros in elit.
            </Typography>
          </AccordionDetails>
        </Accordion>
      </div>
    );
  },
};

/**
 * Only one accordion can be expanded at a time, with visual customization.
 */
export const OnlyOneExpanded: Story = {
  render: () => {
    const [expanded, setExpanded] = useState<string | false>('panel1');

    const handleChange =
      (panel: string) => (_event: React.SyntheticEvent, newExpanded: boolean) => {
        setExpanded(newExpanded ? panel : false);
      };

    return (
      <div>
        {['panel1', 'panel2', 'panel3'].map((panel, index) => (
          <Accordion
            key={panel}
            expanded={expanded === panel}
            onChange={handleChange(panel)}
            disableGutters
            elevation={0}
            square
            sx={{
              border: '1px solid',
              borderColor: 'divider',
              '&:not(:last-child)': { borderBottom: 0 },
              '&::before': { display: 'none' },
            }}
          >
            <AccordionSummary>
              <Typography>Collapsible Group Item #{index + 1}</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Typography>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                Suspendisse malesuada lacus ex, sit amet blandit leo lobortis
                eget.
              </Typography>
            </AccordionDetails>
          </Accordion>
        ))}
      </div>
    );
  },
};

/**
 * Square accordion without rounded corners.
 */
export const Square: Story = {
  render: () => (
    <div>
      <Accordion square>
        <AccordionSummary>
          <Typography>Square Accordion</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            This accordion has square corners instead of the default rounded
            ones.
          </Typography>
        </AccordionDetails>
      </Accordion>
    </div>
  ),
};

