import type { Meta, StoryObj } from '@storybook/react';
import { Select, FormControl } from '../../components';
import { MenuItem, InputLabel } from '@mui/material';
import { useState } from 'react';

const meta: Meta<typeof Select> = {
  title: 'UI Components/Select',
  component: Select,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component: 'Exotel-approved select component that wraps MUI\'s Select. Provides a dropdown selection interface.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    variant: {
      control: 'select',
      options: ['standard', 'outlined', 'filled'],
      description: 'The variant to use',
      table: {
        type: { summary: "'standard' | 'outlined' | 'filled'" },
        defaultValue: { summary: "'outlined'" },
      },
    },
    size: {
      control: 'select',
      options: ['small', 'medium'],
      description: 'The size of the component',
      table: {
        type: { summary: "'small' | 'medium'" },
        defaultValue: { summary: "'medium'" },
      },
    },
    disabled: {
      control: 'boolean',
      description: 'If true, the component is disabled',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    error: {
      control: 'boolean',
      description: 'If true, the component is displayed in an error state',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    fullWidth: {
      control: 'boolean',
      description: 'If true, the select will take up the full width of its container',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    required: {
      control: 'boolean',
      description: 'If true, the label is displayed as required',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Select>;

/**
 * Basic select
 */
export const Basic: Story = {
  render: () => {
    const [value, setValue] = useState('');
    return (
      <FormControl sx={{ minWidth: 120 }}>
        <InputLabel>Age</InputLabel>
        <Select value={value} onChange={(e) => setValue(e.target.value)} label="Age">
          <MenuItem value={10}>Ten</MenuItem>
          <MenuItem value={20}>Twenty</MenuItem>
          <MenuItem value={30}>Thirty</MenuItem>
        </Select>
      </FormControl>
    );
  },
};

/**
 * Different variants
 */
export const Variants: Story = {
  render: () => {
    const [value1, setValue1] = useState('');
    const [value2, setValue2] = useState('');
    const [value3, setValue3] = useState('');
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', width: '300px' }}>
        <FormControl>
          <InputLabel>Standard</InputLabel>
          <Select value={value1} onChange={(e) => setValue1(e.target.value)} label="Standard" variant="standard">
            <MenuItem value={10}>Option 1</MenuItem>
            <MenuItem value={20}>Option 2</MenuItem>
          </Select>
        </FormControl>
        <FormControl>
          <InputLabel>Outlined</InputLabel>
          <Select value={value2} onChange={(e) => setValue2(e.target.value)} label="Outlined" variant="outlined">
            <MenuItem value={10}>Option 1</MenuItem>
            <MenuItem value={20}>Option 2</MenuItem>
          </Select>
        </FormControl>
        <FormControl>
          <InputLabel>Filled</InputLabel>
          <Select value={value3} onChange={(e) => setValue3(e.target.value)} label="Filled" variant="filled">
            <MenuItem value={10}>Option 1</MenuItem>
            <MenuItem value={20}>Option 2</MenuItem>
          </Select>
        </FormControl>
      </div>
    );
  },
};

/**
 * Different sizes
 */
export const Sizes: Story = {
  render: () => {
    const [value1, setValue1] = useState('');
    const [value2, setValue2] = useState('');
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', width: '300px' }}>
        <FormControl>
          <InputLabel>Small</InputLabel>
          <Select value={value1} onChange={(e) => setValue1(e.target.value)} label="Small" size="small">
            <MenuItem value={10}>Option 1</MenuItem>
            <MenuItem value={20}>Option 2</MenuItem>
          </Select>
        </FormControl>
        <FormControl>
          <InputLabel>Medium</InputLabel>
          <Select value={value2} onChange={(e) => setValue2(e.target.value)} label="Medium" size="medium">
            <MenuItem value={10}>Option 1</MenuItem>
            <MenuItem value={20}>Option 2</MenuItem>
          </Select>
        </FormControl>
      </div>
    );
  },
};

/**
 * Error state
 */
export const Error: Story = {
  render: () => {
    const [value, setValue] = useState('');
    return (
      <FormControl error sx={{ minWidth: 120 }}>
        <InputLabel>Age</InputLabel>
        <Select value={value} onChange={(e) => setValue(e.target.value)} label="Age" error>
          <MenuItem value={10}>Ten</MenuItem>
          <MenuItem value={20}>Twenty</MenuItem>
          <MenuItem value={30}>Thirty</MenuItem>
        </Select>
      </FormControl>
    );
  },
};

/**
 * Disabled state
 */
export const Disabled: Story = {
  render: () => (
    <FormControl disabled sx={{ minWidth: 120 }}>
      <InputLabel>Age</InputLabel>
      <Select value={10} label="Age" disabled>
        <MenuItem value={10}>Ten</MenuItem>
        <MenuItem value={20}>Twenty</MenuItem>
        <MenuItem value={30}>Thirty</MenuItem>
      </Select>
    </FormControl>
  ),
};

/**
 * Full width
 */
export const FullWidth: Story = {
  render: () => {
    const [value, setValue] = useState('');
    return (
      <FormControl fullWidth>
        <InputLabel>Age</InputLabel>
        <Select value={value} onChange={(e) => setValue(e.target.value)} label="Age" fullWidth>
          <MenuItem value={10}>Ten</MenuItem>
          <MenuItem value={20}>Twenty</MenuItem>
          <MenuItem value={30}>Thirty</MenuItem>
        </Select>
      </FormControl>
    );
  },
};
