import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import {
  StructuredDialog,
  DialogBody,
  DialogFooter,
  Button,
  Typography,
  Box,
  EnhancedTextField as TextField,
  Radio,
  FormControl,
} from '../../components';
import { Divider, RadioGroup, FormControlLabel } from '@mui/material';

const meta: Meta<typeof StructuredDialog> = {
  title: 'UI Components/StructuredDialog',
  component: StructuredDialog,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'Exotel-approved structured dialog component with Header/Body/Footer layout. Provides predictable scrolling behavior with fixed header and footer, scrollable body.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    open: {
      control: 'boolean',
      description: 'If true, the dialog is open',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    title: {
      control: 'text',
      description: 'Title displayed in the header',
    },
    showHeader: {
      control: 'boolean',
      description: 'Whether to show the header section',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'true' },
      },
    },
    showFooter: {
      control: 'boolean',
      description: 'Whether to show the footer section',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof StructuredDialog>;

/**
 * Basic StructuredDialog with header, body, and footer
 */
export const Basic: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    return (
      <Box>
        <Button onClick={() => setOpen(true)}>Open Dialog</Button>
        <StructuredDialog
          open={open}
          onClose={() => setOpen(false)}
          title="Heading"
          showFooter={true}
          footerContent={
            <Button variant="contained" onClick={() => setOpen(false)}>
              Save and Dial
            </Button>
          }
        >
          <DialogBody>
            <Typography variant="body2">
              This is the body content of the dialog. You can add any content here,
              such as forms, lists, or other components.
            </Typography>
          </DialogBody>
        </StructuredDialog>
      </Box>
    );
  },
};

/**
 * Dialog with form content (matching Figma design)
 */
export const WithForm: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    const [channel, setChannel] = useState('whatsapp');
    const [number, setNumber] = useState('9876543210');
    const [template, setTemplate] = useState('Hi {Customer name} can we connect ?');

    return (
      <Box>
        <Button onClick={() => setOpen(true)}>Open Form Dialog</Button>
        <StructuredDialog
          open={open}
          onClose={() => setOpen(false)}
          title="Heading"
          showFooter={true}
          footerContent={
            <Button variant="contained" onClick={() => setOpen(false)}>
              Save and Dial
            </Button>
          }
        >
          <DialogBody>
            {/* Channel Selection */}
            <Box sx={{ mb: 3 }}>
              <Typography variant="body2" sx={{ mb: 2, fontWeight: 500 }}>
                Channel
              </Typography>
              <FormControl>
                <RadioGroup
                  value={channel}
                  onChange={(e) => setChannel(e.target.value)}
                  row
                >
                  <FormControlLabel value="call" control={<Radio />} label="Call" />
                  <FormControlLabel
                    value="whatsapp"
                    control={<Radio />}
                    label="WhatsApp Chat"
                  />
                </RadioGroup>
              </FormControl>
            </Box>

            {/* Note */}
            <Box
              sx={{
                p: 2,
                mb: 3,
                backgroundColor: 'action.hover',
                borderRadius: 1,
              }}
            >
              <Typography variant="body3" color="text.secondary">
                Note : Please ensure the selected number is available on WhatsApp
              </Typography>
            </Box>

            {/* Number Input */}
            <Box sx={{ mb: 3 }}>
              <TextField
                fullWidth
                label="Enter or select number"
                value={number}
                onChange={(e) => setNumber(e.target.value)}
              />
            </Box>

            {/* Template Text Area */}
            <Box>
              <TextField
                fullWidth
                label="Select Template"
                multiline
                rows={4}
                value={template}
                onChange={(e) => setTemplate(e.target.value)}
              />
            </Box>
          </DialogBody>
        </StructuredDialog>
      </Box>
    );
  },
};

/**
 * Dialog with long, scrollable body
 */
export const ScrollableBody: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    return (
      <Box>
        <Button onClick={() => setOpen(true)}>Open Scrollable Dialog</Button>
        <StructuredDialog
          open={open}
          onClose={() => setOpen(false)}
          title="Long Content Example"
          showFooter={true}
          footerContent={
            <Button variant="contained" onClick={() => setOpen(false)}>
              Save
            </Button>
          }
        >
          <DialogBody>
            {Array.from({ length: 50 }, (_, i) => (
              <Typography key={i} variant="body2" sx={{ mb: 2 }}>
                This is paragraph {i + 1}. The body section should scroll when
                content overflows, while the header and footer remain fixed.
              </Typography>
            ))}
          </DialogBody>
        </StructuredDialog>
      </Box>
    );
  },
};

/**
 * Dialog without header
 */
export const WithoutHeader: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    return (
      <Box>
        <Button onClick={() => setOpen(true)}>Open Dialog (No Header)</Button>
        <StructuredDialog
          open={open}
          onClose={() => setOpen(false)}
          showHeader={false}
          showFooter={true}
          footerContent={
            <Button variant="contained" onClick={() => setOpen(false)}>
              Continue
            </Button>
          }
        >
          <DialogBody>
            <Typography variant="body2">
              This dialog does not have a header. The close button is not rendered
              when the header is hidden. Users must use the footer action or click
              outside to close.
            </Typography>
          </DialogBody>
        </StructuredDialog>
      </Box>
    );
  },
};

/**
 * Dialog without footer
 */
export const WithoutFooter: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    return (
      <Box>
        <Button onClick={() => setOpen(true)}>Open Dialog (No Footer)</Button>
        <StructuredDialog
          open={open}
          onClose={() => setOpen(false)}
          title="Information Dialog"
          showFooter={false}
        >
          <DialogBody>
            <Typography variant="body2">
              This dialog does not have a footer. It's useful for informational
              dialogs where the only action is to close via the header close button
              or backdrop click.
            </Typography>
          </DialogBody>
        </StructuredDialog>
      </Box>
    );
  },
};

/**
 * Dialog with multiple footer actions
 */
export const MultipleFooterActions: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    return (
      <Box>
        <Button onClick={() => setOpen(true)}>Open Dialog (Multiple Actions)</Button>
        <StructuredDialog
          open={open}
          onClose={() => setOpen(false)}
          title="Confirm Action"
          showFooter={true}
          footerContent={
            <>
              <Button variant="outlined" color="error" onClick={() => setOpen(false)}>
                Delete
              </Button>
              <Button variant="contained" onClick={() => setOpen(false)}>
                Save Changes
              </Button>
            </>
          }
        >
          <DialogBody>
            <Typography variant="body2">
              This dialog has multiple actions in the footer. Notice there's no
              default Cancel button - the close (×) button is the primary dismissal
              action.
            </Typography>
          </DialogBody>
        </StructuredDialog>
      </Box>
    );
  },
};

/**
 * Small dialog with minimal content
 */
export const SmallDialog: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    return (
      <Box>
        <Button onClick={() => setOpen(true)}>Open Small Dialog</Button>
        <StructuredDialog
          open={open}
          onClose={() => setOpen(false)}
          title="Confirmation"
          showFooter={true}
          footerContent={
            <Button variant="contained" onClick={() => setOpen(false)}>
              Confirm
            </Button>
          }
        >
          <DialogBody>
            <Typography variant="body2">
              Are you sure you want to proceed with this action?
            </Typography>
          </DialogBody>
        </StructuredDialog>
      </Box>
    );
  },
};
