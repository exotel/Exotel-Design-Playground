import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { Tabs, Box, Typography, Icon } from '../../components';
import MuiTab from '@mui/material/Tab';
// TabPanel is not a separate component in MUI - we'll create a simple wrapper
function TabPanel(props: { children?: React.ReactNode; index: number; value: number }) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );
}

const meta: Meta<typeof Tabs> = {
  title: 'UI Components/Tabs',
  component: Tabs,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component: 'Exotel-approved tabs component that wraps MUI\'s Tabs. Provides navigation between different views or sections.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    value: {
      control: 'number',
      description: 'The value of the currently selected tab',
    },
    variant: {
      control: 'select',
      options: ['standard', 'scrollable', 'fullWidth'],
      description: 'The variant to use',
      table: {
        type: { summary: "'standard' | 'scrollable' | 'fullWidth'" },
        defaultValue: { summary: "'standard'" },
      },
    },
    orientation: {
      control: 'select',
      options: ['horizontal', 'vertical'],
      description: 'The orientation of the tabs',
      table: {
        type: { summary: "'horizontal' | 'vertical'" },
        defaultValue: { summary: "'horizontal'" },
      },
    },
    scrollButtons: {
      control: 'select',
      options: ['auto', true, false],
      description: 'Determine behavior of scroll buttons when tabs are set to scroll',
      table: {
        type: { summary: "'auto' | true | false" },
        defaultValue: { summary: "'auto'" },
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Tabs>;

/**
 * Basic tabs
 */
export const Basic: Story = {
  render: () => {
    const [value, setValue] = useState(0);
    return (
      <Box sx={{ width: '100%', maxWidth: 600 }}>
        <Tabs value={value} onChange={(e, newValue) => setValue(newValue)}>
          <MuiTab label="Item One" />
          <MuiTab label="Item Two" />
          <MuiTab label="Item Three" />
        </Tabs>
        <TabPanel value={value} index={0}>
          <Typography>Content for Item One</Typography>
        </TabPanel>
        <TabPanel value={value} index={1}>
          <Typography>Content for Item Two</Typography>
        </TabPanel>
        <TabPanel value={value} index={2}>
          <Typography>Content for Item Three</Typography>
        </TabPanel>
      </Box>
    );
  },
};

/**
 * Scrollable tabs
 */
export const Scrollable: Story = {
  render: () => {
    const [value, setValue] = useState(0);
    return (
      <Box sx={{ width: '100%', maxWidth: 400 }}>
        <Tabs
          value={value}
          onChange={(e, newValue) => setValue(newValue)}
          variant="scrollable"
          scrollButtons="auto"
        >
          {['Tab 1', 'Tab 2', 'Tab 3', 'Tab 4', 'Tab 5', 'Tab 6', 'Tab 7'].map((label, index) => (
            <MuiTab key={index} label={label} />
          ))}
        </Tabs>
      </Box>
    );
  },
};

/**
 * Full width tabs
 */
export const FullWidth: Story = {
  render: () => {
    const [value, setValue] = useState(0);
    return (
      <Box sx={{ width: '100%', maxWidth: 600 }}>
        <Tabs
          value={value}
          onChange={(e, newValue) => setValue(newValue)}
          variant="fullWidth"
        >
          <MuiTab label="Item One" />
          <MuiTab label="Item Two" />
          <MuiTab label="Item Three" />
        </Tabs>
      </Box>
    );
  },
};

/**
 * Vertical tabs
 */
export const Vertical: Story = {
  render: () => {
    const [value, setValue] = useState(0);
    return (
      <Box sx={{ display: 'flex', width: '100%', maxWidth: 600, height: 300 }}>
        <Tabs
          value={value}
          onChange={(e, newValue) => setValue(newValue)}
          orientation="vertical"
          variant="scrollable"
        >
          <MuiTab label="Item One" />
          <MuiTab label="Item Two" />
          <MuiTab label="Item Three" />
          <MuiTab label="Item Four" />
        </Tabs>
        <Box sx={{ p: 3, flex: 1 }}>
          <TabPanel value={value} index={0}>
            <Typography>Content for Item One</Typography>
          </TabPanel>
          <TabPanel value={value} index={1}>
            <Typography>Content for Item Two</Typography>
          </TabPanel>
          <TabPanel value={value} index={2}>
            <Typography>Content for Item Three</Typography>
          </TabPanel>
          <TabPanel value={value} index={3}>
            <Typography>Content for Item Four</Typography>
          </TabPanel>
        </Box>
      </Box>
    );
  },
};

/**
 * Tabs with icons
 */
export const WithIcons: Story = {
  render: () => {
    const [value, setValue] = useState(0);
    return (
      <Box sx={{ width: '100%', maxWidth: 600 }}>
        <Tabs value={value} onChange={(e, newValue) => setValue(newValue)}>
          <MuiTab icon={<Icon name="chart-bar" size="sm" />} label="Dashboard" iconPosition="start" />
          <MuiTab icon={<Icon name="envelope" size="sm" />} label="Messages" iconPosition="start" />
          <MuiTab icon={<Icon name="gear" size="sm" />} label="Settings" iconPosition="start" />
        </Tabs>
      </Box>
    );
  },
};

/**
 * Interactive tabs with all controls
 */
export const Interactive: Story = {
  args: {
    variant: 'standard',
    orientation: 'horizontal',
    scrollButtons: 'auto',
  },
  render: (args) => {
    const [value, setValue] = useState(0);
    return (
      <Box sx={{ width: '100%', maxWidth: 600 }}>
        <Tabs
          {...args}
          value={value}
          onChange={(e, newValue) => setValue(newValue)}
        >
          <MuiTab label="Tab One" />
          <MuiTab label="Tab Two" />
          <MuiTab label="Tab Three" />
        </Tabs>
      </Box>
    );
  },
};
