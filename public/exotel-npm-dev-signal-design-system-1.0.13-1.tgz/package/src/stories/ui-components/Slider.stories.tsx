import type { Meta, StoryObj } from '@storybook/react';
import { Slider } from '../../components';

const meta: Meta<typeof Slider> = {
  title: 'UI Components/Slider',
  component: Slider,
  parameters: { layout: 'centered' },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof Slider>;

export const Basic: Story = { args: { defaultValue: 30 } };
export const Disabled: Story = { args: { defaultValue: 30, disabled: true } };
