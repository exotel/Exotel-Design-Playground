import type { Meta, StoryObj } from '@storybook/react';
import { Tooltip, Button } from '../../components';

const meta: Meta<typeof Tooltip> = {
  title: 'UI Components/Tooltip',
  component: Tooltip,
  parameters: { layout: 'centered' },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof Tooltip>;

export const Basic: Story = {
  render: () => (
    <Tooltip title="This is a tooltip">
      <Button>Hover me</Button>
    </Tooltip>
  ),
};
