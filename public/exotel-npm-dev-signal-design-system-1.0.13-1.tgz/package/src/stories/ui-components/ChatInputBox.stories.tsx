import { useState, useCallback } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { ChatInputBox, Box } from '../../components';
import type { ChatInputAttachment, MentionSuggestion } from '../../components';

const allMembers: MentionSuggestion[] = [
  { id: 'u1', label: 'Samarth Kumar', secondary: 'samarth@exotel.com', avatar: '' },
  { id: 'u2', label: 'Priya Sharma', secondary: 'priya@exotel.com', avatar: '' },
  { id: 'u3', label: 'Rahul Verma', secondary: 'rahul@exotel.com', avatar: '' },
  { id: 'u4', label: 'Sales Campaign', secondary: 'Campaign', avatar: '' },
  { id: 'u5', label: 'Support Queue', secondary: 'Queue', avatar: '' },
  { id: 'u6', label: 'Inbound Campaign', secondary: 'Campaign', avatar: '' },
  { id: 'u7', label: 'Premium Support Queue', secondary: 'Queue', avatar: '' },
  { id: 'u8', label: 'Outbound Sales', secondary: 'Campaign', avatar: '' },
];

const meta: Meta<typeof ChatInputBox> = {
  title: 'UI Components/ChatInputBox',
  component: ChatInputBox,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'A chat input box component supporting text input, file attachments, inline @mentions with search-as-you-type suggestions, ' +
          'character count, and a send button. Attachments render above the text area. ' +
          'Type `@` in the input to open the mention popover — selected mentions are inserted inline as highlighted text. ' +
          'The search query is passed to the parent via `onMentionSearch` for backend filtering.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    placeholder: {
      control: 'text',
      description: 'Placeholder text',
    },
    maxLength: {
      control: 'number',
      description: 'Maximum character count',
    },
    disabled: {
      control: 'boolean',
      description: 'Disables the entire input',
    },
    mentionLoading: {
      control: 'boolean',
      description: 'Shows loading spinner in mention popover',
    },
  },
  decorators: [
    (Story) => (
      <Box sx={{ width: 608, p: 4, display: 'flex', justifyContent: 'center' }}>
        <Story />
      </Box>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof ChatInputBox>;

export const Default: Story = {
  args: {
    placeholder: 'Type @ to select processes, campaigns and queues you want to configure',
    maxLength: 200,
  },
};

export const WithMentionSearch: Story = {
  render: () => {
    const Demo = () => {
      const [value, setValue] = useState('');
      const [suggestions, setSuggestions] = useState<MentionSuggestion[]>([]);
      const [loading, setLoading] = useState(false);

      const handleMentionSearch = useCallback((query: string) => {
        setLoading(true);
        setTimeout(() => {
          const filtered = allMembers.filter(
            (m) => m.label.toLowerCase().includes(query.toLowerCase())
          );
          setSuggestions(filtered);
          setLoading(false);
        }, 300);
      }, []);

      const handleMentionSelect = useCallback((suggestion: MentionSuggestion) => {
        console.log('Mention selected:', suggestion);
      }, []);

      return (
        <ChatInputBox
          value={value}
          onChange={setValue}
          mentionSuggestions={suggestions}
          onMentionSearch={handleMentionSearch}
          onMentionSelect={handleMentionSelect}
          mentionLoading={loading}
          onSend={(text, _atts, mentionsList) => {
            console.log('Sent:', { text, mentions: mentionsList });
          }}
          maxLength={200}
          placeholder="Type @ to mention someone..."
        />
      );
    };
    return <Demo />;
  },
};

export const WithAttachments: Story = {
  render: () => {
    const Demo = () => {
      const [attachments, setAttachments] = useState<ChatInputAttachment[]>([
        { id: '1', name: 'campaign-config.json', type: 'application/json', size: 2400 },
        { id: '2', name: 'agent-list.csv', type: 'text/csv', size: 15600 },
      ]);

      return (
        <ChatInputBox
          attachments={attachments}
          onAttach={(files) => {
            const newAttachments = files.map((file) => ({
              id: String(Date.now()) + file.name,
              name: file.name,
              type: file.type,
              size: file.size,
              file,
            }));
            setAttachments((prev) => [...prev, ...newAttachments]);
          }}
          onRemoveAttachment={(id) => setAttachments((prev) => prev.filter((a) => a.id !== id))}
          onSend={(text, atts) => {
            console.log('Sent:', { text, attachments: atts });
            console.log('Files ready for upload:', atts.map((a) => a.file).filter(Boolean));
          }}
          maxLength={200}
        />
      );
    };
    return <Demo />;
  },
};

export const Interactive: Story = {
  render: () => {
    const Demo = () => {
      const [value, setValue] = useState('');
      const [attachments, setAttachments] = useState<ChatInputAttachment[]>([]);
      const [suggestions, setSuggestions] = useState<MentionSuggestion[]>([]);
      const [loading, setLoading] = useState(false);

      const handleMentionSearch = useCallback((query: string) => {
        setLoading(true);
        setTimeout(() => {
          setSuggestions(
            allMembers.filter((m) => m.label.toLowerCase().includes(query.toLowerCase()))
          );
          setLoading(false);
        }, 300);
      }, []);

      const handleMentionSelect = useCallback((suggestion: MentionSuggestion) => {
        console.log('Mention selected:', suggestion);
      }, []);

      return (
        <ChatInputBox
          value={value}
          onChange={setValue}
          attachments={attachments}
          onAttach={(files) => {
            const newAttachments = files.map((file) => ({
              id: String(Date.now()) + file.name,
              name: file.name,
              type: file.type,
              size: file.size,
              file,
            }));
            setAttachments((prev) => [...prev, ...newAttachments]);
          }}
          onRemoveAttachment={(id) => setAttachments((prev) => prev.filter((a) => a.id !== id))}
          mentionSuggestions={suggestions}
          onMentionSearch={handleMentionSearch}
          onMentionSelect={handleMentionSelect}
          mentionLoading={loading}
          onSend={(text, atts, mentionsList) => {
            alert(
              `Sent!\nText: ${text}\nAttachments: ${atts.map((a) => a.name).join(', ')}\nMentions: ${mentionsList.map((m) => m.label).join(', ')}`
            );
          }}
          maxLength={200}
          placeholder="Type @ to mention someone..."
        />
      );
    };
    return <Demo />;
  },
};

export const Disabled: Story = {
  args: {
    disabled: true,
    placeholder: 'This input is disabled',
    maxLength: 200,
  },
};
