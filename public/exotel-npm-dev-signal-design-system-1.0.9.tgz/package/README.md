# @exotel/design-system

Exotel's Design System package - the single source of truth for all Exotel frontend teams.

## Overview

This package provides:
- **Components**: Reusable UI components built on top of Material-UI (MUI)
- **Theme**: Exotel's design tokens and theme configuration
- **Storybook**: Component documentation and playground (coming soon)

This package **wraps** MUI without modifying it, providing Exotel-specific components and theming.

## Project Structure

```
src/
  components/     # Reusable UI components built on top of MUI
  theme/          # Exotel's design tokens and theme configuration
  index.ts        # Main entry point - exports all public APIs
```

## Development

### Prerequisites

- Node.js 18+
- npm or yarn

### Setup

```bash
npm install
```

### Build

```bash
npm run build
```

This generates:
- ES modules: `dist/exotel-design-system.es.js`
- CommonJS: `dist/exotel-design-system.cjs.js`
- TypeScript declarations: `dist/index.d.ts`

### Type Checking

```bash
npm run type-check
```

### Linting

```bash
npm run lint
```

## Publishing

This package will be published as `@exotel/design-system` to npm.

## Dependencies

- `react`, `react-dom` - React framework
- `@mui/material` - Material-UI components
- `@mui/icons-material` - Material-UI icons
- `@emotion/react`, `@emotion/styled` - CSS-in-JS styling (required by MUI)

## License

[To be determined]
