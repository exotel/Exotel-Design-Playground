import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import dayjs, { type Dayjs } from 'dayjs';
import { DateTimeRangePicker, type DateTimeRangePickerProps } from '../../components';
import type { DateRange } from '@mui/x-date-pickers-pro';

const meta: Meta<typeof DateTimeRangePicker> = {
  title: 'Date & Time Pickers/DateTimeRangePicker',
  component: DateTimeRangePicker,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          "Exotel-approved date-time range picker that wraps MUI X DateTimeRangePicker (pro). Allows selection of a start and end date-time. Includes a built-in LocalizationProvider with dayjs.",
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
      description: 'The size of the picker input',
      table: {
        type: { summary: "'small' | 'medium' | 'large'" },
        defaultValue: { summary: "'medium'" },
      },
    },
    label: {
      control: 'text',
      description: 'External label rendered above the picker',
      table: { type: { summary: 'ReactNode' } },
    },
    disabled: {
      control: 'boolean',
      description: 'If true, the picker is disabled',
      table: { type: { summary: 'boolean' }, defaultValue: { summary: 'false' } },
    },
    readOnly: {
      control: 'boolean',
      description: 'If true, the picker is read-only',
      table: { type: { summary: 'boolean' }, defaultValue: { summary: 'false' } },
    },
    disableFuture: {
      control: 'boolean',
      description: 'If true, future dates are disabled',
      table: { type: { summary: 'boolean' }, defaultValue: { summary: 'false' } },
    },
    disablePast: {
      control: 'boolean',
      description: 'If true, past dates are disabled',
      table: { type: { summary: 'boolean' }, defaultValue: { summary: 'false' } },
    },
    ampm: {
      control: 'boolean',
      description: 'If true, uses 12-hour format with AM/PM',
      table: { type: { summary: 'boolean' }, defaultValue: { summary: 'true' } },
    },
  },
};

export default meta;
type Story = StoryObj<typeof DateTimeRangePicker>;

/**
 * Basic date-time range picker with a label.
 */
export const Basic: Story = {
  render: () => <DateTimeRangePicker label="Select date-time range" />,
};

/**
 * All three sizes — small (32px), medium (40px), and large (50px) — matching EnhancedTextField.
 */
export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16, minWidth: 600 }}>
      <DateTimeRangePicker label="Small" size="small" />
      <DateTimeRangePicker label="Medium" size="medium" />
      <DateTimeRangePicker label="Large" size="large" />
    </div>
  ),
};

/**
 * Controlled date-time range picker with React state.
 */
export const Controlled: Story = {
  render: () => {
    const [value, setValue] = useState<DateRange<Dayjs>>([null, null]);
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16, minWidth: 600 }}>
        <DateTimeRangePicker
          label="Date-time range"
          value={value}
          onChange={(newValue) => setValue(newValue)}
        />
        <div style={{ fontSize: 14, color: '#666' }}>
          Start: {value[0] ? value[0].format('MMM D, YYYY hh:mm A') : 'None'}
          {' — '}
          End: {value[1] ? value[1].format('MMM D, YYYY hh:mm A') : 'None'}
        </div>
      </div>
    );
  },
};

/**
 * Without an external label.
 */
export const WithoutLabel: Story = {
  render: () => <DateTimeRangePicker />,
};

/**
 * Disabled state.
 */
export const Disabled: Story = {
  render: () => (
    <DateTimeRangePicker
      label="Disabled"
      disabled
      defaultValue={[dayjs(), dayjs().add(3, 'day').hour(17).minute(0)]}
    />
  ),
};

/**
 * Read-only state.
 */
export const ReadOnly: Story = {
  render: () => (
    <DateTimeRangePicker
      label="Read only"
      readOnly
      defaultValue={[dayjs(), dayjs().add(3, 'day').hour(17).minute(0)]}
    />
  ),
};

/**
 * Only future dates are selectable.
 */
export const DisablePast: Story = {
  render: () => <DateTimeRangePicker label="Future only" disablePast />,
};

/**
 * 24-hour format (no AM/PM).
 */
export const TwentyFourHour: Story = {
  render: () => <DateTimeRangePicker label="24-hour format" ampm={false} />,
};

/**
 * Restrict to a specific date window.
 */
export const MinMaxDate: Story = {
  render: () => (
    <DateTimeRangePicker
      label="This month only"
      minDateTime={dayjs().startOf('month')}
      maxDateTime={dayjs().endOf('month')}
    />
  ),
};

/**
 * With built-in default shortcuts panel (Today, Yesterday, Last 7 Days, etc.).
 */
export const WithoutShortcuts: Story = {
  render: () => <DateTimeRangePicker label="Without shortcuts" shortcuts={false} />,
};

/**
 * Interactive playground with all controls.
 */
export const Interactive: Story = {
  args: {
    label: 'Pick a date-time range',
    size: 'medium',
    disabled: false,
    readOnly: false,
    disableFuture: false,
    disablePast: false,
    ampm: true,
  },
  render: (args: DateTimeRangePickerProps) => <DateTimeRangePicker {...args} />,
};
