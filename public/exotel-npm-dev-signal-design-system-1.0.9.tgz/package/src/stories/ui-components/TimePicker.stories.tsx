import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import dayjs, { type Dayjs } from 'dayjs';
import { TimePicker, type TimePickerProps } from '../../components';

const meta: Meta<typeof TimePicker> = {
  title: 'Date & Time Pickers/TimePicker',
  component: TimePicker,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          "Exotel-approved time picker that wraps MUI X TimePicker. Includes a built-in LocalizationProvider with dayjs so consumers don't need to add one.",
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
      description: 'The size of the picker input',
      table: {
        type: { summary: "'small' | 'medium' | 'large'" },
        defaultValue: { summary: "'medium'" },
      },
    },
    label: {
      control: 'text',
      description: 'External label rendered above the picker',
      table: { type: { summary: 'ReactNode' } },
    },
    disabled: {
      control: 'boolean',
      description: 'If true, the picker is disabled',
      table: { type: { summary: 'boolean' }, defaultValue: { summary: 'false' } },
    },
    readOnly: {
      control: 'boolean',
      description: 'If true, the picker is read-only',
      table: { type: { summary: 'boolean' }, defaultValue: { summary: 'false' } },
    },
    ampm: {
      control: 'boolean',
      description: 'If true, uses 12-hour format with AM/PM',
      table: { type: { summary: 'boolean' }, defaultValue: { summary: 'true' } },
    },
  },
};

export default meta;
type Story = StoryObj<typeof TimePicker>;

/**
 * Basic time picker with a label.
 */
export const Basic: Story = {
  render: () => <TimePicker label="Select time" />,
};

/**
 * All three sizes — small (32px), medium (40px), and large (50px) — matching EnhancedTextField.
 */
export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16, width: 300 }}>
      <TimePicker label="Small" size="small" />
      <TimePicker label="Medium" size="medium" />
      <TimePicker label="Large" size="large" />
    </div>
  ),
};

/**
 * Controlled time picker with React state.
 */
export const Controlled: Story = {
  render: () => {
    const [value, setValue] = useState<Dayjs | null>(dayjs());
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16, width: 300 }}>
        <TimePicker label="Time" value={value} onChange={(newValue) => setValue(newValue)} />
        <div style={{ fontSize: 14, color: '#666' }}>
          Selected: {value ? value.format('hh:mm A') : 'None'}
        </div>
      </div>
    );
  },
};

/**
 * Without an external label.
 */
export const WithoutLabel: Story = {
  render: () => <TimePicker />,
};

/**
 * Time picker in disabled state.
 */
export const Disabled: Story = {
  render: () => <TimePicker label="Disabled" disabled defaultValue={dayjs()} />,
};

/**
 * Read-only time picker.
 */
export const ReadOnly: Story = {
  render: () => <TimePicker label="Read only" readOnly defaultValue={dayjs()} />,
};

/**
 * 24-hour format (no AM/PM).
 */
export const TwentyFourHour: Story = {
  render: () => <TimePicker label="24-hour format" ampm={false} />,
};

/**
 * With seconds visible.
 */
export const WithSeconds: Story = {
  render: () => (
    <TimePicker label="Include seconds" views={['hours', 'minutes', 'seconds']} format="hh:mm:ss A" />
  ),
};

/**
 * Restrict to specific time range.
 */
export const MinMaxTime: Story = {
  render: () => (
    <TimePicker
      label="Business hours (9 AM – 5 PM)"
      minTime={dayjs().hour(9).minute(0)}
      maxTime={dayjs().hour(17).minute(0)}
    />
  ),
};

/**
 * Interactive playground with all controls.
 */
export const Interactive: Story = {
  args: {
    label: 'Pick a time',
    size: 'medium',
    disabled: false,
    readOnly: false,
    ampm: true,
  },
  render: (args: TimePickerProps) => <TimePicker {...args} />,
};
