/**
 * MultiSelect Component
 * 
 * A multi-select dropdown component with support for grouped options,
 * select all functionality, and tree structure.
 */

import React, { useState, useRef } from 'react';
import {
  Popper,
  ClickAwayListener,
  useTheme,
} from '@mui/material';
import { Checkbox } from '../Checkbox';
import { ListItemText } from '../List/ListItemText';
import { Paper } from '../Paper';
import { List } from '../List';
import { ListItem } from '../List/ListItem';
import { IconButton } from '../IconButton';
import { Box } from '../Box';
import { Typography } from '../Typography';
import { Divider } from '../Divider';
import { InputAdornment } from '@mui/material';
import { EnhancedTextField } from '../EnhancedTextField';
import { Icon, type IconName } from '../Icon';

export interface MultiSelectOption {
  /**
   * Unique identifier for the option
   */
  id: string;
  /**
   * Display label for the option
   */
  label: string;
  /**
   * Value of the option
   */
  value: string;
  /**
   * Parent option ID (for nested options)
   */
  parentId?: string;
  /**
   * Whether this is a group header
   */
  isGroup?: boolean;
  /**
   * Whether this option is disabled
   */
  disabled?: boolean;
  /**
   * Children options
   */
  children?: MultiSelectOption[];
}

export interface MultiSelectProps {
  /**
   * Label for the select
   */
  label: string;
  /**
   * Array of options
   */
  options: MultiSelectOption[];
  /**
   * Selected values
   */
  value: string[];
  /**
   * Change handler
   */
  onChange: (values: string[]) => void;
  /**
   * Placeholder text
   */
  placeholder?: string;
  /**
   * Whether the select is disabled
   */
  disabled?: boolean;
  /**
   * Width of the component
   */
  width?: number | string;
  /**
   * Enable select all functionality
   */
  showSelectAll?: boolean;
  /**
   * Whether to show clear button
   */
  clearable?: boolean;
  /**
   * Maximum number of items to show in the field
   */
  maxDisplayItems?: number;
  /**
   * When false, the closed field always shows `label` only; selected values appear elsewhere (e.g. applied-filters chips).
   * @default true
   */
  showSelectedValuesInTrigger?: boolean;
  /**
   * Icon displayed at the start of the trigger field.
   */
  iconName?: IconName;
}

export const MultiSelect = React.forwardRef<HTMLDivElement, MultiSelectProps>(
  (props, ref) => {
    const {
      label,
      options,
      value = [],
      onChange,
      placeholder = 'Select items',
      disabled = false,
      width,
      showSelectAll = true,
      clearable = true,
      maxDisplayItems = 2,
      showSelectedValuesInTrigger = true,
      iconName,
    } = props;

    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
    const [open, setOpen] = useState(false);
    const inputRef = useRef<HTMLDivElement>(null);
    const theme = useTheme();

    const handleClick = (event: React.MouseEvent<HTMLElement>) => {
      if (!disabled) {
        setAnchorEl(event.currentTarget);
        setOpen((prev) => !prev);
      }
    };

    const handleClose = () => {
      setOpen(false);
    };

    const handleClear = (event: React.MouseEvent) => {
      event.stopPropagation();
      onChange([]);
    };

    // Get all non-group options
    const selectableOptions = options.filter((opt) => !opt.isGroup && !opt.disabled);

    // Check if all selectable items are selected
    const allSelected = selectableOptions.length > 0 && 
      selectableOptions.every((opt) => value.includes(opt.value));

    const handleSelectAll = () => {
      if (allSelected) {
        // Deselect all
        onChange([]);
      } else {
        // Select all selectable options
        onChange(selectableOptions.map((opt) => opt.value));
      }
    };

    const handleToggleOption = (optionValue: string) => {
      const option = options.find((opt) => opt.value === optionValue);
      if (option?.disabled) return;

      const currentIndex = value.indexOf(optionValue);
      const newValue = [...value];

      if (currentIndex === -1) {
        newValue.push(optionValue);
      } else {
        newValue.splice(currentIndex, 1);
      }

      onChange(newValue);
    };

    // Get display text
    const getDisplayText = () => {
      if (!showSelectedValuesInTrigger) {
        return label;
      }
      if (value.length === 0) return placeholder;

      const selectedOptions = options.filter(
        (opt) => value.includes(opt.value) && !opt.isGroup
      );

      if (selectedOptions.length <= maxDisplayItems) {
        return selectedOptions.map((opt) => opt.label).join(', ');
      }

      const firstItems = selectedOptions
        .slice(0, maxDisplayItems)
        .map((opt) => opt.label)
        .join(', ');
      const remaining = selectedOptions.length - maxDisplayItems;
      return `${firstItems} +${remaining}`;
    };

    // Group options by parent
    const groupedOptions: { [key: string]: MultiSelectOption[] } = {};
    const rootOptions: MultiSelectOption[] = [];

    options.forEach((option) => {
      if (option.parentId) {
        if (!groupedOptions[option.parentId]) {
          groupedOptions[option.parentId] = [];
        }
        groupedOptions[option.parentId].push(option);
      } else {
        rootOptions.push(option);
      }
    });

    const renderOption = (option: MultiSelectOption, depth: number = 0) => {
      const isChecked = value.includes(option.value);
      const children = groupedOptions[option.id] || [];

      if (option.isGroup) {
        return (
          <React.Fragment key={option.id}>
            <ListItem
              sx={{
                pl: depth * 2 + 2,
                py: 0.5,
                cursor: 'default',
              }}
            >
              <Typography variant="body2" fontWeight={600} color="text.secondary">
                {option.label}
              </Typography>
            </ListItem>
            {children.map((child) => renderOption(child, depth + 1))}
          </React.Fragment>
        );
      }

      return (
        <React.Fragment key={option.id}>
          <ListItem
            onClick={() => !option.disabled && handleToggleOption(option.value)}
            sx={{
              pl: depth * 2 + 2,
              py: 0.5,
              cursor: option.disabled ? 'default' : 'pointer',
              '&:hover': {
                backgroundColor: option.disabled ? 'transparent' : 'action.hover',
              },
              opacity: option.disabled ? 0.5 : 1,
            }}
          >
            <Checkbox
              checked={isChecked}
              disabled={option.disabled}
              sx={{ py: 0, px: 1 }}
            />
            <ListItemText
              primary={option.label}
              primaryTypographyProps={{
                variant: 'body2',
              }}
            />
          </ListItem>
          {children.map((child) => renderOption(child, depth + 1))}
        </React.Fragment>
      );
    };

    return (
      <ClickAwayListener onClickAway={handleClose}>
        <div ref={ref}>
          <EnhancedTextField
            ref={inputRef}
            label={label}
            showLabel={showSelectedValuesInTrigger}
            value={getDisplayText()}
            size="small"
            disabled={disabled}
            placeholder={placeholder}
            InputProps={{
              sx: {
                '& .MuiInputAdornment-root': {
                  marginRight: 'unset'
                },
                '& .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'var(--mui-palette-Chip-defaultBorder)',
                }
              },
              readOnly: true,
              onClick: handleClick,
              startAdornment: iconName ? (
                <InputAdornment position="start">
                  <Icon name={iconName} size="sm" />
                </InputAdornment>
              ) : undefined,
              endAdornment: (
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                  {clearable && showSelectedValuesInTrigger && value.length > 0 && !disabled && (
                    <IconButton
                      size="small"
                      onClick={handleClear}
                      sx={{ p: 0.5 }}
                    >
                      <Icon name="x" size="xs" weight='bold' />
                    </IconButton>
                  )}
                  <Icon width={14} color={theme.vars?.palette?.text?.secondary} name="caret-down" weight='fill' size="xs" />
                </Box>
              ),
            }}
            sx={{
              minWidth: width || 'fit-content',
              cursor: disabled ? 'default' : 'pointer',
              '& input': {
                cursor: disabled ? 'default' : 'pointer',
              },
            }}
          />
          <Popper
            open={open}
            anchorEl={anchorEl}
            placement="bottom-start"
            style={{ zIndex: 1300, minWidth: anchorEl?.offsetWidth }}
          >
            <Paper
              elevation={8}
              sx={{
                maxHeight: 400,
                overflow: 'auto',
              }}
            >
              <List dense sx={{ py: 0 }}>
                {showSelectAll && selectableOptions.length > 0 && (
                  <>
                    <ListItem
                      onClick={handleSelectAll}
                      sx={{
                        cursor: 'pointer',
                        '&:hover': {
                          backgroundColor: 'action.hover',
                        },
                        py: 1,
                      }}
                    >
                      <Checkbox
                        checked={allSelected}
                        indeterminate={
                          value.length > 0 && value.length < selectableOptions.length
                        }
                        sx={{ py: 0, px: 1 }}
                      />
                      <ListItemText
                        primary="Select All"
                        primaryTypographyProps={{
                          variant: 'body2',
                          fontWeight: 600,
                        }}
                      />
                    </ListItem>
                    <Divider />
                  </>
                )}
                {rootOptions.map((option) => renderOption(option, 0))}
              </List>
            </Paper>
          </Popper>
        </div>
      </ClickAwayListener>
    );
  }
);

MultiSelect.displayName = 'MultiSelect';
