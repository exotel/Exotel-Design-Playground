/**
 * DataGrid Component
 *
 * A thin abstraction layer over MUI X DataGridPro that provides a consistent API
 * while preserving full access to the underlying component's capabilities.
 *
 * This component does NOT add opinionated defaults - it forwards all props directly.
 *
 * Usage:
 * ```tsx
 * import { DataGrid } from '@exotel/design-system';
 *
 * <DataGrid
 *   rows={rows}
 *   columns={columns}
 *   // All MUI DataGridPro props are supported
 * />
 * ```
 */

import { DataGridPro } from '@mui/x-data-grid-pro';
import type { GridColDef } from '@mui/x-data-grid-pro';
import { forwardRef, useState, useMemo, useCallback } from 'react';
import { Box } from '@mui/material';
import { buildAppliedFilters } from './appliedFilters';
import { getInitialFilterValues } from './functions';
import { CustomToolbar } from './toolbar/CustomToolbar';
import { PageHeader } from '../PageHeader';
import { Icon } from '../Icon';
import type { DataGridColDef, DataGridProps, FilterRecords, FilterValue } from './types';
import { Stack } from '../Stack';
import { Typography } from '../Typography';

export type {
  BulkDeleteConfig,
  DataGridColDef,
  DataGridTableHeaderProps,
  DataGridProps,
  DateRangeValue,
  FilterRecords,
  FilterValue,
  ToolbarButtonConfig,
  ToolbarFilterConfig,
} from './types';

function renderColumnHeaderWithIcon(col: DataGridColDef) {
  return () => (
    <Stack direction="row" alignItems="center" gap={1}>
      {col.iconName && <Icon name={col.iconName} size="xs" />}
      <Typography variant='title2'>{col.headerName}</Typography>
    </Stack>
  );
}

function processColumns(columns: DataGridColDef[]): GridColDef[] {
  return columns.map((col) => {
    if (col.renderHeader) return col;
    return { ...col, renderHeader: renderColumnHeaderWithIcon(col) };
  });
}

/**
 * DataGrid Component
 *
 * A thin wrapper around MUI X DataGridPro that:
 * - Forwards all props to the underlying DataGridPro
 * - Maintains ref forwarding for DOM access
 * - Provides a consistent naming convention
 * - Enables toolbar with quick filter by default
 * - Does NOT duplicate MUI DataGridPro logic
 */
export const DataGrid = forwardRef<HTMLDivElement, DataGridProps>((props, ref) => {
  const {
    showToolbar = true,
    columns,
    customToolbarButtons,
    customToolbarFilters,
    onToolbarFiltersChange,
    onRefresh,
    showAppliedFilters = false,
    maxVisibleAppliedFilters = 4,
    bulkDeleteConfig,
    hideSort = false,
    tableHeader,
    slots,
    slotProps,
    sortModel,
    onSortModelChange,
    sx,
    ...rest
  } = props;

  const resolvedColumns = useMemo(() => processColumns(columns), [columns]);

  const [filterValues, setFilterValues] = useState<FilterRecords>(() =>
    getInitialFilterValues(customToolbarFilters)
  );

  const handleFilterValuesChange = useCallback((id: string, value: FilterValue) => {
    setFilterValues((prev) => {
      const newValues = { ...prev, [id]: value };
      onToolbarFiltersChange?.(newValues);
      return newValues;
    });
  }, []);

  const handleClearAllFilters = useCallback(() => {
    const initialValues = getInitialFilterValues(customToolbarFilters);
    setFilterValues(initialValues);
    onToolbarFiltersChange?.(initialValues);
  }, [customToolbarFilters]);

  const appliedFilters = useMemo(
    () => buildAppliedFilters(customToolbarFilters, filterValues),
    [customToolbarFilters, filterValues]
  );

  return (
    <Box height='100%' display='flex' flexDirection='column'>
      {tableHeader && <PageHeader {...tableHeader} />}
      <DataGridPro
        ref={ref}
        columns={resolvedColumns}
        sx={{
          padding: (theme) => theme.spacing(0.5, 2, 1.5, 2),
          backgroundColor: 'surface.elevation1',
          flex: 1,
          ...sx
        }}
        showToolbar={showToolbar}
        slots={{
          toolbar: CustomToolbar,
          ...slots,
        }}
        sortingMode="server"
        sortModel={sortModel}
        onSortModelChange={onSortModelChange}
        slotProps={{
          toolbar: {
            customButtons: customToolbarButtons,
            customFilters: customToolbarFilters,
            appliedFilters: appliedFilters,
            showAppliedFilters: showAppliedFilters,
            maxVisibleAppliedFilters: maxVisibleAppliedFilters,
            bulkDeleteConfig: bulkDeleteConfig,
            filterValues: filterValues,
            hideSort: hideSort,
            onFilterValuesChange: handleFilterValuesChange,
            onClearAllFilters: handleClearAllFilters,
            onRefresh: onRefresh,
            loading: rest.loading,
          } as any,
          ...slotProps,
        }}
        {...rest}
      />
    </Box>
  );
});

DataGrid.displayName = 'DataGrid';
