import type { ReactNode } from 'react';
import type { DataGridProProps, GridColDef, GridRowId, GridSortModel } from '@mui/x-data-grid-pro';
import type { Dayjs } from 'dayjs';
import type { MultiSelectOption } from '../MultiSelect';
import type { PageHeaderProps } from '../PageHeader';
import type { DateRangeShortcut } from '../DateRangePicker';
import type { IconName } from '../Icon';

/**
 * Date Range Value
 */
export interface DateRangeValue {
  startDate: Dayjs | null;
  endDate: Dayjs | null;
}

export type FilterValue = string | DateRangeValue | string[] | undefined;

export type FilterRecords = Record<string, FilterValue>;

/**
 * Custom Toolbar Button Configuration
 */
export interface ToolbarButtonConfig {
  id: string;
  icon: ReactNode;
  label: string;
  tooltip?: string;
  onClick: () => void;
  disabled?: boolean;
  color?: 'default' | 'primary' | 'secondary' | 'error' | 'info' | 'success' | 'warning';
}

/**
 * Custom Toolbar Filter Configuration
 */
export interface ToolbarFilterConfig {
  id: string;
  type: 'select' | 'date-range' | 'multi-select';
  label: string;
  iconName?: IconName;
  initialValue?: FilterValue;
  onChange?: (value: FilterValue) => void;
  options?: Array<{ value: string; label: string }>;
  multiSelectOptions?: MultiSelectOption[];
  placeholder?: string;
  width?: number;
  disabled?: boolean;
  shortcuts?: DateRangeShortcut[];
  allowPastDates?: boolean;
  allowFutureDates?: boolean;
  showSelectAll?: boolean;
  clearable?: boolean;
  maxDisplayItems?: number;
}

/**
 * Bulk Delete Configuration
 */
export interface BulkDeleteConfig {
  onDelete: (selectedIds: GridRowId[]) => void;
  label?: string | ((selectedCount: number) => string);
  icon?: ReactNode;
  disabled?: boolean;
}

export interface DataGridTableHeaderProps extends PageHeaderProps {};

/**
 * Extended column definition with optional header icon support.
 * When `iconName` is set, the column header renders the icon alongside `headerName`.
 */
export type DataGridColDef = GridColDef & {
  iconName?: IconName;
};

/**
 * DataGrid Props
 */
export interface DataGridProps extends Omit<DataGridProProps, 'ref' | 'columns'> {
  columns: DataGridColDef[];
  customToolbarButtons?: ToolbarButtonConfig[];
  customToolbarFilters?: ToolbarFilterConfig[];
  hideSort?: boolean;
  sortModel?: GridSortModel;
  onSortModelChange?: (sortModel: GridSortModel) => void;
  onToolbarFiltersChange?: (appliedFilters: FilterRecords) => void;
  onRefresh?: () => void;
  showAppliedFilters?: boolean;
  maxVisibleAppliedFilters?: number;
  bulkDeleteConfig?: BulkDeleteConfig;
  tableHeader?: DataGridTableHeaderProps;
}
