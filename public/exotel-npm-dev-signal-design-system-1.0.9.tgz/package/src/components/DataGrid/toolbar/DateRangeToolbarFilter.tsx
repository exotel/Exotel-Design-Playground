import { useState } from 'react';
import dayjs, { type Dayjs } from 'dayjs';
import { DateRangePicker } from '../../DateRangePicker';
import type { DateRangeValue, FilterValue, ToolbarFilterConfig } from '../types';
import { LabelOnlyDateRangeTextField } from './LabelOnlyDateRangeTextField';

export interface DateRangeToolbarFilterProps {
  filter: ToolbarFilterConfig;
  value: FilterValue;
  onFilterChange: (value: FilterValue, filter: ToolbarFilterConfig) => void;
}

const emptyRange: DateRangeValue = { startDate: null, endDate: null };

export function DateRangeToolbarFilter({ filter, value, onFilterChange }: DateRangeToolbarFilterProps) {
  const dateRangeValue = (value as DateRangeValue | undefined) ?? emptyRange;
  const [tempValue, setTempValue] = useState<DateRangeValue>(dateRangeValue);
  const [isOpen, setIsOpen] = useState(false);

  return (
    <DateRangePicker
      shortcuts={filter.shortcuts}
      enableAccessibleFieldDOMStructure={false}
      open={isOpen}
      onOpen={() => {
        setIsOpen(true);
        setTempValue(dateRangeValue);
      }}
      onClose={() => setIsOpen(false)}
      value={[tempValue.startDate, tempValue.endDate]}
      onChange={(newValue) => {
        if (newValue && Array.isArray(newValue)) {
          setTempValue({
            startDate: newValue[0] as Dayjs,
            endDate: newValue[1] as Dayjs,
          });
        }
      }}
      onAccept={(newValue) => {
        if (newValue && Array.isArray(newValue)) {
          const [startDate, endDate] = newValue;
          if (startDate && endDate) {
            onFilterChange(
              { startDate: startDate as Dayjs, endDate: endDate as Dayjs },
              filter
            );
          }
        }
        setIsOpen(false);
      }}
      disabled={filter.disabled}
      closeOnSelect={false}
      minDate={filter.allowPastDates === false ? dayjs().startOf('day') : undefined}
      maxDate={filter.allowFutureDates === false ? dayjs().endOf('day') : undefined}
      slots={{
        textField: LabelOnlyDateRangeTextField,
        clearButton: () => <></>,
      }}
      slotProps={{
        field: {
          clearable: true,
          onClear: () => {
            onFilterChange(emptyRange, filter);
          },
        },
        textField: {
          filterLabel: filter.label,
          size: 'small',
          sx: {
            minWidth: filter.width,
            '& .MuiOutlinedInput-notchedOutline': {
              borderColor: 'var(--mui-palette-Chip-defaultBorder)',
            }
          },
          onClick: (event: React.MouseEvent) => {
            event.stopPropagation();
            if (!isOpen) setIsOpen(true);
          },
        } as any,
        shortcuts: {
          changeImportance: 'accept',
        },
        actionBar: {
          actions: ['cancel', 'accept'],
        },
      }}
    />
  );
}
