import { InputAdornment, MenuItem } from '@mui/material';
import { MultiSelect } from '../../MultiSelect';
import { EnhancedTextField } from '../../EnhancedTextField';
import { Icon } from '../../Icon';
import type { FilterRecords, FilterValue, ToolbarFilterConfig } from '../types';
import { DateRangeToolbarFilter } from './DateRangeToolbarFilter';

export interface ToolbarFilterFieldProps {
  filter: ToolbarFilterConfig;
  filterValues: FilterRecords;
  onFilterChange: (value: FilterValue, filter: ToolbarFilterConfig) => void;
}

export function ToolbarFilterField({ filter, filterValues, onFilterChange }: ToolbarFilterFieldProps) {
  const commonProps = {
    disabled: filter.disabled,
    size: 'small' as const,
    sx: { minWidth: filter.width }
  };

  switch (filter.type) {
    case 'select':
      return (
        <EnhancedTextField
          {...commonProps}
          id={filter.id}
          key={filter.id}
          showLabel={false}
          select
          value={filterValues[filter.id] ?? ''}
          slotProps={{
            select: {
              displayEmpty: true,
              renderValue: () => filter.label,
              MenuProps: {
                anchorOrigin: {
                  vertical: 'bottom', 
                  horizontal: 'left',
                },
                transformOrigin: {
                  vertical: 'top',
                  horizontal: 'left',
                }
              }
            },
            input: {
              startAdornment: filter.iconName ? (
                <InputAdornment position="start">
                  <Icon name={filter.iconName} size="sm" />
                </InputAdornment>
              ) : undefined,
              sx: {
                '& .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'var(--mui-palette-Chip-defaultBorder)',
                },
                '& .MuiInputAdornment-root': {
                  marginRight: 'unset'
                }
              }
            }
          }}
          onChange={(e) => {
            onFilterChange(e.target.value, filter);
          }}
        >
          {filter.options?.map((option) => (
            <MenuItem key={option.value} value={option.value}>
              {option.label}
            </MenuItem>
          ))}
        </EnhancedTextField>
      );

    case 'multi-select':
      return (
        <MultiSelect
          key={filter.id}
          label={filter.label}
          iconName={filter.iconName}
          options={filter.multiSelectOptions || []}
          value={(filterValues[filter.id] as string[]) ?? []}
          onChange={(values) => {
            onFilterChange(values, filter);
          }}
          placeholder={filter.placeholder}
          disabled={filter.disabled}
          width={filter.width}
          showSelectAll={filter.showSelectAll !== false}
          clearable={filter.clearable !== false}
          maxDisplayItems={filter.maxDisplayItems}
          showSelectedValuesInTrigger={false}
        />
      );

    case 'date-range':
      return (
        <DateRangeToolbarFilter
          key={filter.id}
          filter={filter}
          value={filterValues[filter.id]}
          onFilterChange={onFilterChange}
        />
      );

    default:
      return null;
  }
}
