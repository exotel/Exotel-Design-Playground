/** Storybook layout params for Theme Tokens galleries (kept out of .tsx for HMR). */
export const LAYOUT = {
  layout: 'fullscreen' as const,
};
