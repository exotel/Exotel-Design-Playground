import type { Meta, StoryObj } from '@storybook/react';
import { Box, Stack, Typography, useTheme } from '../../components';
import { GalleryShell } from './ThemeTokens.shared';
import { LAYOUT } from './ThemeTokens.layout';

const meta: Meta = {
  title: 'Theme Tokens/Typography Scale',
  parameters: LAYOUT,
};

export default meta;
type Story = StoryObj;

const VARIANTS = [
  'h1',
  'h2',
  'h3',
  'h4',
  'h5',
  'h6',
  'title1',
  'title2',
  'title3',
  'label1',
  'label2',
  'label3',
  'body1',
  'body2',
  'body3',
  'caption',
  'overline',
] as const;

export const TypographyScale: Story = {
  name: 'Typography Scale',
  render: () => {
    const theme = useTheme();
    return (
      <GalleryShell
        title="Typography scale"
        description={`fontWeightSemiBold = ${theme.typography.fontWeightSemiBold}. Use Typography variant="…". See UI Components → Typography for the component API.`}
      >
        <Box
          sx={{
            bgcolor: 'surface.elevation2',
            border: '1px solid',
            borderColor: 'divider',
            borderRadius: 2,
            overflow: 'hidden',
          }}
        >
          {VARIANTS.map((variant, index) => {
            const style = theme.typography[variant];
            const fontSize =
              typeof style === 'object' && style && 'fontSize' in style ? String(style.fontSize) : '';
            const fontWeight =
              typeof style === 'object' && style && 'fontWeight' in style
                ? String(style.fontWeight)
                : '';
            return (
              <Stack
                key={variant}
                direction={{ xs: 'column', sm: 'row' }}
                spacing={1.5}
                alignItems={{ xs: 'flex-start', sm: 'baseline' }}
                sx={{
                  px: 2.5,
                  py: 2,
                  borderTop: index === 0 ? 'none' : '1px solid',
                  borderColor: 'divider',
                  '&:hover': { bgcolor: 'action.hover' },
                }}
              >
                <Typography
                  variant="caption"
                  color="text.secondary"
                  sx={{
                    minWidth: 88,
                    fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
                  }}
                >
                  {variant}
                </Typography>
                <Typography variant={variant} sx={{ flex: 1 }}>
                  The quick brown fox
                </Typography>
                <Typography variant="caption" color="text.secondary" sx={{ minWidth: 120 }}>
                  {fontSize} · {fontWeight}
                </Typography>
              </Stack>
            );
          })}
        </Box>
      </GalleryShell>
    );
  },
};
