import type { Meta, StoryObj } from '@storybook/react';
import { GalleryShell, TokenGroup, TokenSwatch, useActiveSchemeTheme } from './ThemeTokens.shared';
import { LAYOUT } from './ThemeTokens.layout';

const meta: Meta = {
  title: 'Theme Tokens/Custom And App Launcher',
  parameters: LAYOUT,
};

export default meta;
type Story = StoryObj;

export const CustomAndAppLauncher: Story = {
  name: 'Custom And App Launcher',
  render: () => {
    const { palette } = useActiveSchemeTheme();
    const highlight = palette.custom.highlight;
    const trial = palette.appLauncher?.trialChip;
    return (
      <GalleryShell
        title="Custom & App Launcher"
        description="Built-in custom tokens. Add product keys via themeOverrides → colorSchemes.light|dark.palette.custom. Click a path to copy."
      >
        <TokenGroup title="custom" hint="palette.custom.*">
          <TokenSwatch
            label="highlight"
            path="palette.custom.highlight"
            value={highlight}
            previewBg={highlight}
          />
        </TokenGroup>

        {trial ? (
          <TokenGroup title="appLauncher.trialChip" hint="palette.appLauncher.trialChip.*">
            <TokenSwatch
              label="bg"
              path="palette.appLauncher.trialChip.bg"
              value={trial.bg}
              previewBg={trial.bg}
              previewFg={trial.text}
            />
            <TokenSwatch
              label="text"
              path="palette.appLauncher.trialChip.text"
              value={trial.text}
              previewBg={trial.text}
              previewFg={trial.bg}
            />
          </TokenGroup>
        ) : null}
      </GalleryShell>
    );
  },
};
