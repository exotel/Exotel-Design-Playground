import type { Meta, StoryObj } from '@storybook/react';
import { GalleryShell, TokenGroup, TokenSwatch, useActiveSchemeTheme } from './ThemeTokens.shared';
import { LAYOUT } from './ThemeTokens.layout';

const meta: Meta = {
  title: 'Theme Tokens/Text And Background',
  parameters: LAYOUT,
};

export default meta;
type Story = StoryObj;

export const TextAndBackground: Story = {
  name: 'Text And Background',
  render: () => {
    const { palette } = useActiveSchemeTheme();
    const { text, background, action, divider } = palette;
    return (
      <GalleryShell
        title="Text, background & action"
        description="Content and chrome colors for light and dark schemes. Toggle the Theme toolbar to compare modes. Click a path to copy."
      >
        <TokenGroup title="Text" hint="palette.text.*">
          <TokenSwatch
            label="primary"
            path="palette.text.primary"
            value={text.primary}
            previewBg={text.primary}
            previewFg={background.paper}
          />
          <TokenSwatch
            label="secondary"
            path="palette.text.secondary"
            value={text.secondary}
            previewBg={text.secondary}
            previewFg={background.paper}
          />
          <TokenSwatch
            label="disabled"
            path="palette.text.disabled"
            value={text.disabled}
            previewBg={text.disabled}
            previewFg={background.paper}
          />
        </TokenGroup>

        <TokenGroup title="Background" hint="palette.background.*">
          <TokenSwatch
            label="default"
            path="palette.background.default"
            value={background.default}
            previewBg={background.default}
          />
          <TokenSwatch
            label="paper"
            path="palette.background.paper"
            value={background.paper}
            previewBg={background.paper}
          />
        </TokenGroup>

        <TokenGroup title="Divider & action" hint="palette.divider · palette.action.*">
          <TokenSwatch label="divider" path="palette.divider" value={divider} previewBg={divider} />
          <TokenSwatch
            label="active"
            path="palette.action.active"
            value={action.active}
            previewBg={action.active}
            previewFg={background.paper}
          />
          <TokenSwatch label="hover" path="palette.action.hover" value={action.hover} previewBg={action.hover} />
          <TokenSwatch
            label="selected"
            path="palette.action.selected"
            value={action.selected}
            previewBg={action.selected}
          />
          <TokenSwatch
            label="disabled"
            path="palette.action.disabled"
            value={action.disabled}
            previewBg={action.disabled}
            previewFg={background.paper}
          />
          <TokenSwatch
            label="disabledBg"
            path="palette.action.disabledBackground"
            value={action.disabledBackground}
            previewBg={action.disabledBackground}
          />
        </TokenGroup>
      </GalleryShell>
    );
  },
};
