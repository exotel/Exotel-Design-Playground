import type { Meta, StoryObj } from '@storybook/react';
import { Box, Stack, Typography, useTheme } from '../../components';
import { GalleryShell, TokenGroup } from './ThemeTokens.shared';
import { LAYOUT } from './ThemeTokens.layout';

const meta: Meta = {
  title: 'Theme Tokens/Spacing Shape Shadows',
  parameters: LAYOUT,
};

export default meta;
type Story = StoryObj;

export const SpacingShapeShadows: Story = {
  name: 'Spacing Shape Shadows',
  render: () => {
    const theme = useTheme();
    const spacings = [0.5, 1, 1.5, 2, 3, 4, 6, 8] as const;
    const shadowLevels = [0, 1, 2, 3, 4, 5] as const;

    return (
      <GalleryShell
        title="Spacing, shape & shadows"
        description="Spacing unit is 8px. shape.borderRadius is 8. Shadows 6–24 clamp to level 5."
      >
        <Box
          sx={{
            bgcolor: 'surface.elevation2',
            border: '1px solid',
            borderColor: 'divider',
            borderRadius: 2,
            p: 2.5,
          }}
        >
          <Typography variant="title2" sx={{ mb: 2 }}>
            Spacing · theme.spacing(n)
          </Typography>
          <Stack spacing={1.25}>
            {spacings.map((n) => (
              <Stack key={n} direction="row" spacing={2} alignItems="center">
                <Typography
                  variant="caption"
                  color="text.secondary"
                  sx={{
                    minWidth: 128,
                    fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
                  }}
                >
                  spacing({n}) = {theme.spacing(n)}
                </Typography>
                <Box
                  sx={{
                    height: 12,
                    width: theme.spacing(n),
                    maxWidth: '100%',
                    bgcolor: 'primary.main',
                    borderRadius: 999,
                  }}
                />
              </Stack>
            ))}
          </Stack>
        </Box>

        <TokenGroup title="Shape" hint="theme.shape.borderRadius">
          <Box
            sx={{
              gridColumn: '1 / -1',
              display: 'flex',
              alignItems: 'center',
              gap: 3,
              flexWrap: 'wrap',
            }}
          >
            <Box
              sx={{
                width: 96,
                height: 96,
                bgcolor: 'primary.main',
                borderRadius: `${theme.shape.borderRadius}px`,
                boxShadow: 1,
              }}
            />
            <Stack spacing={0.5}>
              <Typography variant="title2">borderRadius</Typography>
              <Typography
                variant="body2"
                color="text.secondary"
                sx={{ fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace' }}
              >
                shape.borderRadius = {theme.shape.borderRadius}
              </Typography>
            </Stack>
          </Box>
        </TokenGroup>

        <Box
          sx={{
            bgcolor: 'surface.elevation2',
            border: '1px solid',
            borderColor: 'divider',
            borderRadius: 2,
            p: 2.5,
          }}
        >
          <Typography variant="title2" sx={{ mb: 0.5 }}>
            Shadows
          </Typography>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 2 }}>
            theme.shadows[n] · sx boxShadow: n
          </Typography>
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: {
                xs: 'repeat(2, minmax(0, 1fr))',
                sm: 'repeat(3, minmax(0, 1fr))',
                md: 'repeat(6, minmax(0, 1fr))',
              },
              gap: 2,
            }}
          >
            {shadowLevels.map((n) => (
              <Box
                key={n}
                sx={{
                  height: 96,
                  bgcolor: 'background.paper',
                  borderRadius: 2,
                  boxShadow: n,
                  border: '1px solid',
                  borderColor: 'divider',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Typography
                  variant="caption"
                  sx={{ fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace' }}
                >
                  shadows[{n}]
                </Typography>
              </Box>
            ))}
          </Box>
        </Box>
      </GalleryShell>
    );
  },
};
