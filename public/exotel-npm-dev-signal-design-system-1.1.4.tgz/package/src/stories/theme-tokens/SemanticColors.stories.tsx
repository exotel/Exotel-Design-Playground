import type { Meta, StoryObj } from '@storybook/react';
import { GalleryShell, SEMANTIC, TokenGroup, TokenSwatch, useActiveSchemeTheme } from './ThemeTokens.shared';
import { LAYOUT } from './ThemeTokens.layout';

const meta: Meta = {
  title: 'Theme Tokens/Semantic Colors',
  parameters: LAYOUT,
};

export default meta;
type Story = StoryObj;

export const SemanticColors: Story = {
  name: 'Semantic Colors',
  render: () => {
    const { palette } = useActiveSchemeTheme();
    return (
      <GalleryShell
        title="Semantic colors"
        description="Brand and status palettes. Prefer main / light / dark / contrastText in product UI. Click a path to copy."
      >
        {SEMANTIC.map((key) => {
          const pal = palette[key];
          return (
            <TokenGroup key={key} title={key} hint={`palette.${key}.*`}>
              <TokenSwatch
                label="main"
                path={`palette.${key}.main`}
                value={pal.main}
                previewBg={pal.main}
                previewFg={pal.contrastText}
              />
              <TokenSwatch
                label="light"
                path={`palette.${key}.light`}
                value={pal.light}
                previewBg={pal.light}
                previewFg={pal.contrastText}
              />
              <TokenSwatch
                label="dark"
                path={`palette.${key}.dark`}
                value={pal.dark}
                previewBg={pal.dark}
                previewFg={pal.contrastText}
              />
              <TokenSwatch
                label="contrastText"
                path={`palette.${key}.contrastText`}
                value={pal.contrastText}
                previewBg={pal.contrastText}
                previewFg={pal.main}
              />
            </TokenGroup>
          );
        })}
      </GalleryShell>
    );
  },
};
