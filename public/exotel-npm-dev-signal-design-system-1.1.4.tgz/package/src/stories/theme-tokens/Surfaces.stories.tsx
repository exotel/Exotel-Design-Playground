import type { Meta, StoryObj } from '@storybook/react';
import { GalleryShell, TokenGroup, TokenSwatch, useActiveSchemeTheme } from './ThemeTokens.shared';
import { LAYOUT } from './ThemeTokens.layout';

const meta: Meta = {
  title: 'Theme Tokens/Surfaces',
  parameters: LAYOUT,
};

export default meta;
type Story = StoryObj;

export const Surfaces: Story = {
  name: 'Surfaces',
  render: () => {
    const { palette } = useActiveSchemeTheme();
    const surface = palette.surface;
    return (
      <GalleryShell
        title="Surface elevations"
        description="Product layers: Canvas (0), Shell (1), Raised (2). Higher steps follow the MUI overlay ladder. Click a path to copy."
      >
        <TokenGroup title="Product layers" hint="palette.surface.elevation0–2">
          <TokenSwatch
            label="Canvas"
            path="palette.surface.elevation0"
            value={surface.elevation0}
            previewBg={surface.elevation0}
          />
          <TokenSwatch
            label="Shell"
            path="palette.surface.elevation1"
            value={surface.elevation1}
            previewBg={surface.elevation1}
          />
          <TokenSwatch
            label="Raised"
            path="palette.surface.elevation2"
            value={surface.elevation2}
            previewBg={surface.elevation2}
          />
        </TokenGroup>

        <TokenGroup title="Overlay ladder" hint="palette.surface.elevation3–5 (3–24 available)">
          <TokenSwatch
            label="elevation3"
            path="palette.surface.elevation3"
            value={surface.elevation3}
            previewBg={surface.elevation3}
          />
          <TokenSwatch
            label="elevation4"
            path="palette.surface.elevation4"
            value={surface.elevation4}
            previewBg={surface.elevation4}
          />
          <TokenSwatch
            label="elevation5"
            path="palette.surface.elevation5"
            value={surface.elevation5}
            previewBg={surface.elevation5}
          />
        </TokenGroup>
      </GalleryShell>
    );
  },
};
