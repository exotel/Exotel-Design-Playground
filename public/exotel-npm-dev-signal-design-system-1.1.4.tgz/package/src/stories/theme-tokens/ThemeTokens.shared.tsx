/**
 * Shared UI for Theme Tokens galleries — Signal-styled token explorer.
 */

import { useMemo, useState, type ReactNode } from 'react';
import { Box, Stack, Typography, useColorScheme, useTheme } from '../../components';
import type { Theme } from '@mui/material/styles';
import type { TonalSemanticColor } from '../../theme/tonal';

export const SEMANTIC = ['primary', 'secondary', 'error', 'warning', 'info', 'success'] as const;

/**
 * MUI CSS-variable themes keep `theme.palette.*` as `var(--mui-…)` (or the
 * default scheme). For galleries we need the *resolved* light/dark hex values
 * from `theme.colorSchemes[mode].palette`, keyed off the active color scheme.
 */
export function useActiveSchemeTheme(): { mode: 'light' | 'dark'; theme: Theme; palette: Theme['palette'] } {
  const theme = useTheme();
  const { mode: colorSchemeMode } = useColorScheme();
  const mode: 'light' | 'dark' = colorSchemeMode === 'dark' ? 'dark' : 'light';

  return useMemo(() => {
    const schemePalette = theme.colorSchemes?.[mode]?.palette;
    if (!schemePalette) {
      const fallback = { ...theme, palette: { ...theme.palette, mode } } as Theme;
      return { mode, theme: fallback, palette: fallback.palette };
    }
    const activeTheme = {
      ...theme,
      palette: {
        ...theme.palette,
        ...schemePalette,
        mode,
      },
    } as Theme;
    return { mode, theme: activeTheme, palette: activeTheme.palette };
  }, [theme, mode]);
}

export const TONAL_COLORS: TonalSemanticColor[] = [
  'default',
  'primary',
  'secondary',
  'error',
  'warning',
  'info',
  'success',
];

const MONO = {
  fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
  fontSize: 11,
  lineHeight: 1.45,
} as const;

/** Page chrome for every Theme Tokens gallery */
export function GalleryShell({
  title,
  description,
  children,
}: {
  title: string;
  description?: ReactNode;
  children: ReactNode;
}) {
  return (
    <Box
      sx={{
        minHeight: '100%',
        bgcolor: 'surface.elevation0',
        px: { xs: 2, md: 3 },
        py: { xs: 2.5, md: 3 },
      }}
    >
      <Stack spacing={0.75} sx={{ mb: 3, maxWidth: 960 }}>
        <Typography variant="h5" component="h1">
          {title}
        </Typography>
        {description ? (
          <Typography variant="body2" color="text.secondary" sx={{ maxWidth: 720 }}>
            {description}
          </Typography>
        ) : null}
      </Stack>
      <Stack spacing={2.5}>{children}</Stack>
    </Box>
  );
}

/** Group of related tokens on a raised surface */
export function TokenGroup({
  title,
  hint,
  action,
  children,
}: {
  title: string;
  hint?: string;
  action?: ReactNode;
  children: ReactNode;
}) {
  return (
    <Box
      sx={{
        bgcolor: 'surface.elevation2',
        border: '1px solid',
        borderColor: 'divider',
        borderRadius: 2,
        overflow: 'hidden',
      }}
    >
      <Stack
        direction="row"
        alignItems="center"
        justifyContent="space-between"
        gap={2}
        sx={{
          px: 2.5,
          py: 1.75,
          borderBottom: '1px solid',
          borderColor: 'divider',
          bgcolor: 'surface.elevation1',
        }}
      >
        <Stack spacing={0.25}>
          <Typography variant="title3" textTransform="capitalize">
            {title}
          </Typography>
          {hint ? (
            <Typography variant="caption" color="text.secondary" sx={MONO}>
              {hint}
            </Typography>
          ) : null}
        </Stack>
        {action}
      </Stack>
      <Box
        sx={{
          p: 2.5,
          display: 'grid',
          gridTemplateColumns: {
            xs: 'repeat(2, minmax(0, 1fr))',
            sm: 'repeat(3, minmax(0, 1fr))',
            md: 'repeat(4, minmax(0, 1fr))',
            lg: 'repeat(auto-fill, minmax(160px, 1fr))',
          },
          gap: 2,
        }}
      >
        {children}
      </Box>
    </Box>
  );
}

async function copyText(value: string) {
  try {
    await navigator.clipboard.writeText(value);
    return true;
  } catch {
    return false;
  }
}

/** Single token tile — click path to copy (value is display-only) */
export function TokenSwatch({
  label,
  path,
  value,
  previewBg,
  previewFg,
}: {
  label: string;
  path: string;
  value: string;
  previewBg: string;
  /** Optional sample text color drawn on the swatch */
  previewFg?: string;
}) {
  const [copied, setCopied] = useState(false);

  const handleCopyPath = async () => {
    const ok = await copyText(path);
    if (!ok) return;
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1200);
  };

  return (
    <Box
      sx={{
        borderRadius: 1.5,
        border: '1px solid',
        borderColor: 'divider',
        overflow: 'hidden',
        bgcolor: 'background.paper',
        transition: 'box-shadow 120ms ease, border-color 120ms ease',
        '&:hover': {
          borderColor: 'text.disabled',
          boxShadow: 1,
        },
      }}
    >
      <Box
        sx={{
          height: 80,
          position: 'relative',
          borderBottom: '1px solid',
          borderColor: 'divider',
          backgroundSize: '10px 10px',
          backgroundPosition: '0 0, 0 5px, 5px -5px, -5px 0',
        }}
      >
        <Box
          sx={{
            position: 'absolute',
            inset: 0,
            bgcolor: previewBg,
            color: previewFg,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            typography: 'title2',
          }}
        >
          {previewFg ? 'Aa' : null}
        </Box>
      </Box>
      <Stack spacing={0.5} sx={{ p: 1.5 }}>
        <Typography variant="title2">{label}</Typography>
        <Box
          component="button"
          type="button"
          onClick={handleCopyPath}
          title="Copy token path"
          sx={{
            all: 'unset',
            cursor: 'pointer',
            display: 'block',
            width: '100%',
            borderRadius: 0.5,
            '&:hover .token-meta': { color: 'primary.main' },
            '&:focus-visible': { outline: '2px solid', outlineColor: 'primary.main', outlineOffset: 2 },
          }}
        >
          <Typography
            className="token-meta"
            variant="caption"
            color="text.secondary"
            sx={{ ...MONO, display: 'block', wordBreak: 'break-all' }}
          >
            {copied ? 'Copied path' : path}
          </Typography>
        </Box>
        <Typography
          variant="caption"
          color="text.disabled"
          sx={{ ...MONO, display: 'block', wordBreak: 'break-all' }}
        >
          {value}
        </Typography>
      </Stack>
    </Box>
  );
}
