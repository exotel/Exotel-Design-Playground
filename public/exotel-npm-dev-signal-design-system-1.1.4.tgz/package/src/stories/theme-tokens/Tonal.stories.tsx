import type { Meta, StoryObj } from '@storybook/react';
import { Chip } from '../../components';
import { resolveTonalColor } from '../../theme/tonal';
import { GalleryShell, TONAL_COLORS, TokenGroup, TokenSwatch, useActiveSchemeTheme } from './ThemeTokens.shared';
import { LAYOUT } from './ThemeTokens.layout';

const meta: Meta = {
  title: 'Theme Tokens/Tonal',
  parameters: LAYOUT,
};

export default meta;
type Story = StoryObj;

export const Tonal: Story = {
  name: 'Tonal',
  render: () => {
    const { theme } = useActiveSchemeTheme();
    return (
      <GalleryShell
        title="Tonal surfaces"
        description="Prefer Chip / Button variant='tonal' in product UI. Light uses solid palette.tonal; dark uses alpha tonalSurface. Click a path to copy."
      >
        {TONAL_COLORS.map((color) => {
          const tokens = resolveTonalColor(theme, color);
          return (
            <TokenGroup
              key={color}
              title={color}
              hint={`tonal.${color}.*`}
              action={
                <Chip
                  label={color}
                  variant="tonal"
                  color={color === 'default' ? 'default' : color}
                  size="small"
                />
              }
            >
              <TokenSwatch
                label="bg"
                path={`tonal.${color}.bg`}
                value={tokens.bg}
                previewBg={tokens.bg}
                previewFg={tokens.text}
              />
              <TokenSwatch
                label="text"
                path={`tonal.${color}.text`}
                value={tokens.text}
                previewBg={tokens.text}
                previewFg={tokens.bg}
              />
              <TokenSwatch
                label="hoverBg"
                path={`tonal.${color}.hoverBg`}
                value={tokens.hoverBg}
                previewBg={tokens.hoverBg}
                previewFg={tokens.text}
              />
              <TokenSwatch
                label="disabledBg"
                path={`tonal.${color}.disabledBg`}
                value={tokens.disabledBg}
                previewBg={tokens.disabledBg}
                previewFg={tokens.text}
              />
            </TokenGroup>
          );
        })}
      </GalleryShell>
    );
  },
};
