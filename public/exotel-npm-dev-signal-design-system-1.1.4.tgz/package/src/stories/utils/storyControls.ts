import type { ArgTypes, Parameters } from '@storybook/react';

/** Hide Controls on every story under a meta (non-Interactive demos). */
export const metaControlsDisabled: Parameters = {
  controls: { disable: true },
};

/** Show Controls only on the Interactive playground story. */
export const interactiveControlsEnabled: Parameters = {
  controls: { disable: false, expanded: true, sort: 'alpha' },
};

/**
 * Props that break or freeze Storybook when edited from Controls.
 * Merge into Interactive `argTypes`. Event handlers should use `action` separately.
 */
export const unsafePropArgTypes = {
  sx: { control: false },
  style: { control: false },
  className: { control: false },
  classes: { control: false },
  slots: { control: false },
  slotProps: { control: false },
  components: { control: false },
  componentsProps: { control: false },
  component: { control: false },
  ref: { table: { disable: true } },
  key: { table: { disable: true } },
} satisfies Partial<ArgTypes>;
