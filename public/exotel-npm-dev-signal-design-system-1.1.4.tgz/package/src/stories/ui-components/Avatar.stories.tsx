import type { Meta, StoryObj } from '@storybook/react';
import { Avatar, Badge } from '../../components';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof Avatar> = {
  title: 'UI Components/Avatar',
  component: Avatar,
  parameters: {
    layout: 'centered',
    ...metaControlsDisabled,
    docs: {
      description: {
        component: 'Exotel-approved avatar component that wraps MUI\'s Avatar. Can display images, text, or icons.',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Avatar>;

/**
 * Text avatar
 */
export const Text: Story = {
  args: {
    children: 'AB',
  },
};

/**
 * Image avatar
 */
export const Image: Story = {
  args: {
    src: 'https://mui.com/static/images/avatar/1.jpg',
    alt: 'Avatar',
  },
};

/**
 * Different sizes
 */
export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
      <Avatar size="small">S</Avatar>
      <Avatar size="medium">M</Avatar>
      <Avatar size="large">L</Avatar>
    </div>
  ),
};

/**
 * Different variants
 */
export const Variants: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
      <Avatar variant="circular">C</Avatar>
      <Avatar variant="rounded">R</Avatar>
      <Avatar variant="square">S</Avatar>
    </div>
  ),
};

/**
 * Avatar with Badge
 */
export const WithBadge: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '24px', alignItems: 'center' }}>
      <Badge badgeContent={4} color="primary">
        <Avatar>AB</Avatar>
      </Badge>
      <Badge badgeContent={99} color="error">
        <Avatar src="https://mui.com/static/images/avatar/1.jpg" alt="Avatar" />
      </Badge>
      <Badge badgeContent={0} color="primary" variant="dot">
        <Avatar>CD</Avatar>
      </Badge>
    </div>
  ),
};

/**
 * Interactive avatar with all controls
 */
export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    imgProps: { control: false },
    sizes: {
      control: 'select',
      options: ['small', 'medium', 'large'],
    },
    variant: {
      control: 'select',
      options: ['circular', 'rounded', 'square'],
    },
    alt: { control: 'text' },
    src: { control: 'text' },
    children: { control: 'text' },
  },
  args: {
    children: 'AB',
    variant: 'circular',
    sizes: 'medium',
    src: '',
    alt: '',
  },
  render: (args) => {
    const { sizes, src, children, ...rest } = args;
    return (
      <Avatar {...rest} size={sizes} src={src || undefined}>
        {src ? undefined : children}
      </Avatar>
    );
  },
};
