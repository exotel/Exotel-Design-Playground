import type { Meta, StoryObj } from '@storybook/react';
import { Link } from '../../components';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof Link> = {
  title: 'UI Components/Link',
  component: Link,
  parameters: { layout: 'centered', ...metaControlsDisabled },
};

export default meta;
type Story = StoryObj<typeof Link>;

export const Basic: Story = { args: { href: '#', children: 'Link' } };
export const UnderlineNone: Story = { args: { href: '#', underline: 'none', children: 'No underline' } };

export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    children: { control: 'text' },
    href: { control: 'text' },
    underline: { control: 'select', options: ['none', 'hover', 'always'] },
    color: {
      control: 'select',
      options: ['primary', 'secondary', 'error', 'info', 'success', 'warning', 'inherit'],
    },
    variant: {
      control: 'select',
      options: [
        'body1',
        'body2',
        'button',
        'caption',
        'h1',
        'h2',
        'h3',
        'h4',
        'h5',
        'h6',
        'inherit',
        'overline',
        'subtitle1',
        'subtitle2',
      ],
    },
  },
  args: {
    href: '#',
    children: 'Link',
    underline: 'hover',
    color: 'primary',
  },
  render: (args) => <Link {...args} />,
};
