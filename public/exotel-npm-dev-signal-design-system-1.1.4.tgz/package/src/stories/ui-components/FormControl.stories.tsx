import type { Meta, StoryObj } from '@storybook/react';
import { FormControl, TextField, Box } from '../../components';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof FormControl> = {
  title: 'UI Components/FormControl',
  component: FormControl,
  parameters: {
    layout: 'centered',
    ...metaControlsDisabled,
    docs: {
      description: {
        component:
          'Exotel-approved form control component that wraps MUI\'s FormControl. Provides context (error, disabled, required) to child form elements.',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof FormControl>;

export const Default: Story = {
  render: () => (
    <FormControl>
      <TextField label="Name" helperText="Enter your full name" />
    </FormControl>
  ),
};

export const ErrorState: Story = {
  render: () => (
    <FormControl error>
      <TextField
        label="Email"
        defaultValue="invalid"
        helperText="Please enter a valid email"
      />
    </FormControl>
  ),
};

export const DisabledState: Story = {
  render: () => (
    <FormControl disabled>
      <TextField
        label="Disabled"
        defaultValue="Cannot edit"
        helperText="This field is disabled"
      />
    </FormControl>
  ),
};

export const RequiredField: Story = {
  render: () => (
    <FormControl required>
      <TextField label="Required" helperText="This field is required" />
    </FormControl>
  ),
};

export const AllStates: Story = {
  render: () => (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3, width: 300 }}>
      <FormControl>
        <TextField label="Default" />
      </FormControl>
      <FormControl error>
        <TextField
          label="Error"
          defaultValue="Invalid"
          helperText="Something went wrong"
        />
      </FormControl>
      <FormControl disabled>
        <TextField label="Disabled" defaultValue="Locked" />
      </FormControl>
      <FormControl required>
        <TextField label="Required" />
      </FormControl>
    </Box>
  ),
};

export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    children: { control: false },
    error: { control: 'boolean' },
    disabled: { control: 'boolean' },
    required: { control: 'boolean' },
    fullWidth: { control: 'boolean' },
    variant: { control: 'select', options: ['standard', 'outlined', 'filled'] },
    size: { control: 'select', options: ['small', 'medium'] },
    margin: { control: 'select', options: ['none', 'dense', 'normal'] },
  },
  args: {
    error: false,
    disabled: false,
    required: false,
    fullWidth: false,
    variant: 'outlined',
    size: 'medium',
    margin: 'none',
  },
  render: (args) => (
    <FormControl {...args}>
      <TextField label="Name" helperText="Enter your full name" />
    </FormControl>
  ),
};
