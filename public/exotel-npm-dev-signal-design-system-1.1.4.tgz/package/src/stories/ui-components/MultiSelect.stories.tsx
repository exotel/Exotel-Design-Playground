/**
 * MultiSelect Component Stories
 * 
 * Stories demonstrating the MultiSelect component - a multi-select dropdown
 * with support for grouped options and select all functionality.
 */

import type { Meta, StoryObj } from '@storybook/react';
import { MultiSelect, type MultiSelectOption } from '../../components/MultiSelect';
import { useState } from 'react';
import { Box } from '@mui/material';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof MultiSelect> = {
  title: 'UI Components/MultiSelect',
  component: MultiSelect,
  parameters: {
    layout: 'padded',
    ...metaControlsDisabled,
    docs: {
      description: {
        component: `
### MultiSelect

A multi-select dropdown component with support for:
- Multiple selection with checkboxes
- Grouped/nested options (tree structure)
- Select all functionality
- Clear button
- Customizable display (shows selected count)

**Key Features:**
- ✅ Tree structure with parent-child relationships
- ✅ Select all/deselect all
- ✅ Group headers
- ✅ Disabled options support
- ✅ Clearable
- ✅ Truncates long selection lists

**Use Cases:**
- Disposition filters
- Status filters
- Category/tag selection
- Any multi-selection with grouped options
        `,
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof MultiSelect>;

// Sample data matching the image structure
const dispositionOptions: MultiSelectOption[] = [
  {
    id: 'system-defined',
    label: 'System Defined',
    value: 'system-defined',
    isGroup: true,
  },
  {
    id: 'failed-call',
    label: 'failed.call.auto.dispose',
    value: 'failed.call.auto.dispose',
    parentId: 'system-defined',
  },
  {
    id: 'schedule-callback',
    label: 'schedule.callback',
    value: 'schedule.callback',
    parentId: 'system-defined',
  },
  {
    id: 'callback',
    label: 'Callback',
    value: 'callback',
    parentId: 'system-defined',
  },
  {
    id: 'status',
    label: 'Status',
    value: 'status',
    isGroup: true,
  },
  {
    id: 'open',
    label: 'Open',
    value: 'open',
    parentId: 'status',
  },
  {
    id: 'closed',
    label: 'Closed',
    value: 'closed',
    parentId: 'status',
  },
  {
    id: 'new-status',
    label: 'new status',
    value: 'new-status',
    parentId: 'status',
  },
];

/**
 * Basic multi-select matching the image
 */
export const DispositionFilter: Story = {
  render: (args) => {
    const [selectedValues, setSelectedValues] = useState<string[]>([
      'schedule.callback',
      'callback',
    ]);

    return (
      <Box sx={{ p: 2 }}>
        <MultiSelect
          {...args}
          value={selectedValues}
          onChange={setSelectedValues}
        />
      </Box>
    );
  },
  args: {
    label: 'Disposition',
    options: dispositionOptions,
    placeholder: 'Select dispositions',
    showSelectAll: true,
    clearable: true,
    width: 300,
    maxDisplayItems: 2,
  },
  parameters: {
    docs: {
      description: {
        story: 'Multi-select with grouped options (System Defined and Status groups). Pre-selected with "schedule.callback" and "Callback".',
      },
    },
  },
};

/**
 * Simple flat list without groups
 */
export const SimpleList: Story = {
  render: (args) => {
    const [selectedValues, setSelectedValues] = useState<string[]>([]);

    const simpleOptions: MultiSelectOption[] = [
      { id: '1', label: 'Option 1', value: 'option-1' },
      { id: '2', label: 'Option 2', value: 'option-2' },
      { id: '3', label: 'Option 3', value: 'option-3' },
      { id: '4', label: 'Option 4', value: 'option-4' },
      { id: '5', label: 'Option 5', value: 'option-5' },
    ];

    return (
      <Box sx={{ p: 2 }}>
        <MultiSelect
          {...args}
          value={selectedValues}
          onChange={setSelectedValues}
          options={simpleOptions}
        />
      </Box>
    );
  },
  args: {
    label: 'Simple Select',
    placeholder: 'Select options',
    showSelectAll: true,
    clearable: true,
    width: 280,
  },
  parameters: {
    docs: {
      description: {
        story: 'Simple multi-select without groups.',
      },
    },
  },
};

/**
 * With disabled options
 */
export const WithDisabledOptions: Story = {
  render: (args) => {
    const [selectedValues, setSelectedValues] = useState<string[]>(['active']);

    const optionsWithDisabled: MultiSelectOption[] = [
      { id: '1', label: 'Active', value: 'active' },
      {
        id: '2',
        label: 'Inactive (Disabled)',
        value: 'inactive',
        disabled: true,
        disabledTooltip: 'Inactive statuses cannot be selected',
      },
      { id: '3', label: 'Pending', value: 'pending' },
      {
        id: '4',
        label: 'Archived (Disabled)',
        value: 'archived',
        disabled: true,
        disabledTooltip: 'Archived items are read-only',
      },
      { id: '5', label: 'Draft', value: 'draft', disabled: true, },
    ];

    return (
      <Box sx={{ p: 2 }}>
        <MultiSelect
          {...args}
          value={selectedValues}
          onChange={setSelectedValues}
          options={optionsWithDisabled}
        />
      </Box>
    );
  },
  args: {
    label: 'Status',
    placeholder: 'Select status',
    showSelectAll: true,
    clearable: true,
    width: 280,
  },
  parameters: {
    docs: {
      description: {
        story: 'Multi-select with some options disabled. Disabled options may include an optional `disabledTooltip` shown on hover.',
      },
    },
  },
};

/**
 * Multiple groups
 */
export const MultipleGroups: Story = {
  render: (args) => {
    const [selectedValues, setSelectedValues] = useState<string[]>([]);

    const groupedOptions: MultiSelectOption[] = [
      { id: 'fruits', label: 'Fruits', value: 'fruits', isGroup: true },
      { id: 'apple', label: 'Apple', value: 'apple', parentId: 'fruits' },
      { id: 'banana', label: 'Banana', value: 'banana', parentId: 'fruits' },
      { id: 'orange', label: 'Orange', value: 'orange', parentId: 'fruits' },
      
      { id: 'vegetables', label: 'Vegetables', value: 'vegetables', isGroup: true },
      { id: 'carrot', label: 'Carrot', value: 'carrot', parentId: 'vegetables' },
      { id: 'broccoli', label: 'Broccoli', value: 'broccoli', parentId: 'vegetables' },
      { id: 'spinach', label: 'Spinach', value: 'spinach', parentId: 'vegetables' },
      
      { id: 'dairy', label: 'Dairy', value: 'dairy', isGroup: true },
      { id: 'milk', label: 'Milk', value: 'milk', parentId: 'dairy' },
      { id: 'cheese', label: 'Cheese', value: 'cheese', parentId: 'dairy' },
      { id: 'yogurt', label: 'Yogurt', value: 'yogurt', parentId: 'dairy' },
    ];

    return (
      <Box sx={{ p: 2 }}>
        <MultiSelect
          {...args}
          value={selectedValues}
          onChange={setSelectedValues}
          options={groupedOptions}
        />
      </Box>
    );
  },
  args: {
    label: 'Food Categories',
    placeholder: 'Select items',
    showSelectAll: true,
    clearable: true,
    width: 300,
  },
  parameters: {
    docs: {
      description: {
        story: 'Multi-select with multiple groups (Fruits, Vegetables, Dairy).',
      },
    },
  },
};

/**
 * Many selected items
 */
export const ManySelectedItems: Story = {
  render: (args) => {
    const [selectedValues, setSelectedValues] = useState<string[]>([
      'option-1',
      'option-2',
      'option-3',
      'option-4',
      'option-5',
    ]);

    const manyOptions: MultiSelectOption[] = Array.from({ length: 10 }, (_, i) => ({
      id: `${i + 1}`,
      label: `Option ${i + 1}`,
      value: `option-${i + 1}`,
    }));

    return (
      <Box sx={{ p: 2 }}>
        <MultiSelect
          {...args}
          value={selectedValues}
          onChange={setSelectedValues}
          options={manyOptions}
        />
      </Box>
    );
  },
  args: {
    label: 'Select Multiple',
    placeholder: 'Select options',
    showSelectAll: true,
    clearable: true,
    width: 300,
    maxDisplayItems: 2,
  },
  parameters: {
    docs: {
      description: {
        story: 'When more than maxDisplayItems are selected, it shows "Option 1, Option 2 +3" format.',
      },
    },
  },
};

/**
 * Without select all
 */
export const WithoutSelectAll: Story = {
  render: (args) => {
    const [selectedValues, setSelectedValues] = useState<string[]>([]);

    const options: MultiSelectOption[] = [
      { id: '1', label: 'Red', value: 'red' },
      { id: '2', label: 'Blue', value: 'blue' },
      { id: '3', label: 'Green', value: 'green' },
      { id: '4', label: 'Yellow', value: 'yellow' },
    ];

    return (
      <Box sx={{ p: 2 }}>
        <MultiSelect
          {...args}
          value={selectedValues}
          onChange={setSelectedValues}
          options={options}
        />
      </Box>
    );
  },
  args: {
    label: 'Colors',
    placeholder: 'Select colors',
    showSelectAll: false,
    clearable: true,
    width: 280,
  },
  parameters: {
    docs: {
      description: {
        story: 'Multi-select without "Select All" option.',
      },
    },
  },
};

/**
 * Disabled state
 */
export const Disabled: Story = {
  render: (args) => {
    const [selectedValues, setSelectedValues] = useState<string[]>(['option-1', 'option-2']);

    const options: MultiSelectOption[] = [
      { id: '1', label: 'Option 1', value: 'option-1' },
      { id: '2', label: 'Option 2', value: 'option-2' },
      { id: '3', label: 'Option 3', value: 'option-3' },
    ];

    return (
      <Box sx={{ p: 2 }}>
        <MultiSelect
          {...args}
          value={selectedValues}
          onChange={setSelectedValues}
          options={options}
        />
      </Box>
    );
  },
  args: {
    label: 'Disabled Select',
    placeholder: 'Select options',
    disabled: true,
    showSelectAll: true,
    clearable: true,
    width: 280,
  },
  parameters: {
    docs: {
      description: {
        story: 'Disabled multi-select component.',
      },
    },
  },
};

/**
 * In a form layout
 */
export const InFormLayout: Story = {
  render: () => {
    const [disposition, setDisposition] = useState<string[]>(['callback']);
    const [status, setStatus] = useState<string[]>(['open']);
    const [priority, setPriority] = useState<string[]>([]);

    return (
      <Box sx={{ p: 2, display: 'flex', flexDirection: 'column', gap: 2, maxWidth: 400 }}>
        <MultiSelect
          label="Disposition"
          options={dispositionOptions}
          value={disposition}
          onChange={setDisposition}
          placeholder="Select dispositions"
          width="100%"
        />
        
        <MultiSelect
          label="Status"
          options={[
            { id: '1', label: 'Open', value: 'open' },
            { id: '2', label: 'In Progress', value: 'in-progress' },
            { id: '3', label: 'Closed', value: 'closed' },
            { id: '4', label: 'Pending', value: 'pending' },
          ]}
          value={status}
          onChange={setStatus}
          placeholder="Select status"
          width="100%"
        />
        
        <MultiSelect
          label="Priority"
          options={[
            { id: '1', label: 'Low', value: 'low' },
            { id: '2', label: 'Medium', value: 'medium' },
            { id: '3', label: 'High', value: 'high' },
            { id: '4', label: 'Critical', value: 'critical' },
          ]}
          value={priority}
          onChange={setPriority}
          placeholder="Select priority"
          width="100%"
        />
      </Box>
    );
  },
  parameters: {
    docs: {
      description: {
        story: 'Multiple multi-select components in a form layout.',
      },
    },
  },
};

/**
 * Interactive playground — Controls enabled for serializable props.
 * Options and value are managed in render (options fixed to disposition sample).
 */
export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    options: { control: false },
    value: { control: false },
    onChange: { action: 'onChange' },
    label: { control: 'text' },
    placeholder: { control: 'text' },
    disabled: { control: 'boolean' },
    showSelectAll: { control: 'boolean' },
    clearable: { control: 'boolean' },
    maxDisplayItems: { control: 'number' },
    width: { control: 'number' },
    showSelectedValuesInTrigger: { control: 'boolean' },
    useBottomSheet: { control: 'boolean' },
    iconName: { control: 'text' },
  },
  args: {
    label: 'Disposition',
    placeholder: 'Select dispositions',
    showSelectAll: true,
    clearable: true,
    width: 300,
    maxDisplayItems: 2,
    disabled: false,
    showSelectedValuesInTrigger: true,
    useBottomSheet: false,
  },
  render: (args) => {
    const [selectedValues, setSelectedValues] = useState<string[]>([
      'schedule.callback',
      'callback',
    ]);

    return (
      <Box sx={{ p: 2 }}>
        <MultiSelect
          {...args}
          options={dispositionOptions}
          value={selectedValues}
          onChange={(values) => {
            setSelectedValues(values);
            args.onChange?.(values);
          }}
        />
      </Box>
    );
  },
};
