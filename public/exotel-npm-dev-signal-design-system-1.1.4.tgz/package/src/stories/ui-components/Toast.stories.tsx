import type { Meta, StoryObj } from '@storybook/react';
import { useRef } from 'react';
import { Box, Button, Stack, Typography } from '../../components';
import { ToastProvider, useToast } from '../../components/Toast';
import type { ToastSeverity, ToastTransition } from '../../components/Toast';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof ToastProvider> = {
  title: 'UI Components/Toast',
  component: ToastProvider,
  parameters: {
    layout: 'centered',
    ...metaControlsDisabled,
    docs: {
      description: {
        component:
          'Notification toasts powered by notistack. Wrap your app in `<ToastProvider>`, then call `useToast()` from any component. Supports multiple severities, transitions (Slide, Grow), positioning, and auto-dismiss.',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof ToastProvider>;

function SeverityDemo() {
  const { showSuccess, showError, showWarning, showInfo } = useToast();
  return (
    <Stack spacing={1.5} direction="row" flexWrap="wrap">
      <Button variant="contained" color="success" onClick={() => showSuccess('Operation completed successfully.')}>
        Success
      </Button>
      <Button variant="contained" color="error" onClick={() => showError('Something went wrong.')}>
        Error
      </Button>
      <Button variant="contained" color="warning" onClick={() => showWarning('Please check your input.')}>
        Warning
      </Button>
      <Button variant="contained" color="info" onClick={() => showInfo('New update available.')}>
        Info
      </Button>
    </Stack>
  );
}

export const Severities: Story = {
  name: 'Severities',
  render: () => (
    <ToastProvider>
      <SeverityDemo />
    </ToastProvider>
  ),
};

function WithTitleDemo() {
  const { showSuccess, showError } = useToast();
  return (
    <Stack spacing={1.5} direction="row">
      <Button
        variant="contained"
        color="success"
        onClick={() => showSuccess('Your changes have been saved.', { title: 'Saved' })}
      >
        With title
      </Button>
      <Button
        variant="contained"
        color="error"
        onClick={() => showError('Please try again later.', { title: 'Request failed' })}
      >
        Error with title
      </Button>
    </Stack>
  );
}

export const WithTitle: Story = {
  name: 'With title',
  render: () => (
    <ToastProvider>
      <WithTitleDemo />
    </ToastProvider>
  ),
};

function TransitionDemo({ transition }: { transition: ToastTransition }) {
  const { showInfo } = useToast();
  return (
    <Button
      variant="outlined"
      onClick={() => showInfo(`This toast uses "${transition}" transition.`, { transition })}
    >
      {transition}
    </Button>
  );
}

export const SlideTransition: Story = {
  name: 'Transition — Slide',
  render: () => (
    <ToastProvider transition="slide">
      <TransitionDemo transition="slide" />
    </ToastProvider>
  ),
};

export const GrowTransition: Story = {
  name: 'Transition — Grow',
  render: () => (
    <ToastProvider transition="grow">
      <TransitionDemo transition="grow" />
    </ToastProvider>
  ),
};

function PositionDemo() {
  const { showInfo } = useToast();
  const positions = [
    { vertical: 'top', horizontal: 'left' },
    { vertical: 'top', horizontal: 'center' },
    { vertical: 'top', horizontal: 'right' },
    { vertical: 'bottom', horizontal: 'left' },
    { vertical: 'bottom', horizontal: 'center' },
    { vertical: 'bottom', horizontal: 'right' },
  ] as const;

  return (
    <Stack spacing={1} direction="row" flexWrap="wrap" useFlexGap>
      {positions.map((pos) => (
        <Button
          key={`${pos.vertical}-${pos.horizontal}`}
          variant="outlined"
          size="small"
          onClick={() =>
            showInfo(`${pos.vertical} ${pos.horizontal}`, {
              anchorOrigin: pos,
            })
          }
        >
          {pos.vertical}-{pos.horizontal}
        </Button>
      ))}
    </Stack>
  );
}

export const Positions: Story = {
  name: 'Anchor positions',
  render: () => (
    <ToastProvider>
      <PositionDemo />
    </ToastProvider>
  ),
};

function OffsetDemo() {
  const { showInfo } = useToast();
  return (
    <Box>
      <Typography variant="body2" sx={{ mb: 1.5 }}>
        This provider is anchored bottom-right with <code>offset={'{300}'}</code>, so toasts sit
        300px above the bottom edge instead of the default 14px.
      </Typography>
      <Button variant="contained" onClick={() => showInfo('Lifted 300px above the bottom edge.')}>
        Show offset toast
      </Button>
    </Box>
  );
}

export const Offset: Story = {
  name: 'Relative offset (300px from bottom)',
  render: () => (
    <ToastProvider offset={300}>
      <OffsetDemo />
    </ToastProvider>
  ),
};

function PersistDemo() {
  const { showWarning, closeToast } = useToast();
  return (
    <Stack spacing={1.5} direction="row">
      <Button
        variant="contained"
        color="warning"
        onClick={() =>
          showWarning('This toast will not auto-dismiss. Close it manually.', {
            persist: true,
            key: 'persistent-toast',
          })
        }
      >
        Show persistent toast
      </Button>
      <Button variant="outlined" onClick={() => closeToast('persistent-toast')}>
        Dismiss by key
      </Button>
    </Stack>
  );
}

export const Persistent: Story = {
  name: 'Persistent (no auto-hide)',
  render: () => (
    <ToastProvider>
      <PersistDemo />
    </ToastProvider>
  ),
};

function StackedDemo() {
  const { showSuccess, showError, showWarning, showInfo } = useToast();
  const counter = useRef(0);
  const show = () => {
    counter.current += 1;
    const fns = [showSuccess, showError, showWarning, showInfo];
    const msgs = ['Saved!', 'Failed!', 'Check input', 'FYI'];
    const idx = counter.current % 4;
    fns[idx](msgs[idx]);
  };
  return (
    <Box>
      <Typography variant="body2" sx={{ mb: 1.5 }}>
        Click rapidly to see up to 3 stacked toasts (configurable via <code>maxToasts</code>).
      </Typography>
      <Button variant="contained" onClick={show}>
        Enqueue toast
      </Button>
    </Box>
  );
}

export const Stacked: Story = {
  name: 'Stacked (max 3)',
  render: () => (
    <ToastProvider maxToasts={3}>
      <StackedDemo />
    </ToastProvider>
  ),
};

interface InteractiveArgs {
  maxToasts: number;
  vertical: 'top' | 'bottom';
  horizontal: 'left' | 'center' | 'right';
  transition: ToastTransition;
  autoHideDuration: number;
  dense: boolean;
  offset: number;
  toastOffset: number;
  severity: ToastSeverity;
  title: string;
  message: string;
  persist: boolean;
}

function InteractiveDemo({
  severity,
  title,
  message,
  persist,
  toastOffset,
}: Pick<InteractiveArgs, 'severity' | 'title' | 'message' | 'persist' | 'toastOffset'>) {
  const { showToast, closeToast } = useToast();
  return (
    <Stack spacing={1.5} direction="row" flexWrap="wrap" useFlexGap>
      <Button
        variant="contained"
        onClick={() =>
          showToast(message, {
            severity,
            title: title || undefined,
            persist,
            offset: toastOffset || undefined,
          })
        }
      >
        Show toast
      </Button>
      <Button variant="outlined" onClick={() => closeToast()}>
        Dismiss all
      </Button>
    </Stack>
  );
}

export const Interactive: StoryObj<InteractiveArgs> = {
  name: 'Interactive',
  parameters: {
    ...interactiveControlsEnabled,
    docs: {
      description: {
        story:
          'Tweak every `ToastProvider` prop and the toast options live from the Controls panel, then click "Show toast". Provider-level props (position, offset, transition, max stack) reset the provider as you change them.',
      },
    },
  },
  argTypes: {
    ...unsafePropArgTypes,
    maxToasts: {
      control: { type: 'number', min: 1, max: 6, step: 1 },
      description: 'Maximum toasts visible at once.',
      table: { category: 'Provider' },
    },
    vertical: {
      control: 'inline-radio',
      options: ['top', 'bottom'],
      description: 'Vertical anchor of the toast container.',
      table: { category: 'Provider' },
    },
    horizontal: {
      control: 'inline-radio',
      options: ['left', 'center', 'right'],
      description: 'Horizontal anchor of the toast container.',
      table: { category: 'Provider' },
    },
    transition: {
      control: 'inline-radio',
      options: ['slide', 'grow'],
      description: 'Enter/exit animation.',
      table: { category: 'Provider' },
    },
    autoHideDuration: {
      control: { type: 'number', min: 1000, max: 15000, step: 500 },
      description: 'Milliseconds before auto-dismiss (ignored when "persist" is on).',
      table: { category: 'Provider' },
    },
    dense: {
      control: 'boolean',
      description: 'Denser spacing (useful on mobile).',
      table: { category: 'Provider' },
    },
    offset: {
      control: { type: 'number', min: 0, max: 600, step: 10 },
      description: 'Global offset (px) of the container from its anchored vertical edge.',
      table: { category: 'Provider' },
    },
    toastOffset: {
      control: { type: 'number', min: 0, max: 300, step: 10 },
      description: 'Individual offset (px) added to this toast on top of the global offset.',
      table: { category: 'Toast' },
    },
    severity: {
      control: 'inline-radio',
      options: ['success', 'error', 'warning', 'info'],
      description: 'Alert color and icon.',
      table: { category: 'Toast' },
    },
    title: {
      control: 'text',
      description: 'Optional bold title above the message.',
      table: { category: 'Toast' },
    },
    message: {
      control: 'text',
      description: 'Body text of the toast.',
      table: { category: 'Toast' },
    },
    persist: {
      control: 'boolean',
      description: 'Keep the toast until dismissed (overrides auto-hide).',
      table: { category: 'Toast' },
    },
  },
  args: {
    maxToasts: 3,
    vertical: 'bottom',
    horizontal: 'right',
    transition: 'slide',
    autoHideDuration: 5000,
    dense: false,
    offset: 24,
    toastOffset: 0,
    severity: 'info',
    title: 'Heads up',
    message: 'This is an interactive toast — tweak the controls and reshow.',
    persist: false,
  },
  render: ({
    maxToasts,
    vertical,
    horizontal,
    transition,
    autoHideDuration,
    dense,
    offset,
    toastOffset,
    severity,
    title,
    message,
    persist,
  }) => (
    <ToastProvider
      key={`${vertical}-${horizontal}-${transition}-${maxToasts}-${offset}-${dense}-${autoHideDuration}`}
      maxToasts={maxToasts}
      anchorOrigin={{ vertical, horizontal }}
      transition={transition}
      autoHideDuration={autoHideDuration}
      dense={dense}
      offset={offset}
    >
      <InteractiveDemo
        severity={severity}
        title={title}
        message={message}
        persist={persist}
        toastOffset={toastOffset}
      />
    </ToastProvider>
  ),
};
