import type { Meta, StoryObj } from '@storybook/react';
import { Switch } from '../../components';
import { useState } from 'react';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof Switch> = {
  title: 'UI Components/Switch',
  component: Switch,
  parameters: {
    layout: 'centered',
    ...metaControlsDisabled,
    docs: {
      description: {
        component:
          "Exotel-approved switch component that wraps MUI's Switch. Used for binary on/off states.",
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Switch>;

/**
 * Unchecked switch
 */
export const Unchecked: Story = {
  args: {
    checked: false,
  },
};

/**
 * Checked switch
 */
export const Checked: Story = {
  args: {
    checked: true,
  },
};

/**
 * Different colors
 */
export const Colors: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
      <Switch checked color="default" />
      <Switch checked color="primary" />
      <Switch checked color="secondary" />
      <Switch checked color="success" />
      <Switch checked color="error" />
      <Switch checked color="info" />
      <Switch checked color="warning" />
    </div>
  ),
};

/**
 * Different sizes
 */
export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
      <Switch checked size="small" />
      <Switch checked size="medium" />
    </div>
  ),
};

/**
 * With label
 */
export const WithLabel: Story = {
  render: () => {
    const [checked, setChecked] = useState(false);
    return (
      <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
        <Switch
          checked={checked}
          onChange={(e) => setChecked(e.target.checked)}
        />
        <span>Enable notifications</span>
      </label>
    );
  },
};

/**
 * Disabled state
 */
export const Disabled: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
      <Switch disabled />
      <Switch disabled checked />
    </div>
  ),
};

/**
 * Interactive playground — Controls enabled for serializable props.
 */
export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    icon: { control: false },
    checkedIcon: { control: false },
    onChange: { action: 'onChange' },
    color: {
      control: 'select',
      options: ['default', 'primary', 'secondary', 'error', 'info', 'success', 'warning'],
    },
    size: {
      control: 'select',
      options: ['small', 'medium'],
    },
    disabled: { control: 'boolean' },
    checked: { control: 'boolean' },
  },
  args: {
    checked: false,
    color: 'primary',
    size: 'medium',
    disabled: false,
  },
  render: (args) => {
    const [checked, setChecked] = useState(args.checked ?? false);
    return (
      <Switch
        {...args}
        checked={checked}
        onChange={(e, value) => {
          setChecked(e.target.checked);
          args.onChange?.(e, value);
        }}
      />
    );
  },
};
