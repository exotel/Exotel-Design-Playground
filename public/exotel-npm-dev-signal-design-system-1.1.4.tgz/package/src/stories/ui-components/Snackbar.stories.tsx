import type { Meta, StoryObj } from '@storybook/react';
import { Snackbar, Alert, Button, Box } from '../../components';
import { useState } from 'react';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof Snackbar> = {
  title: 'UI Components/Snackbar',
  component: Snackbar,
  parameters: { layout: 'centered', ...metaControlsDisabled },
};

export default meta;
type Story = StoryObj<typeof Snackbar>;

export const Basic: Story = {
  render: () => {
    const [open, setOpen] = useState(true);
    return (
      <Snackbar open={open} autoHideDuration={6000} onClose={() => setOpen(false)}>
        <Alert severity="success" onClose={() => setOpen(false)}>
          This is a success message!
        </Alert>
      </Snackbar>
    );
  },
};

export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    children: { control: false },
    open: { control: false },
    onClose: { action: 'onClose' },
    autoHideDuration: { control: 'number' },
    message: { control: 'text' },
    anchorOrigin: { control: 'object' },
  },
  args: {
    autoHideDuration: 6000,
    message: 'This is a snackbar message',
    anchorOrigin: { vertical: 'bottom', horizontal: 'left' },
  },
  render: (args) => {
    const [open, setOpen] = useState(false);
    const { message, onClose, ...rest } = args;

    return (
      <Box>
        <Button variant="contained" onClick={() => setOpen(true)}>
          Show Snackbar
        </Button>
        <Snackbar
          {...rest}
          open={open}
          onClose={(event, reason) => {
            setOpen(false);
            onClose?.(event, reason);
          }}
          message={message}
        />
      </Box>
    );
  },
};
