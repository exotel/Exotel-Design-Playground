import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { AppBar, Icon, Popover, Typography, Box } from '../../components';
import type { AvatarMenuFooterInfo, AvatarMenuGroup, Product, ThemeMode } from '../../components';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

function makeProducts(): Product[] {
  return [
    { id: 'home', name: 'Home', icon: <Icon name="house" size="md" />, section: 'home', order: 0, onProductClick: () => console.log('home') },
    { id: 'ecc', name: 'Enterprise Contact Centre', icon: <Icon name="headset" size="md" />, section: 'products', order: 0, onProductClick: () => console.log('ecc') },
    { id: 'voicebot', name: 'Voicebot', icon: <Icon name="phone" size="md" />, section: 'products', isTrial: true, order: 1, onProductClick: () => console.log('voicebot') },
    { id: 'chatbot', name: 'Chatbot', icon: <Icon name="chat" size="md" />, section: 'products', order: 2, onProductClick: () => console.log('chatbot') },
    { id: 'campaigns', name: 'Campaigns', icon: <Icon name="chart-line" size="md" />, section: 'recommended', order: 0, onProductClick: () => console.log('campaigns') },
    { id: 'engage', name: 'Engage', icon: <Icon name="envelope" size="md" />, section: 'explore', order: 0, onProductClick: () => console.log('engage') },
  ];
}

const DEFAULT_PRODUCTS = makeProducts();

const EXOTEL_LOGO_URL =
  'https://ik.imagekit.io/kx5hycpnh/LogoExpanded.svg?updatedAt=1763974367162';

const AVATAR_MENU_GROUPS: AvatarMenuGroup[] = [
  {
    id: 'primary',
    items: [
      { id: 'item1', label: 'Menu Item 1', onClick: () => console.log('item1') },
      { id: 'item2', label: 'Menu Item 2', onClick: () => console.log('item2') },
      { id: 'item3', label: 'Menu Item 3', onClick: () => console.log('item3') },
    ],
  },
  {
    id: 'secondary',
    items: [
      { id: 'error-logs', label: 'Send Error Logs', onClick: () => console.log('error-logs') },
      { id: 'shortcuts', label: 'Keyboard Shortcuts', onClick: () => console.log('shortcuts') },
    ],
  },
];

const AVATAR_MENU_FOOTER: AvatarMenuFooterInfo[] = [
  { label: 'Last Login', value: 'Jun 21 at 08:37' },
  { label: 'Version', value: '6.0' },
];

const sharedAvatarArgs = {
  avatarName: 'Anjali Srivastava',
  avatarMenuGroups: AVATAR_MENU_GROUPS,
  avatarFooterInfo: AVATAR_MENU_FOOTER,
  avatarSelectedTheme: 'system' as ThemeMode,
  onAvatarThemeChange: (mode: ThemeMode) => console.log('theme changed:', mode),
  onAvatarLogout: () => console.log('logout'),
};

const meta: Meta<typeof AppBar> = {
  title: 'UI Components/AppBar',
  component: AppBar,
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        component:
          'Composed app bar with an optional AppLauncher trigger, brand logo, notification bell, and AvatarMenu. Pass a URL string or any React node as `brandLogo`. Provide `appLauncherProducts` to show the launcher; omit it to hide.',
      },
    },
    ...metaControlsDisabled,
  },
};

export default meta;

type Story = StoryObj<typeof AppBar>;

/** Minimal shell: brand logo + AvatarMenu. */
export const Default: Story = {
  name: 'Default',
  parameters: {
    docs: {
      description: {
        story:
          'Baseline AppBar with logo and AvatarMenu. For menu groups, theme, footer info, presence, and other user-menu props, see the [AvatarMenu](?path=/docs/ui-components-avatar-menu--docs) docs.',
      },
    },
  },
  args: {
    brandLogo: EXOTEL_LOGO_URL,
    brandLogoAlt: 'Exotel',
    ...sharedAvatarArgs,
  },
};

export const LogoAsReactNode: Story = {
  name: 'Logo as React node',
  args: {
    brandLogo: (
      <svg width="96" height="24" viewBox="0 0 96 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-label="Exotel">
        <rect width="96" height="24" rx="4" fill="#0F3460" />
        <text x="8" y="17" fontFamily="sans-serif" fontSize="13" fontWeight="700" fill="white">exotel</text>
      </svg>
    ),
    ...sharedAvatarArgs,
  },
};

export const WithAppLauncher: Story = {
  name: 'With AppLauncher',
  parameters: {
    docs: {
      description: {
        story:
          'AppBar with product switcher enabled via `appLauncherProducts`. For layout modes (`default` / `sectioned`), product shape, trial chips, and launcher behavior, see the [AppLauncher](?path=/docs/ui-components-app-launcher--docs) docs.',
      },
    },
  },
  args: {
    brandLogo: EXOTEL_LOGO_URL,
    brandLogoAlt: 'Exotel',
    appLauncherType: 'sectioned',
    appLauncherProducts: DEFAULT_PRODUCTS,
    ...sharedAvatarArgs,
  },
};

export const WithAvatarPresence: Story = {
  name: 'With Avatar Presence',
  args: {
    brandLogo: EXOTEL_LOGO_URL,
    brandLogoAlt: 'Exotel',
    avatarPresenceStatus: 'available',
    ...sharedAvatarArgs,
  },
};

export const WithNotifications: Story = {
  name: 'With Notifications',
  render: (args) => {
    const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);
    const open = Boolean(anchorEl);

    return (
      <>
        <AppBar
          {...args}
          showNotificationIcon
          notificationOpen={open}
          onNotificationClick={(event) => {
            setAnchorEl(event.currentTarget);
          }}
        />
        <Popover
          open={open}
          anchorEl={anchorEl}
          onClose={() => setAnchorEl(null)}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
          transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        >
          <Box sx={{ p: 2, minWidth: 240 }}>
            <Typography variant="label2">Notifications</Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
              No new notifications.
            </Typography>
          </Box>
        </Popover>
      </>
    );
  },
  args: {
    brandLogo: EXOTEL_LOGO_URL,
    brandLogoAlt: 'Exotel',
    ...sharedAvatarArgs,
  },
};

export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    appLauncherProducts: { control: false },
    avatarMenuGroups: { control: false },
    avatarFooterInfo: { control: false },
    brandLogoStyle: { control: false },
    notificationButtonRef: { control: false },
    children: { control: false },
    onAvatarThemeChange: { action: 'onAvatarThemeChange' },
    onAvatarLogout: { action: 'onAvatarLogout' },
    onNotificationClick: { action: 'onNotificationClick' },
    appLauncherType: {
      control: 'radio',
      options: ['default', 'sectioned'],
    },
    appLauncherIconName: {
      control: 'select',
      options: ['squares-four', 'house', 'list', 'menu', 'columns'],
    },
    avatarSize: {
      control: 'select',
      options: ['small', 'medium', 'large'],
    },
    avatarPresenceStatus: {
      control: 'select',
      options: ['available', 'busy', 'do-not-disturb', 'be-right-back', 'away', 'offline'],
    },
    avatarSelectedTheme: {
      control: 'select',
      options: ['light', 'dark', 'system'],
    },
  },
  args: {
    brandLogo: EXOTEL_LOGO_URL,
    brandLogoAlt: 'Exotel',
    appLauncherType: 'sectioned',
    appLauncherProducts: DEFAULT_PRODUCTS,
    appLauncherIconName: 'squares-four',
    avatarName: 'Anjali Srivastava',
    avatarSize: 'small',
    avatarPresenceStatus: 'available',
    avatarMenuGroups: AVATAR_MENU_GROUPS,
    avatarFooterInfo: AVATAR_MENU_FOOTER,
    avatarSelectedTheme: 'system',
    showNotificationIcon: false,
    notificationOpen: false,
  },
  render: (args) => <AppBar {...args} />,
};
