import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { AvatarMenu, Stack, Typography } from '../../components';
import type { AvatarMenuGroup, AvatarMenuFooterInfo, ThemeMode, PresenceStatus } from '../../components';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const PRIMARY_GROUP: AvatarMenuGroup = {
  id: 'primary',
  items: [
    { id: 'item1', label: 'Menu Item 1', onClick: () => console.log('item1') },
    { id: 'item2', label: 'Menu Item 2', onClick: () => console.log('item2') },
    { id: 'item3', label: 'Menu Item 3', onClick: () => console.log('item3') },
  ],
};

const SECONDARY_GROUP: AvatarMenuGroup = {
  id: 'secondary',
  items: [
    { id: 'error-logs', label: 'Send Error Logs', onClick: () => console.log('error-logs') },
    { id: 'shortcuts', label: 'Keyboard Shortcuts', onClick: () => console.log('shortcuts') },
  ],
};

const FOOTER_INFO: AvatarMenuFooterInfo[] = [
  { label: 'Last Login', value: 'Jun 21 at 08:37' },
  { label: 'Version', value: '6.0' },
];

const PRESENCE_STATUSES: PresenceStatus[] = [
  'available',
  'busy',
  'do-not-disturb',
  'be-right-back',
  'away',
  'offline',
];

const meta: Meta<typeof AvatarMenu> = {
  title: 'UI Components/AvatarMenu',
  component: AvatarMenu,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'Avatar trigger (with presence-status badge) that opens a structured dropdown. Supply `menuGroups` — an array of item groups each separated by a divider. The header, Theme and Logout rows are built-in constants. Static footer rows (last login, version, etc.) are provided via `footerInfo: { label, value }[]`.',
      },
    },
    ...metaControlsDisabled,
  },
};

export default meta;
type Story = StoryObj<typeof AvatarMenu>;

export const Default: Story = {
  render: (args) => {
    const [selectedTheme, setSelectedTheme] = useState<ThemeMode>('system');
    return (
      <AvatarMenu
        {...args}
        selectedTheme={selectedTheme}
        onThemeChange={(mode) => { setSelectedTheme(mode); console.log('theme changed:', mode); }}
      />
    );
  },
  args: {
    avatarName: 'Anjali Srivastava',
    menuGroups: [PRIMARY_GROUP, SECONDARY_GROUP],
    footerInfo: FOOTER_INFO,
    onLogout: () => console.log('logout'),
    selectedTheme: 'system',
    onThemeChange: () => {},
  },
};

export const PresenceStatuses: Story = {
  name: 'Presence statuses',
  render: () => (
    <Stack direction="row" spacing={3} alignItems="center" flexWrap="wrap" useFlexGap>
      {PRESENCE_STATUSES.map((status) => (
        <Stack key={status} spacing={1} alignItems="center">
          <AvatarMenu
            avatarName="Anjali Srivastava"
            presenceStatus={status}
            menuGroups={[PRIMARY_GROUP]}
            footerInfo={FOOTER_INFO}
            selectedTheme="system"
            onThemeChange={() => {}}
            onLogout={() => {}}
          />
          <Typography variant="caption" color="text.secondary">
            {status}
          </Typography>
        </Stack>
      ))}
    </Stack>
  ),
};

export const LightThemeSelected: Story = {
  name: 'Light theme pre-selected',
  args: {
    avatarName: 'Olivia Pope',
    menuGroups: [PRIMARY_GROUP, SECONDARY_GROUP],
    footerInfo: FOOTER_INFO,
    selectedTheme: 'light',
    onThemeChange: (mode) => console.log('theme:', mode),
    onLogout: () => console.log('logout'),
  },
};

export const ThreeGroups: Story = {
  name: 'Three groups',
  render: (args) => {
    const [selectedTheme, setSelectedTheme] = useState<ThemeMode>('dark');
    return (
      <AvatarMenu
        {...args}
        selectedTheme={selectedTheme}
        onThemeChange={(mode) => { setSelectedTheme(mode); console.log('theme:', mode); }}
      />
    );
  },
  args: {
    avatarName: 'Rudraksh Prasanth',
    presenceStatus: 'busy',
    menuGroups: [
      {
        id: 'g1',
        items: [
          { id: 'item1', label: 'Menu Item 1', onClick: () => console.log('item1') },
          { id: 'item2', label: 'Menu Item 2', onClick: () => console.log('item2') },
          { id: 'item3', label: 'Menu Item 3', onClick: () => console.log('item3') },
        ],
      },
      {
        id: 'g2',
        items: [
          { id: 'error-logs', label: 'Send Error Logs', onClick: () => console.log('error-logs') },
          { id: 'shortcuts', label: 'Keyboard Shortcuts', onClick: () => console.log('shortcuts') },
        ],
      },
    ],
    footerInfo: [
      { label: 'Last Login', value: 'Mar 23 at 11:00' },
      { label: 'Version', value: '6.0' },
    ],
    selectedTheme: 'dark',
    onThemeChange: () => {},
    onLogout: () => console.log('logout'),
  },
};

export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    menuGroups: { control: false },
    onThemeChange: { action: 'onThemeChange' },
    onLogout: { action: 'onLogout' },
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
    },
    presenceStatus: {
      control: 'select',
      options: PRESENCE_STATUSES,
    },
    selectedTheme: {
      control: 'select',
      options: ['light', 'dark', 'system'],
    },
  },
  args: {
    avatarName: 'Anjali Srivastava',
    size: 'medium',
    presenceStatus: 'available',
    menuGroups: [PRIMARY_GROUP, SECONDARY_GROUP],
    footerInfo: FOOTER_INFO,
    selectedTheme: 'system',
  },
  render: (args) => {
    const [selectedTheme, setSelectedTheme] = useState<ThemeMode>(args.selectedTheme);
    return (
      <AvatarMenu
        {...args}
        selectedTheme={selectedTheme}
        onThemeChange={(mode) => {
          setSelectedTheme(mode);
          args.onThemeChange?.(mode);
        }}
      />
    );
  },
};
