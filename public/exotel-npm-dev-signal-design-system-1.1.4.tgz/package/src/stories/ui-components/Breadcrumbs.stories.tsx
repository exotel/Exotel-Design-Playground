import type { Meta, StoryObj } from '@storybook/react';
import { Breadcrumbs, Link, Typography, Icon, Box } from '../../components';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof Breadcrumbs> = {
  title: 'UI Components/Breadcrumbs',
  component: Breadcrumbs,
  parameters: {
    layout: 'centered',
    ...metaControlsDisabled,
    docs: {
      description: {
        component:
          'Exotel-approved breadcrumbs component that wraps MUI\'s Breadcrumbs. Displays navigation hierarchy using a list of links.',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Breadcrumbs>;

export const Default: Story = {
  render: () => (
    <Breadcrumbs>
      <Link underline="hover" color="inherit" href="#">
        Home
      </Link>
      <Link underline="hover" color="inherit" href="#">
        Settings
      </Link>
      <Typography color="text.primary">General</Typography>
    </Breadcrumbs>
  ),
};

export const WithIcons: Story = {
  render: () => (
    <Breadcrumbs>
      <Link underline="hover" color="inherit" href="#" sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
        <Icon name="house" size="xs" />
        Home
      </Link>
      <Link underline="hover" color="inherit" href="#" sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
        <Icon name="gear" size="xs" />
        Settings
      </Link>
      <Typography color="text.primary" sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
        <Icon name="user" size="xs" />
        Profile
      </Typography>
    </Breadcrumbs>
  ),
};

export const CustomSeparator: Story = {
  render: () => (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      <Breadcrumbs separator="›">
        <Link underline="hover" color="inherit" href="#">Home</Link>
        <Link underline="hover" color="inherit" href="#">Category</Link>
        <Typography color="text.primary">Item</Typography>
      </Breadcrumbs>
      <Breadcrumbs separator="-">
        <Link underline="hover" color="inherit" href="#">Home</Link>
        <Link underline="hover" color="inherit" href="#">Category</Link>
        <Typography color="text.primary">Item</Typography>
      </Breadcrumbs>
      <Breadcrumbs separator={<Icon name="caret-right" size="xs" />}>
        <Link underline="hover" color="inherit" href="#">Home</Link>
        <Link underline="hover" color="inherit" href="#">Category</Link>
        <Typography color="text.primary">Item</Typography>
      </Breadcrumbs>
    </Box>
  ),
};

export const Collapsed: Story = {
  args: {
    maxItems: 3,
    itemsBeforeCollapse: 1,
    itemsAfterCollapse: 1,
  },
  render: (args) => (
    <Breadcrumbs {...args}>
      <Link underline="hover" color="inherit" href="#">Home</Link>
      <Link underline="hover" color="inherit" href="#">Dashboard</Link>
      <Link underline="hover" color="inherit" href="#">Settings</Link>
      <Link underline="hover" color="inherit" href="#">Security</Link>
      <Typography color="text.primary">Passwords</Typography>
    </Breadcrumbs>
  ),
};

export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    children: { control: false },
    separator: { control: 'text' },
    maxItems: { control: 'number' },
    itemsBeforeCollapse: { control: 'number' },
    itemsAfterCollapse: { control: 'number' },
  },
  args: {
    separator: '/',
    maxItems: 8,
    itemsBeforeCollapse: 1,
    itemsAfterCollapse: 1,
  },
  render: (args) => (
    <Breadcrumbs {...args}>
      <Link underline="hover" color="inherit" href="#">Home</Link>
      <Link underline="hover" color="inherit" href="#">Dashboard</Link>
      <Link underline="hover" color="inherit" href="#">Settings</Link>
      <Typography color="text.primary">General</Typography>
    </Breadcrumbs>
  ),
};
