/**
 * DataGrid Component Stories
 */

import type { Meta, StoryObj } from '@storybook/react';
import type { ReactNode } from 'react';
import {
  DataGrid,
  type DataGridColDef,
  type ToolbarButtonConfig,
  type ToolbarFilterConfig,
  type DateRangeValue,
  type FilterRecords,
} from '../../components/DataGrid';
import { Icon } from '../../components/Icon';
import { IconButton } from '../../components/IconButton';
import { Tooltip } from '../../components/Tooltip';
import { getAvatarColors } from '../../functions';
import type { MultiSelectOption } from '../../components/MultiSelect';
import type { GridListViewColDef, GridRenderCellParams, GridRowId, GridRowsProp } from '../..';
import { useState, useEffect, useCallback, useRef } from 'react';
import { Alert, Avatar, Box, Chip, Stack, Typography, Menu } from '../../components';
import MenuItem from '@mui/material/MenuItem';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import type { GridDensity, GridSortModel } from '@mui/x-data-grid-pro';
import dayjs from 'dayjs';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const ENTITY_LABEL = 'Team Members';

const meta: Meta<typeof DataGrid> = {
  title: 'UI Components/DataGrid',
  component: DataGrid,
  parameters: {
    layout: 'padded',
    ...metaControlsDisabled,
    docs: {
      description: {
        component: `
### DataGrid

A thin abstraction layer over MUI X DataGridPro that provides a consistent API while preserving full access to the underlying component's capabilities.

**Responsive toolbar (below 756px width):** filter selects, multi-select, date range, **Manage columns**, and **Sort** use **bottom drawers**; at **756px and wider** they use standard dropdowns/popovers.

**Responsive layout (below the \`sm\` breakpoint, 600px):** the grid automatically switches to a mobile **list view** using \`listCellConfig\` (or a custom \`listViewColumn\`).

**API Documentation:**
For the complete list of available props, refer to the [MUI DataGridPro API](https://mui.com/x/api/data-grid/data-grid-pro/)
        `,
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof DataGrid>;

// ──────────────────────────────────────────────────────────
// Shared fixtures & helpers
// ──────────────────────────────────────────────────────────

const sampleRows: GridRowsProp = [
  { id: 1, name: 'Sarah Connor', email: 'sarah.connor@example.com', role: 'Admin', status: 'Active', joinDate: '2026-01-23' },
  { id: 2, name: 'Kyle Reese', email: 'kyle.reese@example.com', role: 'Manager', status: 'Active', joinDate: '2026-01-23' },
  { id: 3, name: 'Ellen Ripley', email: 'ellen.ripley@example.com', role: 'User', status: 'Active', joinDate: '2026-01-22' },
  { id: 4, name: 'Han Solo', email: 'han.solo@example.com', role: 'User', status: 'Inactive', joinDate: '2026-01-22' },
  { id: 5, name: 'Leia Organa', email: 'leia.organa@example.com', role: 'Admin', status: 'Active', joinDate: '2026-01-21' },
  { id: 6, name: 'Luke Skywalker', email: 'luke.skywalker@example.com', role: 'Manager', status: 'Active', joinDate: '2026-01-21' },
  { id: 7, name: 'Obi-Wan Kenobi', email: 'obiwan.kenobi@example.com', role: 'User', status: 'Active', joinDate: '2026-01-20' },
  { id: 8, name: 'Anakin Skywalker', email: 'anakin.skywalker@example.com', role: 'User', status: 'Inactive', joinDate: '2026-01-20' },
  { id: 9, name: 'Tony Stark', email: 'tony.stark@example.com', role: 'Admin', status: 'Active', joinDate: '2026-01-19' },
  { id: 10, name: 'Bruce Banner', email: 'bruce.banner@example.com', role: 'User', status: 'Active', joinDate: '2026-01-18' },
  { id: 11, name: 'Natasha Romanoff', email: 'natasha.romanoff@example.com', role: 'Manager', status: 'Active', joinDate: '2026-01-17' },
  { id: 12, name: 'Steve Rogers', email: 'steve.rogers@example.com', role: 'Admin', status: 'Active', joinDate: '2026-01-16' },
  { id: 13, name: 'Thor Odinson', email: 'thor.odinson@example.com', role: 'User', status: 'Active', joinDate: '2026-01-15' },
  { id: 14, name: 'Peter Parker', email: 'peter.parker@example.com', role: 'User', status: 'Inactive', joinDate: '2026-01-14' },
  { id: 15, name: 'Wanda Maximoff', email: 'wanda.maximoff@example.com', role: 'Manager', status: 'Active', joinDate: '2026-01-13' },
  { id: 16, name: 'John Doe', email: 'john.doe@example.com', role: 'Admin', status: 'Active', joinDate: '2023-01-15' },
  { id: 17, name: 'Jane Smith', email: 'jane.smith@example.com', role: 'User', status: 'Active', joinDate: '2023-02-20' },
  { id: 18, name: 'Bob Johnson', email: 'bob.johnson@example.com', role: 'User', status: 'Inactive', joinDate: '2023-03-10' },
  { id: 19, name: 'Alice Williams', email: 'alice.williams@example.com', role: 'Manager', status: 'Active', joinDate: '2023-04-05' },
  { id: 20, name: 'Charlie Brown', email: 'charlie.brown@example.com', role: 'User', status: 'Active', joinDate: '2023-05-12' },
];

const TOTAL_ROWS = sampleRows.length;

function entityTitle(count: number = TOTAL_ROWS): string {
  return `${ENTITY_LABEL} (${count})`;
}

function getInitials(name: string): string {
  return name
    .split(' ')
    .filter(Boolean)
    .map((part) => part[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();
}

function statusChipColor(status: string): 'success' | 'default' {
  return status === 'Active' ? 'success' : 'default';
}

function StoryWrapper({ children, height = 680 }: { children: ReactNode; height?: number | string }) {
  return <Box sx={{ height, width: '100%' }}>{children}</Box>;
}

function ViewportHint() {
  return (
    <Alert severity="info" sx={{ mb: 1.5 }}>
      Change the Storybook viewport (toolbar above the canvas) to <strong>Small mobile</strong> or{' '}
      <strong>Large mobile</strong> to preview the list layout.
    </Alert>
  );
}

const bulkDeleteConfig = {
  onDelete: (ids: GridRowId[]) => alert(`Delete ${ids.length} rows`),
  label: (count: number) => `Delete ${count} Rows`,
};

const statusFilterOptions = [
  { value: 'all', label: 'All status' },
  { value: 'Active', label: 'Active' },
  { value: 'Inactive', label: 'Inactive' },
];

const roleFilterOptions = [
  { value: 'all', label: 'All roles' },
  { value: 'Admin', label: 'Admin' },
  { value: 'User', label: 'User' },
  { value: 'Manager', label: 'Manager' },
];

function createStatusFilter(initialValue = 'all'): ToolbarFilterConfig {
  return {
    id: 'status',
    type: 'select',
    label: 'Status',
    iconName: 'check-circle',
    initialValue,
    options: statusFilterOptions,
  };
}

function createRoleFilter(initialValue = 'all'): ToolbarFilterConfig {
  return {
    id: 'role',
    type: 'select',
    label: 'Role',
    iconName: 'shield-check',
    initialValue,
    options: roleFilterOptions,
  };
}

const roleMultiSelectOptions: MultiSelectOption[] = [
  { id: 'admin', label: 'Admin', value: 'Admin' },
  { id: 'manager', label: 'Manager', value: 'Manager' },
  { id: 'user', label: 'User', value: 'User' },
];

function createRoleMultiSelectFilter(initialValue: string[] = []): ToolbarFilterConfig {
  return {
    id: 'role',
    type: 'multi-select',
    label: 'Role',
    iconName: 'shield-check',
    initialValue,
    multiSelectOptions: roleMultiSelectOptions,
    placeholder: 'Select roles',
  };
}

const emptyDateRange: DateRangeValue = { startDate: null, endDate: null };

function createJoinDateRangeFilter(initialValue: DateRangeValue = emptyDateRange): ToolbarFilterConfig {
  return {
    id: 'joinDate',
    type: 'date-range',
    label: 'Join date range',
    iconName: 'calendar-blank',
    initialValue,
  };
}

const sampleColumns: DataGridColDef[] = [
  { field: 'id', headerName: 'ID', width: 90, iconName: 'hash' },
  {
    field: 'name',
    headerName: 'Name',
    width: 220,
    iconName: 'user',
    renderCell: (params) => (
      <Stack direction="row" spacing={1} alignItems="center" sx={{ height: '100%' }}>
        <Avatar sx={{ width: 32, height: 32, typography: 'label3' }}>
          {getInitials(params.value as string)}
        </Avatar>
        <Typography variant="body2">{params.value as string}</Typography>
      </Stack>
    ),
  },
  { field: 'email', headerName: 'Email', width: 250, iconName: 'envelope-simple' },
  { field: 'role', headerName: 'Role', width: 150, iconName: 'shield-check' },
  {
    field: 'status',
    headerName: 'Status',
    width: 130,
    iconName: 'check-circle',
    renderCell: (params) => (
      <Stack alignItems="flex-start" justifyContent="center" sx={{ height: '100%' }}>
        <Chip
          label={params.value as string}
          variant="tonal"
          color={statusChipColor(params.value as string)}
          size="small"
        />
      </Stack>
    ),
  },
  { field: 'joinDate', headerName: 'Join Date', width: 150, iconName: 'calendar-blank' },
];

type RowData = (typeof sampleRows)[number];

// ──────────────────────────────────────────────────────────
// Fake server helper (used by server-side pagination/filters/interactive)
// ──────────────────────────────────────────────────────────

const FAKE_DELAY_MS = 800;

interface ServerFetchResult {
  rows: RowData[];
  totalRows: number;
}

function fakeServerFetch(
  allRows: readonly RowData[],
  filters: FilterRecords,
  sort: GridSortModel,
  page: number,
  pageSize: number
): Promise<ServerFetchResult> {
  return new Promise((resolve) => {
    setTimeout(() => {
      let rows = [...allRows];

      const status = filters.status as string | undefined;
      if (status && status !== 'all') {
        rows = rows.filter((r) => r.status === status);
      }

      const role = filters.role;
      if (Array.isArray(role)) {
        if (role.length > 0) {
          rows = rows.filter((r) => role.includes(r.role));
        }
      } else if (role && role !== 'all') {
        rows = rows.filter((r) => r.role === role);
      }

      const joinDate = filters.joinDate as DateRangeValue | undefined;
      if (joinDate?.startDate && joinDate?.endDate) {
        rows = rows.filter((r) => {
          const rowDate = dayjs(r.joinDate);
          return (
            (rowDate.isAfter(joinDate.startDate) || rowDate.isSame(joinDate.startDate, 'day')) &&
            (rowDate.isBefore(joinDate.endDate) || rowDate.isSame(joinDate.endDate, 'day'))
          );
        });
      }

      if (sort.length > 0) {
        const { field, sort: dir } = sort[0];
        rows.sort((a, b) => {
          const aVal = a[field] as string;
          const bVal = b[field] as string;
          const cmp = aVal < bVal ? -1 : aVal > bVal ? 1 : 0;
          return dir === 'desc' ? -cmp : cmp;
        });
      }

      const totalRows = rows.length;
      const start = page * pageSize;
      const paginatedRows = rows.slice(start, start + pageSize);

      resolve({ rows: paginatedRows, totalRows });
    }, FAKE_DELAY_MS);
  });
}

// ──────────────────────────────────────────────────────────
// Without toolbar
// ──────────────────────────────────────────────────────────

export const WithoutToolbar: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Grid with the toolbar hidden via `showToolbar={false}` — no search, filters, or column/sort controls.',
      },
    },
  },
  render: (args) => (
    <StoryWrapper>
      <DataGrid {...args} />
    </StoryWrapper>
  ),
  args: {
    rows: sampleRows,
    columns: sampleColumns,
    tableHeader: { title: entityTitle() },
    showToolbar: false,
  },
};

// ──────────────────────────────────────────────────────────
// With custom toolbar buttons
// ──────────────────────────────────────────────────────────

export const WithCustomToolbarButtons: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Additional toolbar actions via `customToolbarButtons`, alongside the default search and sort controls.',
      },
    },
  },
  render: (args) => (
    <StoryWrapper>
      <DataGrid {...args} />
    </StoryWrapper>
  ),
  args: {
    rows: sampleRows,
    columns: sampleColumns,
    tableHeader: { title: entityTitle() },
    initialState: { pagination: { paginationModel: { page: 0, pageSize: 5 } } },
    pageSizeOptions: [5, 10, 25],
    pagination: true,
    customToolbarButtons: [
      { id: 'add', icon: <Icon name="plus" size={20} />, label: 'Add New', tooltip: 'Add new row', onClick: () => alert('Add'), color: 'primary' },
      { id: 'delete', icon: <Icon name="trash" size={20} />, label: 'Delete', tooltip: 'Delete', onClick: () => alert('Delete'), color: 'error' },
    ] as ToolbarButtonConfig[],
  },
};

// ──────────────────────────────────────────────────────────
// Loading state
// ──────────────────────────────────────────────────────────

export const LoadingState: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Loading state via `loading={true}` — the grid shows a skeleton overlay while data is being fetched.',
      },
    },
  },
  render: (args) => (
    <StoryWrapper height={480}>
      <DataGrid {...args} />
    </StoryWrapper>
  ),
  args: {
    rows: [],
    columns: sampleColumns,
    tableHeader: { title: entityTitle() },
    loading: true,
  },
};

// ──────────────────────────────────────────────────────────
// Error state
// ──────────────────────────────────────────────────────────

export const ErrorState: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Error overlay via `error={true}` with a refresh action wired to `onRefresh`.',
      },
    },
  },
  render: (args) => (
    <StoryWrapper height={480}>
      <DataGrid {...args} onRefresh={() => alert('Refreshing...')} />
    </StoryWrapper>
  ),
  args: {
    rows: sampleRows,
    columns: sampleColumns,
    tableHeader: { title: entityTitle() },
    error: true,
  },
};

// ──────────────────────────────────────────────────────────
// With checkbox (bulk delete)
// ──────────────────────────────────────────────────────────

export const WithCheckboxBulkDelete: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Bulk row selection via `checkboxSelection` — selecting rows reveals a bulk delete action via `bulkDeleteConfig`.',
      },
    },
  },
  render: (args) => (
    <StoryWrapper>
      <DataGrid {...args} />
    </StoryWrapper>
  ),
  args: {
    rows: sampleRows,
    columns: sampleColumns,
    tableHeader: { title: entityTitle() },
    checkboxSelection: true,
    initialState: { pagination: { paginationModel: { page: 0, pageSize: 5 } } },
    pageSizeOptions: [5, 10, 25],
    pagination: true,
    bulkDeleteConfig,
  },
};

// ──────────────────────────────────────────────────────────
// Default list view (mobile)
// ──────────────────────────────────────────────────────────

export const DefaultListView: Story = {
  parameters: {
    viewport: { defaultViewport: 'mobile1' },
    docs: {
      description: {
        story:
          'Below the `sm` breakpoint (600px) the grid automatically switches to the built-in mobile list layout, configured via `listCellConfig`. Set the Storybook viewport to a small screen to see list mode.',
      },
    },
  },
  render: (args) => (
    <>
      <ViewportHint />
      <StoryWrapper height={640}>
        <DataGrid {...args} />
      </StoryWrapper>
    </>
  ),
  args: {
    rows: sampleRows,
    columns: sampleColumns,
    tableHeader: { title: entityTitle() },
    listCellConfig: {
      primaryField: 'name',
      secondaryField: 'joinDate',
      iconName: 'user',
      excludeFields: ['id', 'email'],
    },
    initialState: { pagination: { paginationModel: { page: 0, pageSize: 10 } } },
    pageSizeOptions: [5, 10, 25],
    pagination: true,
  },
};

// ──────────────────────────────────────────────────────────
// Custom list view (mobile)
// ──────────────────────────────────────────────────────────

export const CustomListView: Story = {
  parameters: {
    viewport: { defaultViewport: 'mobile1' },
    docs: {
      description: {
        story:
          'Overrides the mobile list cell with a fully custom `listViewColumn` render — an Avatar with a status-tinted ring, name paired with a tonal status chip, a muted email · role subtitle, and a trailing chevron affordance — instead of the default `listCellConfig` layout.',
      },
    },
  },
  render: (args) => {
    const listViewColumn: GridListViewColDef = {
      field: 'listColumn',
      renderCell: (params: GridRenderCellParams) => {
        const name = params.row.name as string;
        const status = params.row.status as string;
        const color = statusChipColor(status);
        const avatarColors = getAvatarColors(name);

        return (
          <Stack
            direction="row"
            spacing={1.5}
            alignItems="center"
            sx={{
              width: '100%',
              height: '100%',
              px: 2,
              borderBottom: '1px solid',
              borderColor: 'divider',
            }}
          >
            <Avatar
              sx={{
                width: 44,
                height: 44,
                flexShrink: 0,
                typography: 'label2',
                bgcolor: avatarColors.bgcolor,
                color: avatarColors.color,
                border: '2px solid',
                borderColor: color === 'success' ? 'success.main' : 'grey.400',
              }}
            >
              {getInitials(name)}
            </Avatar>

            <Stack spacing={0.25} sx={{ flex: 1, minWidth: 0 }}>
              <Stack direction="row" spacing={1} alignItems="center">
                <Typography variant="title2" noWrap>
                  {params.row.name}
                </Typography>
                <Chip label={status} variant="tonal" color={color} size="small" />
              </Stack>
              <Typography variant="body2" color="text.secondary" noWrap>
                {params.row.email} · {params.row.role}
              </Typography>
            </Stack>

            <Icon name="caret-right" size="sm" color="text.secondary" />
          </Stack>
        );
      },
    };

    return (
      <StoryWrapper height={640}>
        <DataGrid {...args} listView listViewColumn={listViewColumn} rowHeight={80} />
      </StoryWrapper>
    );
  },
  args: {
    rows: sampleRows,
    columns: sampleColumns,
    tableHeader: { title: entityTitle() },
    initialState: { pagination: { paginationModel: { page: 0, pageSize: 10 } } },
    pageSizeOptions: [5, 10, 25],
    pagination: true,
  },
};

// ──────────────────────────────────────────────────────────
// With table header
// ──────────────────────────────────────────────────────────

export const WithTableHeader: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Canonical management page header: title with total count, subtitle, search, and primary CTA via `tableHeader`.',
      },
    },
  },
  render: (args) => {
    const [search, setSearch] = useState('');
    const filteredRows = sampleRows.filter((row) => {
      if (!search) return true;
      const term = search.toLowerCase();
      return (
        String(row.name).toLowerCase().includes(term) ||
        String(row.email).toLowerCase().includes(term) ||
        String(row.role).toLowerCase().includes(term)
      );
    });

    return (
      <StoryWrapper>
        <DataGrid
          {...args}
          rows={filteredRows}
          tableHeader={{
            title: entityTitle(filteredRows.length),
            subtitle: 'Manage your team members and their roles',
            showSearch: true,
            searchType: 'basic',
            onBasicSearch: setSearch,
            actions: [
              { id: 'export', children: 'Export', variant: 'outlined' },
              { id: 'add', children: 'Add Member', variant: 'contained', startIconProps: { name: 'plus' } },
            ],
          }}
        />
      </StoryWrapper>
    );
  },
  args: {
    columns: sampleColumns,
    initialState: { pagination: { paginationModel: { page: 0, pageSize: 10 } } },
    pageSizeOptions: [5, 10, 25],
    pagination: true,
  },
};

// ──────────────────────────────────────────────────────────
// With pagination (server side)
// ──────────────────────────────────────────────────────────

export const WithPaginationServerSide: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'Server-driven pagination with `paginationMode="server"` and `rowCount`. Each page change triggers a fake server call (~800 ms) and shows a loading state.',
      },
    },
  },
  render: (args) => {
    const [rows, setRows] = useState<RowData[]>([]);
    const [loading, setLoading] = useState(true);
    const [rowCount, setRowCount] = useState(0);
    const [paginationModel, setPaginationModel] = useState({ page: 0, pageSize: 10 });

    const fetchPage = useCallback((page: number, pageSize: number) => {
      setLoading(true);
      fakeServerFetch(sampleRows, {}, [], page, pageSize).then((result) => {
        setRows(result.rows);
        setRowCount(result.totalRows);
        setLoading(false);
      });
    }, []);

    useEffect(() => {
      fetchPage(paginationModel.page, paginationModel.pageSize);
    }, []);

    const handlePaginationModelChange = useCallback(
      (newModel: typeof paginationModel) => {
        setPaginationModel(newModel);
        fetchPage(newModel.page, newModel.pageSize);
      },
      [fetchPage]
    );

    return (
      <StoryWrapper>
        <DataGrid
          {...args}
          rows={rows}
          loading={loading}
          rowCount={rowCount}
          paginationMode="server"
          paginationModel={paginationModel}
          onPaginationModelChange={handlePaginationModelChange}
          tableHeader={{ title: entityTitle(rowCount) }}
        />
      </StoryWrapper>
    );
  },
  args: {
    columns: sampleColumns,
    pagination: true,
    pageSizeOptions: [5, 10, 25],
  },
};

// ──────────────────────────────────────────────────────────
// With filters (server side)
// ──────────────────────────────────────────────────────────

export const WithFiltersServerSide: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'Server-driven filtering with all three filter types — `select` (Status), `multi-select` (Role), and `date-range` (Join date). Filters start cleared so **Clear All** in the applied filters bar has a real effect: apply a few filters, then Clear All resets every control and refetches the full unfiltered list. Every filter change triggers a fake server call (~800 ms) that re-fetches page 0 with the active filters applied.',
      },
    },
  },
  render: (args) => {
    const [rows, setRows] = useState<RowData[]>([]);
    const [loading, setLoading] = useState(true);
    const [rowCount, setRowCount] = useState(0);
    const [paginationModel, setPaginationModel] = useState({ page: 0, pageSize: 10 });
    const filtersRef = useRef<FilterRecords>({
      status: 'all',
      role: [],
      joinDate: emptyDateRange,
    });

    const fetchData = useCallback((filters: FilterRecords, page: number, pageSize: number) => {
      setLoading(true);
      fakeServerFetch(sampleRows, filters, [], page, pageSize).then((result) => {
        setRows(result.rows);
        setRowCount(result.totalRows);
        setLoading(false);
      });
    }, []);

    useEffect(() => {
      fetchData(filtersRef.current, paginationModel.page, paginationModel.pageSize);
    }, []);

    const handleFiltersChange = useCallback(
      (newFilters: FilterRecords) => {
        filtersRef.current = newFilters;
        setPaginationModel((prev) => ({ ...prev, page: 0 }));
        fetchData(newFilters, 0, paginationModel.pageSize);
      },
      [paginationModel.pageSize, fetchData]
    );

    const handlePaginationModelChange = useCallback(
      (newModel: typeof paginationModel) => {
        setPaginationModel(newModel);
        fetchData(filtersRef.current, newModel.page, newModel.pageSize);
      },
      [fetchData]
    );

    return (
      <StoryWrapper>
        <DataGrid
          {...args}
          rows={rows}
          loading={loading}
          rowCount={rowCount}
          paginationMode="server"
          paginationModel={paginationModel}
          onPaginationModelChange={handlePaginationModelChange}
          tableHeader={{ title: entityTitle(rowCount) }}
          showAppliedFilters
          maxVisibleAppliedFilters={4}
          customToolbarFilters={[
            createStatusFilter(),
            createRoleMultiSelectFilter(),
            createJoinDateRangeFilter(),
          ]}
          onToolbarFiltersChange={handleFiltersChange}
        />
      </StoryWrapper>
    );
  },
  args: {
    columns: sampleColumns,
    pagination: true,
    pageSizeOptions: [5, 10, 25],
  },
};

// ──────────────────────────────────────────────────────────
// Density
// ──────────────────────────────────────────────────────────

const densityOptions: { value: GridDensity; label: string }[] = [
  { value: 'compact', label: 'Compact' },
  { value: 'standard', label: 'Standard' },
  { value: 'comfortable', label: 'Comfortable' },
];

/**
 * Row density via the `density` prop — toggle between `compact`, `standard`,
 * and `comfortable` to adjust row height and cell padding.
 */
export const Density: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'Row density via `density` — switch between `compact`, `standard`, and `comfortable` to adjust row height and cell padding. Use the toolbar buttons above the grid, or the Storybook controls panel, to change it.',
      },
    },
  },
  render: (args) => {
    const [density, setDensity] = useState<GridDensity>('standard');

    return (
      <Stack spacing={1.5}>
        <Stack direction="row" spacing={1}>
          {densityOptions.map((option) => (
            <Chip
              key={option.value}
              label={option.label}
              size="small"
              variant={density === option.value ? 'tonal' : 'outlined'}
              color={density === option.value ? 'primary' : 'default'}
              onClick={() => setDensity(option.value)}
            />
          ))}
        </Stack>
        <StoryWrapper>
          <DataGrid {...args} density={density} />
        </StoryWrapper>
      </Stack>
    );
  },
  args: {
    rows: sampleRows,
    columns: sampleColumns,
    tableHeader: { title: entityTitle() },
    initialState: { pagination: { paginationModel: { page: 0, pageSize: 10 } } },
    pageSizeOptions: [5, 10, 25],
    pagination: true,
  },
};

// ──────────────────────────────────────────────────────────
// Interactive (kitchen sink)
// ──────────────────────────────────────────────────────────

function RowActionsMenu({ rowId, rowName }: { rowId: number; rowName: string }) {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const handleClose = () => setAnchorEl(null);

  return (
    <>
      <Stack height="100%" alignItems="center" justifyContent="center">
        <Tooltip title="Actions">
          <IconButton
            size="small"
            variant="outlined"
            aria-label="Row actions"
            onClick={(event) => {
              event.stopPropagation();
              setAnchorEl(event.currentTarget);
            }}
          >
            <Icon name="dots-three-vertical" size="sm" />
          </IconButton>
        </Tooltip>
      </Stack>
      <Menu anchorEl={anchorEl} open={open} onClose={handleClose}>
        <MenuItem
          onClick={() => {
            alert(`Edit row ${rowId}: ${rowName}`);
            handleClose();
          }}
        >
          <ListItemIcon>
            <Icon name="pencil-simple" size="sm" />
          </ListItemIcon>
          <ListItemText>Edit</ListItemText>
        </MenuItem>
        <MenuItem
          onClick={() => {
            alert(`Delete row ${rowId}: ${rowName}`);
            handleClose();
          }}
        >
          <ListItemIcon>
            <Icon name="trash" size="sm" />
          </ListItemIcon>
          <ListItemText>Delete</ListItemText>
        </MenuItem>
      </Menu>
    </>
  );
}

const interactiveColumns: DataGridColDef[] = [
  ...sampleColumns,
  {
    field: 'actions',
    headerName: ' ',
    width: 56,
    sortable: false,
    disableColumnMenu: true,
    renderCell: (params) => (
      <RowActionsMenu rowId={params.row.id as number} rowName={params.row.name as string} />
    ),
  },
];

/**
 * Full-featured playground combining table header, search, server-side filters,
 * sorting, pagination, checkbox selection, bulk delete, row actions, and refresh.
 * Use the controls panel to explore individual props against this composition.
 */
export const Interactive: Story = {
  parameters: {
    ...interactiveControlsEnabled,
    docs: {
      description: {
        story:
          'Kitchen-sink story combining header search, server-side filters/sort/pagination, checkbox selection with bulk delete, and a row actions menu — the canonical full management grid composition.',
      },
    },
  },
  argTypes: {
    ...unsafePropArgTypes,
    rows: { control: false },
    columns: { control: false },
    customToolbarFilters: { control: false },
    tableHeader: { control: false },
    bulkDeleteConfig: { control: false },
    listCellConfig: { control: false },
    listViewColumn: { control: false },
    apiRef: { control: false },
    onToolbarFiltersChange: { action: 'onToolbarFiltersChange' },
    onRefresh: { action: 'onRefresh' },
    showAppliedFilters: { control: 'boolean' },
    maxVisibleAppliedFilters: { control: 'number' },
    pagination: { control: 'boolean' },
    checkboxSelection: { control: 'boolean' },
    density: {
      control: 'select',
      options: ['compact', 'standard', 'comfortable'],
    },
    loading: { control: 'boolean' },
    disableColumnMenu: { control: 'boolean' },
    disableColumnFilter: { control: 'boolean' },
    disableColumnSelector: { control: 'boolean' },
    disableDensitySelector: { control: 'boolean' },
    hideFooter: { control: 'boolean' },
    autoHeight: { control: 'boolean' },
  },
  args: {
    columns: interactiveColumns,
    pagination: true,
    pageSizeOptions: [5, 10, 25],
  },
  render: (args) => {
    const [rows, setRows] = useState<RowData[]>([]);
    const [loading, setLoading] = useState(true);
    const [rowCount, setRowCount] = useState(0);
    const [sortModel, setSortModel] = useState<GridSortModel>([]);
    const [paginationModel, setPaginationModel] = useState({ page: 0, pageSize: 10 });
    const [search, setSearch] = useState('');
    const filtersRef = useRef<FilterRecords>({ status: 'all', role: 'all' });

    const fetchData = useCallback(
      (filters: FilterRecords, sort: GridSortModel, page: number, pageSize: number, searchTerm: string) => {
        setLoading(true);
        fakeServerFetch(sampleRows, filters, sort, page, pageSize).then((result) => {
          const term = searchTerm.toLowerCase();
          const rows = term
            ? result.rows.filter(
                (row) =>
                  row.name.toLowerCase().includes(term) ||
                  row.email.toLowerCase().includes(term) ||
                  row.role.toLowerCase().includes(term)
              )
            : result.rows;
          setRows(rows);
          setRowCount(result.totalRows);
          setLoading(false);
        });
      },
      []
    );

    useEffect(() => {
      fetchData(filtersRef.current, sortModel, paginationModel.page, paginationModel.pageSize, search);
    }, []);

    const handleFiltersChange = useCallback(
      (newFilters: FilterRecords) => {
        filtersRef.current = newFilters;
        setPaginationModel((prev) => ({ ...prev, page: 0 }));
        fetchData(newFilters, sortModel, 0, paginationModel.pageSize, search);
      },
      [sortModel, paginationModel.pageSize, search, fetchData]
    );

    const handleSortModelChange = useCallback(
      (newSort: GridSortModel) => {
        setSortModel(newSort);
        setPaginationModel((prev) => ({ ...prev, page: 0 }));
        fetchData(filtersRef.current, newSort, 0, paginationModel.pageSize, search);
      },
      [paginationModel.pageSize, search, fetchData]
    );

    const handlePaginationModelChange = useCallback(
      (newModel: typeof paginationModel) => {
        setPaginationModel(newModel);
        fetchData(filtersRef.current, sortModel, newModel.page, newModel.pageSize, search);
      },
      [sortModel, search, fetchData]
    );

    const handleSearch = useCallback(
      (term: string) => {
        setSearch(term);
        setPaginationModel((prev) => ({ ...prev, page: 0 }));
        fetchData(filtersRef.current, sortModel, 0, paginationModel.pageSize, term);
      },
      [sortModel, paginationModel.pageSize, fetchData]
    );

    const handleRefresh = useCallback(() => {
      fetchData(filtersRef.current, sortModel, paginationModel.page, paginationModel.pageSize, search);
    }, [sortModel, paginationModel, search, fetchData]);

    return (
      <StoryWrapper height={760}>
        <DataGrid
          {...args}
          rows={rows}
          loading={loading}
          rowCount={rowCount}
          paginationMode="server"
          paginationModel={paginationModel}
          onPaginationModelChange={handlePaginationModelChange}
          sortModel={sortModel}
          onSortModelChange={handleSortModelChange}
          onRefresh={handleRefresh}
          checkboxSelection
          bulkDeleteConfig={bulkDeleteConfig}
          showAppliedFilters
          maxVisibleAppliedFilters={4}
          customToolbarFilters={[createStatusFilter('all'), createRoleFilter('all')]}
          onToolbarFiltersChange={handleFiltersChange}
          tableHeader={{
            title: entityTitle(rowCount),
            subtitle: 'Manage your team members and their roles',
            showSearch: true,
            searchType: 'basic',
            onBasicSearch: handleSearch,
            actions: [
              { id: 'add', children: 'Add Member', variant: 'contained', startIconProps: { name: 'plus' } },
            ],
          }}
        />
      </StoryWrapper>
    );
  },
};
