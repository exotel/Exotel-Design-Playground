import { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Popover, Button, Typography, Box } from '../../components';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof Popover> = {
  title: 'UI Components/Popover',
  component: Popover,
  parameters: {
    layout: 'centered',
    ...metaControlsDisabled,
    docs: {
      description: {
        component:
          'Exotel-approved popover component that wraps MUI\'s Popover. Displays floating content anchored to an element.',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Popover>;

export const Default: Story = {
  render: () => {
    const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);
    const open = Boolean(anchorEl);

    return (
      <>
        <Button variant="contained" onClick={(e) => setAnchorEl(e.currentTarget)}>
          Open Popover
        </Button>
        <Popover
          open={open}
          anchorEl={anchorEl}
          onClose={() => setAnchorEl(null)}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
        >
          <Box sx={{ p: 2, maxWidth: 280 }}>
            <Typography variant="subtitle2" gutterBottom>
              Popover Content
            </Typography>
            <Typography variant="body2" color="text.secondary">
              This is a simple popover anchored below the button.
            </Typography>
          </Box>
        </Popover>
      </>
    );
  },
};

export const AnchorPositions: Story = {
  render: () => {
    const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);
    const [origin, setOrigin] = useState<'top' | 'bottom' | 'center'>('bottom');

    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, alignItems: 'center' }}>
        <Box sx={{ display: 'flex', gap: 1 }}>
          {(['top', 'bottom', 'center'] as const).map((pos) => (
            <Button
              key={pos}
              variant="outlined"
              size="small"
              onClick={(e) => {
                setOrigin(pos);
                setAnchorEl(e.currentTarget);
              }}
            >
              {pos}
            </Button>
          ))}
        </Box>
        <Popover
          open={Boolean(anchorEl)}
          anchorEl={anchorEl}
          onClose={() => setAnchorEl(null)}
          anchorOrigin={{ vertical: origin, horizontal: 'center' }}
          transformOrigin={{ vertical: origin === 'bottom' ? 'top' : 'bottom', horizontal: 'center' }}
        >
          <Box sx={{ p: 2 }}>
            <Typography variant="body2">Anchored at: {origin}</Typography>
          </Box>
        </Popover>
      </Box>
    );
  },
};

export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    children: { control: false },
    anchorEl: { control: false },
    open: { control: false },
    onClose: { control: false },
    elevation: { control: { type: 'number', min: 0, max: 24 } },
    marginThreshold: { control: 'number' },
    disableScrollLock: { control: 'boolean' },
  },
  args: {
    elevation: 8,
    marginThreshold: 16,
    disableScrollLock: false,
    anchorOrigin: { vertical: 'bottom', horizontal: 'left' },
    transformOrigin: { vertical: 'top', horizontal: 'left' },
  },
  render: (args) => {
    const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);
    const open = Boolean(anchorEl);

    return (
      <>
        <Button variant="contained" onClick={(e) => setAnchorEl(e.currentTarget)}>
          Open Popover
        </Button>
        <Popover
          {...args}
          open={open}
          anchorEl={anchorEl}
          onClose={() => setAnchorEl(null)}
        >
          <Box sx={{ p: 2, maxWidth: 280 }}>
            <Typography variant="subtitle2" gutterBottom>
              Popover Content
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Use controls to adjust elevation and other props.
            </Typography>
          </Box>
        </Popover>
      </>
    );
  },
};
