/**
 * TextField Component Stories
 *
 * Stories for the Exotel TextField component that wraps MUI's TextField.
 */

import type { Meta, StoryObj } from '@storybook/react';
import { InputAdornment } from '@mui/material';
import { TextField, Icon } from '../../components';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof TextField> = {
  title: 'UI Components/TextField',
  component: TextField,
  parameters: {
    layout: 'centered',
    ...metaControlsDisabled,
    docs: {
      description: {
        component:
          "Exotel-approved text field component with label above the input, wrapping MUI's TextField.",
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof TextField>;

/**
 * Basic text field
 */
export const Basic: Story = {
  args: {
    label: 'Label',
  },
};

/**
 * Different sizes
 */
export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', width: '300px' }}>
      <TextField label="Small" size="small" />
      <TextField label="Medium" size="medium" />
      <TextField label="Large" size="large" />
    </div>
  ),
};

/**
 * With helper text
 */
export const HelperText: Story = {
  args: {
    label: 'Email',
    helperText: 'Enter your email address',
  },
};

/**
 * Disabled, error, and required states
 */
export const DisabledErrorRequired: Story = {
  name: 'Disabled, Error, Required',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', width: '300px' }}>
      <TextField label="Disabled" disabled defaultValue="Disabled value" />
      <TextField label="Email" error helperText="Invalid email address" />
      <TextField label="Required Field" required />
    </div>
  ),
};

/**
 * With start and end icons
 */
export const WithStartAndEndIcons: Story = {
  name: 'With Start and End Icons',
  render: () => (
    <div style={{ width: '300px' }}>
      <TextField
        label="Search"
        slotProps={{
          input: {
            startAdornment: (
              <InputAdornment position="start">
                <Icon name="magnifying-glass" size="sm" />
              </InputAdornment>
            ),
            endAdornment: (
              <InputAdornment position="end">
                <Icon name="x" size="sm" />
              </InputAdornment>
            ),
          },
        }}
      />
    </div>
  ),
};

/**
 * Multiline input (textarea)
 */
export const Multiline: Story = {
  render: () => (
    <div style={{ width: '350px' }}>
      <TextField
        multiline
        label="Description"
        placeholder="Enter a description..."
        minRows={2}
      />
    </div>
  ),
};

/**
 * Interactive playground — Controls enabled for serializable props.
 * Icon adornments are demoed in WithStartAndEndIcons — do not inject
 * React nodes into slotProps from Controls (that freezes Storybook).
 */
export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    InputProps: { control: false },
    inputProps: { control: false },
    SelectProps: { control: false },
    children: { control: false },
    onChange: { action: 'onChange' },
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
    },
    disabled: { control: 'boolean' },
    required: { control: 'boolean' },
    error: { control: 'boolean' },
    fullWidth: { control: 'boolean' },
    showLabel: { control: 'boolean' },
    label: { control: 'text' },
    placeholder: { control: 'text' },
    helperText: { control: 'text' },
    multiline: { control: 'boolean' },
    rows: { control: 'number' },
    minRows: { control: 'number' },
    maxRows: { control: 'number' },
  },
  args: {
    label: 'Label',
    size: 'medium',
    disabled: false,
    required: false,
    error: false,
    fullWidth: false,
    showLabel: true,
    placeholder: '',
    helperText: '',
    multiline: false,
    minRows: 2,
  },
  render: (args) => (
    <div style={{ width: args.fullWidth ? '100%' : 350 }}>
      <TextField {...args} />
    </div>
  ),
};
