import type { Meta, StoryObj } from '@storybook/react';
import { Grid, Paper, Typography } from '../../components';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof Grid> = {
  title: 'UI Components/Grid',
  component: Grid,
  parameters: {
    layout: 'centered',
    ...metaControlsDisabled,
    docs: {
      description: {
        component: 'Exotel-approved grid component that wraps MUI\'s Grid. Provides a responsive grid layout system.',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Grid>;

/**
 * Basic grid layout
 */
export const Basic: Story = {
  render: () => (
    <Grid container spacing={2}>
      <Grid item xs={6}><Paper sx={{ p: 2 }}>Item 1</Paper></Grid>
      <Grid item xs={6}><Paper sx={{ p: 2 }}>Item 2</Paper></Grid>
    </Grid>
  ),
};

/**
 * Responsive grid
 */
export const Responsive: Story = {
  render: () => (
    <Grid container spacing={2}>
      <Grid item xs={12} sm={6} md={4}>
        <Paper sx={{ p: 2 }}>
          <Typography variant="h6">Item 1</Typography>
          <Typography variant="body2">xs=12, sm=6, md=4</Typography>
        </Paper>
      </Grid>
      <Grid item xs={12} sm={6} md={4}>
        <Paper sx={{ p: 2 }}>
          <Typography variant="h6">Item 2</Typography>
          <Typography variant="body2">xs=12, sm=6, md=4</Typography>
        </Paper>
      </Grid>
      <Grid item xs={12} sm={6} md={4}>
        <Paper sx={{ p: 2 }}>
          <Typography variant="h6">Item 3</Typography>
          <Typography variant="body2">xs=12, sm=6, md=4</Typography>
        </Paper>
      </Grid>
    </Grid>
  ),
};

/**
 * Different spacing
 */
export const Spacing: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {[0, 1, 2, 4].map((spacing) => (
        <div key={spacing}>
          <Typography variant="caption" gutterBottom>Spacing: {spacing}</Typography>
          <Grid container spacing={spacing}>
            <Grid item xs={4}><Paper sx={{ p: 2 }}>Item 1</Paper></Grid>
            <Grid item xs={4}><Paper sx={{ p: 2 }}>Item 2</Paper></Grid>
            <Grid item xs={4}><Paper sx={{ p: 2 }}>Item 3</Paper></Grid>
          </Grid>
        </div>
      ))}
    </div>
  ),
};

/**
 * Grid with different column sizes
 */
export const ColumnSizes: Story = {
  render: () => (
    <Grid container spacing={2}>
      <Grid item xs={12}><Paper sx={{ p: 2 }}>Full width (xs=12)</Paper></Grid>
      <Grid item xs={6}><Paper sx={{ p: 2 }}>Half width (xs=6)</Paper></Grid>
      <Grid item xs={6}><Paper sx={{ p: 2 }}>Half width (xs=6)</Paper></Grid>
      <Grid item xs={4}><Paper sx={{ p: 2 }}>One third (xs=4)</Paper></Grid>
      <Grid item xs={4}><Paper sx={{ p: 2 }}>One third (xs=4)</Paper></Grid>
      <Grid item xs={4}><Paper sx={{ p: 2 }}>One third (xs=4)</Paper></Grid>
    </Grid>
  ),
};

export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    children: { control: false },
    spacing: { control: { type: 'number', min: 0, max: 10, step: 1 } },
    container: { control: 'boolean' },
    direction: {
      control: 'select',
      options: ['row', 'row-reverse', 'column', 'column-reverse'],
    },
    justifyContent: {
      control: 'select',
      options: [
        'flex-start',
        'center',
        'flex-end',
        'space-between',
        'space-around',
        'space-evenly',
      ],
    },
    alignItems: {
      control: 'select',
      options: ['flex-start', 'center', 'flex-end', 'stretch', 'baseline'],
    },
    wrap: { control: 'select', options: ['wrap', 'nowrap', 'wrap-reverse'] },
  },
  args: {
    container: true,
    spacing: 2,
    direction: 'row',
    justifyContent: 'flex-start',
    alignItems: 'stretch',
    wrap: 'wrap',
  },
  render: (args) => (
    <Grid {...args} sx={{ minWidth: 400 }}>
      <Grid item xs={4}><Paper sx={{ p: 2 }}>Item 1</Paper></Grid>
      <Grid item xs={4}><Paper sx={{ p: 2 }}>Item 2</Paper></Grid>
      <Grid item xs={4}><Paper sx={{ p: 2 }}>Item 3</Paper></Grid>
    </Grid>
  ),
};
