import { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Box, Typography } from '../../components';
import { SecondaryNavigation } from '../../components/SecondaryNavigation';
import type { NavigationItem } from '../../components/SecondaryNavigation';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const sampleItems: NavigationItem[] = [
  { id: '1', label: 'Inbound Sales' },
  { id: '2', label: 'Customer Support' },
  { id: '3', label: 'Technical Helpdesk' },
  { id: '4', label: 'Billing Queries' },
  { id: '5', label: 'Retention Team' },
  { id: '6', label: 'Enterprise Accounts' },
  { id: '7', label: 'Partner Onboarding' },
];

const meta: Meta<typeof SecondaryNavigation> = {
  title: 'UI Components/SecondaryNavigation',
  component: SecondaryNavigation,
  parameters: {
    layout: 'fullscreen',
    ...metaControlsDisabled,
    docs: {
      description: {
        component:
          'A collapsible side panel that displays a list of selectable entities with an avatar, optional action button, and footer. Commonly used as a left-hand navigation list for campaigns, queues, or similar domain objects.',
      },
    },
  },
  decorators: [
    (Story) => (
      <Box sx={{ display: 'flex', height: '100vh', bgcolor: 'background.default' }}>
        <Story />
        <Box sx={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Typography variant="body1" color="text.secondary">
            Main content area
          </Typography>
        </Box>
      </Box>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof SecondaryNavigation>;

export const Default: Story = {
  args: {
    title: 'Campaigns',
    icon: 'megaphone-simple',
    items: sampleItems,
    selectedId: '2',
    actionLabel: 'Create Campaign',
    actionIcon: 'plus',
    actionVariant: 'outlined',
  },
};

export const Collapsed: Story = {
  args: {
    ...Default.args,
    collapsed: true,
  },
};

export const WithFooter: Story = {
  args: {
    title: 'Queues',
    icon: 'queue',
    items: sampleItems.slice(0, 4),
    selectedId: '1',
    actionLabel: 'Add Queue',
    actionIcon: 'plus',
    actionVariant: 'contained',
    footer: (
      <Box sx={{ px: 1, py: 0.5 }}>
        <Typography variant="caption" color="text.secondary">
          4 of 12 queues shown
        </Typography>
      </Box>
    ),
  },
};

export const EmptyState: Story = {
  args: {
    title: 'Campaigns',
    icon: 'megaphone-simple',
    items: [],
    actionLabel: 'Create Campaign',
    actionIcon: 'plus',
    emptyMessage: 'No campaigns yet. Create one to get started.',
  },
};

export const NoAction: Story = {
  args: {
    title: 'Team Members',
    icon: 'users',
    items: sampleItems.slice(0, 3),
    selectedId: '2',
  },
};

export const CustomEmptyMessage: Story = {
  args: {
    title: 'Search Results',
    icon: 'magnifying-glass',
    items: [],
    emptyMessage: 'No results match your filters.',
  },
};

export const CustomRenderItem: Story = {
  args: {
    title: 'Campaigns',
    icon: 'megaphone-simple',
    items: sampleItems.slice(0, 4),
    selectedId: '2',
    renderItem: (item: NavigationItem, selected: boolean) => (
      <Box
        sx={{
          px: 1.5,
          py: 1,
          borderRadius: '8px',
          bgcolor: selected ? 'action.selected' : 'transparent',
          '&:hover': { bgcolor: selected ? 'action.selected' : 'action.hover' },
          cursor: 'pointer',
        }}
      >
        <Typography variant="body2" fontWeight={selected ? 600 : 400} color="text.primary">
          {item.label}
        </Typography>
        <Typography variant="caption" color="text.secondary">
          ID: {item.id}
        </Typography>
      </Box>
    ),
  },
};

export const ManyItems: Story = {
  args: {
    title: 'All Queues',
    icon: 'queue',
    items: Array.from({ length: 25 }, (_, i) => ({
      id: String(i + 1),
      label: `Queue ${i + 1}`,
    })),
    selectedId: '5',
    actionLabel: 'Add Queue',
    actionIcon: 'plus',
    actionVariant: 'outlined',
  },
};

export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    items: { control: false },
    footer: { control: false },
    renderItem: { control: false },
    selectedId: { control: false },
    onToggleCollapse: { action: 'onToggleCollapse' },
    onActionClick: { action: 'onActionClick' },
    onItemSelect: { action: 'onItemSelect' },
    title: { control: 'text' },
    icon: { control: 'text' },
    collapsed: { control: 'boolean' },
    actionLabel: { control: 'text' },
    actionIcon: { control: 'text' },
    actionVariant: {
      control: 'select',
      options: ['outlined', 'contained', 'text'],
    },
    emptyMessage: { control: 'text' },
  },
  args: {
    title: 'Campaigns',
    icon: 'megaphone-simple',
    actionLabel: 'Create Campaign',
    actionIcon: 'plus',
    actionVariant: 'outlined',
    emptyMessage: 'No campaigns yet. Create one to get started.',
  },
  render: (args) => {
    const [collapsed, setCollapsed] = useState(false);
    const [selectedId, setSelectedId] = useState<string | number>('1');

    return (
      <SecondaryNavigation
        {...args}
        collapsed={collapsed}
        onToggleCollapse={() => setCollapsed((prev) => !prev)}
        onActionClick={() => alert('Create campaign clicked')}
        items={sampleItems}
        selectedId={selectedId}
        onItemSelect={setSelectedId}
      />
    );
  },
};
