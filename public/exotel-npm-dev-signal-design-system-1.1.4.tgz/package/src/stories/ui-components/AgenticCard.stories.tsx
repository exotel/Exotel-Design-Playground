import { useEffect, useRef, useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { AgenticCard, Box, Button, Typography } from '../../components';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof AgenticCard> = {
  title: 'AI-SUITE (Beta)/AgenticCard',
  component: AgenticCard,
  parameters: {
    layout: 'centered',
    ...metaControlsDisabled,
    docs: {
      description: {
        component:
          'AgenticCard is a structured content card used in agentic chat flows. ' +
          'It displays a gray title header, a body area for rich content or images, ' +
          'and an optional footer with action buttons.',
      },
    },
  },
  decorators: [
    (Story) => (
      <Box sx={{ width: 684, p: 2 }}>
        <Story />
      </Box>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof AgenticCard>;

/**
 * Campaign Blueprint — rich text body with a primary CTA button.
 * Matches the first Figma screen (node 30-4664).
 */
export const CampaignBlueprint: Story = {
  render: () => (
    <AgenticCard
      title="Campaign Blueprint"
      actions={
        <Button variant="contained" size="medium">
          Start Building The Journey
        </Button>
      }
    >
      <Typography variant="body2" fontWeight="bold" gutterBottom>
        1. Core Parameters &amp; Targets
      </Typography>
      <ul>
        <li>Primary Objective: Drive application conversion from 12% baseline to ≥20%.</li>
        <li>Audience Segmentation: 45,736 validated leads synced from Salesforce CRM.</li>
        <li>DND Safeguard: 3,156 active DND users isolated strictly to transactional-only routes.</li>
        <li>
          Campaign Lifespan: 7-day sprint max per lead, with an automated return to the nurture pool
          on Day 8.
        </li>
      </ul>
      <Typography variant="body2" fontWeight="bold" gutterBottom sx={{ mt: 2 }}>
        2. Omnichannel Flow Execution Steps
      </Typography>
      <ul>
        <li>Day 0 (SMS): Send personalized reminder with an app deep-link.</li>
        <li>Day 1 (WhatsApp Multi-Path):</li>
        <ul>
          <li>Branch A: If drop-off stage is KYC Upload → Send video tutorial link + "Upload KYC" CTA.</li>
          <li>Branch B: For all other drop-offs → Send step-by-step text onboarding guide.</li>
          <li>
            Fallback Track: Leads without active WhatsApp tokens automatically receive an SMS
            fallback.
          </li>
        </ul>
        <li>
          Day 3 (Voicebot): Trigger an interactive Exotel outbound call to capture intent and drop
          an instant text link.
        </li>
        <li>Day 5 (Preview Dialer): Pass remaining high-priority leads to live human agents.</li>
        <li>
          Exit Condition: Instantly drop a lead from the journey the moment an account opening is
          confirmed.
        </li>
      </ul>
      <Typography variant="body2" fontWeight="bold" gutterBottom sx={{ mt: 2 }}>
        3. Budget &amp; Financial Guardrails
      </Typography>
      <ul>
        <li>
          Cost Efficiency Check: Blended journey cost optimized at ₹1.49 per lead (~₹68,200 total
          campaign spend).
        </li>
        <li>Budget Ceiling: Operating safely within your ₹8.00 per lead maximum limit.</li>
      </ul>
      <Typography variant="body2" sx={{ mt: 2 }}>
        All background assets including Meta WhatsApp formats, DLT text blocks, and conversational
        voicebot scripts are fully staged.
      </Typography>
      <Typography variant="body2" sx={{ mt: 2 }}>
        How would you like to proceed?
      </Typography>
    </AgenticCard>
  ),
};

/**
 * Business Journey — image preview with a primary CTA button.
 * Matches the second Figma screen (node 40-9323).
 */
export const WithImagePreview: Story = {
  render: () => (
    <AgenticCard
      title="Lead Conversion — Demat Account Opening Business Journey"
      imageSrc="https://placehold.co/684x210/f8f8f8/ccc?text=Business+Journey+Preview"
      imageAlt="Business journey flow preview"
      actions={
        <Button variant="contained" size="medium">
          Open Business Journey
        </Button>
      }
    />
  ),
};

/**
 * With Edit action — outlined button footer.
 * Matches the third Figma screen (node 37-8951).
 */
export const WithEditAction: Story = {
  render: () => (
    <AgenticCard
      title="Campaign Blueprint"
      actions={
        <Button variant="outlined" color="inherit" size="medium" startIconProps={{ name: 'note-pencil', size: 'sm' }}>
          Edit
        </Button>
      }
    >
      <Typography variant="body2" fontWeight="bold" gutterBottom>
        1. Core Parameters &amp; Targets
      </Typography>
      <ul>
        <li>Primary Objective: Drive application conversion from 12% baseline to ≥20%.</li>
        <li>Audience Segmentation: 45,736 validated leads synced from Salesforce CRM.</li>
        <li>DND Safeguard: 3,156 active DND users isolated strictly to transactional-only routes.</li>
        <li>
          Campaign Lifespan: 7-day sprint max per lead, with an automated return to the nurture pool
          on Day 8.
        </li>
      </ul>
      <Typography variant="body2" sx={{ mt: 2 }}>
        How would you like to proceed?
      </Typography>
    </AgenticCard>
  ),
};

/**
 * With header action button — outlined button in the header.
 * Matches the Figma screen (node 52-14262) "Sandbox Test Results".
 */
export const WithHeaderAction: Story = {
  render: () => (
    <AgenticCard
      title="Sandbox Test Results"
      headerAction={
        <Button
          variant="outlined"
          size="small"
          sx={{
            backgroundColor: 'surface.elevation1',
            color: 'text.primary',
          }}
          startIconProps={{ name: 'clipboard-text', size: 'sm' }}
        >
          Detailed Report
        </Button>
      }
    >
      <Typography variant="body2" fontWeight="bold" gutterBottom>
        1. Pathway Simulation Diagnostics
      </Typography>
      <ul>
        <li>
          Path 1: Standard SMS Execution (Day 0): 100% PASS | Micro-link tokenization and dynamic
          name variables parsed correctly.
        </li>
        <li>
          Path 2: WhatsApp Segmented Routing (Day 1): 100% PASS | KYC-delayed profiles correctly
          received the localized video tutorial.
        </li>
        <li>
          Path 3: Multi-Channel Fallback Loop: 100% PASS | Profiles without verified WhatsApp
          records seamlessly switched to alternate SMS tracks.
        </li>
        <li>
          Path 4: Smart Outbound Voicebot (Day 3): 100% PASS | Dual-language triggers executed based
          on the user profile preference field.
        </li>
        <li>
          Path 5: Live Escalation Queue (Day 5): 100% PASS | Premium profiles cleanly injected into
          the active HSL_Premium_Sales_Team preview dialer list.
        </li>
      </ul>
      <Typography variant="body2" fontWeight="bold" gutterBottom sx={{ mt: 2 }}>
        2. Compliance &amp; Error Gate Assertions
      </Typography>
      <ul>
        <li>
          TRAI DND Enforcement Check: Passed. Zero promotional materials were dispatched to
          DND-registered test vectors.
        </li>
        <li>
          Quiet Hours Hold Check: Passed. Timers calculated to fire between 8 PM and 9 AM were
          automatically paused and batched for release at exactly 09:00 AM IST.
        </li>
        <li>
          Absolute Journey Exit Rule: Passed. Synced conversion signals successfully terminated all
          pending downstream communications for converted mock profiles instantly.
        </li>
      </ul>
    </AgenticCard>
  ),
};

/**
 * Minimal — title and actions only, no body content.
 */
export const Minimal: Story = {
  args: {
    title: 'Generated Report',
  },
  render: (args) => (
    <AgenticCard
      {...args}
      actions={
        <Button variant="contained" size="medium">
          Download Report
        </Button>
      }
    />
  ),
};

/**
 * Content only — no actions footer.
 */
export const ContentOnly: Story = {
  render: () => (
    <AgenticCard title="Analysis Summary">
      <Typography variant="body2">
        The analysis identified 3 high-priority segments for immediate outreach, with a projected
        15% improvement in conversion rates.
      </Typography>
    </AgenticCard>
  ),
};

/**
 * Iframe preview — non-interactive preview that opens fullscreen on click.
 * The inline preview shows a "Click to interact" overlay. Clicking it
 * opens a fullscreen overlay covering the entire window where the user
 * can interact with the iframe content.
 */
export const WithIframePreview: Story = {
  render: () => (
    <AgenticCard
      title="Live Campaign Dashboard"
      iframeSrc="https://www.wikipedia.org"
      iframeTitle="Campaign dashboard preview"
      actions={
        <Button variant="contained" size="medium">
          Open Full Dashboard
        </Button>
      }
    />
  ),
};

/**
 * Iframe with body content — iframe preview above rich text body.
 */
export const IframeWithBody: Story = {
  render: () => (
    <AgenticCard
      title="Journey Flow Preview"
      iframeSrc="https://www.wikipedia.org"
      iframeTitle="Journey flow diagram"
      iframePreviewHeight={180}
    >
      <Typography variant="body2">
        This is the auto-generated journey flow based on your campaign blueprint. Click the preview
        above to interact with the diagram, zoom in, or inspect individual nodes.
      </Typography>
    </AgenticCard>
  ),
};

/**
 * Iframe with header action — taller preview with a header button.
 */
export const IframeWithHeaderAction: Story = {
  render: () => (
    <AgenticCard
      title="Analytics Report"
      iframeSrc="https://www.wikipedia.org"
      iframeTitle="Analytics report"
      iframePreviewHeight={260}
      headerAction={
        <Button
          variant="outlined"
          size="small"
          sx={{
            backgroundColor: 'surface.elevation1',
            color: 'text.primary',
          }}
          startIconProps={{ name: 'arrow-square-out', size: 'sm' }}
        >
          Open in New Tab
        </Button>
      }
    />
  ),
};

// Minimal embedded "app" that authenticates via a postMessage handshake.
// Uses srcDoc so it is same-origin with the story for a working round trip;
// a real cross-origin embed would validate `event.origin` before trusting it.
const EMBEDDED_APP_HTML = `<!doctype html>
<html>
  <body style="margin:0;font-family:system-ui,sans-serif;padding:24px;color:#111">
    <h3 style="margin:0 0 8px">Embedded authenticated app</h3>
    <p id="status" style="color:#b26a00">Waiting for auth token…</p>
    <script>
      window.addEventListener('message', function (event) {
        var data = event.data || {};
        if (data.type === 'auth' && data.token) {
          document.getElementById('status').style.color = '#1b7f4d';
          document.getElementById('status').textContent =
            'Authenticated with token: ' + data.token;
          // Reply to the exact sender/origin that authenticated us.
          event.source.postMessage({ type: 'auth-ack', ok: true }, event.origin);
        }
      });
    </script>
  </body>
</html>`;

/**
 * Iframe communication & authentication — the intended pattern for authenticated,
 * cross-origin embeds.
 *
 * - `onIframeLoad` posts a short-lived auth token to the frame the moment it is
 *   ready (a single, stable iframe means this handshake runs once — not twice).
 * - `iframeRef` gives a stable handle for further `postMessage` calls.
 * - A `message` listener validates `event.origin` against an allow-list before
 *   trusting anything the frame sends back.
 *
 * This demo uses `srcDoc` (same-origin) so the round trip actually completes;
 * with a real cross-origin URL, pass its origin as the `targetOrigin` instead of
 * `window.location.origin`.
 */
export const IframeWithCommunication: Story = {
  render: () => {
    const iframeRef = useRef<HTMLIFrameElement>(null);
    const [handshake, setHandshake] = useState('Idle — expand or wait for load');

    const targetOrigin = window.location.origin;
    const token = 'demo-jwt-abc123';

    useEffect(() => {
      const allowedOrigins = [window.location.origin];
      const handleMessage = (event: MessageEvent) => {
        if (!allowedOrigins.includes(event.origin)) return; // origin allow-list
        if (event.data?.type === 'auth-ack' && event.data.ok) {
          setHandshake(`Frame acknowledged auth from ${event.origin}`);
        }
      };
      window.addEventListener('message', handleMessage);
      return () => window.removeEventListener('message', handleMessage);
    }, []);

    return (
      <Box display="flex" flexDirection="column" gap={1}>
        <Typography variant="caption" color="text.secondary">
          Handshake: {handshake}
        </Typography>
        <AgenticCard
          title="Live Sandbox (authenticated)"
          iframeSrc="about:blank"
          iframeTitle="Authenticated sandbox"
          iframePreviewHeight={220}
          iframeRef={iframeRef}
          iframeProps={{ srcDoc: EMBEDDED_APP_HTML }}
          onIframeLoad={(iframe) => {
            setHandshake('Sent auth token on load');
            iframe.contentWindow?.postMessage({ type: 'auth', token }, targetOrigin);
          }}
          actions={
            <Button
              variant="outlined"
              size="medium"
              onClick={() =>
                iframeRef.current?.contentWindow?.postMessage(
                  { type: 'ping', at: Date.now() },
                  targetOrigin,
                )
              }
            >
              Send message to frame
            </Button>
          }
        />
      </Box>
    );
  },
};

/**
 * Interactive playground — Controls enabled for serializable props.
 */
export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    children: { control: 'text' },
    headerAction: { control: false },
    actions: { control: false },
    iframeRef: { control: false },
    iframeProps: { control: false },
    feedbackProps: { control: false },
    onIframeLoad: { action: 'onIframeLoad' },
    onCopy: { action: 'onCopy' },
    title: { control: 'text' },
    imageSrc: { control: 'text' },
    imageAlt: { control: 'text' },
    iframeSrc: { control: 'text' },
    iframeTitle: { control: 'text' },
    iframePreviewHeight: { control: 'number' },
    iframeSandbox: { control: 'text' },
    iframeAllow: { control: 'text' },
  },
  args: {
    title: 'Campaign Blueprint',
    children:
      'Use Controls to tweak the title and body. Image and iframe URLs are optional.',
    imageSrc: '',
    imageAlt: '',
    iframeSrc: '',
    iframeTitle: '',
    iframePreviewHeight: 200,
  },
  render: (args) => (
    <AgenticCard
      {...args}
      actions={
        <Button variant="contained" size="medium">
          Primary action
        </Button>
      }
    />
  ),
};
