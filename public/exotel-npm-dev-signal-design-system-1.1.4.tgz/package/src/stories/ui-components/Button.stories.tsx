/**
 * Button Component Stories
 *
 * Stories for the Exotel Button component that wraps MUI's Button.
 */

import type { Meta, StoryObj } from '@storybook/react';
import { Button, Stack, Typography } from '../../components';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof Button> = {
  title: 'UI Components/Button',
  component: Button,
  parameters: {
    layout: 'centered',
    ...metaControlsDisabled,
    docs: {
      description: {
        component:
          "Exotel-approved button component that wraps MUI's Button. Provides consistent styling and behavior across Exotel applications.",
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Button>;

/**
 * Primary button — the default variant for primary actions
 */
export const Primary: Story = {
  args: {
    children: 'Button',
    variant: 'contained',
    color: 'primary',
  },
};

/**
 * All variants side by side
 */
export const Variants: Story = {
  render: () => (
    <Stack direction="row" spacing={2} alignItems="center" flexWrap="wrap" useFlexGap>
      <Button variant="contained" color="primary">Contained</Button>
      <Button variant="tonal" color="primary">Tonal</Button>
      <Button variant="outlined" color="primary">Outlined</Button>
      <Button variant="text" color="primary">Text</Button>
    </Stack>
  ),
};

/**
 * Disabled state across all variants
 */
export const DisabledVariants: Story = {
  name: 'Disabled variants',
  render: () => (
    <Stack direction="row" spacing={2} alignItems="center" flexWrap="wrap" useFlexGap>
      <Button variant="contained" color="primary" disabled>Contained</Button>
      <Button variant="tonal" color="primary" disabled>Tonal</Button>
      <Button variant="outlined" color="primary" disabled>Outlined</Button>
      <Button variant="text" color="primary" disabled>Text</Button>
    </Stack>
  ),
};

/**
 * All semantic colors with every variant
 */
export const Colors: Story = {
  render: () => (
    <Stack spacing={3} alignItems="flex-start">
      <Stack spacing={1}>
        <Typography variant="title2">Primary</Typography>
        <Stack direction="row" spacing={2} alignItems="center" flexWrap="wrap" useFlexGap>
          <Button variant="contained" color="primary">Contained</Button>
          <Button variant="tonal" color="primary">Tonal</Button>
          <Button variant="outlined" color="primary">Outlined</Button>
          <Button variant="text" color="primary">Text</Button>
        </Stack>
      </Stack>
      <Stack spacing={1}>
        <Typography variant="title2">Secondary</Typography>
        <Stack direction="row" spacing={2} alignItems="center" flexWrap="wrap" useFlexGap>
          <Button variant="contained" color="secondary">Contained</Button>
          <Button variant="tonal" color="secondary">Tonal</Button>
          <Button variant="outlined" color="secondary">Outlined</Button>
          <Button variant="text" color="secondary">Text</Button>
        </Stack>
      </Stack>
      <Stack spacing={1}>
        <Typography variant="title2">Success</Typography>
        <Stack direction="row" spacing={2} alignItems="center" flexWrap="wrap" useFlexGap>
          <Button variant="contained" color="success">Contained</Button>
          <Button variant="tonal" color="success">Tonal</Button>
          <Button variant="outlined" color="success">Outlined</Button>
          <Button variant="text" color="success">Text</Button>
        </Stack>
      </Stack>
      <Stack spacing={1}>
        <Typography variant="title2">Error</Typography>
        <Stack direction="row" spacing={2} alignItems="center" flexWrap="wrap" useFlexGap>
          <Button variant="contained" color="error">Contained</Button>
          <Button variant="tonal" color="error">Tonal</Button>
          <Button variant="outlined" color="error">Outlined</Button>
          <Button variant="text" color="error">Text</Button>
        </Stack>
      </Stack>
      <Stack spacing={1}>
        <Typography variant="title2">Info</Typography>
        <Stack direction="row" spacing={2} alignItems="center" flexWrap="wrap" useFlexGap>
          <Button variant="contained" color="info">Contained</Button>
          <Button variant="tonal" color="info">Tonal</Button>
          <Button variant="outlined" color="info">Outlined</Button>
          <Button variant="text" color="info">Text</Button>
        </Stack>
      </Stack>
      <Stack spacing={1}>
        <Typography variant="title2">Warning</Typography>
        <Stack direction="row" spacing={2} alignItems="center" flexWrap="wrap" useFlexGap>
          <Button variant="contained" color="warning">Contained</Button>
          <Button variant="tonal" color="warning">Tonal</Button>
          <Button variant="outlined" color="warning">Outlined</Button>
          <Button variant="text" color="warning">Text</Button>
        </Stack>
      </Stack>
    </Stack>
  ),
};

/**
 * All available sizes
 */
export const Sizes: Story = {
  render: () => (
    <Stack direction="row" spacing={2} alignItems="center" flexWrap="wrap" useFlexGap>
      <Button size="small" variant="contained" color="primary">Small</Button>
      <Button size="medium" variant="contained" color="primary">Medium</Button>
      <Button size="large" variant="contained" color="primary">Large</Button>
      <Button size="extraLarge" variant="contained" color="primary">Extra Large</Button>
    </Stack>
  ),
};

/**
 * Buttons with start icon, end icon, and both icons
 */
export const WithIcons: Story = {
  name: 'With Icons',
  render: () => (
    <Stack spacing={3} alignItems="flex-start">
      <Stack spacing={1}>
        <Typography variant="title2">Start icon</Typography>
        <Button variant="contained" color="primary" startIconProps={{ name: 'plus' }}>
          Button
        </Button>
      </Stack>
      <Stack spacing={1}>
        <Typography variant="title2">End icon</Typography>
        <Button variant="contained" color="primary" endIconProps={{ name: 'arrow-right' }}>
          Button
        </Button>
      </Stack>
      <Stack spacing={1}>
        <Typography variant="title2">Both icons</Typography>
        <Button
          variant="contained"
          color="primary"
          startIconProps={{ name: 'check' }}
          endIconProps={{ name: 'arrow-right' }}
        >
          Button
        </Button>
      </Stack>
    </Stack>
  ),
};

/**
 * Interactive button with all controls
 */
export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    children: { control: 'text' },
    startIcon: { control: false },
    endIcon: { control: false },
    startIconProps: { control: 'object' },
    endIconProps: { control: 'object' },
    onClick: { action: 'onClick' },
    variant: {
      control: 'select',
      options: ['text', 'outlined', 'contained', 'tonal'],
    },
    color: {
      control: 'select',
      options: ['inherit', 'primary', 'secondary', 'success', 'error', 'info', 'warning'],
    },
    size: {
      control: 'select',
      options: ['small', 'medium', 'large', 'extraLarge'],
    },
    disabled: { control: 'boolean' },
    fullWidth: { control: 'boolean' },
    disableElevation: { control: 'boolean' },
    disableRipple: { control: 'boolean' },
    disableFocusRipple: { control: 'boolean' },
    disableTouchRipple: { control: 'boolean' },
    href: { control: 'text' },
  },
  args: {
    children: 'Button',
    variant: 'contained',
    color: 'primary',
    size: 'medium',
    disabled: false,
    fullWidth: false,
    disableElevation: false,
    disableRipple: false,
  },
  render: (args) => <Button {...args} />,
};
