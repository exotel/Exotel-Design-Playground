import type { Meta, StoryObj } from '@storybook/react';
import { Container, Box, Typography, Paper } from '../../components';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof Container> = {
  title: 'UI Components/Container',
  component: Container,
  parameters: {
    layout: 'fullscreen',
    ...metaControlsDisabled,
    docs: {
      description: {
        component:
          'Exotel-approved container component that wraps MUI\'s Container. Centers and constrains content width with responsive breakpoints.',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Container>;

export const Default: Story = {
  args: {
    maxWidth: 'lg',
  },
  render: (args) => (
    <Container {...args}>
      <Paper sx={{ p: 3, textAlign: 'center' }}>
        <Typography variant="h6">Container (lg)</Typography>
        <Typography variant="body2" color="text.secondary">
          Content is centered and horizontally constrained.
        </Typography>
      </Paper>
    </Container>
  ),
};

export const MaxWidths: Story = {
  render: () => (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, py: 2 }}>
      {(['xs', 'sm', 'md', 'lg', 'xl'] as const).map((size) => (
        <Container key={size} maxWidth={size}>
          <Paper sx={{ p: 2, textAlign: 'center', bgcolor: 'action.hover' }}>
            <Typography variant="body2" fontWeight={600}>maxWidth=&quot;{size}&quot;</Typography>
          </Paper>
        </Container>
      ))}
    </Box>
  ),
};

export const Fixed: Story = {
  args: {
    fixed: true,
  },
  render: (args) => (
    <Container {...args}>
      <Paper sx={{ p: 3, textAlign: 'center' }}>
        <Typography variant="h6">Fixed Container</Typography>
        <Typography variant="body2" color="text.secondary">
          Width snaps to the current breakpoint.
        </Typography>
      </Paper>
    </Container>
  ),
};

export const DisableGutters: Story = {
  args: {
    disableGutters: true,
    maxWidth: 'md',
  },
  render: (args) => (
    <Container {...args}>
      <Paper sx={{ p: 3, textAlign: 'center' }}>
        <Typography variant="h6">No Gutters</Typography>
        <Typography variant="body2" color="text.secondary">
          Content extends to the edges without horizontal padding.
        </Typography>
      </Paper>
    </Container>
  ),
};

export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    children: { control: false },
    maxWidth: { control: 'select', options: ['xs', 'sm', 'md', 'lg', 'xl', false] },
    fixed: { control: 'boolean' },
    disableGutters: { control: 'boolean' },
  },
  args: {
    maxWidth: 'lg',
    fixed: false,
    disableGutters: false,
  },
  render: (args) => (
    <Container {...args}>
      <Paper sx={{ p: 3, textAlign: 'center' }}>
        <Typography variant="h6">Interactive Container</Typography>
        <Typography variant="body2" color="text.secondary">
          Use controls to change maxWidth, fixed, and gutters.
        </Typography>
      </Paper>
    </Container>
  ),
};
