import type { Meta, StoryObj } from '@storybook/react';
import { Fab, Icon, Box } from '../../components';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof Fab> = {
  title: 'UI Components/Fab',
  component: Fab,
  parameters: {
    layout: 'centered',
    ...metaControlsDisabled,
    docs: {
      description: {
        component:
          'Exotel-approved floating action button (FAB) that wraps MUI\'s Fab. Used for the primary action on a screen.',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Fab>;

export const Default: Story = {
  args: {
    color: 'primary',
    children: <Icon name="plus" />,
  },
};

export const Extended: Story = {
  args: {
    variant: 'extended',
    color: 'primary',
  },
  render: (args) => (
    <Fab {...args}>
      <Icon name="plus" />
      Create
    </Fab>
  ),
};

export const Sizes: Story = {
  render: () => (
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
      <Fab size="small" color="primary">
        <Icon name="plus" />
      </Fab>
      <Fab size="medium" color="primary">
        <Icon name="plus" />
      </Fab>
      <Fab size="large" color="primary">
        <Icon name="plus" />
      </Fab>
    </Box>
  ),
};

export const Colors: Story = {
  render: () => (
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, flexWrap: 'wrap' }}>
      <Fab color="default"><Icon name="plus" /></Fab>
      <Fab color="primary"><Icon name="plus" /></Fab>
      <Fab color="secondary"><Icon name="plus" /></Fab>
      <Fab color="success"><Icon name="check" /></Fab>
      <Fab color="error"><Icon name="x" /></Fab>
      <Fab color="warning"><Icon name="warning" /></Fab>
      <Fab color="info"><Icon name="info" /></Fab>
    </Box>
  ),
};

export const Disabled: Story = {
  args: {
    disabled: true,
    children: <Icon name="plus" />,
  },
};

export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    children: { control: false },
    color: {
      control: 'select',
      options: ['default', 'primary', 'secondary', 'error', 'info', 'success', 'warning', 'inherit'],
    },
    size: { control: 'select', options: ['small', 'medium', 'large'] },
    variant: { control: 'select', options: ['circular', 'extended'] },
    disabled: { control: 'boolean' },
    onClick: { action: 'onClick' },
  },
  args: {
    color: 'primary',
    size: 'large',
    variant: 'circular',
    disabled: false,
    children: <Icon name="plus" />,
  },
  render: (args) => <Fab {...args} />,
};
