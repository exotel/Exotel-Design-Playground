import type { Meta, StoryObj } from '@storybook/react';
import { Icon } from '../../components';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof Icon> = {
  title: 'UI Components/Icon',
  component: Icon,
  parameters: {
    layout: 'centered',
    ...metaControlsDisabled,
    docs: {
      description: {
        component: 'Exotel-approved icon component that wraps Phosphor Icons. Provides a consistent, string-based API for using icons across Exotel applications.',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Icon>;

/**
 * Basic icon
 */
export const Basic: Story = {
  args: {
    name: 'phone',
    size: 'md',
    weight: 'regular',
  },
};

/**
 * Different sizes
 */
export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
      <Icon name="phone" size="xs" />
      <Icon name="phone" size="sm" />
      <Icon name="phone" size="md" />
      <Icon name="phone" size="lg" />
    </div>
  ),
};

/**
 * Different weights
 */
export const Weights: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
      <Icon name="warning" weight="light" />
      <Icon name="warning" weight="regular" />
      <Icon name="warning" weight="bold" />
      <Icon name="warning" weight="fill" />
    </div>
  ),
};

/**
 * Different colors
 */
export const Colors: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
      <Icon name="check-circle" color="#4caf50" />
      <Icon name="x-circle" color="#d32f2f" />
      <Icon name="info" color="#0288d1" />
      <Icon name="warning" color="#ed6c02" />
    </div>
  ),
};

/**
 * Common icons showcase
 */
export const CommonIcons: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
      <Icon name="phone" />
      <Icon name="envelope" />
      <Icon name="user" />
      <Icon name="gear" />
      <Icon name="magnifying-glass" />
      <Icon name="list" />
      <Icon name="check" />
      <Icon name="x" />
      <Icon name="plus" />
      <Icon name="minus" />
      <Icon name="trash" />
      <Icon name="pencil" />
    </div>
  ),
};

/**
 * Navigation icons
 */
export const NavigationIcons: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
      <Icon name="arrow-left" />
      <Icon name="arrow-right" />
      <Icon name="arrow-up" />
      <Icon name="arrow-down" />
      <Icon name="caret-left" />
      <Icon name="caret-right" />
      <Icon name="caret-up" />
      <Icon name="caret-down" />
    </div>
  ),
};

/**
 * Interactive icon with all controls
 */
export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    name: {
      control: 'select',
      options: [
        'phone', 'warning', 'check-circle', 'x-circle', 'info', 'question',
        'arrow-left', 'arrow-right', 'arrow-up', 'arrow-down',
        'caret-left', 'caret-right', 'caret-up', 'caret-down',
        'trash', 'pencil', 'plus', 'minus', 'x', 'check',
        'envelope', 'bell', 'chat', 'list', 'magnifying-glass', 'funnel',
        'gear', 'user', 'lock', 'lock-open', 'eye', 'eye-slash',
        'circle',
      ],
    },
    size: {
      control: 'select',
      options: ['xs', 'sm', 'md', 'lg'],
    },
    weight: {
      control: 'select',
      options: ['regular', 'bold', 'fill', 'light'],
    },
    color: { control: 'color' },
  },
  args: {
    name: 'phone',
    size: 'md',
    weight: 'regular',
    color: undefined,
  },
  render: (args) => <Icon {...args} />,
};
