import type { Meta, StoryObj } from '@storybook/react';
import { Paper, Typography, Button } from '../../components';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof Paper> = {
  title: 'UI Components/Paper',
  component: Paper,
  parameters: {
    layout: 'centered',
    ...metaControlsDisabled,
    docs: {
      description: {
        component: 'Exotel-approved paper component that wraps MUI\'s Paper. Provides elevation and surface styling for content containers.',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Paper>;

/**
 * Basic paper
 */
export const Basic: Story = {
  render: () => (
    <Paper sx={{ p: 2, minWidth: 300 }}>
      <Typography variant="h6" gutterBottom>
        Paper Title
      </Typography>
      <Typography variant="body2">
        This is a basic paper component with some content.
      </Typography>
    </Paper>
  ),
};

/**
 * Different elevations
 */
export const Elevations: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
      {[0, 1, 2, 4, 8, 16].map((elevation) => (
        <Paper key={elevation} elevation={elevation} sx={{ p: 2, minWidth: 150 }}>
          <Typography variant="body2">Elevation {elevation}</Typography>
        </Paper>
      ))}
    </div>
  ),
};

/**
 * Outlined variant
 */
export const Outlined: Story = {
  render: () => (
    <Paper variant="outlined" sx={{ p: 2, minWidth: 300 }}>
      <Typography variant="h6" gutterBottom>
        Outlined Paper
      </Typography>
      <Typography variant="body2">
        This paper uses the outlined variant instead of elevation.
      </Typography>
    </Paper>
  ),
};

/**
 * Paper with interactive content
 */
export const WithContent: Story = {
  render: () => (
    <Paper sx={{ p: 3, minWidth: 400 }}>
      <Typography variant="h5" gutterBottom>
        Paper with Content
      </Typography>
      <Typography variant="body1" paragraph>
        This paper contains various types of content including headings, paragraphs, and buttons.
      </Typography>
      <div style={{ display: 'flex', gap: '8px', marginTop: '16px' }}>
        <Button variant="contained">Primary Action</Button>
        <Button variant="outlined">Secondary Action</Button>
      </div>
    </Paper>
  ),
};

/**
 * Interactive paper with all controls
 */
export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    children: { control: false },
    variant: {
      control: 'select',
      options: ['elevation', 'outlined'],
    },
    elevation: { control: { type: 'number', min: 0, max: 24, step: 1 } },
    square: { control: 'boolean' },
  },
  args: {
    variant: 'elevation',
    elevation: 1,
    square: false,
  },
  render: (args) => (
    <Paper {...args} sx={{ p: 2, minWidth: 300 }}>
      <Typography variant="h6" gutterBottom>
        Interactive Paper
      </Typography>
      <Typography variant="body2">
        Use the controls to change variant, elevation, and square properties.
      </Typography>
    </Paper>
  ),
};
