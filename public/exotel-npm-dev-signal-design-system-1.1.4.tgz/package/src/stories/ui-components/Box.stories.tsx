import type { Meta, StoryObj } from '@storybook/react';
import { Box, Typography, Button } from '../../components';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof Box> = {
  title: 'UI Components/Box',
  component: Box,
  parameters: {
    layout: 'centered',
    ...metaControlsDisabled,
    docs: {
      description: {
        component: 'Exotel-approved box component that wraps MUI\'s Box. A versatile container component with access to the theme for styling.',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Box>;

/**
 * Basic box
 */
export const Basic: Story = {
  render: () => (
    <Box sx={{ width: 200, height: 100, bgcolor: 'primary.main', color: 'white', p: 2, borderRadius: 1 }}>
      <Typography>Box Component</Typography>
    </Box>
  ),
};

/**
 * Box with theme colors
 */
export const ThemeColors: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
      <Box sx={{ width: 150, height: 80, bgcolor: 'primary.main', color: 'white', p: 2, borderRadius: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        Primary
      </Box>
      <Box sx={{ width: 150, height: 80, bgcolor: 'secondary.main', color: 'white', p: 2, borderRadius: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        Secondary
      </Box>
      <Box sx={{ width: 150, height: 80, bgcolor: 'error.main', color: 'white', p: 2, borderRadius: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        Error
      </Box>
      <Box sx={{ width: 150, height: 80, bgcolor: 'success.main', color: 'white', p: 2, borderRadius: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        Success
      </Box>
    </div>
  ),
};

/**
 * Box as different HTML elements
 */
export const AsComponent: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <Box component="section" sx={{ p: 2, bgcolor: 'grey.100', borderRadius: 1 }}>
        <Typography variant="h6">Box as section</Typography>
      </Box>
      <Box component="article" sx={{ p: 2, bgcolor: 'grey.100', borderRadius: 1 }}>
        <Typography variant="h6">Box as article</Typography>
      </Box>
      <Box component="div" sx={{ p: 2, bgcolor: 'grey.100', borderRadius: 1 }}>
        <Typography variant="h6">Box as div (default)</Typography>
      </Box>
    </div>
  ),
};

/**
 * Box with flexbox layout
 */
export const Flexbox: Story = {
  render: () => (
    <Box
      sx={{
        display: 'flex',
        gap: 2,
        p: 2,
        bgcolor: 'grey.100',
        borderRadius: 1,
        minWidth: 400,
      }}
    >
      <Button variant="contained">Button 1</Button>
      <Button variant="outlined">Button 2</Button>
      <Button variant="text">Button 3</Button>
    </Box>
  ),
};

/**
 * Box with spacing and padding
 */
export const Spacing: Story = {
  render: () => (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      <Box sx={{ p: 1, bgcolor: 'primary.main', color: 'white', borderRadius: 1 }}>
        Padding: 1 (8px)
      </Box>
      <Box sx={{ p: 2, bgcolor: 'primary.main', color: 'white', borderRadius: 1 }}>
        Padding: 2 (16px)
      </Box>
      <Box sx={{ p: 3, bgcolor: 'primary.main', color: 'white', borderRadius: 1 }}>
        Padding: 3 (24px)
      </Box>
    </Box>
  ),
};

export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    children: { control: 'text' },
  },
  args: {
    children: 'Box content',
    sx: {
      width: 200,
      height: 100,
      bgcolor: 'primary.main',
      color: 'white',
      p: 2,
      borderRadius: 1,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
  },
  render: (args) => <Box {...args} />,
};
