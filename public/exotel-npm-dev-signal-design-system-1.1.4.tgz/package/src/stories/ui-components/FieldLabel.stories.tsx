import type { Meta, StoryObj } from '@storybook/react';
import { FieldWrapper, TextField } from '../../components';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof FieldWrapper> = {
  title: 'UI Components/FieldWrapper',
  component: FieldWrapper,
  parameters: {
    layout: 'centered',
    ...metaControlsDisabled,
    docs: {
      description: {
        component:
          'Shared wrapper that renders an external label above any field component. Used by TextField, Autocomplete, and all date/time pickers.',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof FieldWrapper>;

export const Default: Story = {
  args: {
    label: 'Email address',
    htmlFor: 'email-input',
  },
  render: (args) => (
    <FieldWrapper {...args}>
      <TextField id="email-input" placeholder="you@example.com" size="small" />
    </FieldWrapper>
  ),
};

export const Required: Story = {
  args: {
    label: 'Full name',
    htmlFor: 'name-input',
    required: true,
  },
  render: (args) => (
    <FieldWrapper {...args}>
      <TextField id="name-input" placeholder="John Doe" size="small" />
    </FieldWrapper>
  ),
};

export const NoLabel: Story = {
  args: {
    label: undefined,
  },
  render: (args) => (
    <FieldWrapper {...args}>
      <TextField placeholder="No external label" size="small" />
    </FieldWrapper>
  ),
};

export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    children: { control: false },
    label: { control: 'text' },
    htmlFor: { control: 'text' },
    required: { control: 'boolean' },
  },
  args: {
    label: 'Email address',
    htmlFor: 'interactive-email-input',
    required: false,
  },
  render: (args) => (
    <FieldWrapper {...args}>
      <TextField id="interactive-email-input" placeholder="you@example.com" size="small" />
    </FieldWrapper>
  ),
};
