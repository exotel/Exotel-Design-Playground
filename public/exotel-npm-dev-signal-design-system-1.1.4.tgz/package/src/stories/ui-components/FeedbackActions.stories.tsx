import { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { AgenticCard, Box, Button, FeedbackActions, Typography } from '../../components';
import type { FeedbackReaction, FeedbackSubmission } from '../../components';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof FeedbackActions> = {
  title: 'AI-SUITE (Beta)/FeedbackActions',
  component: FeedbackActions,
  parameters: {
    layout: 'centered',
    ...metaControlsDisabled,
    docs: {
      description: {
        component:
          'FeedbackActions provides a thumbs-up / thumbs-down feedback flow. ' +
          'Clicking a thumb fires `onReactionChange` immediately. The third pencil icon ' +
          'opens a popover for optional detailed reasons; selecting "Other" reveals a text field.',
      },
    },
  },
  decorators: [
    (Story) => (
      <Box sx={{ p: 4 }}>
        <Story />
      </Box>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof FeedbackActions>;

export const Default: Story = {
  render: () => (
    <FeedbackActions
      onReactionChange={(r) => console.log('Reaction:', r)}
      onSubmit={(fb) => console.log('Feedback:', fb)}
    />
  ),
};

export const CustomReasons: Story = {
  render: () => (
    <FeedbackActions
      positiveReasons={[
        { id: 'fast', label: 'Fast response' },
        { id: 'relevant', label: 'Relevant answer' },
        { id: 'creative', label: 'Creative solution' },
      ]}
      negativeReasons={[
        { id: 'slow', label: 'Too slow' },
        { id: 'irrelevant', label: 'Not relevant' },
        { id: 'incomplete', label: 'Incomplete answer' },
      ]}
      onReactionChange={(r) => console.log('Reaction:', r)}
      onSubmit={(fb) => console.log('Custom feedback:', fb)}
    />
  ),
};

export const WithAgenticCard: Story = {
  decorators: [
    (Story) => (
      <Box sx={{ width: 684, p: 2, display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
        <Story />
      </Box>
    ),
  ],
  render: () => {
    const [currentReaction, setCurrentReaction] = useState<FeedbackReaction | null>(null);

    return (
      <Box display="flex" flexDirection="column" gap={1}>
        <AgenticCard
          title="Campaign Blueprint"
          actions={
            <Button variant="contained" size="medium">
              Start Building The Journey
            </Button>
          }
        >
          <Typography variant="body2" fontWeight="bold" gutterBottom>
            1. Core Parameters &amp; Targets
          </Typography>
          <ul>
            <li>Primary Objective: Drive application conversion from 12% baseline to ≥20%.</li>
            <li>Audience Segmentation: 45,736 validated leads synced from Salesforce CRM.</li>
          </ul>
          <Typography variant="body2" sx={{ mt: 2 }}>
            How would you like to proceed?
          </Typography>
        </AgenticCard>

        <Box display="flex" justifyContent="flex-end" width="100%">
          <FeedbackActions
            onReactionChange={setCurrentReaction}
            onSubmit={(fb) => console.log('Submitted:', fb)}
          />
        </Box>

        {currentReaction && (
          <Typography variant="caption" color="text.secondary" textAlign="right" width="100%">
            {currentReaction === 'positive' ? 'Glad you found it helpful!' : 'Sorry to hear that.'}
            {' Use the pencil icon to share more details.'}
          </Typography>
        )}
      </Box>
    );
  },
};

export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    positiveReasons: { control: false },
    negativeReasons: { control: false },
    onReactionChange: { action: 'onReactionChange' },
    onSubmit: { action: 'onSubmit' },
  },
  render: (args) => {
    const [currentReaction, setCurrentReaction] = useState<FeedbackReaction | null>(null);
    const [lastSubmission, setLastSubmission] = useState<FeedbackSubmission | null>(null);

    return (
      <Box display="flex" flexDirection="column" alignItems="flex-end" gap={2}>
        <FeedbackActions
          {...args}
          onReactionChange={(r) => {
            setCurrentReaction(r);
            args.onReactionChange?.(r);
          }}
          onSubmit={(fb) => {
            setLastSubmission(fb);
            args.onSubmit?.(fb);
          }}
        />
        <Box sx={{ p: 1.5, borderRadius: 1, backgroundColor: 'surface.elevation1', maxWidth: 360 }}>
          <Typography variant="caption" color="text.secondary" component="pre" sx={{ m: 0, whiteSpace: 'pre-wrap' }}>
            {JSON.stringify({ reaction: currentReaction, details: lastSubmission }, null, 2)}
          </Typography>
        </Box>
      </Box>
    );
  },
};
