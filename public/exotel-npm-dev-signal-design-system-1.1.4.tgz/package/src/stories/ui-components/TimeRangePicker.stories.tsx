import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import dayjs, { type Dayjs } from 'dayjs';
import { TimeRangePicker, type TimeRangePickerProps } from '../../components';
import type { DateRange } from '@mui/x-date-pickers-pro';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof TimeRangePicker> = {
  title: 'Date & Time Pickers/TimeRangePicker',
  component: TimeRangePicker,
  parameters: {
    layout: 'centered',
    ...metaControlsDisabled,
    docs: {
      description: {
        component:
          "Exotel-approved time range picker that wraps MUI X TimeRangePicker (pro). Allows selection of a start and end time. Includes a built-in LocalizationProvider with dayjs.",
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof TimeRangePicker>;

/**
 * Basic time range picker with a label.
 */
export const Basic: Story = {
  render: () => <TimeRangePicker label="Select time range" />,
};

/**
 * All three sizes — small (32px), medium (40px), and large (50px) — matching TextField.
 */
export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16, minWidth: 500 }}>
      <TimeRangePicker label="Small" size="small" />
      <TimeRangePicker label="Medium" size="medium" />
      <TimeRangePicker label="Large" size="large" />
    </div>
  ),
};

/**
 * Controlled time range picker with React state.
 */
export const Controlled: Story = {
  render: () => {
    const [value, setValue] = useState<DateRange<Dayjs>>([null, null]);
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16, minWidth: 500 }}>
        <TimeRangePicker label="Time range" value={value} onChange={(newValue) => setValue(newValue)} />
        <div style={{ fontSize: 14, color: '#666' }}>
          Start: {value[0] ? value[0].format('hh:mm A') : 'None'}
          {' — '}
          End: {value[1] ? value[1].format('hh:mm A') : 'None'}
        </div>
      </div>
    );
  },
};

/**
 * Without an external label.
 */
export const WithoutLabel: Story = {
  render: () => <TimeRangePicker />,
};

/**
 * Disabled state.
 */
export const Disabled: Story = {
  render: () => (
    <TimeRangePicker
      label="Disabled"
      disabled
      defaultValue={[dayjs().hour(9).minute(0), dayjs().hour(17).minute(0)]}
    />
  ),
};

/**
 * Read-only state.
 */
export const ReadOnly: Story = {
  render: () => (
    <TimeRangePicker
      label="Read only"
      readOnly
      defaultValue={[dayjs().hour(9).minute(0), dayjs().hour(17).minute(0)]}
    />
  ),
};

/**
 * 24-hour format (no AM/PM).
 */
export const TwentyFourHour: Story = {
  render: () => <TimeRangePicker label="24-hour format" ampm={false} />,
};

/**
 * Pre-filled business hours range.
 */
export const BusinessHours: Story = {
  render: () => (
    <TimeRangePicker
      label="Business hours"
      defaultValue={[dayjs().hour(9).minute(0), dayjs().hour(17).minute(0)]}
    />
  ),
};

/**
 * Default action bar with Cancel and Accept actions.
 */
export const ActionBar: Story = {
  render: () => (
    <TimeRangePicker
      label="With action bar"
      slotProps={{
        actionBar: {
          actions: ['clear', 'cancel', 'accept'],
        },
      }}
    />
  ),
};


/**
 * Interactive playground with all controls.
 */
export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    value: { control: false },
    defaultValue: { control: false },
    referenceDate: { control: false },
    minTime: { control: false },
    maxTime: { control: false },
    onChange: { action: 'onChange' },
    onAccept: { action: 'onAccept' },
    onClose: { action: 'onClose' },
    onOpen: { action: 'onOpen' },
    onError: { action: 'onError' },
    size: { control: 'select', options: ['small', 'medium', 'large'] },
    label: { control: 'text' },
    disabled: { control: 'boolean' },
    readOnly: { control: 'boolean' },
    ampm: { control: 'boolean' },
  },
  args: {
    label: 'Pick a time range',
    size: 'medium',
    disabled: false,
    readOnly: false,
    ampm: true,
  },
  render: (args: TimeRangePickerProps) => <TimeRangePicker {...args} />,
};
