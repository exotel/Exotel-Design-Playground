import type { Meta, StoryObj } from '@storybook/react';
import { Divider, Box, Typography, Chip } from '../../components';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof Divider> = {
  title: 'UI Components/Divider',
  component: Divider,
  parameters: {
    layout: 'centered',
    ...metaControlsDisabled,
    docs: {
      description: {
        component:
          'Exotel-approved divider component that wraps MUI\'s Divider. A thin line that groups content in lists and layouts.',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Divider>;

export const Default: Story = {
  decorators: [
    (Story) => (
      <Box sx={{ width: 400 }}>
        <Story />
      </Box>
    ),
  ],
};

export const WithText: Story = {
  args: {
    children: 'OR',
  },
  decorators: [
    (Story) => (
      <Box sx={{ width: 400 }}>
        <Story />
      </Box>
    ),
  ],
};

export const WithChip: Story = {
  render: () => (
    <Box sx={{ width: 400 }}>
      <Divider>
        <Chip label="Section" size="small" />
      </Divider>
    </Box>
  ),
};

export const Variants: Story = {
  render: () => (
    <Box sx={{ width: 400, display: 'flex', flexDirection: 'column', gap: 2 }}>
      <Typography variant="caption" color="text.secondary">fullWidth</Typography>
      <Divider variant="fullWidth" />
      <Typography variant="caption" color="text.secondary">inset</Typography>
      <Divider variant="inset" />
      <Typography variant="caption" color="text.secondary">middle</Typography>
      <Divider variant="middle" />
    </Box>
  ),
};

export const Vertical: Story = {
  render: () => (
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, height: 40 }}>
      <Typography variant="body2">Item 1</Typography>
      <Divider orientation="vertical" flexItem />
      <Typography variant="body2">Item 2</Typography>
      <Divider orientation="vertical" flexItem />
      <Typography variant="body2">Item 3</Typography>
    </Box>
  ),
};

export const TextAlignment: Story = {
  render: () => (
    <Box sx={{ width: 400, display: 'flex', flexDirection: 'column', gap: 2 }}>
      <Divider textAlign="left">Left</Divider>
      <Divider textAlign="center">Center</Divider>
      <Divider textAlign="right">Right</Divider>
    </Box>
  ),
};

export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    orientation: { control: 'select', options: ['horizontal', 'vertical'] },
    variant: { control: 'select', options: ['fullWidth', 'inset', 'middle'] },
    textAlign: { control: 'select', options: ['center', 'left', 'right'] },
    light: { control: 'boolean' },
    flexItem: { control: 'boolean' },
    absolute: { control: 'boolean' },
    children: { control: 'text' },
  },
  args: {
    orientation: 'horizontal',
    variant: 'fullWidth',
    textAlign: 'center',
    light: false,
    children: 'OR',
  },
  decorators: [
    (Story) => (
      <Box sx={{ width: 400 }}>
        <Story />
      </Box>
    ),
  ],
  render: (args) => <Divider {...args} />,
};
