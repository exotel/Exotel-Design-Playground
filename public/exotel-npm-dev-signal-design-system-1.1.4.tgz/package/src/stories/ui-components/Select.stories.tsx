import type { Meta, StoryObj } from '@storybook/react';
import { Select } from '../../components';
import { MenuItem } from '@mui/material';
import { useState } from 'react';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof Select> = {
  title: 'UI Components/Select',
  component: Select,
  parameters: {
    layout: 'centered',
    ...metaControlsDisabled,
    docs: {
      description: {
        component:
          "Exotel-approved select component. Only supports the outlined variant and renders an external label above the input, consistent with Autocomplete.",
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Select>;

/**
 * Basic select with external label
 */
export const Basic: Story = {
  render: () => {
    const [value, setValue] = useState('');
    return (
      <Select
        label="Age"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        sx={{ minWidth: 200 }}
      >
        <MenuItem value={10}>Ten</MenuItem>
        <MenuItem value={20}>Twenty</MenuItem>
        <MenuItem value={30}>Thirty</MenuItem>
      </Select>
    );
  },
};

/**
 * Different sizes
 */
export const Sizes: Story = {
  render: () => {
    const [value1, setValue1] = useState('');
    const [value2, setValue2] = useState('');
    const [value3, setValue3] = useState('');
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', width: '300px' }}>
        <Select
          label="Small"
          size="small"
          value={value1}
          onChange={(e) => setValue1(e.target.value)}
        >
          <MenuItem value={10}>Option 1</MenuItem>
          <MenuItem value={20}>Option 2</MenuItem>
        </Select>
        <Select
          label="Medium"
          size="medium"
          value={value2}
          onChange={(e) => setValue2(e.target.value)}
        >
          <MenuItem value={10}>Option 1</MenuItem>
          <MenuItem value={20}>Option 2</MenuItem>
        </Select>
        <Select
          label="Large"
          size="large"
          value={value3}
          onChange={(e) => setValue3(e.target.value)}
        >
          <MenuItem value={10}>Option 1</MenuItem>
          <MenuItem value={20}>Option 2</MenuItem>
        </Select>
      </div>
    );
  },
};

/**
 * Error state
 */
export const Error: Story = {
  render: () => {
    const [value, setValue] = useState('');
    return (
      <Select
        label="Age"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        error
        helperText="Please select an age"
        sx={{ minWidth: 200 }}
      >
        <MenuItem value={10}>Ten</MenuItem>
        <MenuItem value={20}>Twenty</MenuItem>
        <MenuItem value={30}>Thirty</MenuItem>
      </Select>
    );
  },
};

/**
 * Disabled state
 */
export const Disabled: Story = {
  render: () => (
    <Select label="Age" value={10} disabled sx={{ minWidth: 200 }}>
      <MenuItem value={10}>Ten</MenuItem>
      <MenuItem value={20}>Twenty</MenuItem>
      <MenuItem value={30}>Thirty</MenuItem>
    </Select>
  ),
};

/**
 * Full width
 */
export const FullWidth: Story = {
  render: () => {
    const [value, setValue] = useState('');
    return (
      <div style={{ width: '360px' }}>
        <Select
          label="Age"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          fullWidth
        >
          <MenuItem value={10}>Ten</MenuItem>
          <MenuItem value={20}>Twenty</MenuItem>
          <MenuItem value={30}>Thirty</MenuItem>
        </Select>
      </div>
    );
  },
};

/**
 * Custom placeholder
 */
export const WithPlaceholder: Story = {
  render: () => {
    const [value, setValue] = useState('');
    return (
      <Select
        label="Status"
        placeholder="Choose a status"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        sx={{ minWidth: 200 }}
      >
        <MenuItem value="open">Open</MenuItem>
        <MenuItem value="closed">Closed</MenuItem>
      </Select>
    );
  },
};

/**
 * Interactive playground — Controls enabled for serializable props.
 * MenuItem children and value are managed in render.
 */
export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    children: { control: false },
    value: { control: false },
    onChange: { action: 'onChange' },
    InputProps: { control: false },
    inputProps: { control: false },
    SelectProps: { control: false },
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
    },
    label: { control: 'text' },
    placeholder: { control: 'text' },
    helperText: { control: 'text' },
    disabled: { control: 'boolean' },
    error: { control: 'boolean' },
    fullWidth: { control: 'boolean' },
    required: { control: 'boolean' },
    showLabel: { control: 'boolean' },
  },
  args: {
    label: 'Age',
    size: 'medium',
    placeholder: '',
    helperText: '',
    disabled: false,
    error: false,
    fullWidth: false,
    required: false,
    showLabel: true,
  },
  render: (args) => {
    const [value, setValue] = useState('');
    return (
      <div style={{ width: args.fullWidth ? '100%' : 240 }}>
        <Select
          {...args}
          value={value}
          onChange={(e) => {
            setValue(e.target.value);
            args.onChange?.(e);
          }}
        >
          <MenuItem value={10}>Ten</MenuItem>
          <MenuItem value={20}>Twenty</MenuItem>
          <MenuItem value={30}>Thirty</MenuItem>
        </Select>
      </div>
    );
  },
};
