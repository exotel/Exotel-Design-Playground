import type { Meta, StoryObj } from '@storybook/react';
import { FormControlLabel, Radio, RadioGroup } from '../../index';
import { useState } from 'react';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

// MUI re-exports lack displayName, so Storybook's dynamic Code panel
// would otherwise render them as <React.ForwardRef>.
FormControlLabel.displayName = 'FormControlLabel';
RadioGroup.displayName = 'RadioGroup';

const meta: Meta<typeof Radio> = {
  title: 'UI Components/Radio',
  component: Radio,
  parameters: {
    layout: 'centered',
    ...metaControlsDisabled,
    docs: {
      description: {
        component:
          "Exotel-approved radio component that wraps MUI's Radio. Used for single selection from a list of options.",
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Radio>;

/**
 * Unchecked radio
 */
export const Unchecked: Story = {
  args: {
    checked: false,
  },
};

/**
 * Checked radio
 */
export const Checked: Story = {
  args: {
    checked: true,
  },
};

/**
 * Different colors
 */
export const Colors: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
      <Radio checked color="default" />
      <Radio checked color="primary" />
      <Radio checked color="secondary" />
      <Radio checked color="success" />
      <Radio checked color="error" />
      <Radio checked color="info" />
      <Radio checked color="warning" />
    </div>
  ),
};

/**
 * Different sizes
 */
export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
      <Radio checked size="small" />
      <Radio checked size="medium" />
    </div>
  ),
};

/**
 * Radio group with labels
 */
export const WithLabel: Story = {
  render: () => (
    <RadioGroup defaultValue="female" name="radio-buttons-group">
      <FormControlLabel value="female" control={<Radio />} label="Female" />
      <FormControlLabel value="male" control={<Radio />} label="Male" />
      <FormControlLabel value="other" control={<Radio />} label="Other" />
    </RadioGroup>
  ),
};

/**
 * Disabled state
 */
export const Disabled: Story = {
  render: () => (
    <RadioGroup defaultValue="checked" name="disabled-radio-group">
      <FormControlLabel value="unchecked" disabled control={<Radio />} label="Unchecked" />
      <FormControlLabel value="checked" disabled control={<Radio />} label="Checked" />
    </RadioGroup>
  ),
};

/**
 * Interactive playground — Controls enabled for serializable props.
 */
export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    icon: { control: false },
    checkedIcon: { control: false },
    onChange: { action: 'onChange' },
    color: {
      control: 'select',
      options: ['default', 'primary', 'secondary', 'error', 'info', 'success', 'warning'],
    },
    size: {
      control: 'select',
      options: ['small', 'medium'],
    },
    disabled: { control: 'boolean' },
    checked: { control: 'boolean' },
  },
  args: {
    checked: false,
    color: 'primary',
    size: 'medium',
    disabled: false,
  },
  render: (args) => {
    const [checked, setChecked] = useState(args.checked ?? false);
    return (
      <Radio
        {...args}
        checked={checked}
        onChange={(e, value) => {
          setChecked(e.target.checked);
          args.onChange?.(e, value);
        }}
      />
    );
  },
};
