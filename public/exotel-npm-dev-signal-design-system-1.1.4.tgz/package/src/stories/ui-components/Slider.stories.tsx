import type { Meta, StoryObj } from '@storybook/react';
import { Box, Slider } from '../../components';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof Slider> = {
  title: 'UI Components/Slider',
  component: Slider,
  parameters: { layout: 'centered', ...metaControlsDisabled },
};

export default meta;
type Story = StoryObj<typeof Slider>;

export const Basic: Story = { args: { defaultValue: 30 } };
export const Disabled: Story = { args: { defaultValue: 30, disabled: true } };

export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    color: {
      control: 'select',
      options: ['primary', 'secondary', 'error', 'info', 'success', 'warning'],
    },
    size: { control: 'select', options: ['small', 'medium'] },
    orientation: { control: 'select', options: ['horizontal', 'vertical'] },
    disabled: { control: 'boolean' },
    valueLabelDisplay: { control: 'select', options: ['auto', 'on', 'off'] },
    min: { control: 'number' },
    max: { control: 'number' },
    step: { control: 'number' },
    marks: { control: 'boolean' },
    defaultValue: { control: { type: 'range', min: 0, max: 100 } },
    onChange: { action: 'onChange' },
    onChangeCommitted: { action: 'onChangeCommitted' },
  },
  args: {
    defaultValue: 30,
    color: 'primary',
    size: 'medium',
    orientation: 'horizontal',
    disabled: false,
    valueLabelDisplay: 'off',
    min: 0,
    max: 100,
    step: 1,
    marks: false,
  },
  decorators: [
    (Story) => (
      <Box sx={{ width: 300 }}>
        <Story />
      </Box>
    ),
  ],
  render: (args) => <Slider {...args} />,
};
