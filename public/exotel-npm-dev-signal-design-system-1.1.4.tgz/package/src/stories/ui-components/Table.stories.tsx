import type { Meta, StoryObj } from '@storybook/react';
import {
  Table,
  Box,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  Chip,
} from '../../components';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof Table> = {
  title: 'UI Components/Table',
  component: Table,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'Exotel-approved table component that wraps MUI\'s Table. For data-heavy use cases, prefer DataGrid. Use Table for simple, static tabular layouts.',
      },
    },
    ...metaControlsDisabled,
  },
};

export default meta;
type Story = StoryObj<typeof Table>;

const sampleRows = [
  { id: 1, name: 'Inbound Sales', agents: 12, status: 'Active' },
  { id: 2, name: 'Customer Support', agents: 8, status: 'Active' },
  { id: 3, name: 'Billing Team', agents: 5, status: 'Paused' },
  { id: 4, name: 'Technical Support', agents: 15, status: 'Active' },
  { id: 5, name: 'Retention', agents: 3, status: 'Inactive' },
];

export const Default: Story = {
  render: () => (
    <TableContainer component={Paper} sx={{ maxWidth: 600 }}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Queue Name</TableCell>
            <TableCell align="right">Agents</TableCell>
            <TableCell align="right">Status</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {sampleRows.map((row) => (
            <TableRow key={row.id}>
              <TableCell>{row.name}</TableCell>
              <TableCell align="right">{row.agents}</TableCell>
              <TableCell align="right">
                <Chip
                  label={row.status}
                  size="small"
                  color={row.status === 'Active' ? 'success' : row.status === 'Paused' ? 'warning' : 'default'}
                  variant="tonal"
                />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  ),
};

export const SmallSize: Story = {
  render: () => (
    <TableContainer component={Paper} sx={{ maxWidth: 600 }}>
      <Table size="small">
        <TableHead>
          <TableRow>
            <TableCell>Queue Name</TableCell>
            <TableCell align="right">Agents</TableCell>
            <TableCell align="right">Status</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {sampleRows.map((row) => (
            <TableRow key={row.id}>
              <TableCell>{row.name}</TableCell>
              <TableCell align="right">{row.agents}</TableCell>
              <TableCell align="right">{row.status}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  ),
};

export const StickyHeader: Story = {
  render: () => (
    <TableContainer component={Paper} sx={{ maxWidth: 600, maxHeight: 200 }}>
      <Table stickyHeader>
        <TableHead>
          <TableRow>
            <TableCell>Queue Name</TableCell>
            <TableCell align="right">Agents</TableCell>
            <TableCell align="right">Status</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {[...sampleRows, ...sampleRows].map((row, idx) => (
            <TableRow key={idx}>
              <TableCell>{row.name}</TableCell>
              <TableCell align="right">{row.agents}</TableCell>
              <TableCell align="right">{row.status}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  ),
};

export const Borderless: Story = {
  render: () => (
    <Box sx={{ maxWidth: 600 }}>
      <Typography variant="subtitle2" sx={{ mb: 1 }}>Recent Activity</Typography>
      <Table size="small">
        <TableBody>
          {sampleRows.slice(0, 3).map((row) => (
            <TableRow key={row.id} sx={{ '&:last-child td': { border: 0 } }}>
              <TableCell sx={{ pl: 0 }}>{row.name}</TableCell>
              <TableCell align="right">{row.agents} agents</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Box>
  ),
};

export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    children: { control: false },
    size: {
      control: 'select',
      options: ['small', 'medium'],
    },
    padding: {
      control: 'select',
      options: ['normal', 'checkbox', 'none'],
    },
  },
  args: {
    size: 'medium',
    stickyHeader: false,
    padding: 'normal',
  },
  render: (args) => (
    <TableContainer
      component={Paper}
      sx={{ maxWidth: 600, maxHeight: args.stickyHeader ? 200 : undefined }}
    >
      <Table {...args}>
        <TableHead>
          <TableRow>
            <TableCell>Queue Name</TableCell>
            <TableCell align="right">Agents</TableCell>
            <TableCell align="right">Status</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {(args.stickyHeader ? [...sampleRows, ...sampleRows] : sampleRows).map((row, idx) => (
            <TableRow key={args.stickyHeader ? idx : row.id}>
              <TableCell>{row.name}</TableCell>
              <TableCell align="right">{row.agents}</TableCell>
              <TableCell align="right">
                <Chip
                  label={row.status}
                  size="small"
                  color={row.status === 'Active' ? 'success' : row.status === 'Paused' ? 'warning' : 'default'}
                  variant="tonal"
                />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  ),
};
