import type { Meta, StoryObj } from '@storybook/react';
import { Tooltip, Button } from '../../components';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof Tooltip> = {
  title: 'UI Components/Tooltip',
  component: Tooltip,
  parameters: { layout: 'centered', ...metaControlsDisabled },
};

export default meta;
type Story = StoryObj<typeof Tooltip>;

export const Basic: Story = {
  render: () => (
    <Tooltip title="This is a tooltip">
      <Button>Hover me</Button>
    </Tooltip>
  ),
};

export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    children: { control: false },
    title: { control: 'text' },
    placement: {
      control: 'select',
      options: [
        'bottom-end',
        'bottom-start',
        'bottom',
        'left-end',
        'left-start',
        'left',
        'right-end',
        'right-start',
        'right',
        'top-end',
        'top-start',
        'top',
      ],
    },
    arrow: { control: 'boolean' },
    open: { control: 'boolean' },
    disableHoverListener: { control: 'boolean' },
    disableFocusListener: { control: 'boolean' },
    disableTouchListener: { control: 'boolean' },
    enterDelay: { control: 'number' },
    leaveDelay: { control: 'number' },
  },
  args: {
    title: 'This is a tooltip',
    placement: 'bottom',
    arrow: true,
    open: undefined,
  },
  render: (args) => (
    <Tooltip {...args}>
      <Button>Hover me</Button>
    </Tooltip>
  ),
};
