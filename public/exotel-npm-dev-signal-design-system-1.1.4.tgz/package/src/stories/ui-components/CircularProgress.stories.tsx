import type { Meta, StoryObj } from '@storybook/react';
import { CircularProgress } from '../../components';
import {
  metaControlsDisabled,
  interactiveControlsEnabled,
  unsafePropArgTypes,
} from '../utils/storyControls';

const meta: Meta<typeof CircularProgress> = {
  title: 'UI Components/CircularProgress',
  component: CircularProgress,
  parameters: { layout: 'centered', ...metaControlsDisabled },
};

export default meta;
type Story = StoryObj<typeof CircularProgress>;

export const Indeterminate: Story = {};
export const Determinate: Story = { args: { variant: 'determinate', value: 75 } };

export const Interactive: Story = {
  parameters: interactiveControlsEnabled,
  argTypes: {
    ...unsafePropArgTypes,
    variant: { control: 'select', options: ['determinate', 'indeterminate'] },
    color: {
      control: 'select',
      options: ['primary', 'secondary', 'error', 'info', 'success', 'warning', 'inherit'],
    },
    size: { control: 'number' },
    thickness: { control: 'number' },
    value: { control: { type: 'range', min: 0, max: 100 } },
    disableShrink: { control: 'boolean' },
  },
  args: {
    variant: 'indeterminate',
    color: 'primary',
    size: 40,
    thickness: 3.6,
    value: 75,
  },
  render: (args) => <CircularProgress {...args} />,
};
