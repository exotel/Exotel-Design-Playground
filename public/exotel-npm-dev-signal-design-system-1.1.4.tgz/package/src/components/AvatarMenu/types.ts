import type { IconName } from '../Icon';

export interface AvatarMenuItem {
  /** Unique identifier for the item */
  id: string;
  /** Display label */
  label: string;
  /** Optional Phosphor icon shown to the left of the label */
  icon?: IconName;
  /** Whether the item is disabled */
  disabled?: boolean;
  /** Click handler */
  onClick: () => void;
}

/** A logical group of menu items. Groups are separated by dividers automatically. */
export interface AvatarMenuGroup {
  /** Unique identifier for the group */
  id: string;
  items: AvatarMenuItem[];
}

/** A key-value row rendered as static text in the footer (e.g. last login, version). */
export interface AvatarMenuFooterInfo {
  label: string;
  value: string;
}

export type ThemeMode = 'light' | 'dark' | 'system';

/**
 * Presence / availability shown as the status badge on the avatar trigger.
 * Icons and colours follow the Signal presence set (Teams-style).
 */
export type PresenceStatus =
  | 'available'
  | 'busy'
  | 'do-not-disturb'
  | 'be-right-back'
  | 'away'
  | 'offline';

export interface AvatarMenuProps {
  /** Full name used to derive initials and avatar background colour */
  avatarName: string;
  /**
   * Size of the avatar
   * @default 'medium'
   */
  size?: 'small' | 'medium' | 'large';
  /**
   * Presence badge on the avatar trigger.
   * Omit to hide the badge entirely.
   */
  presenceStatus?: PresenceStatus;
  /**
   * Grouped menu items. Each group is rendered as a block separated from the
   * next by a Divider. Groups map to the sections visible in the popup.
   */
  menuGroups: AvatarMenuGroup[];
  /**
   * Static info rows displayed beneath the Logout row.
   * e.g. [{ label: 'Last Login', value: 'Jun 21 at 08:37' }, { label: 'Version', value: '6.0' }]
   */
  footerInfo: AvatarMenuFooterInfo[];
  /** Currently active theme mode — used to highlight the selected option in the submenu */
  selectedTheme: ThemeMode;
  /** Called when the user picks a theme option in the Theme submenu */
  onThemeChange: (mode: ThemeMode) => void;
  /** Called when the constant "Logout" row is clicked */
  onLogout: () => void;
}
