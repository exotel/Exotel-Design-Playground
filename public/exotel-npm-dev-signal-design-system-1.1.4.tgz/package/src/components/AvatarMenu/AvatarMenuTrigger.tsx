import { Avatar } from '../Avatar';
import { Box } from '../Box';
import { Typography } from '../Typography';
import { getAvatarColors, getInitials } from '../../functions';
import { avatarSizeMap } from './constants';
import { getPresenceStatusLabel, PresenceBadge } from './PresenceBadge';
import type { PresenceStatus } from './types';

interface AvatarMenuTriggerProps {
  avatarName: string;
  size?: 'small' | 'medium' | 'large';
  /** When omitted, no presence badge is shown. */
  presenceStatus?: PresenceStatus;
  open: boolean;
  onOpen: (event: React.MouseEvent<HTMLDivElement>) => void;
  onKeyDown: (event: React.KeyboardEvent<HTMLDivElement>) => void;
}

export function AvatarMenuTrigger({
  avatarName,
  size = 'medium',
  presenceStatus,
  open,
  onOpen,
  onKeyDown,
}: AvatarMenuTriggerProps) {
  const avatarSize = avatarSizeMap[size];
  const avatarColors = getAvatarColors(avatarName);
  const presenceLabel = getPresenceStatusLabel(presenceStatus);

  return (
    <Box
      role="button"
      tabIndex={0}
      aria-label={presenceLabel ? `Open user menu, ${presenceLabel}` : 'Open user menu'}
      aria-haspopup="true"
      aria-expanded={open}
      onClick={onOpen}
      onKeyDown={onKeyDown}
      display="inline-flex"
      sx={{ cursor: 'pointer' }}
    >
      <PresenceBadge status={presenceStatus}>
        <Avatar
          variant="rounded"
          sx={{
            ...avatarColors,
            cursor: 'pointer',
            width: avatarSize,
            height: avatarSize,
          }}
        >
          <Typography variant="title3" color="inherit">
            {getInitials(avatarName)}
          </Typography>
        </Avatar>
      </PresenceBadge>
    </Box>
  );
}
