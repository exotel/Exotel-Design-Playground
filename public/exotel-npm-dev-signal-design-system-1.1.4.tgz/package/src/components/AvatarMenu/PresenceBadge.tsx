import { Badge } from '../Badge';
import { Box } from '../Box';
import { Icon } from '../Icon';
import { presenceStatusConfig } from './constants';
import type { PresenceStatus } from './types';

const SIZE = 10;
const INSET = 4;

export interface PresenceBadgeProps {
  /** When omitted, children render without a badge. */
  status?: PresenceStatus;
  children: React.ReactNode;
}

/** Circular presence indicator overlaid on an avatar (or other child). */
export function PresenceBadge({
  status,
  children,
}: PresenceBadgeProps): React.ReactElement {
  if (!status) return <>{children}</>;

  const { color, icon, hollow } = presenceStatusConfig[status];

  return (
    <Badge
      overlap="circular"
      anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      badgeContent={
        <Box
          aria-hidden
          sx={(theme) => ({
            width: SIZE,
            height: SIZE,
            borderRadius: '50%',
            boxSizing: 'border-box',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: `0 0 0 2px ${theme.palette.background.paper}`,
            bgcolor: hollow ? 'background.paper' : color,
            border: hollow ? '1.5px solid' : 0,
            borderColor: color,
            color: 'common.white',
          })}
        >
          {icon ? <Icon name={icon} size={6} weight="bold" color="currentColor" /> : null}
        </Box>
      }
      sx={{
        '& .MuiBadge-badge': {
          p: 0,
          minWidth: 0,
          width: SIZE,
          height: SIZE,
          borderRadius: '50%',
          bgcolor: 'transparent',
          bottom: INSET,
          right: INSET,
        },
      }}
    >
      {children}
    </Badge>
  );
}

/** Accessible label for a presence status (e.g. for trigger `aria-label`). */
export function getPresenceStatusLabel(status?: PresenceStatus): string | undefined {
  return status ? presenceStatusConfig[status].label : undefined;
}
