import type { IconName } from '../Icon';
import type { PresenceStatus } from './types';

/** Avatar menu rows inherit dense MenuItem spacing and body2 labels from theme; keep sx minimal. */
export const menuItemSx = {} as const;

export const avatarSizeMap = {
  small: 32,
  medium: 40,
  large: 48,
} as const;

export interface PresenceStatusConfig {
  /** Theme palette path used for the badge fill / ring */
  color: string;
  /** Accessible label for the status */
  label: string;
  /**
   * Optional glyph inside the badge (DND minus, BRB clock, away moon).
   * Solid statuses omit this and render a filled circle.
   */
  icon?: IconName;
  /** Offline: hollow ring instead of a filled disc */
  hollow?: boolean;
}

export const presenceStatusConfig: Record<PresenceStatus, PresenceStatusConfig> = {
  available: {
    color: 'success.main',
    label: 'Available',
  },
  busy: {
    color: 'error.main',
    label: 'Busy',
  },
  'do-not-disturb': {
    color: 'error.main',
    label: 'Do not disturb',
    icon: 'minus',
  },
  'be-right-back': {
    color: 'warning.main',
    label: 'Be right back',
    icon: 'clock',
  },
  away: {
    color: 'warning.main',
    label: 'Away',
    icon: 'moon',
  },
  offline: {
    color: 'grey.500',
    label: 'Offline',
    hollow: true,
  },
};
