/**
 * MultiSelect — multi-select dropdown with groups, select-all, and tree options.
 */

import React, { useMemo, useState, type ReactNode } from 'react';
import { Popper, ClickAwayListener, Drawer, InputAdornment } from '../../components';
import { useTheme } from '@mui/material/styles';
import { Checkbox } from '../Checkbox';
import { ListItemText } from '../List/ListItemText';
import { Paper } from '../Paper';
import { List } from '../List';
import { ListItem } from '../List/ListItem';
import { IconButton } from '../IconButton';
import { Box } from '../Box';
import { Typography } from '../Typography';
import { Divider } from '../Divider';
import { TextField } from '../TextField';
import { Icon, type IconName } from '../Icon';
import { Tooltip } from '../Tooltip';
import { resolveFieldPlaceholder } from '../../functions/resolveFieldPlaceholder';

export interface MultiSelectOption {
  id: string;
  label: string;
  value: string;
  parentId?: string;
  isGroup?: boolean;
  disabled?: boolean;
  /** Shown on hover when `disabled` is true. */
  disabledTooltip?: ReactNode;
  children?: MultiSelectOption[];
}

export interface MultiSelectProps {
  label: string;
  options: MultiSelectOption[];
  value: string[];
  onChange: (values: string[]) => void;
  placeholder?: string;
  disabled?: boolean;
  width?: number | string;
  showSelectAll?: boolean;
  clearable?: boolean;
  maxDisplayItems?: number;
  /** When false, trigger shows `label` only (selection rendered elsewhere). @default true */
  showSelectedValuesInTrigger?: boolean;
  iconName?: IconName;
  /** Open options in a bottom sheet instead of a popper. */
  useBottomSheet?: boolean;
}

export const MultiSelect = React.forwardRef<HTMLDivElement, MultiSelectProps>(
  (
    {
      label,
      options,
      value = [],
      onChange,
      placeholder,
      disabled = false,
      width,
      showSelectAll = true,
      clearable = true,
      maxDisplayItems = 2,
      showSelectedValuesInTrigger = true,
      iconName,
      useBottomSheet = false,
    },
    ref,
  ) => {
    const theme = useTheme();
    const resolvedPlaceholder = resolveFieldPlaceholder(label, placeholder, 'select');
    const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
    const [open, setOpen] = useState(false);

    const selectableOptions = useMemo(
      () => options.filter((o) => !o.isGroup && !o.disabled),
      [options],
    );
    const allSelected =
      selectableOptions.length > 0 && selectableOptions.every((o) => value.includes(o.value));

    const { groupedOptions, rootOptions } = useMemo(() => {
      const grouped: Record<string, MultiSelectOption[]> = {};
      const roots: MultiSelectOption[] = [];
      for (const option of options) {
        if (option.parentId) {
          (grouped[option.parentId] ??= []).push(option);
        } else {
          roots.push(option);
        }
      }
      return { groupedOptions: grouped, rootOptions: roots };
    }, [options]);

    const displayText = useMemo(() => {
      if (!showSelectedValuesInTrigger) return label;
      if (value.length === 0) return resolvedPlaceholder;

      const selected = options.filter((o) => value.includes(o.value) && !o.isGroup);
      if (selected.length <= maxDisplayItems) {
        return selected.map((o) => o.label).join(', ');
      }
      const head = selected.slice(0, maxDisplayItems).map((o) => o.label).join(', ');
      return `${head} +${selected.length - maxDisplayItems}`;
    }, [
      showSelectedValuesInTrigger,
      label,
      value,
      resolvedPlaceholder,
      options,
      maxDisplayItems,
    ]);

    const handleOpen = (event: React.MouseEvent<HTMLElement>) => {
      if (disabled) return;
      if (!useBottomSheet) setAnchorEl(event.currentTarget);
      setOpen((prev) => !prev);
    };

    const handleToggle = (optionValue: string) => {
      if (options.find((o) => o.value === optionValue)?.disabled) return;
      onChange(
        value.includes(optionValue)
          ? value.filter((v) => v !== optionValue)
          : [...value, optionValue],
      );
    };

    const renderOption = (option: MultiSelectOption, depth = 0): ReactNode => {
      const children = groupedOptions[option.id] ?? [];
      const childNodes = children.map((child) => renderOption(child, depth + 1));

      if (option.isGroup) {
        return (
          <React.Fragment key={option.id}>
            <ListItem sx={{ pl: depth * 2 + 2, py: 0.5, cursor: 'default' }}>
              <Typography variant="body2" fontWeight={600} color="text.secondary">
                {option.label}
              </Typography>
            </ListItem>
            {childNodes}
          </React.Fragment>
        );
      }

      const content = (
        <Box
          component="span"
          display="inline-flex"
          alignItems="center"
          sx={{ width: 'fit-content', maxWidth: '100%' }}
        >
          <Checkbox checked={value.includes(option.value)} disabled={option.disabled} sx={{ py: 0, px: 1 }} />
          <ListItemText
            primary={option.label}
            slotProps={{ primary: { variant: 'body2' } }}
            sx={{ flex: '0 1 auto', my: 0 }}
          />
        </Box>
      );

      return (
        <React.Fragment key={option.id}>
          <ListItem
            onClick={() => !option.disabled && handleToggle(option.value)}
            sx={{
              pl: depth * 2 + 2,
              py: 0.5,
              cursor: option.disabled ? 'default' : 'pointer',
              opacity: option.disabled ? 0.5 : 1,
              '&:hover': { backgroundColor: option.disabled ? 'transparent' : 'action.hover' },
            }}
          >
            {option.disabled && option.disabledTooltip ? (
              <Tooltip title={option.disabledTooltip} placement="top">
                {content}
              </Tooltip>
            ) : (
              content
            )}
          </ListItem>
          {childNodes}
        </React.Fragment>
      );
    };

    const optionsPanel = (
      <Paper elevation={5} sx={{ maxHeight: 400, overflow: 'auto' }}>
        <List dense sx={{ py: 0 }}>
          {showSelectAll && selectableOptions.length > 0 && (
            <>
              <ListItem
                onClick={() =>
                  onChange(allSelected ? [] : selectableOptions.map((o) => o.value))
                }
                sx={{ cursor: 'pointer', py: 1, '&:hover': { backgroundColor: 'action.hover' } }}
              >
                <Checkbox
                  checked={allSelected}
                  indeterminate={value.length > 0 && value.length < selectableOptions.length}
                  sx={{ py: 0, px: 1 }}
                />
                <ListItemText
                  primary="Select All"
                  slotProps={{ primary: { variant: 'body2', fontWeight: 600 } }}
                />
              </ListItem>
              <Divider />
            </>
          )}
          {rootOptions.map((option) => renderOption(option))}
        </List>
      </Paper>
    );

    return (
      <ClickAwayListener onClickAway={useBottomSheet ? () => undefined : () => setOpen(false)}>
        <div ref={ref}>
          <TextField
            label={label}
            showLabel={showSelectedValuesInTrigger}
            value={displayText}
            size="small"
            disabled={disabled}
            placeholder={resolvedPlaceholder}
            slotProps={{
              input: {
                readOnly: true,
                onClick: handleOpen,
                sx: {
                  '& .MuiInputAdornment-root': { marginRight: 'unset' },
                  '& .MuiOutlinedInput-notchedOutline': {
                    borderColor: 'var(--mui-palette-Chip-defaultBorder)',
                  },
                },
                startAdornment: iconName ? (
                  <InputAdornment position="start">
                    <Icon name={iconName} size="sm" />
                  </InputAdornment>
                ) : undefined,
                endAdornment: (
                  <Box display="flex" alignItems="center" gap={0.5}>
                    {clearable && showSelectedValuesInTrigger && value.length > 0 && !disabled && (
                      <IconButton
                        size="small"
                        onClick={(e) => {
                          e.stopPropagation();
                          onChange([]);
                        }}
                        sx={{ p: 0.5 }}
                      >
                        <Icon name="x" size="xs" weight="bold" />
                      </IconButton>
                    )}
                    <Icon
                      name="caret-down"
                      size="xs"
                      weight="fill"
                      width={14}
                      color={theme.vars?.palette?.text?.secondary}
                    />
                  </Box>
                ),
              },
            }}
            sx={{
              minWidth: width || '160px',
              cursor: disabled ? 'default' : 'pointer',
              '& input': { cursor: disabled ? 'default' : 'pointer' },
            }}
          />
          {useBottomSheet ? (
            <Drawer
              anchor="bottom"
              open={open}
              onClose={() => setOpen(false)}
              slotProps={{
                paper: {
                  sx: { maxHeight: '85vh', borderRadius: '16px 16px 0 0', overflow: 'hidden' },
                },
              }}
            >
              {optionsPanel}
            </Drawer>
          ) : (
            <Popper
              open={open}
              anchorEl={anchorEl}
              placement="bottom-start"
              style={{ zIndex: 1300, minWidth: anchorEl?.offsetWidth }}
            >
              {optionsPanel}
            </Popper>
          )}
        </div>
      </ClickAwayListener>
    );
  },
);

MultiSelect.displayName = 'MultiSelect';
