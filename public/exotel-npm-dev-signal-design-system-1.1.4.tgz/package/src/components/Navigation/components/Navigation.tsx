import { forwardRef, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { NavToolbar } from "./NavToolbar";
import { NavSections } from "./NavSections";
import type { NavSectionProps } from "./NavSection";
import { NavigationProvider, type NavigationContextProps } from "../navigationContext";
import { NavFooter } from "./NavFooter";
import { Divider } from "../../Divider";
import { buildDisplayConfig, filterSectionsBySearch, filterSectionsByVisibility, mergeDisplayConfig } from "../utils";
import { Box } from "../../Box";
import type { NavItemProps, NavItemPayload } from "./NavItem";

export interface NavigationProps {
  items: NavSectionProps[];
  staticSidebar?: boolean;
  initialPath?: string;
  pinByDefault?: boolean;
  /** Single handler called when any leaf route is clicked, with full route info. */
  onNavigate?: (item: NavItemPayload) => void;
}

export const Navigation = forwardRef<HTMLDivElement, NavigationProps>((props, ref) => {
  const { items, staticSidebar = false, initialPath, pinByDefault = false, onNavigate } = props;

  const [ search, setSearch ] = useState('');
  const [ isPinned, setIsPinned ] = useState(pinByDefault);
  const [ isHovered, setIsHovered ] = useState(false);
  const [ sections, setSections ] = useState<NavSectionProps[]>([]);
  const [ currentPath, setCurrentPath ] = useState(initialPath || window.location.pathname);
  const [ displayConfig, setDisplayConfig ] = useState(() => buildDisplayConfig(items));
  const [ searchExpandedIds, setSearchExpandedIds ] = useState<Set<string>>(new Set());
  const [ pinnedItems, setPinnedItems ] = useState<NavItemProps[]>([]);

  const sidebarExpanded = staticSidebar || isPinned || isHovered;
  const localRef = useRef<HTMLDivElement | null>(null);

  const setCombinedRef = useCallback(
    (node: HTMLDivElement | null) => {
      localRef.current = node;
      if (typeof ref === "function") {
        ref(node);
      } else if (ref) {
        ref.current = node;
      }
    }, [ref]);

  const visibleSections = useMemo(() => {
    const visibilityFiltered = filterSectionsByVisibility(sections, displayConfig);
    const searchResult = filterSectionsBySearch(visibilityFiltered, search);
    setSearchExpandedIds(searchResult.expandedIds);
    return searchResult.sections;
  }, [sections, displayConfig, search]);

  const navigationData: NavigationContextProps = {
    staticSidebar,
    currentPath,
    setCurrentPath,
    sidebarExpanded,
    isPinned,
    setIsPinned,
    search,
    setSearch,
    sections,
    setSections,
    displayConfig,
    setDisplayConfig,
    searchExpandedIds,
    setSearchExpandedIds,
    pinnedItems,
    setPinnedItems,
    onNavigate,
  };
  
  useEffect(() => {
    setSections(items);
    setDisplayConfig((prev) => mergeDisplayConfig(prev, items));
  }, [items]);

  useEffect(() => {
    const node = localRef.current;
    if (!node) {
      return;
    }
    const handleEnter = () => setIsHovered(true);
    const handleLeave = () => setIsHovered(false);
    node.addEventListener('mouseenter', handleEnter);
    node.addEventListener('mouseleave', handleLeave);
    return () => {
      node.removeEventListener('mouseenter', handleEnter);
      node.removeEventListener('mouseleave', handleLeave);
    };
  }, []);

  return (
    <NavigationProvider value={navigationData}>
      <Box
        sx={{
          height: '100%',
          width: (staticSidebar || isPinned) ? undefined : '57px',
          zIndex: 20,
          position: 'sticky',
        }}
        component="aside"
        ref={setCombinedRef}
      >
        <Box
          component="nav"
          sx={{
            width: sidebarExpanded ? '250px' : '57px',
            paddingBlock: '12px 8px',
            paddingInline: 1.5,
            overflow: 'hidden',
            transition: 'width 0.25s ease, border-color 0.25s ease',
            display: 'flex',
            flexDirection: 'column',
            height: '100%',
            backgroundColor: 'surface.elevation1',
            borderRight: '1px solid',
            borderColor: 'divider',
          }}
          aria-label="navigation-bar"
        >
          <NavToolbar id="navigation" />
          <NavSections sections={visibleSections} />
          <Divider />
          <NavFooter />
        </Box>
      </Box>
    </NavigationProvider>
  )
});

Navigation.displayName = 'Navigation';