export const getInitials = (name: string) => {
  const words = name.split(' ');

  if (words.length === 1) {
    return words[0][0].toUpperCase();
  }
  return words[0][0].toUpperCase() + words[words.length - 1][0].toUpperCase();
};

/**
 * Curated avatar background + text pairs (≥ 4.5:1 contrast).
 * Explicit text color is required so theme mode does not override initials contrast.
 */
const AVATAR_PALETTE = [
  { bgcolor: '#1565C0', color: '#FFFFFF' },
  { bgcolor: '#2E7D32', color: '#FFFFFF' },
  { bgcolor: '#C62828', color: '#FFFFFF' },
  { bgcolor: '#6A1B9A', color: '#FFFFFF' },
  { bgcolor: '#EF6C00', color: '#FFFFFF' },
  { bgcolor: '#00838F', color: '#FFFFFF' },
  { bgcolor: '#AD1457', color: '#FFFFFF' },
  { bgcolor: '#4527A0', color: '#FFFFFF' },
  { bgcolor: '#283593', color: '#FFFFFF' },
  { bgcolor: '#558B2F', color: '#FFFFFF' },
  { bgcolor: '#4E342E', color: '#FFFFFF' },
  { bgcolor: '#00695C', color: '#FFFFFF' },
] as const;

function hashString(value: string): number {
  let hash = 0;

  for (let i = 0; i < value.length; i += 1) {
    hash = value.charCodeAt(i) + ((hash << 5) - hash);
  }

  return Math.abs(hash);
}

export type AvatarColors = {
  bgcolor: string;
  color: string;
};

/** Deterministic avatar colors with WCAG AA text contrast (≥ 4.5:1), stable in light and dark themes. */
export function getAvatarColors(name: string): AvatarColors {
  const index = hashString(name) % AVATAR_PALETTE.length;
  return AVATAR_PALETTE[index];
}

/** @deprecated Prefer `getAvatarColors(name).bgcolor` — random hash colors may fail contrast. */
export function stringToColor(string: string) {
  return getAvatarColors(string).bgcolor;
}
