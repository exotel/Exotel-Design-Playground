import type { ReactNode } from 'react';

export type FieldPlaceholderKind = 'text' | 'select';

function labelToString(label: ReactNode | undefined): string | undefined {
  if (typeof label !== 'string') {
    return undefined;
  }

  const trimmed = label.trim();
  return trimmed.length > 0 ? trimmed : undefined;
}

/**
 * Placeholders are enabled by default: when `placeholder` is omitted and a string
 * `label` is present, derive a hint from the label. Pass `placeholder=""` to disable.
 */
export function resolveFieldPlaceholder(
  label: ReactNode | undefined,
  placeholder: string | undefined,
  kind: FieldPlaceholderKind = 'text',
): string | undefined {
  if (placeholder !== undefined) {
    return placeholder === '' ? undefined : placeholder;
  }

  const labelText = labelToString(label);
  if (!labelText) {
    return undefined;
  }

  return kind === 'select' ? `Select ${labelText}` : `Enter ${labelText}`;
}
