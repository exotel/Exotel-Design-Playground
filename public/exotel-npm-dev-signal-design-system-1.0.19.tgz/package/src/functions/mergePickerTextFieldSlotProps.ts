import type { ReactNode } from 'react';
import { resolveFieldPlaceholder } from './resolveFieldPlaceholder';

type PickerSize = 'small' | 'medium' | 'large';

export function mergePickerTextFieldSlotProps<
  TSlotProps extends { textField?: object } | undefined,
>(
  label: ReactNode | undefined,
  size: PickerSize,
  placeholder: string | undefined,
  slotProps?: TSlotProps,
): TSlotProps {
  const userTextField = slotProps?.textField as { placeholder?: string } | undefined;
  const resolvedPlaceholder = resolveFieldPlaceholder(
    label,
    placeholder ?? userTextField?.placeholder,
    'select',
  );

  return {
    ...slotProps,
    textField: {
      size,
      ...(slotProps?.textField as object),
      ...(resolvedPlaceholder !== undefined ? { placeholder: resolvedPlaceholder } : {}),
    },
  } as TSlotProps;
}
