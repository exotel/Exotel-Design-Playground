import { Children, isValidElement, type ReactElement, type ReactNode } from 'react';

export function isEmptySelectValue(value: unknown): boolean {
  return value === '' || value === undefined || value === null;
}

export function findMenuItemLabel(children: ReactNode, value: unknown): ReactNode {
  let match: ReactNode = value as ReactNode;

  Children.forEach(children, (child) => {
    if (!isValidElement(child)) {
      return;
    }

    const item = child as ReactElement<{ value?: unknown; children?: ReactNode }>;
    if (Object.is(item.props.value, value)) {
      match = item.props.children;
    }
  });

  return match;
}

export type SelectSlotConfig = {
  displayEmpty?: boolean;
  renderValue?: (value: unknown) => ReactNode;
};

export function mergeSelectPlaceholderSlotProps(
  resolvedPlaceholder: string | undefined,
  children: ReactNode | undefined,
  renderEmptyValue: (placeholder: string) => ReactNode,
  slotProps?: { select?: SelectSlotConfig },
  legacySelectProps?: SelectSlotConfig,
): { select?: SelectSlotConfig } | undefined {
  if (resolvedPlaceholder === undefined) {
    return slotProps;
  }

  const userSelect = slotProps?.select ?? legacySelectProps;
  const userRenderValue = userSelect?.renderValue;

  if (userRenderValue) {
    return {
      ...slotProps,
      select: {
        displayEmpty: userSelect?.displayEmpty ?? true,
        ...userSelect,
      },
    };
  }

  return {
    ...slotProps,
    select: {
      displayEmpty: userSelect?.displayEmpty ?? true,
      ...userSelect,
      renderValue: (selected: unknown) => {
        if (isEmptySelectValue(selected)) {
          return renderEmptyValue(resolvedPlaceholder);
        }

        return findMenuItemLabel(children, selected);
      },
    },
  };
}
