
export const getMicPermission = async () => {
    return window.navigator.permissions.query({ name: 'microphone' }).then((result) => {
        return result.state;
    });
};

export const subscribeToMicPermission = async (callback: (this: PermissionStatus, ev: Event) => any) => {
    if (!window?.navigator?.permissions) {
        return false;
    }

    try {
        const permissionStatus = await window.navigator.permissions.query({ name: 'microphone'})
        permissionStatus.addEventListener('change', callback);

        // Return a function to unsubscribe
        return () => {
            permissionStatus.removeEventListener('change', callback);
        }
    } catch (error) {
        return false;
    }
};

export const requestMicPermission = async () => {
    if (!window?.navigator?.mediaDevices) {
        return false;
    }
    try {
        const stream = await window.navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach(track => track.stop());
        return true;
    } catch (error) {
        return false;
    }
};
