/**
 * @exotel-npm-dev/signal-design-system/lottie
 *
 * Separate entry point that re-exports lottie-react's component, hooks, player,
 * and types. This keeps lottie-react (and lottie-web) out of the main bundle —
 * consumers only pay the cost when they import from this path.
 *
 * Usage:
 *   import {
 *     Lottie,
 *     useLottie,
 *     useLottieInteractivity,
 *     type LottieRefCurrentProps,
 *   } from '@exotel-npm-dev/signal-design-system/lottie';
 */
export { default as Lottie } from 'lottie-react';
export * from 'lottie-react';
