import SvgIcon, { type SvgIconProps } from '@mui/material/SvgIcon';

const OUTLINE_STROKE_WIDTH = {
  small: 1,
  medium: 1.5,
  large: 2,
} as const;

function resolveOutlineStrokeWidth(fontSize: SvgIconProps['fontSize']): number {
  if (fontSize === 'small') {
    return OUTLINE_STROKE_WIDTH.small;
  }
  if (fontSize === 'large') {
    return OUTLINE_STROKE_WIDTH.large;
  }
  return OUTLINE_STROKE_WIDTH.medium;
}

/** Matches MUI `CheckBoxOutlineBlank` outer bounds (18×18 in a 24×24 viewBox). */
const OUTER_MIN = 3;
const OUTER_SIZE = 18;

function outlineRect(strokeWidth: number) {
  return {
    x: OUTER_MIN + strokeWidth / 2,
    y: OUTER_MIN + strokeWidth / 2,
    size: OUTER_SIZE - strokeWidth,
  };
}

/** Unchecked checkbox — thinner stroke, same outer size as MUI (1.5px medium, 1px small). */
export function CheckboxOutlineIcon(props: SvgIconProps) {
  const strokeWidth = resolveOutlineStrokeWidth(props.fontSize);
  const { x, y, size } = outlineRect(strokeWidth);

  return (
    <SvgIcon viewBox="0 0 24 24" {...props}>
      <rect
        x={x}
        y={y}
        width={size}
        height={size}
        rx="2"
        fill="none"
        stroke="currentColor"
        strokeWidth={strokeWidth}
      />
    </SvgIcon>
  );
}
