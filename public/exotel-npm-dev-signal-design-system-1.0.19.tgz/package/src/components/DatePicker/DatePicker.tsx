/**
 * DatePicker Component
 *
 * Exotel-approved date picker component that wraps MUI X DatePicker.
 * Relies on the LocalizationProvider in ExotelThemeProvider.
 */

import { DatePicker as MuiDatePicker, type DatePickerProps as MuiDatePickerProps } from '@mui/x-date-pickers/DatePicker';
import { forwardRef, useMemo } from 'react';
import { mergePickerTextFieldSlotProps } from '../../functions/mergePickerTextFieldSlotProps';
import { FieldWrapper } from '../FieldLabel';

export interface DatePickerProps extends Omit<MuiDatePickerProps, 'ref'> {
  /** The size of the picker input. Matches TextField sizes. */
  size?: 'small' | 'medium' | 'large';
  /**
   * Placeholder text inside the input. Derived from `label` when omitted.
   * Pass an empty string to disable the default placeholder.
   */
  placeholder?: string;
}

export const DatePicker = forwardRef<HTMLDivElement, DatePickerProps>(
  (props, ref) => {
    const { label, size = 'medium', placeholder, slotProps, ...rest } = props;

    const mergedSlotProps = useMemo(
      () => mergePickerTextFieldSlotProps(label, size, placeholder, slotProps),
      [label, size, placeholder, slotProps],
    );

    return (
      <FieldWrapper label={label}>
        <MuiDatePicker ref={ref} slotProps={mergedSlotProps} {...rest} />
      </FieldWrapper>
    );
  }
);

DatePicker.displayName = 'DatePicker';
