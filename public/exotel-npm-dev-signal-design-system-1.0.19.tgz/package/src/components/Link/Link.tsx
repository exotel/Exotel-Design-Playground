/**
 * Link Component
 * 
 * Exotel-approved link component that wraps MUI's Link.
 */

import MuiLink, { type LinkProps as MuiLinkProps } from '@mui/material/Link';
import { forwardRef } from 'react';

export interface LinkProps extends Omit<MuiLinkProps, 'ref'> {
  children?: React.ReactNode;
}

export const Link = forwardRef<HTMLAnchorElement, LinkProps>(
  (props, ref) => <MuiLink ref={ref} {...props} />
);

Link.displayName = 'Link';
