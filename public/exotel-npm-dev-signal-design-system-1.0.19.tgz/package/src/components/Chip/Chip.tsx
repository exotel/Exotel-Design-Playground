/**
 * Chip Component
 *
 * Exotel-approved chip component that wraps MUI's Chip.
 * Supports a custom `tonal` variant (Signal Design System): light mode uses solid
 * palette tokens; dark mode uses alpha-tinted backgrounds with lighter ramp text —
 * aligned with Badge `tonal`.
 */

import MuiChip, { type ChipProps as MuiChipProps } from '@mui/material/Chip';
import { type SxProps, type Theme } from '@mui/material/styles';
import { forwardRef } from 'react';
import { createTonalSurfaceStyles, resolveTonalColor } from '../../theme/tonal';
import { Icon } from '../Icon';

function tonalChipSx(theme: Theme, chipColor: MuiChipProps['color']): object {
  const tokens = resolveTonalColor(theme, chipColor);
  const surface = createTonalSurfaceStyles(tokens, theme.palette.text.disabled);

  return {
    ...surface,
    '& .MuiChip-icon': { color: tokens.text },
    '& .MuiChip-deleteIcon': { color: tokens.text },
  };
}

function mergeChipSx(
  tonal: boolean,
  chipColor: MuiChipProps['color'],
  userSx: SxProps<Theme> | undefined,
): SxProps<Theme> | undefined {
  if (!tonal && userSx === undefined) {
    return undefined;
  }
  const sxFn = (theme: Theme) => {
    const tonalStyles = tonal ? tonalChipSx(theme, chipColor) : {};
    const resolved = typeof userSx === 'function' ? userSx(theme) : userSx;
    if (Array.isArray(resolved)) {
      return [tonalStyles, ...resolved] as SxProps<Theme>;
    }
    return { ...tonalStyles, ...resolved };
  };
  return sxFn as SxProps<Theme>;
}

export interface ChipProps extends Omit<MuiChipProps, 'ref' | 'variant'> {
  label?: React.ReactNode;
  /** Includes `tonal` (Signal DS); also augmented on `@mui/material/Chip`. */
  variant?: MuiChipProps['variant'] | 'tonal';
}

export const Chip = forwardRef<HTMLDivElement, ChipProps>(
  ({ variant = 'filled', color = 'default', sx, ...props }, ref) => {
    const tonal = variant === 'tonal';
    const muiVariant: MuiChipProps['variant'] = tonal ? 'filled' : variant;

    return (
      <MuiChip
        {...props}
        ref={ref}
        variant={muiVariant}
        color={tonal ? 'default' : color}
        {...(tonal ? { 'data-variant': 'tonal' as const } : {})}
        deleteIcon={<Icon name="x" size="xs" weight="bold" />}
        sx={mergeChipSx(tonal, color, sx)}
      />
    );
  },
);

Chip.displayName = 'Chip';
