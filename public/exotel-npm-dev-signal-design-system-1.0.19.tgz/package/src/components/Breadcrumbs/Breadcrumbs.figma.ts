// url=https://www.figma.com/design/CiTSqZD3DKtMu91owRSkZW/Signal-Design-System?node-id=6572-50436
// source=src/components/Breadcrumbs/Breadcrumbs.tsx
// component=Breadcrumbs
import figma from 'figma';

const instance = figma.selectedInstance;

const separatorKind = instance.getEnum('Separator', {
  'Text*': 'text',
  Icon: 'icon',
});

const collapsed = instance.getEnum('Collapsed', {
  False: false,
  True: true,
});

const showLeadIcon = instance.getBoolean('Icon');

const sepSwap = separatorKind === 'icon' ? instance.getInstanceSwap('Separator Icon') : null;
let sepSnippet;
if (sepSwap && sepSwap.type === 'INSTANCE' && sepSwap.hasCodeConnect()) {
  sepSnippet = sepSwap.executeTemplate().example;
}

const leadIconInstance = showLeadIcon ? instance.findInstance('<Icon>') : null;
let leadSnippet;
if (leadIconInstance && leadIconInstance.type === 'INSTANCE' && leadIconInstance.hasCodeConnect()) {
  leadSnippet = leadIconInstance.executeTemplate().example;
}

export default {
  example: figma.code`
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
      ${leadSnippet ? figma.code`${leadSnippet}` : ''}
      <Breadcrumbs
        ${separatorKind === 'text' ? figma.code`separator="/"` : sepSnippet ? figma.code`separator={${sepSnippet}}` : figma.code`separator={<Icon name="caret-right" size="sm" />}`}
        ${collapsed ? figma.code`maxItems={3} itemsBeforeCollapse={1} itemsAfterCollapse={1}` : ''}
      >
        <Link underline="hover" color="inherit" href="/">
          Level 1
        </Link>
        <Link underline="hover" color="inherit" href="/">
          Level 2
        </Link>
        <Typography color="text.primary">Level 3</Typography>
      </Breadcrumbs>
    </Box>
  `,
  imports: [
    'import { Breadcrumbs, Link, Typography, Box, Icon } from "@exotel-npm-dev/signal-design-system"',
  ],
  id: 'breadcrumbs',
  metadata: {
    nestable: true,
  },
};
