import { useState } from "react";
import MuiDrawer from "@mui/material/Drawer";
import { Navigation } from "../../Navigation/components/Navigation"
import type { NavigationProps } from "../../Navigation/components/Navigation"
import { IconButton } from "../../IconButton";
import { Icon } from "../../Icon";

/** Matches expanded Navigation width (UX Constitution). */
const NAV_DRAWER_WIDTH = 250;

export interface NavigationDrawerProps {
    items: NavigationProps['items'];
}

export const NavigationDrawer = (props: NavigationDrawerProps) => {
    const { items } = props;

    const [ isOpen, setIsOpen ] = useState(false);

    return (
        <>
            <IconButton onClick={() => setIsOpen(true)}>
                <Icon name='list' size='sm' />
            </IconButton>
            <MuiDrawer
                open={isOpen}
                onClose={() => setIsOpen(false)}
                slotProps={{
                    paper: {
                        sx: {
                            width: NAV_DRAWER_WIDTH,
                            maxWidth: NAV_DRAWER_WIDTH,
                        },
                    },
                }}
            >
                <Navigation staticSidebar={true} items={items} />
            </MuiDrawer>
        </>
    )
};
