import MuiMenuItem from '@mui/material/MenuItem';
import MuiToggleButton from '@mui/material/ToggleButton';
import MuiToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import { forwardRef, useCallback, useState, type MouseEvent } from 'react';
import { Box } from '../Box';
import type { ButtonProps } from '../Button';
import { Button } from '../Button';
import { TextField } from '../TextField';
import { Icon, type IconName } from '../Icon';
import { IconButton } from '../IconButton';
import { ListItemIcon, ListItemText } from '../List';
import { Menu } from '../Menu';
import { Typography } from '../Typography';

export interface ToggleButtonOption {
  value: string;
  iconName: IconName;
  ariaLabel?: string;
}

export interface PageHeaderToggleGroupConfig {
  options: ToggleButtonOption[];
  value: string;
  onChange: (value: string) => void;
  exclusive?: boolean;
  size?: 'small' | 'medium' | 'large';
}

export interface PageHeaderProps {
  title?: string;
  subtitle?: string;
  actions?: ButtonProps[];
  maxVisibleActions?: number;
  showSearch?: boolean;
  searchType?: 'basic' | 'advanced';
  onBasicSearch?: (search: string) => void;
  toggleButtonGroup?: PageHeaderToggleGroupConfig;
}

export const PageHeader = forwardRef<HTMLDivElement, PageHeaderProps>((props, ref) => {
  const {
    title,
    subtitle,
    actions,
    maxVisibleActions = 2,
    showSearch,
    searchType,
    onBasicSearch,
    toggleButtonGroup,
  } = props;
  const [menuAnchor, setMenuAnchor] = useState<HTMLElement | null>(null);
  const menuOpen = Boolean(menuAnchor);

  const handleOpenMenu = useCallback((event: MouseEvent<HTMLButtonElement>) => {
    setMenuAnchor(event.currentTarget);
  }, []);

  const handleCloseMenu = useCallback(() => {
    setMenuAnchor(null);
  }, []);

  const list = actions ?? [];
  const effectiveLimit = Math.max(0, maxVisibleActions);
  const visibleActions = list.slice(0, effectiveLimit);
  const overflowActions = list.slice(effectiveLimit);

  return (
    <Box
      component="div"
      bgcolor="surface.elevation1"
      ref={ref}
      p={(theme) => theme.spacing(1.5, 2)}
      display="flex"
      flexWrap="wrap"
      alignItems="center"
      gap={1.5}
    >
      <Box display="flex" flexDirection="column" gap={0.5} flex="1 1 200px">
        {title && <Typography variant="title3">{title}</Typography>}
        {subtitle && <Typography variant="body2">{subtitle}</Typography>}
      </Box>

      <Box
        display="flex"
        flexWrap="wrap"
        alignItems="center"
        gap={1.5}
      >
        <Box display="flex" alignItems="center" gap={1.5}>
          {showSearch && searchType === 'basic' && (
            <TextField
              id="search"
              placeholder="Search"
              size="medium"
              onChange={(e) => onBasicSearch?.(e.target.value)}
              slotProps={{
                input: {
                  startAdornment: <Icon name="magnifying-glass" size="sm" />,
                },
              }}
            />
          )}
          {overflowActions.length > 0 && (
            <>
              <IconButton
                size="medium"
                aria-label="More actions"
                aria-haspopup="true"
                aria-expanded={menuOpen ? 'true' : undefined}
                onClick={handleOpenMenu}
                variant="outlined"
              >
                <Icon name="dots-three-vertical" size="sm" />
              </IconButton>
              <Menu
                anchorEl={menuAnchor}
                open={menuOpen}
                onClose={handleCloseMenu}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                transformOrigin={{ vertical: 'top', horizontal: 'right' }}
                slotProps={{
                  paper: {
                    sx: {
                      minWidth: 200,
                    },
                  },
                }}
              >
                {overflowActions.map((action) => {
                  const { id, onClick, disabled, children, startIconProps } = action;
                  return (
                    <MuiMenuItem
                      key={id ?? String(children)}
                      disabled={disabled}
                      onClick={(e) => {
                        onClick?.(e as unknown as MouseEvent<HTMLButtonElement>);
                        handleCloseMenu();
                      }}
                    >
                      {startIconProps ? (
                        <ListItemIcon minWidth={36}>
                          <Icon {...startIconProps} size="sm" />
                        </ListItemIcon>
                      ) : null}
                      <ListItemText>{children}</ListItemText>
                    </MuiMenuItem>
                  );
                })}
              </Menu>
            </>
          )}
        </Box>
        {toggleButtonGroup && toggleButtonGroup.options.length > 0 && (
          <MuiToggleButtonGroup
            value={toggleButtonGroup.value}
            exclusive={toggleButtonGroup.exclusive ?? true}
            onChange={(_e, newValue) => {
              if (newValue !== null) toggleButtonGroup.onChange(newValue);
            }}
            size={toggleButtonGroup.size ?? 'small'}
          >
            {toggleButtonGroup.options.map((opt) => (
              <MuiToggleButton key={opt.value} value={opt.value} aria-label={opt.ariaLabel ?? opt.value}>
                <Icon name={opt.iconName} size="sm" />
              </MuiToggleButton>
            ))}
          </MuiToggleButtonGroup>
        )}
        {visibleActions.length > 0 && (
          <Box display="flex" alignItems="center" gap={1.5}>
            {visibleActions.map((action) => (
              <Button size="medium" key={action.id} {...action} />
            ))}
          </Box>
        )}
      </Box>
    </Box>
  );
});

PageHeader.displayName = 'PageHeader';
