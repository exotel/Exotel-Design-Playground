import { Box } from '../../components';
import { useColorScheme } from '@mui/material/styles';
import { Typography } from '../Typography';
import DefaultEmptySvg from '../../assets/empty-messages.svg';

interface EmptyOverlayProps {
  message?: string;
  /** Image shown in light mode. Also used for dark mode (with invert filter) when darkImage is not provided. */
  lightImage?: string;
  /** Image shown in dark mode. When omitted, lightImage is used with an invert filter. */
  darkImage?: string;
}

export function EmptyOverlay({
  message = 'No data available',
  lightImage,
  darkImage,
}: EmptyOverlayProps) {
  const { mode } = useColorScheme();
  const isDark = mode === 'dark';

  let src: string;
  let filter: string | undefined;

  if (lightImage && darkImage) {
    src = isDark ? darkImage : lightImage;
  } else if (lightImage) {
    src = lightImage;
    if (isDark) filter = 'invert(1)';
  } else {
    src = DefaultEmptySvg;
    if (isDark) filter = 'invert(1)';
  }

  return (
    <Box
      display="flex"
      flexDirection="column"
      alignItems="center"
      justifyContent="center"
      height="100%"
      gap={1.5}
      sx={{ pointerEvents: 'none' }}
    >
      <img
        src={src}
        alt="Empty"
        width={120}
        height={100}
        style={filter ? { filter } : undefined}
      />
      <Typography variant="body2" color="text.secondary">
        {message}
      </Typography>
    </Box>
  );
}
