import type { AppliedFilter } from '../AppliedFilters';
import type { MultiSelectOption } from '../MultiSelect';
import type { DateRangeValue, FilterRecords, ToolbarFilterConfig } from './types';

function findMultiSelectLabel(options: MultiSelectOption[], val: string): string | null {
  for (const opt of options) {
    if (opt.value === val) return opt.label;
    if (opt.children) {
      const found = findMultiSelectLabel(opt.children, val);
      if (found) return found;
    }
  }
  return null;
}

export function buildAppliedFilters(
  customToolbarFilters: ToolbarFilterConfig[] | undefined,
  filterValues: FilterRecords
): AppliedFilter[] {
  const filters: AppliedFilter[] = [];

  if (!customToolbarFilters) {
    return filters;
  }

  for (const filter of customToolbarFilters) {
    const value = filterValues[filter.id];
    let hasValue = false;
    let displayValue: string | string[] = '';

    if (filter.type === 'multi-select') {
      const values = value as string[] | undefined;
      if (values && values.length > 0) {
        hasValue = true;
        displayValue = values.map((val) => {
          if (filter.multiSelectOptions) {
            return findMultiSelectLabel(filter.multiSelectOptions, val) || val;
          }
          return val;
        });
      }
    } else if (filter.type === 'date-range') {
      const dateRange = value as DateRangeValue | undefined;
      if (dateRange && dateRange.startDate && dateRange.endDate) {
        hasValue = true;
        displayValue = `${dateRange.startDate.format('MMM DD, YYYY')} - ${dateRange.endDate.format('MMM DD, YYYY')}`;
      }
    } else if (filter.type === 'select') {
      const strValue = value as string | undefined;
      if (strValue && strValue !== 'all' && strValue !== '') {
        hasValue = true;
        const option = filter.options?.find((opt) => opt.value === strValue);
        displayValue = option?.label || strValue;
      }
    }

    if (hasValue) {
      filters.push({
        id: filter.id,
        label: filter.label,
        value: displayValue,
      });
    }
  }

  return filters;
}
