/**
 * DataGridPagination
 *
 * Custom pagination footer for the DataGrid. All controls — the rows-per-page
 * selector, the row range, and the Previous/Next buttons — are grouped and
 * aligned to the right, matching the Signal pagination spec.
 *
 * Works for both client-side and server-side pagination by reading state from
 * the grid API rather than the DOM.
 */

import { forwardRef, useCallback, useMemo } from 'react';
import {
  useGridApiContext,
  useGridSelector,
  useGridRootProps,
  gridPaginationModelSelector,
  gridPaginationRowCountSelector,
  gridPageCountSelector,
} from '@mui/x-data-grid-pro';
import { Box, MenuItem } from '../../components';
import { Stack } from '../Stack';
import { Typography } from '../Typography';
import { Button } from '../Button';
import { TextField } from '../TextField';

type PageSizeOption = number | { value: number; label: string };

function normalizeOptions(
  options: readonly PageSizeOption[] = []
): { value: number; label: string }[] {
  return options
    .map((option) =>
      typeof option === 'number' ? { value: option, label: `${option}` } : option
    )
    .filter((option) => Number.isFinite(option.value));
}

export const DataGridPagination = forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>((props, ref) => {
  const apiRef = useGridApiContext();
  const rootProps = useGridRootProps();
  const paginationModel = useGridSelector(apiRef, gridPaginationModelSelector);
  const rowCount = useGridSelector(apiRef, gridPaginationRowCountSelector);
  const pageCount = useGridSelector(apiRef, gridPageCountSelector);

  const { page, pageSize } = paginationModel;

  const pageSizeOptions = useMemo(
    () => normalizeOptions(rootProps.pageSizeOptions as readonly PageSizeOption[]),
    [rootProps.pageSizeOptions]
  );

  const isRowCountKnown = rowCount !== -1;
  const lastPage = Math.max(0, pageCount - 1);

  const firstRow = rowCount === 0 ? 0 : page * pageSize + 1;
  const lastRow = isRowCountKnown
    ? Math.min(rowCount, (page + 1) * pageSize)
    : (page + 1) * pageSize;
  const rangeLabel = isRowCountKnown
    ? `${firstRow}-${lastRow} of ${rowCount}`
    : `${firstRow}-${lastRow}`;

  const handlePageSizeChange = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      apiRef.current.setPageSize(Number(event.target.value));
    },
    [apiRef]
  );

  const handlePrevious = useCallback(() => {
    apiRef.current.setPage(page - 1);
  }, [apiRef, page]);

  const handleNext = useCallback(() => {
    apiRef.current.setPage(page + 1);
  }, [apiRef, page]);

  const isPreviousDisabled = page <= 0;
  const isNextDisabled = isRowCountKnown ? page >= lastPage : false;

  return (
    <Box
      ref={ref}
      {...props}
      sx={{
        display: 'flex',
        flex: 1,
        alignItems: 'center',
        justifyContent: 'flex-end',
        gap: 2,
        px: 1,
        py: 1,
      }}
    >
      {pageSizeOptions.length > 0 && (
        <Stack direction="row" alignItems="center" spacing={0.75}>
          <Typography variant="body2" color="text.secondary" noWrap>
            Results per page:
          </Typography>
          <TextField
            select
            showLabel={false}
            size="small"
            value={pageSize}
            onChange={handlePageSizeChange}
            sx={{
              '& .MuiInputBase-root': { minWidth: 0 },
              '& .MuiSelect-select': { pr: (theme) => `${theme.spacing(2.5)} !important` },
            }}
          >
            {pageSizeOptions.map((option) => (
              <MenuItem key={option.value} value={option.value}>
                {option.label}
              </MenuItem>
            ))}
          </TextField>
        </Stack>
      )}

      <Typography variant="body2" color="text.primary" noWrap>
        {rangeLabel}
      </Typography>

      <Stack direction="row" alignItems="center" spacing={1}>
        <Button
          variant="outlined"
          size="small"
          color="inherit"
          onClick={handlePrevious}
          disabled={isPreviousDisabled}
        >
          Previous
        </Button>
        <Button
          variant="outlined"
          size="small"
          color="inherit"
          onClick={handleNext}
          disabled={isNextDisabled}
        >
          Next
        </Button>
      </Stack>
    </Box>
  );
});

DataGridPagination.displayName = 'DataGridPagination';
