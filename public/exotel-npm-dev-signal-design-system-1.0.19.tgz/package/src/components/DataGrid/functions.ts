import type { FilterRecords, ToolbarFilterConfig } from './types';

export const getInitialFilterValues = (customFilters?: ToolbarFilterConfig[]) => {
  if (!customFilters) {
    return {};
  }
  return customFilters.reduce((acc, filter) => {
    acc[filter.id] = filter.initialValue;
    return acc;
  }, {} as FilterRecords);
}
