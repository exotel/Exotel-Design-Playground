import { createContext, useContext, type ReactNode } from 'react';

/**
 * Matches viewports strictly below 756px wide. Used for DataGrid toolbar: bottom drawers
 * vs anchored dropdowns/popovers.
 */
export const DATA_GRID_COMPACT_TOOLBAR_MEDIA = '(max-width:755px)';

const DataGridCompactToolbarContext = createContext(false);

export function DataGridCompactToolbarProvider({
  value,
  children,
}: {
  value: boolean;
  children: ReactNode;
}) {
  return (
    <DataGridCompactToolbarContext.Provider value={value}>
      {children}
    </DataGridCompactToolbarContext.Provider>
  );
}

export function useDataGridCompactToolbar() {
  return useContext(DataGridCompactToolbarContext);
}
