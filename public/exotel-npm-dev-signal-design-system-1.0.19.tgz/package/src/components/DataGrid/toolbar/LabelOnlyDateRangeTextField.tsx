import { forwardRef } from 'react';
import { TextField, type TextFieldProps } from '../../TextField';

export type LabelOnlyDateRangeTextFieldProps = TextFieldProps & {
  filterLabel: string;
};

/**
 * DateRangePicker textField slot: always shows the filter category label; the range appears in applied-filters chips only.
 */
export const LabelOnlyDateRangeTextField = forwardRef<HTMLDivElement, LabelOnlyDateRangeTextFieldProps>(
  function LabelOnlyDateRangeTextField({ filterLabel, value: _ignored, ...rest }, ref) {
    return (
      <TextField
        ref={ref}
        {...rest}
        showLabel={false}
        value={filterLabel}
        InputProps={{
          ...rest.InputProps,
          readOnly: true,
        }}
      />
    );
  }
);

LabelOnlyDateRangeTextField.displayName = 'LabelOnlyDateRangeTextField';
