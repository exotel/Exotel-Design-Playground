/**
 * Dialog Component
 * 
 * Exotel-approved dialog component that wraps MUI's Dialog.
 * Supports structured layout with Header/Body/Footer pattern.
 * 
 * Recommended usage with structured layout:
 * ```tsx
 * <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
 *   {showHeader && (
 *     <DialogTitle>
 *       Heading
 *       <IconButton onClick={onClose} />
 *     </DialogTitle>
 *   )}
 *   <DialogContent dividers>
 *     Dialog content goes here
 *   </DialogContent>
 *   {showFooter && (
 *     <DialogActions>
 *       <Button variant="contained">Save and Dial</Button>
 *     </DialogActions>
 *   )}
 * </Dialog>
 * ```
 */

import MuiDialog, { type DialogProps as MuiDialogProps } from '@mui/material/Dialog';
import { forwardRef } from 'react';
import { useMediaQuery, useTheme } from '@mui/material';

export interface DialogProps extends Omit<MuiDialogProps, 'ref'> {
  children?: React.ReactNode;
}

export const Dialog = forwardRef<HTMLDivElement, DialogProps>(
  ({ PaperProps, ...props }, ref) => {
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
    const isTablet = useMediaQuery(theme.breakpoints.between('sm', 'md'));
    
    // Responsive max-height: 90vh for mobile/tablet, 80vh for desktop
    const maxHeight = isMobile || isTablet ? '90vh' : '80vh';

    return (
      <MuiDialog
        ref={ref}
        {...props}
        PaperProps={{
          ...PaperProps,
          sx: {
            maxHeight,
            display: 'flex',
            flexDirection: 'column',
            margin: (theme) => theme.spacing(2),
            ...PaperProps?.sx,
          },
        }}
      />
    );
  }
);

Dialog.displayName = 'Dialog';
