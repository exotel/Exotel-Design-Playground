/**
 * StructuredDialog Component
 * 
 * Exotel-approved structured dialog component with Header/Body/Footer layout.
 * Built on top of MUI Dialog with predictable scrolling behavior.
 */

import MuiDialog, { type DialogProps as MuiDialogProps } from '@mui/material/Dialog';
import { forwardRef, type ReactNode } from 'react';
import { Box, DialogTitle, DialogContent, DialogActions, useMediaQuery } from '../../components';
import { useTheme } from '@mui/material/styles';
import { Typography } from '../Typography';
import { IconButton } from '../IconButton';
import { Icon } from '../Icon';

export interface StructuredDialogProps extends Omit<MuiDialogProps, 'ref' | 'children'> {
  /**
   * Title displayed in the header
   */
  title?: string;
  /**
   * Callback fired when the close button is clicked
   */
  onClose?: (event: React.SyntheticEvent, reason?: 'backdropClick' | 'escapeKeyDown') => void;
  /**
   * Whether to show the header section
   * @default true
   */
  showHeader?: boolean;
  /**
   * Whether to show the footer section
   * @default false
   */
  showFooter?: boolean;
  /**
   * Main content to display in the body section
   */
  children?: ReactNode;
  /**
   * Footer content (actions) to display in the footer section
   */
  footerContent?: ReactNode;
  /**
   * Custom header content (overrides title and default close button)
   */
  headerContent?: ReactNode;
}

/**
 * DialogBody Component
 * 
 * Wrapper for dialog body content. Use this to wrap your dialog content.
 */
export const DialogBody = forwardRef<HTMLDivElement, { children?: ReactNode }>(
  ({ children, ...props }, ref) => {
    return (
      <Box ref={ref} {...props}>
        {children}
      </Box>
    );
  }
);

DialogBody.displayName = 'DialogBody';

/**
 * DialogFooter Component
 * 
 * Wrapper for dialog footer actions. Use this to wrap your footer buttons.
 */
export const DialogFooter = forwardRef<HTMLDivElement, { children?: ReactNode }>(
  ({ children, ...props }, ref) => {
    return (
      <Box ref={ref} {...props}>
        {children}
      </Box>
    );
  }
);

DialogFooter.displayName = 'DialogFooter';

export const StructuredDialog = forwardRef<HTMLDivElement, StructuredDialogProps>(
  (
    {
      title,
      onClose,
      showHeader = true,
      showFooter = false,
      children,
      footerContent,
      headerContent,
      ...dialogProps
    },
    ref
  ) => {
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
    const isTablet = useMediaQuery(theme.breakpoints.between('sm', 'md'));
    
    // Responsive max-height: 90vh for mobile/tablet, 80vh for desktop
    const maxHeight = isMobile || isTablet ? '90vh' : '80vh';

    const handleClose = (event: React.SyntheticEvent, reason?: 'backdropClick' | 'escapeKeyDown') => {
      if (onClose) {
        onClose(event, reason);
      }
    };

    return (
      <MuiDialog
        ref={ref}
        maxWidth="sm"
        fullWidth
        {...dialogProps}
        onClose={handleClose}
        PaperProps={{
          sx: {
            maxHeight,
            display: 'flex',
            flexDirection: 'column',
            margin: (theme) => theme.spacing(2),
          },
        }}
      >
        {/* Header Section */}
        {showHeader && (headerContent || title || onClose) && (
          <>
            <DialogTitle
              sx={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                minHeight: 40,
                padding: (theme) => theme.spacing(1, 2),
                borderBottom: 1,
                borderColor: 'divider',
                backgroundColor: 'action.hover',
                flexShrink: 0,
              }}
            >
              {headerContent || (
                <>
                  {title && (
                    <Typography variant="h6" component="h2">
                      {title}
                    </Typography>
                  )}
                  {onClose && (
                    <IconButton
                      edge="end"
                      onClick={(e) => handleClose(e)}
                      aria-label="close dialog"
                      size="small"
                      sx={{
                        color: 'text.primary',
                        '& svg': {
                          color: 'inherit',
                        },
                      }}
                    >
                      <Icon name="x" size="sm" />
                    </IconButton>
                  )}
                </>
              )}
            </DialogTitle>
          </>
        )}

        {/* Body Section - Scrollable */}
        <DialogContent
          sx={{
            flex: 1,
            overflowY: 'auto',
            padding: (theme) => theme.spacing(3, 2),
            backgroundColor: 'background.paper',
            display: 'flex',
            flexDirection: 'column',
          }}
        >
          {children}
        </DialogContent>

        {/* Footer Section */}
        {(showFooter && footerContent) && (
          <DialogActions
            sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'flex-end',
              gap: (theme) => theme.spacing(1),
              minHeight: 64,
              padding: (theme) => theme.spacing(1, 2),
              borderTop: 1,
              borderColor: 'divider',
              backgroundColor: 'background.paper',
              flexShrink: 0,
            }}
          >
            {footerContent}
          </DialogActions>
        )}
      </MuiDialog>
    );
  }
);

StructuredDialog.displayName = 'StructuredDialog';
