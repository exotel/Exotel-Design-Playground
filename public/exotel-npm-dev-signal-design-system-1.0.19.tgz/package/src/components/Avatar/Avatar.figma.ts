// url=https://www.figma.com/design/CiTSqZD3DKtMu91owRSkZW/Signal-Design-System?node-id=6587-47403
// source=src/components/Avatar/Avatar.tsx
// component=Avatar
import figma from 'figma';

const instance = figma.selectedInstance;

const sizePx = instance.getEnum('Size', {
  '40px': 40,
  '32px': 32,
  '24px': 24,
  '18px': 18,
});

const variant = instance.getEnum('Variant', {
  Circular: 'circular',
  Rounded: 'rounded',
  Square: 'square',
});

const content = instance.getEnum('Content', {
  Text: 'text',
  Icon: 'icon',
  Image: 'image',
});

const initials = instance.getString('Initials');
const showBadge = instance.getBoolean('Badge');

const iconChild = content === 'icon' ? instance.findInstance('<Icon>') : null;
let iconSnippet;
if (iconChild && iconChild.type === 'INSTANCE' && iconChild.hasCodeConnect()) {
  iconSnippet = iconChild.executeTemplate().example;
}

const avatarEl =
  content === 'image'
    ? figma.code`
    <Avatar
      variant="${variant}"
      sx={{ width: ${sizePx}, height: ${sizePx} }}
      src="https://mui.com/static/images/avatar/1.jpg"
      alt="Avatar"
    />
  `
    : figma.code`
    <Avatar variant="${variant}" sx={{ width: ${sizePx}, height: ${sizePx} }}>
      ${content === 'text' ? initials : iconSnippet ? figma.code`${iconSnippet}` : ''}
    </Avatar>
  `;

export default {
  example: showBadge
    ? figma.code`
    <Badge
      overlap="circular"
      anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      variant="dot"
    >
      ${figma.code`${avatarEl}`}
    </Badge>
  `
    : avatarEl,
  imports: ['import { Avatar, Badge } from "@exotel-npm-dev/signal-design-system"'],
  id: 'avatar',
  metadata: {
    nestable: true,
  },
};
