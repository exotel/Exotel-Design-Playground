/**
 * Avatar Component
 * 
 * Exotel-approved avatar component that wraps MUI's Avatar.
 */

import MuiAvatar, { type AvatarProps as MuiAvatarProps } from '@mui/material/Avatar';
import { forwardRef } from 'react';

export interface AvatarProps extends Omit<MuiAvatarProps, 'ref'> {
  children?: React.ReactNode;
}

export const Avatar = forwardRef<HTMLDivElement, AvatarProps>(
  (props, ref) => <MuiAvatar ref={ref} {...props} />
);

Avatar.displayName = 'Avatar';
