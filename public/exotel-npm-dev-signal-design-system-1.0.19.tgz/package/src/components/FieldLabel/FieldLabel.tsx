/**
 * FieldWrapper Component
 *
 * Shared wrapper that renders an external label above any field component.
 * Used by TextField, Autocomplete, and all date/time pickers.
 */

import { Stack, Typography } from '../../components';

export interface FieldWrapperProps {
  /** The label content. When falsy the label row is omitted. */
  label?: React.ReactNode;
  /** Associates the label with an input via its id. */
  htmlFor?: string;
  /** If true, a red asterisk is appended to the label. @default false */
  required?: boolean;
  /** The field component(s) rendered below the label. */
  children: React.ReactNode;
}

export function FieldWrapper({ label, htmlFor, required = false, children }: FieldWrapperProps) {
  return (
    <Stack spacing={0.5}>
      {label && (
        <Typography color="text.secondary" component="label" htmlFor={htmlFor} variant="label1">
          {label}
          {required && (
            <Typography component="span" color="error" variant="body2" aria-hidden>
              {' *'}
            </Typography>
          )}
        </Typography>
      )}
      {children}
    </Stack>
  );
}
