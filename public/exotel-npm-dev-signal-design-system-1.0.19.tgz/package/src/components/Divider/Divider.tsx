/**
 * Divider Component
 * 
 * Exotel-approved divider component that wraps MUI's Divider.
 */

import MuiDivider, { type DividerProps as MuiDividerProps } from '@mui/material/Divider';
import { forwardRef } from 'react';

export interface DividerProps extends Omit<MuiDividerProps, 'ref'> {
  children?: React.ReactNode;
}

export const Divider = forwardRef<HTMLHRElement, DividerProps>(
  (props, ref) => <MuiDivider ref={ref} {...props} />
);

Divider.displayName = 'Divider';
