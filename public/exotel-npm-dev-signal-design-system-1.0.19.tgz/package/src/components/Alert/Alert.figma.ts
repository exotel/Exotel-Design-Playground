// url=https://www.figma.com/design/CiTSqZD3DKtMu91owRSkZW/Signal-Design-System?node-id=6595-48211
// source=src/components/Alert/Alert.tsx
// component=Alert
import figma from 'figma';

const instance = figma.selectedInstance;

const severity = instance.getEnum('Severity', {
  Error: 'error',
  Warning: 'warning',
  Info: 'info',
  Success: 'success',
});

const variant = instance.getEnum('Variant', {
  Filled: 'filled',
  Outlined: 'outlined',
  Standard: 'standard',
});

const showClose = instance.getBoolean('On Close?');
const showAction = instance.getBoolean('Action?');
const showTitle = instance.getBoolean('Title?');
const showDescription = instance.getBoolean('Description?');

const titleStr = instance.getString('↳ Title');
const descStr = instance.getString('↳ Description');

const actionSwap = showAction ? instance.getInstanceSwap('↳Instance') : null;
let actionSnippet;
if (actionSwap && actionSwap.type === 'INSTANCE' && actionSwap.hasCodeConnect()) {
  actionSnippet = actionSwap.executeTemplate().example;
}

const parts: string[] = [];
if (showTitle && titleStr) parts.push(titleStr);
if (showDescription && descStr) parts.push(descStr);
const combinedMessage = parts.length > 0 ? parts.join('\n\n') : ' ';

export default {
  example: figma.code`
    <Alert
      severity="${severity}"
      variant="${variant}"
      ${showClose ? 'onClose={() => {}}' : ''}
      ${actionSnippet ? figma.code`action={${actionSnippet}}` : ''}
    >
      ${combinedMessage}
    </Alert>
  `,
  imports: ['import { Alert } from "@exotel-npm-dev/signal-design-system"'],
  id: 'alert',
  metadata: {
    nestable: true,
  },
};
