import { forwardRef } from 'react';
import { Box } from '../../components';
import { AgenticCard } from '../AgenticCard';
import { ChatInputBox } from '../ChatInputBox';
import { MessageComposer } from '../MessageComposer';
import {
  AISuiteDisclaimerView,
  AISuiteEmptyStateView,
  AISuiteSuggestions,
  AssistantTextMessage,
  UserMessageBubble,
} from './AISuiteParts';
import type { AISuiteMessage, AISuiteProps } from './types';

const DEFAULT_CONTENT_MAX_WIDTH = 684;
const DEFAULT_INPUT_MAX_WIDTH = 700;

function renderMessage(message: AISuiteMessage) {
  switch (message.type) {
    case 'user-text':
      return (
        <UserMessageBubble
          key={message.id}
          content={message.content}
          onCopy={message.onCopy}
        />
      );
    case 'assistant-text':
      return (
        <AssistantTextMessage
          key={message.id}
          content={message.content}
          onCopy={message.onCopy}
          feedbackProps={message.feedbackProps}
        />
      );
    case 'agentic-steps':
      return (
        <Box key={message.id} width="100%">
          {message.content}
        </Box>
      );
    case 'agentic-card':
      return (
        <AgenticCard
          key={message.id}
          {...message.card}
          onCopy={message.onCopy}
          feedbackProps={message.feedbackProps}
        />
      );
    case 'message-composer':
      return (
        <Box key={message.id} width="100%">
          <MessageComposer {...message.composer} />
        </Box>
      );
    case 'custom':
      return (
        <Box key={message.id} width="100%">
          {message.content}
        </Box>
      );
    default:
      return null;
  }
}

/**
 * AISuite — agentic chat layout composing messages, steps, cards,
 * clarification prompts, and the bottom ChatInputBox.
 *
 * Container-agnostic: it fills the width and height of whatever wraps it, so it
 * can live in a full page, a left/right panel, or a modal/drawer/popover. Give
 * the wrapper a height (e.g. `100%`, `100dvh`, or a fixed value); the message
 * column stays centered up to `contentMaxWidth` on wide layouts and collapses to
 * full width in narrow ones.
 *
 * ```tsx
 * <AISuite
 *   messages={messages}
 *   chatInput={{ value, onChange, onSend }}
 *   emptyState={{ title: 'Turn business goals into customer journeys' }}
 * />
 * ```
 */
export const AISuite = forwardRef<HTMLDivElement, AISuiteProps>(
  (
    {
      messages = [],
      chatInput,
      emptyState,
      showEmptyState = false,
      suggestions,
      disclaimer,
      contentMaxWidth = DEFAULT_CONTENT_MAX_WIDTH,
      inputMaxWidth = DEFAULT_INPUT_MAX_WIDTH,
      messagesEndRef,
      sx,
    },
    ref,
  ) => {
    const hasMessages = messages.length > 0;
    const showEmpty = !hasMessages || showEmptyState;
    const showMessages = hasMessages && !showEmptyState;
    const isEmptyLayout = showEmpty && !showMessages;
    const showSuggestions = !hasMessages && !showEmptyState && suggestions && suggestions.length > 0;
    const showDisclaimer = disclaimer?.show !== false;

    const inputSection = (
      <Box width="100%" maxWidth={inputMaxWidth} display="flex" flexDirection="column" alignItems="center">
        {chatInput && <ChatInputBox {...chatInput} />}
        {showSuggestions && <AISuiteSuggestions suggestions={suggestions!} />}
        {showDisclaimer && (
          <AISuiteDisclaimerView
            text={disclaimer?.text}
            feedbackLabel={disclaimer?.feedbackLabel}
            onFeedbackClick={disclaimer?.onFeedbackClick}
          />
        )}
      </Box>
    );

    return (
      <Box
        ref={ref}
        display="flex"
        flexDirection="column"
        width="100%"
        height="100%"
        minHeight={0}
        bgcolor="surface.elevation0"
        sx={sx}
      >
        {isEmptyLayout ? (
          <Box
            flex={1}
            minHeight={0}
            overflow="auto"
            display="flex"
            flexDirection="column"
            alignItems="center"
            justifyContent="center"
            px={1}
            py={1.5}
          >
            <Box
              width="100%"
              maxWidth={inputMaxWidth}
              display="flex"
              flexDirection="column"
              alignItems="center"
              gap={3}
            >
              <AISuiteEmptyStateView
                icon={emptyState?.icon}
                title={emptyState?.title}
                subtitle={emptyState?.subtitle}
              />
              {inputSection}
            </Box>
          </Box>
        ) : (
          <>
            <Box
              flex={1}
              minHeight={0}
              overflow="auto"
              display="flex"
              flexDirection="column"
              alignItems="center"
              px={1}
              py={1.5}
            >
              {showEmpty && (
                <Box width="100%" maxWidth={inputMaxWidth} display="flex" flexDirection="column" alignItems="center">
                  <AISuiteEmptyStateView
                    icon={emptyState?.icon}
                    title={emptyState?.title}
                    subtitle={emptyState?.subtitle}
                  />
                </Box>
              )}

              {showMessages && (
                <Box
                  width="100%"
                  maxWidth={contentMaxWidth}
                  display="flex"
                  flexDirection="column"
                  alignItems="center"
                  gap={3}
                  pb={1.5}
                >
                  {messages.map(renderMessage)}
                  <Box ref={messagesEndRef} height={1} width="100%" aria-hidden />
                </Box>
              )}
            </Box>

            <Box
              display="flex"
              flexDirection="column"
              alignItems="center"
              px={1}
              pb={1}
              flexShrink={0}
              bgcolor="surface.elevation0"
            >
              {inputSection}
            </Box>
          </>
        )}
      </Box>
    );
  },
);

AISuite.displayName = 'AISuite';
