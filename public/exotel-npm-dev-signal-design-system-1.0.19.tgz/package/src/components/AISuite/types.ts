import type { ReactNode, RefObject } from 'react';
import type { SxProps, Theme } from '@mui/material/styles';
import type { ChatInputBoxProps } from '../ChatInputBox/ChatInputBox';
import type { AgenticCardProps, FeedbackActionsProps } from '../AgenticCard/types';
import type { MessageComposerProps } from '../MessageComposer/types';

export interface AISuiteEmptyStateProps {
  /** Icon or logo shown above the title */
  icon?: ReactNode;
  /** Primary heading */
  title?: string;
  /** Supporting description */
  subtitle?: string;
}

export interface AISuiteDisclaimerProps {
  /** Whether to show the disclaimer row */
  show?: boolean;
  /** Disclaimer copy */
  text?: string;
  /** Feedback link label */
  feedbackLabel?: string;
  /** Called when the feedback link is clicked */
  onFeedbackClick?: () => void;
}

export interface AISuiteUserTextMessage {
  id: string;
  type: 'user-text';
  content: string;
  onCopy?: () => void;
}

export interface AISuiteAssistantTextMessage {
  id: string;
  type: 'assistant-text';
  content: ReactNode;
  onCopy?: () => void;
  feedbackProps?: Omit<FeedbackActionsProps, 'sx'>;
}

export interface AISuiteAgenticStepsMessage {
  id: string;
  type: 'agentic-steps';
  /** Pre-built AgenticSteps subtree from the parent */
  content: ReactNode;
}

export interface AISuiteAgenticCardMessage {
  id: string;
  type: 'agentic-card';
  card: AgenticCardProps;
  onCopy?: () => void;
  feedbackProps?: Omit<FeedbackActionsProps, 'sx'>;
}

export interface AISuiteMessageComposerMessage {
  id: string;
  type: 'message-composer';
  composer: MessageComposerProps;
}

export interface AISuiteCustomMessage {
  id: string;
  type: 'custom';
  content: ReactNode;
}

export type AISuiteMessage =
  | AISuiteUserTextMessage
  | AISuiteAssistantTextMessage
  | AISuiteAgenticStepsMessage
  | AISuiteAgenticCardMessage
  | AISuiteMessageComposerMessage
  | AISuiteCustomMessage;

export interface AISuiteProps {
  /** Ordered chat messages rendered in the scroll area */
  messages?: AISuiteMessage[];
  /** Props forwarded to the bottom ChatInputBox */
  chatInput?: ChatInputBoxProps;
  /** Empty-state configuration when there are no messages */
  emptyState?: AISuiteEmptyStateProps;
  /** Force empty state even when messages exist */
  showEmptyState?: boolean;
  /** Quick-start suggestions shown below the input when the thread is empty */
  suggestions?: Array<{
    id: string;
    label: string;
    onClick?: () => void;
  }>;
  /** Disclaimer row below the input */
  disclaimer?: AISuiteDisclaimerProps;
  /** Max width of the message column (Figma: 684px) */
  contentMaxWidth?: number;
  /** Max width of the input column (Figma: 700px) */
  inputMaxWidth?: number;
  /** Ref attached to the scroll anchor at the end of the message list */
  messagesEndRef?: RefObject<HTMLDivElement | null>;
  /** Override styles for the root container */
  sx?: SxProps<Theme>;
}
