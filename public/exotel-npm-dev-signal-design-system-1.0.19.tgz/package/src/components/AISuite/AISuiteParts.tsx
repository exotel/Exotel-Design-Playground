import { forwardRef } from 'react';
import { Box, Typography, Icon } from '../../components';
import { MessageActions } from '../AgenticCard/MessageActions';
import type { MessageActionsProps } from '../AgenticCard/types';

export interface UserMessageBubbleProps {
  content: string;
  onCopy?: () => void;
}

/**
 * UserMessageBubble — right-aligned chat bubble for user prompts.
 */
export const UserMessageBubble = forwardRef<HTMLDivElement, UserMessageBubbleProps>(
  ({ content, onCopy }, ref) => (
    <Box
      ref={ref}
      display="flex"
      flexDirection="column"
      alignItems="flex-end"
      width="100%"
    >
      <Box
        display="flex"
        flexDirection="column"
        alignItems="flex-start"
        gap={0.5}
        maxWidth="85%"
      >
        <Box
          bgcolor="tonal.primary.bg"
          borderRadius="12px 2px 12px 12px"
          p={1.5}
          alignSelf="flex-end"
          maxWidth="100%"
        >
          <Typography
            variant="body2"
            color="text.primary"
            sx={{ wordBreak: 'break-word', whiteSpace: 'pre-wrap' }}
          >
            {content}
          </Typography>
        </Box>
        {onCopy && (
          <MessageActions onCopy={onCopy} />
        )}
      </Box>
    </Box>
  ),
);

UserMessageBubble.displayName = 'UserMessageBubble';

export interface AssistantTextMessageProps {
  content: React.ReactNode;
  onCopy?: () => void;
  feedbackProps?: MessageActionsProps['feedbackProps'];
}

/**
 * AssistantTextMessage — left-aligned plain-text agent response with optional feedback actions.
 */
export const AssistantTextMessage = forwardRef<HTMLDivElement, AssistantTextMessageProps>(
  ({ content, onCopy, feedbackProps }, ref) => (
    <Box
      ref={ref}
      display="flex"
      flexDirection="column"
      alignItems="flex-start"
      gap={1.5}
      width="100%"
    >
      <Typography
        variant="body2"
        color="text.primary"
        sx={{
          wordBreak: 'break-word',
          whiteSpace: 'pre-wrap',
          width: '100%',
          '& p': { m: 0, mb: 1, '&:last-of-type': { mb: 0 } },
        }}
      >
        {content}
      </Typography>
      <MessageActions
        onCopy={onCopy}
        feedbackProps={feedbackProps}
      />
    </Box>
  ),
);

AssistantTextMessage.displayName = 'AssistantTextMessage';

export interface AISuiteEmptyStateViewProps {
  icon?: React.ReactNode;
  title?: string;
  subtitle?: string;
}

/**
 * AISuiteEmptyStateView — centered hero shown before the first message.
 */
export const AISuiteEmptyStateView = forwardRef<HTMLDivElement, AISuiteEmptyStateViewProps>(
  (
    {
      icon,
      title = 'Turn business goals into customer journeys',
      subtitle = "Describe your audience, goal, constraints, or campaign idea. I'll design, build, test, and launch it for you.",
    },
    ref,
  ) => (
    <Box
      ref={ref}
      display="flex"
      flexDirection="column"
      alignItems="center"
      textAlign="center"
      gap={2}
      px={2}
      width="100%"
    >
      {icon ?? (
        <Box
          display="flex"
          alignItems="center"
          justifyContent="center"
          width={48}
          height={48}
          borderRadius="50%"
          bgcolor="tonal.primary.bg"
          color="primary.main"
        >
          <Icon name="sparkle" size="lg" />
        </Box>
      )}
      <Box display="flex" flexDirection="column" gap={1.5} maxWidth={536}>
        <Typography variant="title3" color="text.primary">
          {title}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          {subtitle}
        </Typography>
      </Box>
    </Box>
  ),
);

AISuiteEmptyStateView.displayName = 'AISuiteEmptyStateView';

export interface AISuiteSuggestionsProps {
  suggestions: Array<{ id: string; label: string; onClick?: () => void }>;
}

/**
 * AISuiteSuggestions — quick-start chips below the input on an empty thread.
 */
export const AISuiteSuggestions = forwardRef<HTMLDivElement, AISuiteSuggestionsProps>(
  ({ suggestions }, ref) => (
    <Box
      ref={ref}
      display="flex"
      flexWrap="wrap"
      justifyContent="center"
      gap={1}
      pt={1.5}
    >
      {suggestions.map((suggestion) => (
        <Box
          key={suggestion.id}
          component="button"
          type="button"
          onClick={suggestion.onClick}
          sx={{
            appearance: 'none',
            border: 1,
            borderColor: 'divider',
            borderRadius: '16px',
            bgcolor: 'background.paper',
            color: 'text.primary',
            cursor: 'pointer',
            font: 'inherit',
            fontSize: '0.8125rem',
            lineHeight: 1.5,
            px: 1.5,
            py: 0.75,
            '&:hover': {
              bgcolor: 'action.hover',
            },
          }}
        >
          {suggestion.label}
        </Box>
      ))}
    </Box>
  ),
);

AISuiteSuggestions.displayName = 'AISuiteSuggestions';

export interface AISuiteDisclaimerViewProps {
  text?: string;
  feedbackLabel?: string;
  onFeedbackClick?: () => void;
}

/**
 * AISuiteDisclaimerView — "AI can make mistakes" row below the input.
 */
export const AISuiteDisclaimerView = forwardRef<HTMLDivElement, AISuiteDisclaimerViewProps>(
  (
    {
      text = 'AI can make mistakes, so double check it',
      feedbackLabel = 'Send Feedback',
      onFeedbackClick,
    },
    ref,
  ) => (
    <Box
      ref={ref}
      display="flex"
      alignItems="center"
      justifyContent="center"
      gap={2.5}
      py={1}
    >
      <Typography variant="caption" color="text.secondary">
        {text}
      </Typography>
      {onFeedbackClick && (
        <Typography
          component="button"
          type="button"
          variant="caption"
          color="primary.main"
          onClick={onFeedbackClick}
          sx={{
            appearance: 'none',
            background: 'none',
            border: 0,
            cursor: 'pointer',
            font: 'inherit',
            p: 0,
            textDecoration: 'underline',
          }}
        >
          {feedbackLabel}
        </Typography>
      )}
    </Box>
  ),
);

AISuiteDisclaimerView.displayName = 'AISuiteDisclaimerView';
