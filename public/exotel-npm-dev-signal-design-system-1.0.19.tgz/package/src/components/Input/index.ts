/**
 * Input Component (deprecated)
 *
 * @deprecated Use `TextField` from `../TextField` instead.
 * Kept for backward compatibility — re-exports the deprecated wrapper.
 */

export { Input } from './Input';
export type { InputProps } from './Input';
