/**
 * Input Component (deprecated)
 *
 * @deprecated Use `TextField` instead. `Input` is kept for backward
 * compatibility as a thin MUI `Input` wrapper.
 *
 * Usage (prefer TextField):
 * ```tsx
 * import { TextField } from '@exotel-npm-dev/signal-design-system';
 *
 * <TextField label="Email" />
 * ```
 */

import MuiInput, { type InputProps as MuiInputProps } from '@mui/material/Input';
import { forwardRef } from 'react';

/**
 * @deprecated Use `TextFieldProps` instead.
 */
export interface InputProps extends Omit<MuiInputProps, 'ref'> {
  value?: string | number;
}

/**
 * @deprecated Use `TextField` instead.
 */
export const Input = forwardRef<HTMLInputElement, InputProps>(
  (props, ref) => <MuiInput ref={ref} {...props} />
);

Input.displayName = 'Input';
