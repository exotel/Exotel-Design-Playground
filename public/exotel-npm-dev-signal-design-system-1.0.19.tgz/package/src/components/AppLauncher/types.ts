import type { IconName } from '../Icon';

export type LayoutMode = 'default' | 'sectioned';

/** Product shape owned by host/backend. Component renders as-is. */
export interface Product {
  id: string;
  name: string;
  icon: React.ReactNode;
  section: string;
  isTrial?: boolean;
  iconBgColor?: string;
  order?: number;
  onProductClick: () => void;
}

export interface AppLauncherProps {
  /** Layout: flat list (default) or sectioned with subheaders. */
  type: LayoutMode;
  /** Product list from host. Order/section/icon/trial fully owned by host. */
  products: Product[];
  /** Emitted when a product row is activated. Host owns click behavior (e.g. navigation). */
  /** Icon name for the launcher trigger button. Passed from parent. */
  iconName?: IconName;
}
