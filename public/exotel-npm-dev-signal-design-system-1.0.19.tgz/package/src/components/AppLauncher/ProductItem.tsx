import { Box, Chip, Typography } from '../../components';
import { useTheme } from '@mui/material/styles';
import type { Product } from './types';

const TRIAL_CHIP_LABEL = 'TRIAL';

export interface ProductItemProps {
  product: Product;
  onClick: (product: Product) => void;
}

/**
 * Pure presentational row for one product. Renders icon, name, optional trial chip.
 * Accessibility: role="button", tabIndex=0, Enter/Space activate.
 */
export function ProductItem({ product, onClick }: ProductItemProps): React.ReactElement {
  const theme = useTheme();
  const iconBgColor = product.iconBgColor ?? theme.palette.action.selected;

  const handleClick = (): void => {
    onClick(product);
  };

  const handleKeyDown = (event: React.KeyboardEvent): void => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      onClick(product);
    }
  };

  return (
    <Box
      role="button"
      tabIndex={0}
      onClick={handleClick}
      onKeyDown={handleKeyDown}
      aria-label={product.name}
      display="flex"
      alignItems="center"
      width="100%"
      gap={1}
      px={1}
      py={0.5}
      borderRadius={1}
      sx={{
        cursor: 'pointer',
        '&:hover': {
          backgroundColor: theme.palette.action.hover,
        },
        '&:focus-visible': {
          outline: `2px solid ${theme.palette.primary.main}`,
          outlineOffset: 2,
        },
      }}
    >
      <Box
        display="flex"
        alignItems="center"
        justifyContent="center"
        width={36}
        height={36}
        borderRadius={1}
        bgcolor={iconBgColor}
        color={theme.palette.text.primary}
        flexShrink={0}
        sx={{
          ...theme.applyStyles('dark', {
            color: theme.palette.common.white,
          }),
        }}
      >
        {product.icon}
      </Box>
      <Typography variant="body3" flex={1} minWidth={0}>
        {product.name}
      </Typography>
      {product.isTrial === true && (
        <Chip
          label={TRIAL_CHIP_LABEL}
          size="small"
          sx={{
            flexShrink: 0,
            backgroundColor: theme.palette.appLauncher?.trialChip?.bg,
            color: theme.palette.appLauncher?.trialChip?.text,
            fontWeight: 600,
            '& .MuiChip-label': { color: theme?.palette?.appLauncher?.trialChip?.text },
          }}
        />
      )}
    </Box>
  );
}
