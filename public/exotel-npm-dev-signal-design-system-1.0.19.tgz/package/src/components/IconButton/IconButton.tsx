/**
 * IconButton Component
 *
 * Exotel-approved icon button component that wraps MUI's IconButton.
 * Supports shape (circle, square) and variant (text, outlined, contained) props.
 */

import MuiIconButton, { type IconButtonProps as MuiIconButtonProps } from '@mui/material/IconButton';
import { forwardRef } from 'react';

export type IconButtonShape = 'circle' | 'square';
export type IconButtonVariant = 'text' | 'outlined' | 'contained';

export interface IconButtonProps extends Omit<MuiIconButtonProps, 'ref'> {
  children?: React.ReactNode;
  /**
   * The shape of the icon button.
   * @default 'square'
   */
  shape?: IconButtonShape;
  /**
   * The visual style variant of the icon button.
   * @default 'text'
   */
  variant?: IconButtonVariant;
}

export const IconButton = forwardRef<HTMLButtonElement, IconButtonProps>(
  ({ shape = 'square', variant = 'text', ...props }, ref) => (
    <MuiIconButton
      ref={ref}
      data-shape={shape}
      data-variant={variant}
      {...props}
    />
  )
);

IconButton.displayName = 'IconButton';
