import { Box } from "../../Box";
import { NavCustomise } from "./NavCustomise";


export const NavFooter = () => {

    return (
        <Box component="footer" pt={1}>
            <NavCustomise />
        </Box>
    )
};
