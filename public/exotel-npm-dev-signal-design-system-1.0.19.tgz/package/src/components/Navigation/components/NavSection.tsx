import { Box } from "../../Box";
import { Divider } from "../../Divider";
import { List, ListSubheader } from "../../List";
import { useNavigationContext } from "../navigationContext";
import { NavItem, type NavItemProps } from "./NavItem";

export interface NavSectionProps {
    label?: string;
    items: Omit<NavItemProps, 'level'>[];
    level?: number;
}

export const NavSection = ({
    level = 1,
    label,
    items,
}: NavSectionProps) => {
    const { sidebarExpanded } = useNavigationContext();

    if (level > 3) throw new Error('NavSection level cannot be greater than 3');

    const showSubheader = Boolean(label) && sidebarExpanded;

    return (
        <List
            sx={{
                marginLeft: (theme) => theme.spacing(level - 1),
                padding: 0,
                display: 'flex',
                flexDirection: 'column',
                gap: 0.5,
            }}
            component="section"
            subheader={
                <>
                    <Box
                        sx={{
                            height: 8,
                            display: 'flex',
                            alignItems: 'center',
                            alignSelf: 'stretch',
                            'section:first-of-type > &': {
                                display: 'none',
                            },
                        }}
                    >
                        <Divider sx={{ width: '100%' }} />
                    </Box>
                    {showSubheader && (
                        <ListSubheader
                            disableSticky
                            sx={{
                                height: 20,
                                minHeight: 20,
                                fontSize: 11,
                                fontWeight: 500,
                                lineHeight: '15px',
                                color: 'grey.700',
                                textTransform: 'uppercase',
                                margin: 0,
                                padding: 0,
                                display: 'flex',
                                alignItems: 'center',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                whiteSpace: 'nowrap',
                                backgroundColor: 'transparent',
                            }}
                        >
                            {label}
                        </ListSubheader>
                    )}
                </>
            }
        >
            {items.map((item) => (
                <NavItem level={level} key={item.id} {...item} />
            ))}
        </List>
    )
};
