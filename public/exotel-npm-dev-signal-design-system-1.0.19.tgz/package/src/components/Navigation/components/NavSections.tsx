import { Box } from "../../Box";
import { NavSection, type NavSectionProps } from "./NavSection";

export interface NavSectionsProps {
    sections: NavSectionProps[];
}

export const NavSections = ({
    sections,
}: NavSectionsProps) => {
    return (
        <Box
            flex={1}
            overflow="auto"
            mt={1}
            sx={{
                display: 'flex',
                flexDirection: 'column',
                gap: '4px',
            }}
        >
            {sections.filter((section) => section.items?.length).map((section, index) => (
                <NavSection key={`${section.label ?? 'section'}-${index}`} {...section} level={1} />
            ))}
        </Box>
    )
}
