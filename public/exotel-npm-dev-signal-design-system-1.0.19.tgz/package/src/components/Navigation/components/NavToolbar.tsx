import { InputAdornment } from "@mui/material";
import { TextField } from "../../TextField"
import { Icon } from "../../Icon";
import { IconButton } from "../../IconButton";
import { useNavigationContext } from "../navigationContext";
import { Box } from "../../Box";

interface NavToolbarProps {
    id: string;
}

export const NavToolbar = ({
    id
}: NavToolbarProps) => {
    const { search, setSearch, isPinned, setIsPinned, sidebarExpanded, staticSidebar } = useNavigationContext();

    return (
        <Box component="div" display="flex" alignItems="center" gap={0.5}>
            {!sidebarExpanded ? (
                <Box ml={0.75} height={32} display="flex" alignItems="center" justifyContent="center">
                    <Icon size="sm" name="magnifying-glass" color="grey" />
                </Box>
            ) : (
                <>
                    <TextField
                        id={`${id}-nav-toolbar-search`}
                        value={search}
                        size="small"
                        placeholder="Search"
                        sx={{
                            '& .MuiInputBase-root': {
                                paddingLeft: t => `${t.spacing(0.75)} !important`,
                            }
                        }}
                        onChange={(e) => setSearch?.(e.target.value)}
                        slotProps={{
                            input: {
                                startAdornment: (
                                <InputAdornment position="start" sx={{ marginRight: 'unset'}}>
                                    <Icon size="sm" name="magnifying-glass" color="grey" />
                                </InputAdornment>
                                ),
                            },
                        }}
                    />
                    {!staticSidebar && (
                        <IconButton
                            onClick={() => setIsPinned?.(!isPinned)}
                            size="small"
                        >
                            <Icon name={isPinned ? 'push-pin-slash' : 'push-pin'} size="sm" color="grey" />
                        </IconButton>
                    )}
                </>
            )}
        </Box>
    )
}
