import { useState, useEffect } from "react";
import { useNavigationContext } from "../navigationContext";
import { checkActiveChild } from "../utils";
import { ListItemButton, ListItemIcon, ListItemText } from "../../List";
import { Icon, type IconName } from "../../Icon";
import { Collapse } from "@mui/material";
import { NavSection } from "./NavSection";
import { IconButton } from "../../IconButton";

/** Payload passed to the `onNavigate` callback with full route context. */
export interface NavItemPayload {
    id: string;
    label: string;
    path?: string;
    iconName?: IconName;
    openNewPage: boolean;
    level: number;
}

export interface NavItemProps {
    id: string;
    iconName?: IconName;
    label: string;
    path?: string;
    openNewPage?: boolean;
    onClick?: () => void;
    children?: Omit<NavItemProps, 'level'>[];
    level: number;
    showPin?: boolean;
    pinnedItem?: boolean;
}

export const NavItem = ({
    id,
    level,
    iconName,
    label,
    path,
    openNewPage = false,
    onClick,
    children,
    showPin = false,
    pinnedItem = false,
}: NavItemProps) => {
    const [isHovered, setIsHovered] = useState(false);

    if (level > 3) throw new Error('NavItem level cannot be greater than 3');

    const { currentPath, setCurrentPath, sidebarExpanded, search, searchExpandedIds, setPinnedItems, pinnedItems, onNavigate } = useNavigationContext();
    const hasChildren = Boolean(children?.length);
    const isActive = path === currentPath;
    const hasActiveChild = checkActiveChild(children || [], currentPath);
    
    // Determine if this item should be expanded due to search
    const shouldExpandForSearch = Boolean(search) && searchExpandedIds.has(id);
    
    const [ isExpanded, setIsExpanded ] = useState(
        hasChildren && (isActive || hasActiveChild || shouldExpandForSearch)
    );
    const [ userInteracted, setUserInteracted ] = useState(false);
    const isPinned = pinnedItems.some((item) => item.id === id);
    const showPinButton = showPin && (pinnedItem || isHovered);


    // Handle search-based expansion
    useEffect(() => {
        if (hasChildren) {
            const hasSearchQuery = Boolean(search && search.trim());
            if (hasSearchQuery && searchExpandedIds.has(id)) {
                // Expand when this item is in the search path (only if user hasn't manually interacted)
                if (!userInteracted) {
                    setIsExpanded(true);
                }
            } else if (!hasSearchQuery) {
                // When search is cleared, revert to default behavior and reset user interaction flag
                setIsExpanded(isActive || hasActiveChild);
                setUserInteracted(false);
            }
        }
    }, [search, searchExpandedIds, id, hasChildren, isActive, hasActiveChild, userInteracted]);

    const handleClickItem = () => {
        if (hasChildren) {
            setIsExpanded(!isExpanded);
            if (search) {
                setUserInteracted(true);
            }
        } else {
            if (path) setCurrentPath(path);
            onNavigate?.({ id, label, path, iconName, openNewPage, level });
            onClick?.();
        }
    };

    const handlePinClick = (e: React.MouseEvent<HTMLButtonElement>) => {
        e.stopPropagation();
        e.preventDefault();
        if (isPinned) {
            setPinnedItems(pinnedItems.filter((item) => item.id !== id));
        } else {
            setPinnedItems([...pinnedItems, { id, iconName, label, path, openNewPage, level, showPin, pinnedItem: true }]);
        }
    }

    return (
        <>
            <ListItemButton
                dense
                onClick={handleClickItem}
                onMouseEnter={() => setIsHovered(true)}
                onMouseLeave={() => setIsHovered(false)}
                selected={isActive}
                sx={{
                    height: 30,
                    minHeight: 30,
                    marginBlock: 0,
                    paddingBlock: 0.5,
                    paddingInline: 0.75,
                    '& .MuiListItemText-primary': (theme) => ({
                        ...theme.typography.body2,
                    }),
                    '&.Mui-selected .MuiListItemText-primary': (theme) => ({
                        ...theme.typography.label2,
                    }),
                }}
            >
                {iconName && (
                    <ListItemIcon>
                        <Icon name={iconName} size="sm" weight={isActive ? 'bold' : 'regular'} />
                    </ListItemIcon>
                )}
                <ListItemText
                    sx={{
                        opacity: sidebarExpanded ? 1 : 0
                    }}
                    primary={label}
                />
                {!hasChildren && showPinButton && (
                    <IconButton size="small" onClick={handlePinClick}>
                        <Icon name={isPinned ? 'push-pin-slash' : 'push-pin'} size="xs" color="grey" />
                    </IconButton>
                )}
                {openNewPage && (
                    <ListItemIcon sx={{ display: sidebarExpanded ? 'block' : 'none', minWidth: 2.25, marginRight: '4px' }}>
                        <Icon name="arrow-square-out" size="sm" color="grey" />
                    </ListItemIcon>
                )}
                {hasChildren && (
                    <ListItemIcon sx={{ minWidth: 2.25, marginRight: '4px', display: sidebarExpanded ? 'block' : 'none' }}>
                        <Icon size="xs" name={isExpanded ? 'caret-down' : 'caret-right'} weight="fill" />
                    </ListItemIcon>
                )}
            </ListItemButton>
            {children && Boolean(children?.length) && (
                <Collapse in={isExpanded && sidebarExpanded} timeout="auto" unmountOnExit>
                    <NavSection
                        level={level + 1}
                        items={children}
                    />
                </Collapse>
            )}
        </>
    )
}
