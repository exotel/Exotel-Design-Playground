/**
 * CircularProgress Component
 * 
 * Exotel-approved circular progress component that wraps MUI's CircularProgress.
 */

import MuiCircularProgress, { type CircularProgressProps as MuiCircularProgressProps } from '@mui/material/CircularProgress';
import { forwardRef } from 'react';

export interface CircularProgressProps extends Omit<MuiCircularProgressProps, 'ref'> {}

export const CircularProgress = forwardRef<HTMLSpanElement, CircularProgressProps>(
  (props, ref) => <MuiCircularProgress ref={ref} {...props} />
);

CircularProgress.displayName = 'CircularProgress';
