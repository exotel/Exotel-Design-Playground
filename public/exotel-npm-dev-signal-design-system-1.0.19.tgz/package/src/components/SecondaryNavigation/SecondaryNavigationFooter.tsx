import type { ReactNode } from 'react';
import { Box } from '../';

export interface SecondaryNavigationFooterProps {
  footer?: ReactNode;
}

const SecondaryNavigationFooter = ({ footer }: SecondaryNavigationFooterProps) => {
  if (!footer) return null;

  return <Box flexShrink={0} pt={1}>{footer}</Box>;
};

export default SecondaryNavigationFooter;
