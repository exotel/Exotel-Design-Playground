import type { ReactNode } from 'react';
import {
  alpha,
  type Theme,
  Avatar,
  Box,
  Tooltip,
  Typography,
} from '../';
import { getInitials } from '../../functions';

export interface NavigationItem {
  id: string | number;
  label: string;
}

export interface SecondaryNavigationItemsProps {
  items: NavigationItem[];
  selectedId?: string | number | null;
  onItemSelect?: (id: string | number) => void;
  emptyMessage?: string;
  renderItem?: (item: NavigationItem, selected: boolean) => ReactNode;
  collapsed?: boolean;
}

const SecondaryNavigationItems = ({
  items,
  selectedId,
  onItemSelect,
  emptyMessage = 'No items found',
  renderItem,
  collapsed = false,
}: SecondaryNavigationItemsProps) => {
  return (
    <Box display="flex" flexDirection="column" gap={0.5} pr={2}>
      {items.map((item) => {
        const selected = item.id === selectedId;

        if (!collapsed && renderItem) {
          return <Box key={item.id}>{renderItem(item, selected)}</Box>;
        }

        return (
          <Tooltip key={item.id} title={collapsed ? item.label : ''} placement="right">
            <Box
              onClick={() => onItemSelect?.(item.id)}
              sx={{
                display: 'flex',
                alignItems: 'center',
                gap: 1,
                height: 40,
                px: 0.5,
                py: 1,
                borderRadius: '8px',
                cursor: 'pointer',
                overflow: 'hidden',
                ...(selected
                  ? {
                    bgcolor: (theme: Theme) => alpha(theme.palette.primary.main, 0.16),
                    border: 1,
                    borderColor: 'primary.main',
                  }
                  : {
                    border: 1,
                    borderColor: 'transparent',
                    '&:hover': { bgcolor: 'action.hover' },
                  }),
              }}
            >
              <Avatar
                variant="rounded"
                sx={{
                  width: 32,
                  height: 32,
                  flexShrink: 0,
                }}
              >
                {getInitials(item.label)}
              </Avatar>
              <Box
                sx={{
                  overflow: 'hidden',
                  opacity: collapsed ? 0 : 1,
                  width: collapsed ? 0 : 'auto',
                  flex: collapsed ? 'none' : 1,
                  minWidth: 0,
                  transition: 'opacity 0.2s ease',
                }}
              >
                <Typography variant="body2" color="text.primary" noWrap>
                  {item.label}
                </Typography>
              </Box>
            </Box>
          </Tooltip>
        );
      })}
      {items.length === 0 && !collapsed && (
        <Box py={3} textAlign="center">
          <Typography variant="body2" color="text.secondary">
            {emptyMessage}
          </Typography>
        </Box>
      )}
    </Box>
  );
};

export default SecondaryNavigationItems;
