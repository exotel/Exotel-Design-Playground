import {
  Box,
  Button,
  type IconName,
} from '../';

export interface SecondaryNavigationActionsProps {
  actionLabel?: string;
  actionIcon?: IconName;
  actionVariant?: 'outlined' | 'contained' | 'text';
  collapsed?: boolean;
  onActionClick?: () => void;
}

const SecondaryNavigationActions = ({
  actionLabel,
  actionIcon,
  actionVariant = 'outlined',
  onActionClick,
  collapsed = false,
}: SecondaryNavigationActionsProps) => {
  if (!actionLabel) return null;

  return (
    <Box display="flex" flexDirection="column" gap={1}>
      <Button
        variant={actionVariant}
        size="medium"
        color="inherit"
        fullWidth={!collapsed}
        onClick={onActionClick}
        sx={{
          minWidth: 'auto',
          overflow: 'hidden',
          transition: 'all 0.2s ease',
          '& .MuiButton-startIcon': {
            marginRight: collapsed ? 0 : undefined,
            transition: 'margin 0.2s ease',
          },
        }}
        startIconProps={actionIcon ? { name: actionIcon, size: 'xs' } : undefined}
      >
        <Box
          component="span"
          sx={{
            overflow: 'hidden',
            whiteSpace: 'nowrap',
            opacity: collapsed ? 0 : 1,
            width: collapsed ? 0 : 'auto',
            transition: 'opacity 0.2s ease',
          }}
        >
          {actionLabel}
        </Box>
      </Button>
    </Box>
  );
};

export default SecondaryNavigationActions;
