import type { ReactNode } from 'react';
import {
  Box,
  Icon,
  IconButton,
  Typography,
  type IconName,
} from '../';
import SecondaryNavigationActions from './SecondaryNavigationActions';
import SecondaryNavigationItems, { type NavigationItem } from './SecondaryNavigationItems';
import SecondaryNavigationFooter from './SecondaryNavigationFooter';

const EXPANDED_WIDTH = 290;
const COLLAPSED_WIDTH = 59;
const TRANSITION = 'all 0.2s ease';

export interface SecondaryNavigationProps {
  title: string;
  icon?: IconName;
  collapsed?: boolean;
  onToggleCollapse?: () => void;

  actionLabel?: string;
  actionIcon?: IconName;
  actionVariant?: 'outlined' | 'contained' | 'text';
  onActionClick?: () => void;

  items: NavigationItem[];
  selectedId?: string | number | null;
  onItemSelect?: (id: string | number) => void;
  emptyMessage?: string;
  renderItem?: (item: NavigationItem, selected: boolean) => ReactNode;

  footer?: ReactNode;
}

const SecondaryNavigation = ({
  title,
  icon,
  collapsed = false,
  onToggleCollapse,
  actionLabel,
  actionIcon,
  actionVariant,
  onActionClick,
  items,
  selectedId,
  onItemSelect,
  emptyMessage,
  renderItem,
  footer,
}: SecondaryNavigationProps) => {
  const panelWidth = collapsed ? COLLAPSED_WIDTH : EXPANDED_WIDTH;

  return (
    <Box
      sx={{
        width: panelWidth,
        minWidth: panelWidth,
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        borderRight: 1,
        borderColor: 'divider',
        p: (theme) => collapsed ? theme.spacing(2, 1) : theme.spacing(2),
        overflow: 'hidden',
        transition: TRANSITION,
      }}
    >
      <Box display="flex" flexDirection="column" gap={1.5} minHeight={0} flex={1}>
        <Box display="flex" alignItems="center" justifyContent={collapsed ? 'center' : 'space-between'}>
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              gap: 1,
              opacity: collapsed ? 0 : 1,
              width: collapsed ? 0 : 'auto',
              overflow: 'hidden',
              transition: 'opacity 0.2s ease',
            }}
          >
            {icon && <Icon name={icon} size="sm" />}
            <Typography variant="subtitle1" fontWeight={600} color="text.primary" noWrap>
              {title}
            </Typography>
          </Box>
          {onToggleCollapse && (
            <IconButton size="small" onClick={onToggleCollapse} sx={{ flexShrink: 0 }}>
              {collapsed ? <Icon name='caret-double-right' size='sm' /> : <Icon name='caret-double-left' size='sm' />}
            </IconButton>
          )}
        </Box>

        <Box display="flex" flexDirection="column" gap={2} minHeight={0} flex={1}>
          <SecondaryNavigationActions
            actionLabel={actionLabel}
            actionIcon={actionIcon}
            actionVariant={actionVariant}
            onActionClick={onActionClick}
            collapsed={collapsed}
          />
          <Box flex={1} overflow="auto" mr={-2}>
            <SecondaryNavigationItems
              items={items}
              selectedId={selectedId}
              onItemSelect={onItemSelect}
              emptyMessage={emptyMessage}
              renderItem={renderItem}
              collapsed={collapsed}
            />
          </Box>
        </Box>
      </Box>

      {!collapsed && <SecondaryNavigationFooter footer={footer} />}
    </Box>
  );
};

export default SecondaryNavigation;
