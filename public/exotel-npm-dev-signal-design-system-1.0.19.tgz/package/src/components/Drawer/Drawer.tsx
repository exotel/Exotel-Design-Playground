/**
 * Drawer Component
 * 
 * Exotel-approved drawer component with structured Header/Body/Footer layout.
 * Wraps MUI's Drawer with a design-system-level structure.
 */

import MuiDrawer, { type DrawerProps as MuiDrawerProps } from '@mui/material/Drawer';
import { forwardRef, ReactNode } from 'react';
import { Box, Divider } from '@mui/material';
import { Typography } from '../Typography';
import { IconButton } from '../IconButton';
import { Icon } from '../Icon';

export interface DrawerProps extends Omit<MuiDrawerProps, 'ref' | 'children'> {
  /**
   * Title displayed in the header
   */
  title?: string;
  /**
   * Callback fired when the close button is clicked
   */
  onClose?: (event: React.SyntheticEvent) => void;
  /**
   * Footer actions (buttons) to display in the footer
   */
  footerActions?: ReactNode;
  /**
   * Main content to display in the body section
   */
  children?: ReactNode;
  /**
   * Custom header content (overrides title and default close button)
   */
  headerContent?: ReactNode;
  /**
   * Custom footer content (overrides footerActions)
   */
  footerContent?: ReactNode;
  /**
   * Whether to show the close button in the header
   * @default true
   */
  showCloseButton?: boolean;
}

export const Drawer = forwardRef<HTMLDivElement, DrawerProps>(
  (
    {
      title,
      onClose,
      footerActions,
      children,
      headerContent,
      footerContent,
      showCloseButton = true,
      ...drawerProps
    },
    ref
  ) => {
    return (
      <MuiDrawer ref={ref} {...drawerProps} onClose={onClose}>
        <Box
          display="flex"
          flexDirection="column"
          height="100%"
          bgcolor="background.paper"
        >
          {/* Header Strip */}
          {headerContent || (
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                minHeight: 40,
                padding: (theme) => theme.spacing(1, 2),
                borderBottom: 1,
                borderColor: 'divider',
                backgroundColor: 'action.hover',
                flexShrink: 0,
              }}
            >
              {title && (
                <Typography variant="h6" component="h2">
                  {title}
                </Typography>
              )}
              {showCloseButton && onClose && (
                <IconButton
                  edge="end"
                  onClick={onClose}
                  aria-label="close drawer"
                  size="small"
                  sx={{
                    color: 'text.primary',
                    '& svg': {
                      color: 'inherit',
                    },
                  }}
                >
                  <Icon name="x" size="sm" />
                </IconButton>
              )}
            </Box>
          )}

          {/* Body Section - Scrollable */}
          <Box
            sx={{
              flex: 1,
              overflowY: 'auto',
              padding: (theme) => theme.spacing(3, 2),
              backgroundColor: 'background.paper',
            }}
          >
            {children}
          </Box>

          {/* Footer Strip */}
          {(footerContent || footerActions) && (
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                minHeight: 64,
                padding: (theme) => theme.spacing(1, 2),
                borderTop: 1,
                borderColor: 'divider',
                backgroundColor: 'background.paper',
                flexShrink: 0,
              }}
            >
              {/* Left side - empty by default, can be used for secondary actions */}
              <Box flex={1} />
              {/* Right side - primary actions */}
              <Box
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: (theme) => theme.spacing(2),
                }}
              >
                {footerContent || footerActions}
              </Box>
            </Box>
          )}
        </Box>
      </MuiDrawer>
    );
  }
);

Drawer.displayName = 'Drawer';
