/**
 * TextField Component
 *
 * Exports the Exotel TextField component that wraps MUI's TextField.
 */

export { TextField } from './TextField';
export type { TextFieldProps } from './TextField';
