/**
 * TextField Component
 *
 * Exotel-approved text field component that wraps MUI's TextField.
 * Provides consistent styling and behavior across Exotel applications.
 *
 * Usage:
 * ```tsx
 * import { TextField } from '@exotel-npm-dev/signal-design-system';
 *
 * <TextField label="Email" />
 * ```
 */

import MuiTextField, { type TextFieldProps as MuiTextFieldProps } from '@mui/material/TextField';
import { useFormControl } from '@mui/material/FormControl';
import { Typography } from '../../components';
import { forwardRef, useMemo } from 'react';
import { resolveFieldPlaceholder } from '../../functions/resolveFieldPlaceholder';
import { mergeSelectPlaceholderSlotProps } from '../../functions/selectPlaceholder';
import { FieldWrapper } from '../FieldLabel';

/**
 * TextField component props
 * Re-exports MUI TextFieldProps while hiding MUI-specific naming
 */
export interface TextFieldProps
  extends Omit<MuiTextFieldProps, 'ref' | 'variant' | 'size'> {
  /**
   * Controls whether the label is rendered
   */
  showLabel?: boolean;
  /**
   * The label content
   */
  label?: React.ReactNode;
  /**
   * The helper text content
   */
  helperText?: React.ReactNode;
  /**
   * The size of the input
   */
  size?: 'small' | 'medium' | 'large';
  /**
   * Placeholder text inside the input. Derived from `label` when omitted.
   * Pass an empty string to disable the default placeholder.
   */
  placeholder?: string;
}

/**
 * TextField component
 *
 * Wraps MUI's TextField component with Exotel-specific defaults and styling.
 * All MUI TextField props are supported (except `variant`, which is fixed to outlined).
 */
export const TextField = forwardRef<HTMLDivElement, TextFieldProps>(
  (props, ref) => {
    const {
      showLabel = true,
      label,
      helperText,
      id,
      name,
      size = 'medium',
      sx,
      required,
      error,
      disabled,
      fullWidth,
      placeholder,
      select,
      children,
      slotProps,
      SelectProps,
      ...rest
    } = props;
    const formControl = useFormControl();
    const resolvedRequired = required ?? formControl?.required ?? false;
    const resolvedError = error ?? formControl?.error ?? false;
    const resolvedDisabled = disabled ?? formControl?.disabled ?? false;
    const resolvedFullWidth = fullWidth ?? formControl?.fullWidth ?? false;
    const inputId = id ?? name;
    const resolvedPlaceholder = resolveFieldPlaceholder(
      showLabel ? label : undefined,
      placeholder,
      select ? 'select' : 'text',
    );

    const mergedSlotProps = useMemo(() => {
      if (!select) {
        return slotProps;
      }

      return mergeSelectPlaceholderSlotProps(
        resolvedPlaceholder,
        children,
        (emptyPlaceholder) => (
          <Typography component="span" variant="body2" color="text.secondary">
            {emptyPlaceholder}
          </Typography>
        ),
        slotProps,
        SelectProps,
      );
    }, [select, slotProps, SelectProps, resolvedPlaceholder, children]);

    const baseSx = {
      '& .MuiFormHelperText-root': {
        textAlign: 'left',
        marginLeft: 0,
      },
    };
    const mergedSx = Array.isArray(sx) ? [baseSx, ...sx] : sx ? [baseSx, sx] : baseSx;

    return (
      <FieldWrapper
        label={showLabel ? label : undefined}
        htmlFor={inputId}
        required={resolvedRequired}
      >
        <MuiTextField
          ref={ref}
          helperText={helperText}
          id={id}
          name={name}
          placeholder={resolvedPlaceholder}
          select={select}
          size={size}
          required={resolvedRequired}
          error={resolvedError}
          disabled={resolvedDisabled}
          fullWidth={resolvedFullWidth}
          slotProps={mergedSlotProps}
          sx={mergedSx}
          {...rest}
        >
          {children}
        </MuiTextField>
      </FieldWrapper>
    );
  }
);

TextField.displayName = 'TextField';
