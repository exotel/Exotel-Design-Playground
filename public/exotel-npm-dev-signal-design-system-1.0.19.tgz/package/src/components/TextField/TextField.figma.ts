// url=https://www.figma.com/design/CiTSqZD3DKtMu91owRSkZW/Signal-Design-System?node-id=6570-48313
// source=src/components/TextField/TextField.tsx
// component=TextField
// Selection https://www.figma.com/design/CiTSqZD3DKtMu91owRSkZW/Signal-Design-System?node-id=166-67061 resolves to this published <TextField> component.
import figma from 'figma';

const instance = figma.selectedInstance;

const labelText = instance.getString('Label Text');
const showLabel = instance.getBoolean('Label');

const size = instance.getEnum('Size', {
  Large: 'large',
  Medium: 'medium',
  Small: 'small',
});

const state = instance.getEnum('State', {
  Enabled: 'ok',
  Hovered: 'ok',
  Focused: 'ok',
  Disabled: 'disabled',
  Error: 'error',
});
const disabled = state === 'disabled';
const error = state === 'error';

const isNumber = instance.getBoolean('Type: number?');

const showValue = instance.getBoolean('Value?');
const valueStr = instance.getString('↳ Value');

const showPlaceholder = instance.getBoolean('Placeholder?');
const placeholderStr = instance.getString('↳ Placeholder');

const showHelper = instance.getBoolean('Helper?');
const helperLayer = showHelper ? instance.findText('Helper text') : null;
let helperTextStr: string | undefined;
if (helperLayer && helperLayer.type === 'TEXT') {
  helperTextStr = helperLayer.textContent;
}

const showStartAdorn = instance.getBoolean('Adorn. Start?');
const startSwap = showStartAdorn ? instance.getInstanceSwap('↳ Start Instance') : null;
let startAdornSnippet;
if (startSwap && startSwap.type === 'INSTANCE' && startSwap.hasCodeConnect()) {
  startAdornSnippet = startSwap.executeTemplate().example;
}

const showEndAdorn = instance.getBoolean('Adorn. End?');
const endSwap = showEndAdorn ? instance.getInstanceSwap('↳ End Instance') : null;
let endAdornSnippet;
if (endSwap && endSwap.type === 'INSTANCE' && endSwap.hasCodeConnect()) {
  endAdornSnippet = endSwap.executeTemplate().example;
}

let inputPropsLine;
if (startAdornSnippet && endAdornSnippet) {
  inputPropsLine = figma.code`InputProps={{ startAdornment: ${startAdornSnippet}, endAdornment: ${endAdornSnippet} }}`;
} else if (startAdornSnippet) {
  inputPropsLine = figma.code`InputProps={{ startAdornment: ${startAdornSnippet} }}`;
} else if (endAdornSnippet) {
  inputPropsLine = figma.code`InputProps={{ endAdornment: ${endAdornSnippet} }}`;
}

export default {
  example: figma.code`
    <TextField
      size="${size}"
      showLabel={${showLabel}}
      label="${labelText}"
      ${disabled ? 'disabled' : ''}
      ${error ? 'error' : ''}
      type="${isNumber ? 'number' : 'text'}"
      ${showValue && valueStr ? figma.code`defaultValue="${valueStr}"` : ''}
      ${showPlaceholder && placeholderStr ? figma.code`placeholder="${placeholderStr}"` : ''}
      ${helperTextStr !== undefined ? figma.code`helperText="${helperTextStr}"` : ''}
      ${inputPropsLine ? inputPropsLine : ''}
    />
  `,
  imports: ['import { TextField } from "@exotel-npm-dev/signal-design-system"'],
  id: 'text-field',
  metadata: {
    nestable: true,
  },
};
