/**
 * Tooltip Component
 * 
 * Exotel-approved tooltip component that wraps MUI's Tooltip.
 */

import MuiTooltip, { type TooltipProps as MuiTooltipProps } from '@mui/material/Tooltip';
import { forwardRef } from 'react';

export interface TooltipProps extends Omit<MuiTooltipProps, 'ref'> {
  children: React.ReactElement;
  title: React.ReactNode;
}

export const Tooltip = forwardRef<HTMLDivElement, TooltipProps>(
  (props, ref) => <MuiTooltip ref={ref} {...props} />
);

Tooltip.displayName = 'Tooltip';
