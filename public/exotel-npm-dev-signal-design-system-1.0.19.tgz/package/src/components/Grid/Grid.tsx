/**
 * Grid Component
 * 
 * Exotel-approved grid component that wraps MUI's Grid.
 */

import MuiGrid, { type GridProps as MuiGridProps } from '@mui/material/Grid';
import { forwardRef } from 'react';

export interface GridProps extends Omit<MuiGridProps, 'ref'> {
  children?: React.ReactNode;
}

export const Grid = forwardRef<HTMLDivElement, GridProps>(
  (props, ref) => <MuiGrid ref={ref} {...props} />
);

Grid.displayName = 'Grid';
