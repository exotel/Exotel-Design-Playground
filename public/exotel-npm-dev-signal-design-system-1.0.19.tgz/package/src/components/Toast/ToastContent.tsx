import { forwardRef, useCallback } from 'react';
import type { SnackbarKey, SnackbarMessage } from 'notistack';
import { useSnackbar } from 'notistack';
import type { SxProps, Theme } from '@mui/material/styles';
import { Alert } from '../Alert';
import { Typography } from '../Typography';
import type { ToastSeverity } from './types';

export interface ToastContentProps {
  id: SnackbarKey;
  message?: SnackbarMessage;
  title?: React.ReactNode;
  severity?: ToastSeverity;
  /** Extra styles (e.g. per-toast offset margins) merged onto the Alert root. */
  sx?: SxProps<Theme>;
}

export const ToastContent = forwardRef<HTMLDivElement, ToastContentProps>(
  ({ id, message, title, severity = 'info', sx }, ref) => {
    const { closeSnackbar } = useSnackbar();

    const handleClose = useCallback(
      () => closeSnackbar(id),
      [id, closeSnackbar],
    );

    return (
      <Alert
        ref={ref}
        severity={severity}
        variant="filled"
        onClose={handleClose}
        sx={[{ width: '100%' }, ...(Array.isArray(sx) ? sx : [sx])]}
      >
        {title && (
          <Typography variant="subtitle2" fontWeight={600}>
            {title}
          </Typography>
        )}
        {message}
      </Alert>
    );
  },
);

ToastContent.displayName = 'ToastContent';
