import { useCallback, useMemo } from 'react';
import type { ReactNode } from 'react';
import { SnackbarProvider, useSnackbar } from 'notistack';
import type { SnackbarOrigin } from 'notistack';
import { GlobalStyles } from '../../components';
import { ToastContext } from './ToastContext';
import { ToastContent } from './ToastContent';
import { SlideTransition, GrowTransition } from './transitions';
import type {
  ToastContextValue,
  ToastKey,
  ToastOffset,
  ToastOptions,
  ToastOrigin,
  ToastTransition,
} from './types';

const DEFAULT_AUTO_HIDE: number = 5000;
const DEFAULT_ANCHOR: ToastOrigin = { vertical: 'bottom', horizontal: 'right' };
const DEFAULT_TRANSITION: ToastTransition = 'slide';

const TRANSITION_MAP = {
  slide: SlideTransition,
  grow: GrowTransition,
} as const;

const toPx = (value: number | string): string =>
  typeof value === 'number' ? `${value}px` : value;

/**
 * Normalizes the `offset` prop into per-edge CSS lengths. A bare number/string
 * targets the anchored vertical edge (the common "lift toasts up from the
 * bottom" case); an object lets you set each edge directly.
 */
function offsetToEdges(
  offset: number | string | ToastOffset,
  anchor: ToastOrigin,
): Record<'top' | 'bottom' | 'left' | 'right', string | undefined> {
  const raw: ToastOffset = typeof offset === 'object' ? offset : { [anchor.vertical]: offset };
  return {
    top: raw.top !== undefined ? toPx(raw.top) : undefined,
    bottom: raw.bottom !== undefined ? toPx(raw.bottom) : undefined,
    left: raw.left !== undefined ? toPx(raw.left) : undefined,
    right: raw.right !== undefined ? toPx(raw.right) : undefined,
  };
}

export interface ToastProviderProps {
  children: ReactNode;
  /** Maximum toasts visible at once. @default 3 */
  maxToasts?: number;
  /** Default screen anchor for all toasts. @default { vertical: 'bottom', horizontal: 'right' } */
  anchorOrigin?: ToastOrigin;
  /** Default transition for all toasts. @default 'slide' */
  transition?: ToastTransition;
  /** Default auto-hide duration in ms. @default 5000 */
  autoHideDuration?: number | null;
  /** Denser spacing (useful on mobile). @default false */
  dense?: boolean;
  /**
   * Distance of the toast container from the viewport edges, letting you
   * position the widget relative to its anchor. A number/string is applied to
   * the anchored vertical edge (e.g. `offset={300}` with a bottom anchor lifts
   * toasts to 300px above the bottom). Pass an object to control each edge
   * independently (e.g. `{ bottom: 300, right: 24 }`).
   */
  offset?: number | string | ToastOffset;
}

function ToastBridge({
  children,
  defaultAnchor,
  defaultTransition,
  defaultAutoHide,
}: {
  children: ReactNode;
  defaultAnchor: SnackbarOrigin;
  defaultTransition: ToastTransition;
  defaultAutoHide: number | null;
}) {
  const { enqueueSnackbar, closeSnackbar } = useSnackbar();

  const showToast = useCallback(
    (message: ReactNode, options?: ToastOptions): ToastKey => {
      const severity = options?.severity ?? 'info';
      const transition = options?.transition ?? defaultTransition;
      const anchorOrigin = options?.anchorOrigin ?? defaultAnchor;
      let offsetSx: Record<string, string> | undefined;
      if (options?.offset !== undefined) {
        const edges = offsetToEdges(options.offset, anchorOrigin);
        offsetSx = {};
        if (edges.top) offsetSx.marginTop = edges.top;
        if (edges.bottom) offsetSx.marginBottom = edges.bottom;
        if (edges.left) offsetSx.marginLeft = edges.left;
        if (edges.right) offsetSx.marginRight = edges.right;
      }

      return enqueueSnackbar(message, {
        key: options?.key,
        persist: options?.persist ?? false,
        autoHideDuration: options?.autoHideDuration === undefined
          ? defaultAutoHide
          : options.autoHideDuration,
        anchorOrigin,
        TransitionComponent: TRANSITION_MAP[transition],
        content: (key, msg) => (
          <ToastContent
            id={key}
            message={msg}
            title={options?.title}
            severity={severity}
            sx={offsetSx}
          />
        ),
      });
    },
    [enqueueSnackbar, defaultAnchor, defaultTransition, defaultAutoHide],
  );

  const value: ToastContextValue = useMemo(
    () => ({
      showToast,
      showSuccess: (msg, opts) => showToast(msg, { ...opts, severity: 'success' }),
      showError: (msg, opts) => showToast(msg, { ...opts, severity: 'error' }),
      showWarning: (msg, opts) => showToast(msg, { ...opts, severity: 'warning' }),
      showInfo: (msg, opts) => showToast(msg, { ...opts, severity: 'info' }),
      closeToast: (key) => closeSnackbar(key),
    }),
    [showToast, closeSnackbar],
  );

  return (
    <ToastContext.Provider value={value}>
      {children}
    </ToastContext.Provider>
  );
}

export function ToastProvider({
  children,
  maxToasts = 3,
  anchorOrigin = DEFAULT_ANCHOR,
  transition = DEFAULT_TRANSITION,
  autoHideDuration = DEFAULT_AUTO_HIDE,
  dense = false,
  offset,
}: ToastProviderProps) {
  const containerStyles =
    offset !== undefined ? offsetToEdges(offset, anchorOrigin) : null;

  return (
    <>
      {containerStyles && (
        <GlobalStyles
          styles={{
            '.notistack-SnackbarContainer': {
              top: containerStyles.top && `${containerStyles.top} !important`,
              bottom: containerStyles.bottom && `${containerStyles.bottom} !important`,
              left: containerStyles.left && `${containerStyles.left} !important`,
              right: containerStyles.right && `${containerStyles.right} !important`,
            },
          }}
        />
      )}
      <SnackbarProvider
        maxSnack={maxToasts}
        anchorOrigin={anchorOrigin}
        autoHideDuration={autoHideDuration ?? undefined}
        dense={dense}
        TransitionComponent={TRANSITION_MAP[transition]}
      >
        <ToastBridge
          defaultAnchor={anchorOrigin}
          defaultTransition={transition}
          defaultAutoHide={autoHideDuration}
        >
          {children}
        </ToastBridge>
      </SnackbarProvider>
    </>
  );
}

ToastProvider.displayName = 'ToastProvider';
