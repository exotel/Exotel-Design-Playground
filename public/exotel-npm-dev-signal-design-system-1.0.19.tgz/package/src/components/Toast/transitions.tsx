import { forwardRef } from 'react';
import MuiSlide from '@mui/material/Slide';
import MuiGrow from '@mui/material/Grow';
import type { TransitionProps } from 'notistack';

/**
 * Notistack-compatible Slide transition. Notistack passes an anchor-aware
 * `direction` in props (e.g. 'up' for bottom, 'down' for top, 'left' for right),
 * so we keep `direction="up"` only as a fallback and let that prop win.
 */
export const SlideTransition = forwardRef<HTMLDivElement, TransitionProps>(
  (props, ref) => (
    <MuiSlide ref={ref} direction="up" {...(props as any)} />
  ),
);
SlideTransition.displayName = 'SlideTransition';

/**
 * Notistack-compatible Grow transition (scales in from the center).
 */
export const GrowTransition = forwardRef<HTMLDivElement, TransitionProps>(
  (props, ref) => (
    <MuiGrow ref={ref} {...(props as any)} />
  ),
);
GrowTransition.displayName = 'GrowTransition';
