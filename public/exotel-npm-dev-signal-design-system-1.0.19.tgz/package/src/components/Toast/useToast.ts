import { useContext } from 'react';
import { ToastContext } from './ToastContext';
import type { ToastContextValue } from './types';

/**
 * Access the Toast API anywhere inside a `<ToastProvider>`.
 *
 * ```tsx
 * const { showSuccess, showError, closeToast } = useToast();
 * showSuccess('Saved!');
 * ```
 */
export function useToast(): ToastContextValue {
  return useContext(ToastContext);
}
