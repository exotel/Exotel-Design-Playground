import { createContext } from 'react';
import type { ToastContextValue, ToastKey } from './types';

const stub = (): ToastKey => {
  if (typeof process !== 'undefined' && process.env?.NODE_ENV !== 'production') {
    console.warn(
      'useToast() was called outside of a <ToastProvider>. ' +
      'Wrap your app in <ToastProvider>.',
    );
  }
  return '';
};

export const ToastContext = createContext<ToastContextValue>({
  showToast: stub,
  showSuccess: stub,
  showError: stub,
  showWarning: stub,
  showInfo: stub,
  closeToast: () => {},
});
