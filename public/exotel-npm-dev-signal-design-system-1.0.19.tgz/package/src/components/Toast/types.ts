import type { ReactNode } from 'react';
import type { SnackbarOrigin } from 'notistack';

export type ToastSeverity = 'success' | 'error' | 'warning' | 'info';

export type ToastTransition = 'slide' | 'grow';

export type ToastKey = string | number;

export interface ToastOrigin extends SnackbarOrigin {}

/**
 * Per-edge distance of the toast container from the viewport edges.
 * Numbers are treated as pixels; strings are used verbatim (e.g. '2rem', '10%').
 */
export interface ToastOffset {
  top?: number | string;
  bottom?: number | string;
  left?: number | string;
  right?: number | string;
}

export interface ToastOptions {
  /** Title rendered in bold above the message. */
  title?: ReactNode;
  /** Severity determines the Alert color and icon. @default 'info' */
  severity?: ToastSeverity;
  /** Milliseconds before auto-dismiss. Pass `null` to persist. @default 5000 */
  autoHideDuration?: number | null;
  /** Screen anchor position. @default { vertical: 'bottom', horizontal: 'right' } */
  anchorOrigin?: ToastOrigin;
  /**
   * Per-notification offset, nudging this toast away from its anchored edge
   * on top of the provider's global `offset`. A number/string is applied to the
   * anchored vertical edge; pass an object to control each edge independently.
   */
  offset?: number | string | ToastOffset;
  /** Transition animation. @default 'slide' */
  transition?: ToastTransition;
  /** Unique key — pass to prevent duplicates or to close programmatically. */
  key?: ToastKey;
  /** If true, toast stays until explicitly dismissed. @default false */
  persist?: boolean;
}

export interface ToastContextValue {
  /** Show a toast with any severity. */
  showToast: (message: ReactNode, options?: ToastOptions) => ToastKey;
  /** Shorthand — severity: 'success'. */
  showSuccess: (message: ReactNode, options?: Omit<ToastOptions, 'severity'>) => ToastKey;
  /** Shorthand — severity: 'error'. */
  showError: (message: ReactNode, options?: Omit<ToastOptions, 'severity'>) => ToastKey;
  /** Shorthand — severity: 'warning'. */
  showWarning: (message: ReactNode, options?: Omit<ToastOptions, 'severity'>) => ToastKey;
  /** Shorthand — severity: 'info'. */
  showInfo: (message: ReactNode, options?: Omit<ToastOptions, 'severity'>) => ToastKey;
  /** Close a specific toast by key, or all toasts if no key is passed. */
  closeToast: (key?: ToastKey) => void;
}
