/**
 * TimeRangePicker Component
 *
 * Exotel-approved time range picker component that wraps MUI X TimeRangePicker (pro).
 * Relies on the LocalizationProvider in ExotelThemeProvider.
 */

import { TimeRangePicker as MuiTimeRangePicker, type TimeRangePickerProps as MuiTimeRangePickerProps } from '@mui/x-date-pickers-pro/TimeRangePicker';
import { forwardRef, useMemo } from 'react';
import { mergePickerTextFieldSlotProps } from '../../functions/mergePickerTextFieldSlotProps';
import { FieldWrapper } from '../FieldLabel';

export interface TimeRangePickerProps extends Omit<MuiTimeRangePickerProps, 'ref'> {
  /** External label rendered above the picker. */
  label?: React.ReactNode;
  /** The size of the picker input. Matches TextField sizes. */
  size?: 'small' | 'medium' | 'large';
  /** Placeholder text inside the input. Derived from `label` when omitted. */
  placeholder?: string;
}

export const TimeRangePicker = forwardRef<HTMLDivElement, TimeRangePickerProps>(
  (props, ref) => {
    const { label, size = 'medium', placeholder, slotProps, ...rest } = props;

    const mergedSlotProps = useMemo(
      () => mergePickerTextFieldSlotProps(label, size, placeholder, slotProps),
      [label, size, placeholder, slotProps],
    );

    return (
      <FieldWrapper label={label}>
        <MuiTimeRangePicker ref={ref} slotProps={mergedSlotProps as MuiTimeRangePickerProps['slotProps']} {...rest} />
      </FieldWrapper>
    );
  }
);

TimeRangePicker.displayName = 'TimeRangePicker';
