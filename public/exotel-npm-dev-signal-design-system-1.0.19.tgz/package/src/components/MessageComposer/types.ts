export interface MessageComposerOption {
  /**
   * Unique identifier for the option
   */
  id: string;
  /**
   * Text shown for the option
   */
  label: string;
}

export interface MessageComposerProps {
  /**
   * The question / prompt shown in the header
   */
  question: string;
  /**
   * Selectable quick-reply options. Each option is rendered with a
   * sequential letter key cap (A, B, C…).
   */
  options: MessageComposerOption[];
  /**
   * Initial highlighted option. Defaults to the first option.
   */
  defaultActiveOptionId?: string;
  /**
   * Called when the highlighted option changes (keyboard or hover).
   */
  onActiveOptionChange?: (id: string) => void;
  /**
   * Called when an option is selected (click or Enter).
   */
  onSelect?: (option: MessageComposerOption) => void;
  /**
   * Initial value of the free-text input.
   */
  defaultInputValue?: string;
  /**
   * Called when the free-text input value changes.
   */
  onInputChange?: (value: string) => void;
  /**
   * Called when free text is submitted (Enter with non-empty input).
   */
  onSubmit?: (value: string) => void;
  /**
   * Placeholder for the free-text input.
   * @default 'Type something'
   */
  inputPlaceholder?: string;
  /**
   * Whether to render the free-text input row.
   * @default true
   */
  showInput?: boolean;
  /**
   * 1-based index of the current prompt, shown as `{current} of {total}`.
   */
  currentIndex?: number;
  /**
   * Total number of prompts in the sequence.
   */
  totalCount?: number;
  /**
   * Called when the previous-prompt control is clicked.
   */
  onPrev?: () => void;
  /**
   * Called when the next-prompt control is clicked.
   */
  onNext?: () => void;
  /**
   * Called when the close (×) control is clicked. When omitted the close
   * button is hidden.
   */
  onClose?: () => void;
  /**
   * Whether to render the keyboard-hint footer.
   * @default true
   */
  showFooterHints?: boolean;
}
