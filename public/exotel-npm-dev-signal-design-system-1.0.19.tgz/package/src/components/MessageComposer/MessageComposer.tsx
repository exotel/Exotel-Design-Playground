import { forwardRef, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { ChangeEvent, KeyboardEvent as ReactKeyboardEvent } from 'react';
import { alpha } from '@mui/material/styles';
import { Box, Typography, InputBase } from '../../components';
import { IconButton } from '../IconButton';
import { Icon } from '../Icon';
import type { MessageComposerOption, MessageComposerProps } from './types';

const LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const INPUT_SLOT_ID = '__input__';

// Key-cap label is positional (0 → "A"), independent of option.id; falls back to a number past 26.
const getOptionLetter = (index: number) => LETTERS[index] ?? String(index + 1);

function KeyCap({ children }: { children: React.ReactNode }) {
  return (
    <Box display="flex" alignItems="center" flexShrink={0} width={32}>
      <Box
        display="flex"
        alignItems="center"
        justifyContent="center"
        width={24}
        height={24}
        borderRadius="4px"
        bgcolor={(theme) => alpha(theme.palette.text.primary, 0.08)}
        sx={{ typography: 'subtitle2', fontWeight: 500, lineHeight: 1, color: 'text.primary' }}
      >
        {children}
      </Box>
    </Box>
  );
}

/**
 * MessageComposer — an inline clarification prompt used in agentic flows.
 *
 * Shows a question, a list of lettered quick-reply options, an optional
 * free-text input, and a keyboard-hint footer. Options can be navigated with
 * the arrow keys and chosen with Enter; typing in the input and pressing Enter
 * submits free text instead.
 *
 * ```tsx
 * <MessageComposer
 *   question="What is your preferred maximum journey duration per lead?"
 *   options={[
 *     { id: 'a', label: "Let's do a compressed 7-day sprint" },
 *     { id: 'b', label: 'Stick to the standard 10-day window' },
 *     { id: 'c', label: 'Let AI Decide' },
 *   ]}
 *   currentIndex={1}
 *   totalCount={1}
 *   onSelect={(option) => console.log(option)}
 *   onSubmit={(text) => console.log(text)}
 * />
 * ```
 */
export const MessageComposer = forwardRef<HTMLDivElement, MessageComposerProps>(
  (
    {
      question,
      options,
      defaultActiveOptionId,
      onActiveOptionChange,
      onSelect,
      defaultInputValue = '',
      onInputChange,
      onSubmit,
      inputPlaceholder = 'Type something',
      showInput = true,
      currentIndex,
      totalCount,
      onPrev,
      onNext,
      onClose,
      showFooterHints = true,
    },
    ref,
  ) => {
    const rootRef = useRef<HTMLDivElement | null>(null);
    const inputRef = useRef<HTMLInputElement>(null);

    const setRootRef = useCallback(
      (node: HTMLDivElement | null) => {
        rootRef.current = node;
        if (typeof ref === 'function') ref(node);
        else if (ref) (ref as { current: HTMLDivElement | null }).current = node;
      },
      [ref],
    );

    useEffect(() => {
      rootRef.current?.focus();
    }, []);

    const [activeId, setInternalActiveId] = useState(
      defaultActiveOptionId ?? options[0]?.id,
    );

    const [inputText, setInternalInput] = useState(defaultInputValue);

    const isInputActive = activeId === INPUT_SLOT_ID;

    const navIds = useMemo(
      () => [...options.map((o) => o.id), ...(showInput ? [INPUT_SLOT_ID] : [])],
      [options, showInput],
    );

    const showPagination =
      typeof currentIndex === 'number' && typeof totalCount === 'number';

    const setActive = useCallback(
      (id: string) => {
        setInternalActiveId(id);
        onActiveOptionChange?.(id);
      },
      [onActiveOptionChange],
    );

    const moveActive = useCallback(
      (delta: number) => {
        if (navIds.length === 0) return;
        const currentIdx = navIds.indexOf(activeId);
        const base = currentIdx === -1 ? 0 : currentIdx;
        const nextIdx = (base + delta + navIds.length) % navIds.length;
        setActive(navIds[nextIdx]);
        if (navIds[nextIdx] === INPUT_SLOT_ID) {
          inputRef.current?.focus();
        } else {
          rootRef.current?.focus();
        }
      },
      [navIds, activeId, setActive],
    );

    const handleSelect = useCallback(
      (option: MessageComposerOption) => {
        setActive(option.id);
        onSelect?.(option);
      },
      [onSelect, setActive],
    );

    const handleInputChange = useCallback(
      (event: ChangeEvent<HTMLInputElement>) => {
        const next = event.target.value;
        setInternalInput(next);
        onInputChange?.(next);
      },
      [onInputChange],
    );

    const handleKeyDown = useCallback(
      (event: ReactKeyboardEvent<HTMLDivElement>) => {
        switch (event.key) {
          case 'ArrowDown':
            event.preventDefault();
            moveActive(1);
            break;
          case 'ArrowUp':
            event.preventDefault();
            moveActive(-1);
            break;
          case 'Enter': {
            event.preventDefault();
            if (isInputActive) {
              onSubmit?.(inputText);
              return;
            }
            const active = options.find((o) => o.id === activeId);
            if (active) handleSelect(active);
            break;
          }
          default: {
            // Letter shortcuts (A, B, C…) map to option position.
            // Skipped while typing in the free-text input so letters type normally.
            if (isInputActive) break;
            if (event.key.length !== 1 || event.metaKey || event.ctrlKey || event.altKey) {
              break;
            }
            const index = LETTERS.indexOf(event.key.toUpperCase());
            if (index >= 0 && index < options.length) {
              event.preventDefault();
              handleSelect(options[index]);
            }
            break;
          }
        }
      },
      [moveActive, inputText, onSubmit, options, activeId, handleSelect, isInputActive],
    );

    return (
      <Box
        ref={setRootRef}
        onKeyDown={handleKeyDown}
        tabIndex={0}
        display="flex"
        flexDirection="column"
        gap={2}
        p={1.5}
        bgcolor="background.paper"
        border={1}
        borderColor="divider"
        overflow="hidden"
        sx={{
          borderRadius: '16px',
          outline: 'none',
          boxShadow:
            '0px 4px 8px -2px rgba(10,13,18,0.1), 0px 2px 4px -2px rgba(0,0,0,0.06)',
        }}
      >
        <Box
          display="flex"
          alignItems="center"
          justifyContent="space-between"
          gap={1.5}
          width="100%"
        >
          <Typography
            variant="subtitle2"
            sx={{
              flex: 1,
              minWidth: 0,
              fontWeight: 500,
              color: 'text.primary',
            }}
          >
            {question}
          </Typography>

          <Box display="flex" alignItems="center" gap={1.5} flexShrink={0}>
            {showPagination && (
              <Box display="flex" alignItems="center" gap={0.5}>
                <IconButton
                  size="small"
                  aria-label="Previous prompt"
                  onClick={onPrev}
                  disabled={!onPrev}
                  sx={{ p: 0.25 }}
                >
                  <Icon name="caret-left" size="xs" />
                </IconButton>
                <Typography variant="subtitle2" sx={{ color: 'text.secondary' }}>
                  {currentIndex} of {totalCount}
                </Typography>
                <IconButton
                  size="small"
                  aria-label="Next prompt"
                  onClick={onNext}
                  disabled={!onNext}
                  sx={{ p: 0.25 }}
                >
                  <Icon name="caret-right" size="xs" />
                </IconButton>
              </Box>
            )}

            {onClose && (
              <IconButton
                size="small"
                aria-label="Close"
                onClick={onClose}
                sx={{ p: 0.25 }}
              >
                <Icon name="x" size="sm" />
              </IconButton>
            )}
          </Box>
        </Box>

        <Box display="flex" flexDirection="column" gap={0.5} width="100%">
          <Box display="flex" flexDirection="column" gap={1} width="100%">
            {options.map((option, index) => {
              const isActive = option.id === activeId;
              return (
                <Box
                  key={option.id}
                  role="button"
                  tabIndex={-1}
                  onClick={() => handleSelect(option)}
                  onMouseEnter={() => setActive(option.id)}
                  display="flex"
                  alignItems="center"
                  height={36}
                  px={1}
                  bgcolor={(theme) =>
                    isActive ? alpha(theme.palette.primary.main, 0.16) : 'transparent'
                  }
                  sx={{
                    cursor: 'pointer',
                    borderRadius: '8px',
                    transition: 'background-color 0.15s ease-in-out',
                    '&:hover': {
                      bgcolor: (theme) => alpha(theme.palette.primary.main, 0.16),
                    },
                  }}
                >
                  <KeyCap>{getOptionLetter(index)}</KeyCap>
                  <Typography
                    variant="body2"
                    sx={{ flex: 1, minWidth: 0, color: 'text.primary' }}
                  >
                    {option.label}
                  </Typography>
                  {isActive && (
                    <IconButton
                      size="small"
                      tabIndex={-1}
                      sx={{ flexShrink: 0 }}
                    >
                      <Icon name="arrow-elbow-down-left" size="sm" />
                    </IconButton>
                  )}
                </Box>
              );
            })}

            {showInput && (
              <Box
                display="flex"
                alignItems="center"
                height={36}
                px={1}
                onClick={() => {
                  setActive(INPUT_SLOT_ID);
                  inputRef.current?.focus();
                }}
                bgcolor={(theme) =>
                  isInputActive ? alpha(theme.palette.primary.main, 0.16) : 'transparent'
                }
                sx={{
                  cursor: 'text',
                  borderRadius: '8px',
                  transition: 'background-color 0.15s ease-in-out',
                }}
              >
                <Box display="flex" alignItems="center" flexShrink={0} width={32}>
                  <Box
                    display="flex"
                    alignItems="center"
                    justifyContent="center"
                    width={24}
                    height={24}
                    color="text.secondary"
                  >
                    <Icon name="pencil-simple" size="sm" />
                  </Box>
                </Box>
                <InputBase
                  inputRef={inputRef}
                  value={inputText}
                  onChange={handleInputChange}
                  onFocus={() => setActive(INPUT_SLOT_ID)}
                  placeholder={inputPlaceholder}
                  fullWidth
                  sx={{
                    typography: 'body2',
                    color: 'text.primary',
                    pl: '0px !important',
                    minHeight: 36,
                    height: 36,
                    boxShadow: 'none',
                  }}
                />
              </Box>
            )}
          </Box>

          {showFooterHints && (
            <Box
              display="flex"
              alignItems="center"
              justifyContent="center"
              flexWrap="wrap"
              gap={2}
              pt={0.5}
              color="text.disabled"
            >
              <Box display="flex" alignItems="center" gap={0.5}>
                <Box display="flex" alignItems="center">
                  <Icon name="arrow-down" size={14} />
                  <Icon name="arrow-up" size={14} />
                </Box>
                <Typography variant="caption" color="inherit">
                  to navigate
                </Typography>
              </Box>

              <HintDot />

              <Box display="flex" alignItems="center" gap={0.5}>
                <Icon name="arrow-elbow-down-left" size="xs" />
                <Typography variant="caption" color="inherit">
                  Enter to select
                </Typography>
              </Box>

              <HintDot />

              <Typography variant="caption" color="inherit">
                or type below
              </Typography>
            </Box>
          )}
        </Box>
      </Box>
    );
  },
);

function HintDot() {
  return (
    <Box
      width={2}
      height={2}
      borderRadius="50%"
      bgcolor="currentColor"
      sx={{ opacity: 0.6 }}
    />
  );
}

MessageComposer.displayName = 'MessageComposer';
