/**
 * EnhancedTextField Component (deprecated)
 *
 * @deprecated Use `TextField` from `../TextField` instead.
 * Kept for backward compatibility — re-exports the deprecated alias.
 */

export { EnhancedTextField } from './EnhancedTextField';
export type { EnhancedTextFieldProps } from './EnhancedTextField';
