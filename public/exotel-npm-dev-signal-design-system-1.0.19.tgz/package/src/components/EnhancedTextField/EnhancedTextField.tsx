/**
 * EnhancedTextField Component (deprecated)
 *
 * @deprecated Use `TextField` instead. `EnhancedTextField` is kept for backward
 * compatibility and forwards all props to `TextField`.
 *
 * Usage (prefer TextField):
 * ```tsx
 * import { TextField } from '@exotel-npm-dev/signal-design-system';
 *
 * <TextField label="Email" />
 * ```
 */

import { forwardRef } from 'react';
import { TextField, type TextFieldProps } from '../TextField';

/**
 * @deprecated Use `TextFieldProps` instead.
 */
export type EnhancedTextFieldProps = TextFieldProps;

/**
 * @deprecated Use `TextField` instead. This alias forwards to `TextField`.
 */
export const EnhancedTextField = forwardRef<HTMLDivElement, EnhancedTextFieldProps>(
  (props, ref) => <TextField ref={ref} {...props} />
);

EnhancedTextField.displayName = 'EnhancedTextField';
