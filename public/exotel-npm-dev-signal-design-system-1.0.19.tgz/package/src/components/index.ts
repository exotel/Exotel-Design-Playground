/**
 * Components Directory
 * 
 * This directory contains all reusable UI components for the Exotel Design System.
 * 
 * Purpose:
 * - Components wrap MUI components with Exotel-specific styling and behavior
 * - All components should be built on top of @mui/material components
 * - Components should follow Exotel's design guidelines
 * - Each component should be self-contained and reusable
 * 
 * Structure:
 * - Each component should have its own folder
 * - Export components from this index.ts file
 * - Components should be properly typed with TypeScript
 * 
 * Example structure:
 * components/
 *   Button/
 *     Button.tsx
 *     Button.test.tsx
 *     index.ts
 */

// Exporting all mui components, hooks, methods, types, etc.
// If we have same component in both mui and our library, MUI components will be overridden by our components.
export * from '@mui/material';

// Exporting all mui x components
export * from '@mui/x-data-grid-pro';
export * from '@mui/x-date-pickers-pro';
// Resolve ambiguous exports between @mui/material and @mui/x-data-grid-pro
export { type GridClasses, type GridClassKey, gridClasses } from '@mui/x-data-grid-pro';
export { Toolbar, type ToolbarProps } from '@mui/material';

// Theme Provider & hooks
export { ExotelThemeProvider, useThemeMode, useLoadDataByTheme, useFont, useSignal } from './ThemeProvider';
export type { ExotelThemeProviderProps, UseThemeModeReturn, UseFontReturn, SignalContextValue } from './ThemeProvider';
export type { FontKey } from '../theme';

// Accordion
export { Accordion } from './Accordion';
export type { AccordionProps } from './Accordion';

// UI Components - Form Inputs
export { Button } from './Button';
export type { ButtonProps } from './Button';

export { Checkbox } from './Checkbox';
export type { CheckboxProps } from './Checkbox';

export { Radio } from './Radio';
export type { RadioProps } from './Radio';

export { Switch } from './Switch';
export type { SwitchProps } from './Switch';

export { FormField } from './FormField';
export type { FormFieldProps } from './FormField';

export { TextField } from './TextField';
export type { TextFieldProps } from './TextField';

/** @deprecated Use `TextField` instead. Alias kept for backward compatibility. */
export { EnhancedTextField } from './EnhancedTextField';
/** @deprecated Use `TextFieldProps` instead. */
export type { EnhancedTextFieldProps } from './EnhancedTextField';

export { FieldWrapper } from './FieldLabel';
export type { FieldWrapperProps } from './FieldLabel';

/** @deprecated Use `TextField` instead. Kept for backward compatibility. */
export { Input } from './Input';
/** @deprecated Use `TextFieldProps` instead. */
export type { InputProps } from './Input';

export { Select } from './Select';
export type { SelectProps } from './Select';

export { MultiSelect } from './MultiSelect';
export type { MultiSelectProps, MultiSelectOption } from './MultiSelect';

export { AppliedFilters } from './AppliedFilters';
export type { AppliedFiltersProps, AppliedFilter } from './AppliedFilters';

export { Slider } from './Slider';
export type { SliderProps } from './Slider';

export { FormControl } from './FormControl';
export type { FormControlProps } from './FormControl';

// UI Components - Layout
export { Box } from './Box';
export type { BoxProps } from './Box';

export { Container } from './Container';
export type { ContainerProps } from './Container';

export { Grid } from './Grid';
export type { GridProps } from './Grid';

export { Stack } from './Stack';
export type { StackProps } from './Stack';

export { Paper } from './Paper';
export type { PaperProps } from './Paper';

export { Card } from './Card';
export type { CardProps } from './Card';

export { AppBar } from './AppBar';
export type { AppBarProps } from './AppBar';

export { Drawer } from './Drawer';
export type { DrawerProps } from './Drawer';

export { Navigation } from './Navigation';
export type { NavigationProps, NavSectionProps, NavItemPayload } from './Navigation';

export { SecondaryNavigation } from './SecondaryNavigation';
export type { SecondaryNavigationProps, NavigationItem } from './SecondaryNavigation';

export { Link } from './Link';
export type { LinkProps } from './Link';

export { Menu } from './Menu';
export type { MenuProps } from './Menu';

export { PageHeader } from './PageHeader';
export type { PageHeaderProps } from './PageHeader';

export { Tabs } from './Tabs';
export type { TabsProps } from './Tabs';

export { Tab } from './Tabs';
export type { TabProps } from './Tabs';

export { Stepper } from './Stepper';
export type { StepperProps } from './Stepper';

export { Breadcrumbs } from './Breadcrumbs';
export type { BreadcrumbsProps } from './Breadcrumbs';

// UI Components - Feedback
export { Alert } from './Alert';
export type { AlertProps } from './Alert';

export { Dialog } from './Dialog';
export type { DialogProps } from './Dialog';

export { StructuredDialog, DialogBody, DialogFooter } from './Dialog';
export type { StructuredDialogProps } from './Dialog';

export { Snackbar } from './Snackbar';
export type { SnackbarProps } from './Snackbar';

// Toast (notistack-based notification system)
export { ToastProvider, useToast, ToastContext } from './Toast';
export type {
  ToastProviderProps,
  ToastSeverity,
  ToastTransition,
  ToastKey,
  ToastOrigin,
  ToastOptions,
  ToastContextValue,
} from './Toast';

export { CircularProgress } from './CircularProgress';
export type { CircularProgressProps } from './CircularProgress';

export { LinearProgress } from './LinearProgress';
export type { LinearProgressProps } from './LinearProgress';

export { Tooltip } from './Tooltip';
export type { TooltipProps } from './Tooltip';

export { Popover } from './Popover';
export type { PopoverProps } from './Popover';

// UI Components - Data Display
export { Avatar } from './Avatar';
export type { AvatarProps } from './Avatar';

export { Badge } from './Badge';
export type { BadgeProps } from './Badge';

export { Chip } from './Chip';
export type { ChipProps } from './Chip';

export { Divider } from './Divider';
export type { DividerProps } from './Divider';

export { List, ListItem, ListItemIcon, ListItemText, ListItemButton, ListItemSecondaryAction, ListSubheader, ListDivider } from './List';
export type { ListProps, ListItemProps, ListItemIconProps, ListItemTextProps, ListItemButtonProps, ListItemSecondaryActionProps, ListSubheaderProps, ListDividerProps } from './List';

export { Table } from './Table';
export type { TableProps } from './Table';

export { DataGrid } from './DataGrid';
export type { 
  BulkDeleteConfig,
  DataGridProps,
  DataGridTableHeaderProps,
  ToolbarButtonConfig,
  ToolbarFilterConfig,
  DateRangeValue,
  GridColDef,
  GridRowsProp
} from './DataGrid';

export { Typography } from './Typography';
export type { TypographyProps } from './Typography';

// UI Components - Actions
export { IconButton } from './IconButton';
export type { IconButtonProps } from './IconButton';

export { Fab } from './Fab';
export type { FabProps } from './Fab';

// UI Components - Icons
export { Icon } from './Icon';
export type { IconProps, IconSize, IconWeightOption, IconName } from './Icon';

// App Launcher
export {
  AppLauncher,
  ProductItem,
} from './AppLauncher';
export type {
  AppLauncherProps,
  LayoutMode,
  Product,
  ProductItemProps,
} from './AppLauncher';

// AvatarMenu
export { AvatarMenu } from './AvatarMenu';
export type { AvatarMenuProps, AvatarMenuGroup, AvatarMenuItem, AvatarMenuFooterInfo, ThemeMode } from './AvatarMenu';

// Autocomplete
export { Autocomplete } from './Autocomplete';
export type { AutocompleteProps } from './Autocomplete';

// Date & Time Pickers
export { DatePicker } from './DatePicker';
export type { DatePickerProps } from './DatePicker';

export { TimePicker } from './TimePicker';
export type { TimePickerProps } from './TimePicker';

export { DateTimePicker } from './DateTimePicker';
export type { DateTimePickerProps } from './DateTimePicker';

export { DateRangePicker, DEFAULT_DATE_RANGE_SHORTCUTS } from './DateRangePicker';
export type { DateRangePickerProps, DateRangeShortcut } from './DateRangePicker';

export { TimeRangePicker } from './TimeRangePicker';
export type { TimeRangePickerProps } from './TimeRangePicker';

export { DateTimeRangePicker } from './DateTimeRangePicker';
export type { DateTimeRangePickerProps } from './DateTimeRangePicker';

// ChatInputBox
export { ChatInputBox } from './ChatInputBox';
export type { ChatInputBoxProps, ChatInputAttachment, ChatInputMention, MentionSuggestion } from './ChatInputBox';

// AgenticSteps
export { AgenticSteps, StepHeader, AgenticStep } from './AgenticSteps';
export type { AgenticStepsProps, StepHeaderProps, AgenticStepProps, AgenticStepStatus } from './AgenticSteps';

// AgenticCard
export { AgenticCard } from './AgenticCard';
export type { AgenticCardProps } from './AgenticCard';

// MessageComposer
export { MessageComposer } from './MessageComposer';
export type { MessageComposerProps, MessageComposerOption } from './MessageComposer';

// AgenticCard feedback
export { FeedbackActions, MessageActions } from './AgenticCard';
export type {
  FeedbackActionsProps,
  FeedbackReaction,
  FeedbackReason,
  FeedbackSubmission,
  MessageActionsProps,
} from './AgenticCard';

// AISuite
export { AISuite, UserMessageBubble, AssistantTextMessage, AISuiteEmptyStateView, AISuiteDisclaimerView, AISuiteSuggestions } from './AISuite';
export type {
  AISuiteProps,
  AISuiteMessage,
  AISuiteUserTextMessage,
  AISuiteAssistantTextMessage,
  AISuiteAgenticStepsMessage,
  AISuiteAgenticCardMessage,
  AISuiteMessageComposerMessage,
  AISuiteCustomMessage,
  AISuiteEmptyStateProps,
  AISuiteDisclaimerProps,
} from './AISuite';