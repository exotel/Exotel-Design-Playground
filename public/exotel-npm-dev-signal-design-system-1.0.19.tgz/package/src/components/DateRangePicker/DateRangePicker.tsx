/**
 * DateRangePicker Component
 *
 * Exotel-approved date range picker component that wraps MUI X DateRangePicker (pro).
 * Relies on the LocalizationProvider in ExotelThemeProvider.
 */

import { DateRangePicker as MuiDateRangePicker, type DateRangePickerProps as MuiDateRangePickerProps } from '@mui/x-date-pickers-pro/DateRangePicker';
import { forwardRef, useMemo } from 'react';
import { mergePickerTextFieldSlotProps } from '../../functions/mergePickerTextFieldSlotProps';
import { FieldWrapper } from '../FieldLabel';
import { DEFAULT_DATE_RANGE_SHORTCUTS, type DateRangeShortcut } from './dateRangeShortcuts';

export interface DateRangePickerProps extends Omit<MuiDateRangePickerProps, 'ref'> {
  /** External label rendered above the picker. */
  label?: React.ReactNode;
  /**
   * Enable the shortcuts panel for quick date range selection.
   * - `true` uses the built-in default shortcuts (Today, Yesterday, Last 7 Days, etc.)
   * - Pass a custom array of `DateRangeShortcut` items for full control.
   * - `false` / `undefined` disables shortcuts.
   * @default true
   */
  shortcuts?: boolean | DateRangeShortcut[];
  /** The size of the picker input. Matches TextField sizes. */
  size?: 'small' | 'medium' | 'large';
  /** Placeholder text inside the input. Derived from `label` when omitted. */
  placeholder?: string;
}

export const DateRangePicker = forwardRef<HTMLDivElement, DateRangePickerProps>(
  (props, ref) => {
    const { label, shortcuts = true, size = 'medium', placeholder, slotProps, ...rest } = props;

    const mergedSlotProps = useMemo(() => {
      const result: Record<string, unknown> = mergePickerTextFieldSlotProps(
        label,
        size,
        placeholder,
        slotProps,
      );

      if (shortcuts) {
        const items = shortcuts === true ? DEFAULT_DATE_RANGE_SHORTCUTS : shortcuts;
        result.shortcuts = {
          items,
          ...slotProps?.shortcuts,
        };
      }

      return result;
    }, [shortcuts, size, slotProps]);

    return (
      <FieldWrapper label={label}>
        <MuiDateRangePicker ref={ref} slotProps={mergedSlotProps as MuiDateRangePickerProps['slotProps']} {...rest} />
      </FieldWrapper>
    );
  }
);

DateRangePicker.displayName = 'DateRangePicker';
