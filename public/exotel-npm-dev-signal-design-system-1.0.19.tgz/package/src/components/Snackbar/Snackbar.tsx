/**
 * Snackbar Component
 * 
 * Exotel-approved snackbar component that wraps MUI's Snackbar.
 * 
 * @deprecated Use ToastProvider instead.
 */

import MuiSnackbar, { type SnackbarProps as MuiSnackbarProps } from '@mui/material/Snackbar';
import { forwardRef } from 'react';

export interface SnackbarProps extends Omit<MuiSnackbarProps, 'ref'> {
  children?: React.ReactNode;
}

/**
 * @deprecated Use ToastProvider instead.
 */
export const Snackbar = forwardRef<HTMLDivElement, SnackbarProps>(
  (props, ref) => <MuiSnackbar ref={ref} {...props} />
);

Snackbar.displayName = 'Snackbar';
