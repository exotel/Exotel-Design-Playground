/**
 * Menu Component
 * 
 * Exotel-approved menu component that wraps MUI's Menu.
 */

import MuiMenu, { type MenuProps as MuiMenuProps } from '@mui/material/Menu';
import { forwardRef } from 'react';

export interface MenuProps extends Omit<MuiMenuProps, 'ref'> {
  children?: React.ReactNode;
}

export const Menu = forwardRef<HTMLDivElement, MenuProps>(
  (props, ref) => <MuiMenu ref={ref} {...props} />
);

Menu.displayName = 'Menu';
