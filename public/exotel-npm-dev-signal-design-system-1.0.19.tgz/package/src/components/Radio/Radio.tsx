/**
 * Radio Component
 * 
 * Exotel-approved radio component that wraps MUI's Radio.
 */

import MuiRadio, { type RadioProps as MuiRadioProps } from '@mui/material/Radio';
import { forwardRef } from 'react';

export interface RadioProps extends Omit<MuiRadioProps, 'ref'> {
  checked?: boolean;
  disabled?: boolean;
  onChange?: (event: React.ChangeEvent<HTMLInputElement>, checked: boolean) => void;
}

export const Radio = forwardRef<HTMLButtonElement, RadioProps>(
  (props, ref) => <MuiRadio ref={ref} {...props} />
);

Radio.displayName = 'Radio';
