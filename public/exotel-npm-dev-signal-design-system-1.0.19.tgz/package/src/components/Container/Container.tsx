/**
 * Container Component
 * 
 * Exotel-approved container component that wraps MUI's Container.
 */

import MuiContainer, { type ContainerProps as MuiContainerProps } from '@mui/material/Container';
import { forwardRef } from 'react';

export interface ContainerProps extends Omit<MuiContainerProps, 'ref'> {
  children?: React.ReactNode;
}

export const Container = forwardRef<HTMLDivElement, ContainerProps>(
  (props, ref) => <MuiContainer ref={ref} {...props} />
);

Container.displayName = 'Container';
