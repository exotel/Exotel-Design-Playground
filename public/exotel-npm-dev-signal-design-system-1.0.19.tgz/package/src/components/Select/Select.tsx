/**
 * Select Component
 *
 * Exotel-approved select component. Renders an external label above an
 * outlined field via TextField, consistent with Autocomplete.
 */

import { forwardRef } from 'react';
import { TextField, type TextFieldProps } from '../TextField';

export interface SelectProps extends Omit<TextFieldProps, 'select' | 'multiline'> {
  children?: React.ReactNode;
  /**
   * Placeholder text when no value is selected. Derived from `label` when omitted.
   * Pass an empty string to disable the default placeholder.
   */
  placeholder?: string;
}

export const Select = forwardRef<HTMLDivElement, SelectProps>((props, ref) => {
  const { children, ...rest } = props;

  return (
    <TextField ref={ref} select {...rest}>
      {children}
    </TextField>
  );
});

Select.displayName = 'Select';
