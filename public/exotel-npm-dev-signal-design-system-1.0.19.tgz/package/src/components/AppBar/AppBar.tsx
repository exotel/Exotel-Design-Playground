import { Box, Toolbar } from '../../components';
import MuiAppBar, { type AppBarProps as MuiAppBarProps } from '@mui/material/AppBar';
import { forwardRef } from 'react';
import { AppLauncher } from '../AppLauncher';
import type { LayoutMode, Product } from '../AppLauncher/types';
import { AvatarMenu } from '../AvatarMenu';
import type { AvatarMenuGroup, AvatarMenuFooterInfo, ThemeMode } from '../AvatarMenu/types';
import { Icon } from '../Icon';
import type { IconName } from '../Icon';
import { IconButton } from '../IconButton';

export interface AppBarProps extends Omit<MuiAppBarProps, 'ref'> {
  /** Layout mode for the AppLauncher. Omit `appLauncherProducts` to hide the launcher entirely. */
  appLauncherType?: LayoutMode;
  /** Product list rendered inside the AppLauncher. Required to show the launcher. */
  appLauncherProducts?: Product[];
  /** Icon for the AppLauncher trigger button. */
  appLauncherIconName?: IconName;
  /** Full name used to derive initials and avatar background colour. */
  avatarName: string;
  /** Size of the avatar trigger. @default 'small' */
  avatarSize?: 'small' | 'medium' | 'large';
  /** Grouped menu items rendered inside the AvatarMenu popup. */
  avatarMenuGroups: AvatarMenuGroup[];
  /** Static info rows displayed in the AvatarMenu footer (e.g. last login, version). */
  avatarFooterInfo: AvatarMenuFooterInfo[];
  /** Currently active theme mode — highlights the selected option in the Theme submenu. */
  avatarSelectedTheme: ThemeMode;
  /** Called when the user picks a theme option in the Theme submenu. */
  onAvatarThemeChange: (mode: ThemeMode) => void;
  /** Called when the Logout row is clicked. */
  onAvatarLogout: () => void;
  /**
   * Brand logo — either a URL string (renders as <img>) or a React node
   * (renders as-is, e.g. an inline <svg>).
   */
  brandLogo: string | React.ReactNode;
  /** Alt text used when brandLogo is a URL string. */
  brandLogoAlt?: string;
  /** Style applied to the brand logo container. */
  brandLogoStyle?: React.CSSProperties;
  /** Called when the notification bell is clicked. */
  onNotificationClick?: React.MouseEventHandler<HTMLButtonElement>;
}

export const AppBar = forwardRef<HTMLDivElement, AppBarProps>(
  (
    {
      appLauncherType = 'default',
      appLauncherProducts,
      appLauncherIconName,
      avatarName,
      avatarSize,
      avatarMenuGroups,
      avatarFooterInfo,
      avatarSelectedTheme,
      onAvatarThemeChange,
      onAvatarLogout,
      brandLogo,
      brandLogoAlt = 'Brand logo',
      brandLogoStyle,
      onNotificationClick,
      ...rest
    },
    ref,
  ) => {
    const logoNode =
      typeof brandLogo === 'string' ? (
        <Box
          component="img"
          src={brandLogo}
          alt={brandLogoAlt}
          sx={{ width: '96px', height: '24px', ...brandLogoStyle }}
        />
      ) : (
        brandLogo
      );

    return (
      <MuiAppBar
        ref={ref}
        elevation={0}
        position="static"
        sx={(theme) => ({
          backgroundColor: `${theme.vars?.palette?.surface?.elevation1} !important`,
          backgroundImage: 'none',
          boxShadow: 'none',
        })}
        {...rest}
      >
        <Toolbar sx={{ padding: '0 10px' }}>
          {/* Left section: app launcher + brand logo */}
          <Box display="flex" alignItems="center" gap={1.5} flexGrow={1}>
            {appLauncherProducts && (
              <AppLauncher
                type={appLauncherType}
                products={appLauncherProducts}
                iconName={appLauncherIconName}
              />
            )}
            {logoNode}
          </Box>

          {/* Right section: notification + avatar menu */}
          <Box display="flex" alignItems="center" gap={0.5}>
            <IconButton
              aria-label="Notifications"
              onClick={onNotificationClick}
              sx={{ color: 'text.secondary' }}
            >
              <Icon name="bell-ringing" size="md" color="currentColor" />
            </IconButton>
            <AvatarMenu
              avatarName={avatarName}
              size={avatarSize}
              menuGroups={avatarMenuGroups}
              footerInfo={avatarFooterInfo}
              selectedTheme={avatarSelectedTheme}
              onThemeChange={onAvatarThemeChange}
              onLogout={onAvatarLogout}
            />
          </Box>
        </Toolbar>
      </MuiAppBar>
    );
  },
);

AppBar.displayName = 'AppBar';
