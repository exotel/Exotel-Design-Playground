// url=https://www.figma.com/design/CiTSqZD3DKtMu91owRSkZW/Signal-Design-System?node-id=11545-171494
// source=src/components/AppBar/AppBar.tsx
// component=AppBar
// Frame https://www.figma.com/design/CiTSqZD3DKtMu91owRSkZW/Signal-Design-System?node-id=11501-185971 uses instance of this <AppBar> (main: 11545:171494).
import figma from 'figma';

const instance = figma.selectedInstance;

/** Figma <AppBar> currently only exposes Property 1 (Default). */
const property1 = instance.getEnum('Property 1', {
  Default: 'default',
});

export default {
  example: figma.code`
    <AppBar
      appLauncherProps={{
        type: 'default',
        products: [],
      }}
      avatarMenuProps={{
        avatarName: 'User',
        menuGroups: [
          {
            id: 'main',
            items: [{ id: 'logout', label: 'Logout', onClick: () => {} }],
          },
        ],
        footerInfo: [],
        selectedTheme: 'system',
        onThemeChange: () => {},
        onLogout: () => {},
      }}
      brandLogo="https://example.com/brand.svg"
      brandLogoAlt="Brand"
      onNotificationClick={() => {}}
    />
  `,
  imports: ['import { AppBar } from "@exotel-npm-dev/signal-design-system"'],
  id: 'app-bar',
  metadata: {
    nestable: false,
    props: { property1 },
  },
};
