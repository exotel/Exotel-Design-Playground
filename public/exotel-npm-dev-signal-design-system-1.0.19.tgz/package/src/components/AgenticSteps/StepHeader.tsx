import { forwardRef, useState, useCallback } from 'react';
import { Box, Typography, Collapse, IconButton } from '../../components';
import { keyframes } from '@mui/material/styles';
import { Icon } from '../Icon';
import type { StepHeaderProps, AgenticStepStatus } from './types';

const pulse = keyframes`
  0%, 80%, 100% { opacity: 0.3; }
  40% { opacity: 1; }
`;

function StatusIcon({ status }: { status: AgenticStepStatus }) {
  if (status === 'loading') {
    return (
      <Box
        display="flex"
        alignItems="center"
        justifyContent="center"
        width={28}
        height={28}
        gap="3px"
      >
        {[0, 1, 2, 3].map((i) => (
          <Box
            key={i}
            width={5}
            height={5}
            borderRadius="50%"
            bgcolor="primary.main"
            sx={{
              animation: `${pulse} 1.4s ease-in-out infinite`,
              animationDelay: `${i * 0.16}s`,
            }}
          />
        ))}
      </Box>
    );
  }

  if (status === 'success') {
    return (
      <Box
        display="flex"
        alignItems="center"
        justifyContent="center"
        width={28}
        height={28}
      >
        <Icon name="checks" size="sm" weight='bold' color="var(--mui-palette-success-main, #2e7d32)" />
      </Box>
    );
  }

  return (
    <Box
      display="flex"
      alignItems="center"
      justifyContent="center"
      width={28}
      height={28}
    >
      <Icon name="warning-circle" size="sm" weight='bold' color="var(--mui-palette-error-main, #d32f2f)" />
    </Box>
  );
}

export const StepHeader = forwardRef<HTMLDivElement, StepHeaderProps>(
  (
    {
      title,
      status = 'loading',
      defaultExpanded = true,
      expanded: controlledExpanded,
      onExpandChange,
      sx,
      children,
    },
    ref,
  ) => {
    const [internalExpanded, setInternalExpanded] = useState(defaultExpanded);
    const isExpanded = controlledExpanded ?? internalExpanded;

    const handleToggle = useCallback(() => {
      const next = !isExpanded;
      setInternalExpanded(next);
      onExpandChange?.(next);
    }, [isExpanded, onExpandChange]);

    return (
      <Box
        ref={ref}
        display="flex"
        flexDirection="column"
        width="100%"
        sx={sx}
      >
        <Box
          onClick={handleToggle}
          display="flex"
          alignItems="center"
          gap={1.5}
          px={1}
          py={0.75}
          borderRadius={1}
          bgcolor="background.paper"
          sx={{
            cursor: 'pointer',
            '&:hover': {
              bgcolor: 'action.hover',
            },
          }}
        >
          <StatusIcon status={status} />
          <Typography
            variant="body2"
            sx={{
              flex: 1,
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap',
              color: 'text.primary',
            }}
          >
            {title}
          </Typography>
          <IconButton
            size="small"
            tabIndex={-1}
            sx={{
              p: 0,
              transform: isExpanded ? 'rotate(180deg)' : 'rotate(0deg)',
              transition: 'transform 0.2s ease-in-out',
            }}
          >
            <Icon name="caret-down" size="xs" weight='fill' />
          </IconButton>
        </Box>

        <Collapse in={isExpanded} timeout="auto" unmountOnExit>
          <Box display="flex" flexDirection="column">
            {children}
          </Box>
        </Collapse>
      </Box>
    );
  },
);

StepHeader.displayName = 'StepHeader';
