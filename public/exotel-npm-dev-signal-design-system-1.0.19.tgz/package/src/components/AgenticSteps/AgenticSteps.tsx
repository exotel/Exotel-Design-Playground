import { forwardRef } from 'react';
import { Box } from '../../components';
import type { AgenticStepsProps } from './types';

/**
 * AgenticSteps — container for StepHeader + AgenticStep components.
 *
 * Renders a bordered, rounded card that groups a collapsible header
 * (showing overall status) with individual processing steps.
 *
 * ```tsx
 * <AgenticSteps>
 *   <StepHeader title="Thinking" status="loading">
 *     <AgenticStep id="1" title="Analysing Request" status="loading" />
 *     <AgenticStep id="2" title="Building Plan" status="success" resultContent={<p>Done</p>} />
 *   </StepHeader>
 * </AgenticSteps>
 * ```
 */
export const AgenticSteps = forwardRef<HTMLDivElement, AgenticStepsProps>(
  ({ sx, children }, ref) => {
    return (
      <Box
        ref={ref}
        display="flex"
        flexDirection="column"
        alignItems="center"
        borderRadius={1}
        border={1}
        borderColor="divider"
        bgcolor="background.paper"
        overflow="hidden"
        sx={sx}
      >
        {children}
      </Box>
    );
  },
);

AgenticSteps.displayName = 'AgenticSteps';
