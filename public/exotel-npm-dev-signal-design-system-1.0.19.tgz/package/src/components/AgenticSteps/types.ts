import type { ReactNode } from 'react';
import type { SxProps, Theme } from '@mui/material/styles';

export type AgenticStepStatus = 'loading' | 'success' | 'failure';

export interface AgenticStepProps {
  /**
   * Unique identifier for the step
   */
  id: string;
  /**
   * Title displayed in the step row
   */
  title: string;
  /**
   * Current status of the step
   * @default 'loading'
   */
  status?: AgenticStepStatus;
  /**
   * Whether the step content is expanded
   * @default false
   */
  defaultExpanded?: boolean;
  /**
   * Controlled expanded state
   */
  expanded?: boolean;
  /**
   * Callback when expand state changes
   */
  onExpandChange?: (expanded: boolean) => void;
  /**
   * Result content displayed when the step is expanded
   */
  resultContent?: ReactNode;
  /**
   * Override styles
   */
  sx?: SxProps<Theme>;
}

export interface StepHeaderProps {
  /**
   * Title displayed in the header
   */
  title: string;
  /**
   * Current status of the header
   * @default 'loading'
   */
  status?: AgenticStepStatus;
  /**
   * Whether the header content (steps) is expanded
   * @default true
   */
  defaultExpanded?: boolean;
  /**
   * Controlled expanded state
   */
  expanded?: boolean;
  /**
   * Callback when expand state changes
   */
  onExpandChange?: (expanded: boolean) => void;
  /**
   * Override styles
   */
  sx?: SxProps<Theme>;
  /**
   * Child steps
   */
  children?: ReactNode;
}

export interface AgenticStepsProps {
  /**
   * Override styles for the root container
   */
  sx?: SxProps<Theme>;
  /**
   * Child StepHeader and Step components
   */
  children?: ReactNode;
}
