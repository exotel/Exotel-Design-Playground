import { forwardRef, useState, useCallback } from 'react';
import { Box, Typography, Collapse, CircularProgress, IconButton } from '../../components';
import { Icon } from '../Icon';
import type { AgenticStepProps, AgenticStepStatus } from './types';

function StepStatusIcon({ status }: { status: AgenticStepStatus }) {
  if (status === 'loading') {
    return <CircularProgress size={16} thickness={5} />;
  }

  if (status === 'success') {
    return (
      <Icon
        name="check"
        size="xs"
        weight="bold"
        color="var(--mui-palette-success-main, #2e7d32)"
      />
    );
  }

  return (
    <Icon
      name="x"
      size="xs"
      weight="bold"
      color="var(--mui-palette-error-main, #d32f2f)"
    />
  );
}

export const AgenticStep = forwardRef<HTMLDivElement, AgenticStepProps>(
  (
    {
      title,
      status = 'loading',
      defaultExpanded = false,
      expanded: controlledExpanded,
      onExpandChange,
      resultContent,
      sx,
    },
    ref,
  ) => {
    const [internalExpanded, setInternalExpanded] = useState(defaultExpanded);
    const isExpanded = controlledExpanded ?? internalExpanded;
    const hasContent = !!resultContent;

    const handleToggle = useCallback(() => {
      if (!hasContent) return;
      const next = !isExpanded;
      setInternalExpanded(next);
      onExpandChange?.(next);
    }, [isExpanded, onExpandChange, hasContent]);

    return (
      <Box
        ref={ref}
        display="flex"
        flexDirection="column"
        width="100%"
        sx={sx}
      >
        <Box
          onClick={handleToggle}
          display="flex"
          alignItems="center"
          gap={1}
          px={1}
          py={0.75}
          bgcolor="surface.elevation0"
          sx={{
            cursor: hasContent ? 'pointer' : 'default',
            '&:hover': hasContent
              ? { bgcolor: 'action.hover' }
              : {},
          }}
        >
          <StepStatusIcon status={status} />
          <Typography
            variant="body2"
            sx={{
              flex: 1,
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap',
              color: 'text.primary',
              fontWeight: 500,
              letterSpacing: '0.1px',
            }}
          >
            {title}
          </Typography>
          {hasContent && (
            <IconButton
              size="small"
              tabIndex={-1}
              sx={{
                p: 0,
                transform: isExpanded ? 'rotate(180deg)' : 'rotate(0deg)',
                transition: 'transform 0.2s ease-in-out',
              }}
            >
              <Icon name="caret-down" size="xs" weight='fill' />
            </IconButton>
          )}
        </Box>

        {hasContent && (
          <Collapse in={isExpanded} timeout="auto" unmountOnExit>
            <Box
              px={1}
              py={1.5}
              bgcolor="background.paper"
              color="text.secondary"
              sx={{
                typography: 'body2',
                '& ul': {
                  m: 0,
                  pl: 2.5,
                },
                '& li': {
                  mb: 0.25,
                },
                '& p': {
                  m: 0,
                  lineHeight: 1.6,
                },
              }}
            >
              {resultContent}
            </Box>
          </Collapse>
        )}
      </Box>
    );
  },
);

AgenticStep.displayName = 'AgenticStep';
