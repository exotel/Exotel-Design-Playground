/**
 * Stack Component
 * 
 * Exotel-approved stack component that wraps MUI's Stack.
 */

import MuiStack, { type StackProps as MuiStackProps } from '@mui/material/Stack';
import { forwardRef } from 'react';

export interface StackProps extends Omit<MuiStackProps, 'ref'> {
  children?: React.ReactNode;
}

export const Stack = forwardRef<HTMLDivElement, StackProps>(
  (props, ref) => <MuiStack ref={ref} {...props} />
);

Stack.displayName = 'Stack';
