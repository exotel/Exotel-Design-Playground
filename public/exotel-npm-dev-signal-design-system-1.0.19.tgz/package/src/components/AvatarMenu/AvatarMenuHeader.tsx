import { Avatar } from '../Avatar';
import { Box } from '../Box';
import { Typography } from '../Typography';
import { getAvatarColors, getInitials } from '../../functions';

interface AvatarMenuHeaderProps {
  avatarName: string;
}

export function AvatarMenuHeader({ avatarName }: AvatarMenuHeaderProps) {
  const avatarColors = getAvatarColors(avatarName);

  return (
    <Box
      display="flex"
      alignItems="center"
      gap={1}
      bgcolor="action.hover"
      borderRadius={1}
      p={0.5}
      mb={0.25}
    >
      <Avatar
        variant="rounded"
        sx={{
          width: 32,
          height: 32,
          fontSize: 14,
          fontWeight: 600,
          ...avatarColors,
        }}
      >
        {getInitials(avatarName)}
      </Avatar>
      <Typography variant="label3" noWrap>
        {avatarName}
      </Typography>
    </Box>
  );
}
