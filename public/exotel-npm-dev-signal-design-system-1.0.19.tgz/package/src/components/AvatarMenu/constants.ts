/** Avatar menu rows inherit dense MenuItem spacing and body2 labels from theme; keep sx minimal. */
export const menuItemSx = {} as const;

export const avatarSizeMap = {
  small: 32,
  medium: 40,
  large: 48,
} as const;
