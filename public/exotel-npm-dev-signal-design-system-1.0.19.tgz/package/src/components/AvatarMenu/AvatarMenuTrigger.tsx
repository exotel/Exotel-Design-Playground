import { styled } from '@mui/material/styles';
import { Avatar } from '../Avatar';
import { Badge } from '../Badge';
import { Box } from '../Box';
import { getAvatarColors, getInitials } from '../../functions';
import { avatarSizeMap } from './constants';
import { Typography } from '../Typography';

const StyledBadge = styled(Badge)(({ theme }) => ({
  '& .MuiBadge-badge': {
    backgroundColor: '#44b700',
    color: '#44b700',
    boxShadow: `0 0 0 2px ${theme.palette.background.paper}`,
    width: 10,
    height: 10,
    borderRadius: '50%',
    minWidth: 'unset',
    padding: 0,
    bottom: 4,
    right: 4,
  },
}));

interface AvatarMenuTriggerProps {
  avatarName: string;
  size?: 'small' | 'medium' | 'large';
  open: boolean;
  onOpen: (event: React.MouseEvent<HTMLDivElement>) => void;
  onKeyDown: (event: React.KeyboardEvent<HTMLDivElement>) => void;
}

export function AvatarMenuTrigger({ avatarName, size = 'medium', open, onOpen, onKeyDown }: AvatarMenuTriggerProps) {
  const avatarSize = avatarSizeMap[size];
  const avatarColors = getAvatarColors(avatarName);

  return (
    <Box
      role="button"
      tabIndex={0}
      aria-label="Open user menu"
      aria-haspopup="true"
      aria-expanded={open}
      onClick={onOpen}
      onKeyDown={onKeyDown}
      display="inline-flex"
      sx={{ cursor: 'pointer' }}
    >
      <StyledBadge
        overlap="circular"
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
        variant="dot"
      >
        <Avatar
          variant="rounded"
          sx={{
            ...avatarColors,
            cursor: 'pointer',
            width: avatarSize,
            height: avatarSize,
          }}
        >
          <Typography variant="title3" color="inherit">
            {getInitials(avatarName)}
          </Typography>
        </Avatar>
      </StyledBadge>
    </Box>
  );
}
