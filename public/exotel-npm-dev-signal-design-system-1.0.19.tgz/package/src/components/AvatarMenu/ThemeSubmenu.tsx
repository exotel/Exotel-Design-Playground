import lightModeSvg from '../../assets/light-mode.svg';
import darkModeSvg from '../../assets/dark-mode.svg';
import sameAsSystemSvg from '../../assets/same-as-system.svg';
import { Box } from '../Box';
import { Popover } from '../Popover';
import { Typography } from '../Typography';
import type { ThemeMode } from './types';

const THEME_OPTIONS: { mode: ThemeMode; label: string; src: string }[] = [
  { mode: 'light',  label: 'Light Mode',     src: lightModeSvg },
  { mode: 'dark',   label: 'Dark Mode',      src: darkModeSvg },
  { mode: 'system', label: 'Same as System', src: sameAsSystemSvg },
];

interface ThemeSubmenuProps {
  anchorEl: HTMLElement | null;
  selectedTheme: ThemeMode;
  onSelect: (mode: ThemeMode) => void;
  onClose: () => void;
}

export function ThemeSubmenu({ anchorEl, selectedTheme, onSelect, onClose }: ThemeSubmenuProps) {
  return (
    <Popover
      open={Boolean(anchorEl)}
      anchorEl={anchorEl}
      onClose={onClose}
      anchorOrigin={{ vertical: 'top', horizontal: 'left' }}
      transformOrigin={{ vertical: 'top', horizontal: 'right' }}
      slotProps={{
        paper: {
          elevation: 4,
          sx: {
            overflow: 'hidden',
            p: 0.5,
            display: 'flex',
            flexDirection: 'column',
            gap: 0.5,
            transform: 'translateX(-7px) !important',
          },
        },
      }}
    >
      {THEME_OPTIONS.map(({ mode, label, src }) => {
        const isSelected = selectedTheme === mode;
        return (
          <Box
            key={mode}
            role="button"
            onClick={() => { onSelect(mode); onClose(); }}
            display="flex"
            alignItems="center"
            borderRadius={1}
            gap={1}
            px={1}
            py={0.5}
            bgcolor={isSelected ? 'action.selected' : 'transparent'}
            sx={{
              cursor: 'pointer',
              '&:hover': { bgcolor: isSelected ? undefined : 'action.hover' },
            }}
          >
            <img
              src={src}
              alt={label}
              width={80}
              height={48}
              style={{ display: 'block', borderRadius: 4, flexShrink: 0 }}
            />
            <Typography
              variant="body2"
              fontWeight={isSelected ? 600 : 400}
              color={isSelected ? 'primary.main' : 'text.primary'}
              noWrap
            >
              {label}
            </Typography>
          </Box>
        );
      })}
    </Popover>
  );
}
