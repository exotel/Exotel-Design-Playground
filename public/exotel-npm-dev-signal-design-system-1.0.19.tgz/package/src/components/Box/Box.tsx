/**
 * Box Component
 *
 * Re-exports MUI's Box directly so the polymorphic `component` prop keeps
 * working (e.g. `<Box component="img" src="…" />` infers img attributes).
 */

export { default as Box } from '@mui/material/Box';
export type { BoxProps } from '@mui/material/Box';
