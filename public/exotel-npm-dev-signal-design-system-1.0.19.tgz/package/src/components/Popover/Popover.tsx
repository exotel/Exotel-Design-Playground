/**
 * Popover Component
 * 
 * Exotel-approved popover component that wraps MUI's Popover.
 */

import MuiPopover, { type PopoverProps as MuiPopoverProps } from '@mui/material/Popover';
import { forwardRef } from 'react';

export interface PopoverProps extends Omit<MuiPopoverProps, 'ref'> {
  children?: React.ReactNode;
}

export const Popover = forwardRef<HTMLDivElement, PopoverProps>(
  (props, ref) => <MuiPopover ref={ref} {...props} />
);

Popover.displayName = 'Popover';
