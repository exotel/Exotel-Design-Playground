/**
 * Button Component
 * 
 * Exports the Exotel Button component that wraps MUI's Button.
 */

export { Button } from './Button';
export type { ButtonProps } from './Button';
