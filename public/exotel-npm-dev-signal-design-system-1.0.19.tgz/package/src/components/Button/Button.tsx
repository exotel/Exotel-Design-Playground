/**
 * Button Component
 * 
 * Exotel-approved button component that wraps MUI's Button.
 * Provides consistent styling and behavior across Exotel applications.
 * 
 * Usage:
 * ```tsx
 * import { Button } from '@exotel/design-system';
 * 
 * <Button variant="contained" color="primary">
 *   Click me
 * </Button>
 * 
 * <Button variant="tonal" color="primary">
 *   Tonal button
 * </Button>
 * ```
 */

import MuiButton, { type ButtonProps as MuiButtonProps } from '@mui/material/Button';
import { forwardRef } from 'react';
import { Icon, type IconProps } from '../Icon';

/**
 * Button component props
 * Extends MUI ButtonProps with Exotel-specific variant support
 */
export interface ButtonProps extends Omit<MuiButtonProps, 'ref' | 'variant' | 'startIcon' | 'endIcon'> {
  /**
   * The content of the button
   */
  children?: React.ReactNode;
  /**
   * The variant of the button
   * - 'text': Text button (MUI native)
   * - 'outlined': Outlined button (MUI native)
   * - 'contained': Filled button (MUI native)
   * - 'tonal': Material 3 tonal button (Exotel custom)
   */
  variant?: 'text' | 'outlined' | 'contained' | 'tonal';
  /**
   * Start Icon
   * @deprecated It's deprecated by Exotel Design System. Use startIconProps instead
   */
  startIcon?: React.ReactNode;
  /**
   * End Icon
   * @deprecated It's deprecated by Exotel Design System. Use endIconProps instead
   */
  endIcon?: React.ReactNode;
  /**
   * Start Icon
   */
  startIconProps?: IconProps;
  /**
   * End Icon
   */
  endIconProps?: IconProps;
}

/**
 * Button component
 * 
 * Wraps MUI's Button component with Exotel-specific defaults and styling.
 * Supports Exotel's custom 'tonal' variant which maps to MUI's 'contained'
 * with special styling applied via theme overrides.
 */
export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant, startIconProps, endIconProps, ...props }, ref) => {
    // Map Exotel's 'tonal' variant to MUI's 'contained' variant
    // The theme will style it differently based on data-variant attribute
    const muiVariant = variant === 'tonal' ? 'contained' : variant;
    
    // Pass data-variant to ownerState for theme targeting
    // Also set it as a data attribute for CSS targeting if needed
    const buttonProps = variant === 'tonal' 
      ? { ...props, 'data-variant': 'tonal' as const }
      : props;
    
    return (
      <MuiButton
        ref={ref}
        variant={muiVariant}
        startIcon={startIconProps?.name ? <Icon {...startIconProps} /> : undefined}
        endIcon={endIconProps?.name ? <Icon {...endIconProps} /> : undefined}
        {...buttonProps}
      />
    );
  }
);

Button.displayName = 'Button';
