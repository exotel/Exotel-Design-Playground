// url=https://www.figma.com/design/CiTSqZD3DKtMu91owRSkZW/Signal-Design-System?node-id=6543-36744
// source=src/components/Button/Button.tsx
// component=Button
import figma from 'figma';

const instance = figma.selectedInstance;

const label = instance.getString('Label');

const size = instance.getEnum('Size', {
  Large: 'large',
  Medium: 'medium',
  Small: 'small',
});

const color = instance.getEnum('Color', {
  Primary: 'primary',
  Secondary: 'secondary',
  Error: 'error',
  Warning: 'warning',
  Info: 'info',
  Success: 'success',
  Inherit: 'inherit',
  'Inherit (white)': 'inherit',
});

const variant = instance.getEnum('Variant', {
  Contained: 'contained',
  Outlined: 'outlined',
  Text: 'text',
  Tonal: 'tonal',
});

const disabled = instance.getEnum('State', {
  Enabled: false,
  Hovered: false,
  Focused: false,
  Pressed: false,
  Disabled: true,
});

const showStartIcon = instance.getBoolean('Start Icon');
const showEndIcon = instance.getBoolean('End Icon');

const startSwap = showStartIcon ? instance.getInstanceSwap('↳ Start Icon') : null;
let startIconSnippet;
if (startSwap && startSwap.type === 'INSTANCE' && startSwap.hasCodeConnect()) {
  startIconSnippet = startSwap.executeTemplate().example;
}

const endSwap = showEndIcon ? instance.getInstanceSwap('↳ End Icon') : null;
let endIconSnippet;
if (endSwap && endSwap.type === 'INSTANCE' && endSwap.hasCodeConnect()) {
  endIconSnippet = endSwap.executeTemplate().example;
}

export default {
  example: figma.code`
    <Button
      variant="${variant}"
      size="${size}"
      color="${color}"
      ${disabled ? 'disabled' : ''}
      ${startIconSnippet ? figma.code`startIcon={${startIconSnippet}}` : ''}
      ${endIconSnippet ? figma.code`endIcon={${endIconSnippet}}` : ''}
    >
      ${label}
    </Button>
  `,
  imports: ['import { Button } from "@exotel-npm-dev/signal-design-system"'],
  id: 'button',
  metadata: {
    nestable: true,
  },
};
