import { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { DEFAULT_FONT } from "../../theme";
import type { FontKey } from "../../theme";
import { getMicPermission, subscribeToMicPermission } from "../../functions";

export interface UseFontReturn {
  fontKey: FontKey;
  setFont: (key: FontKey) => void;
}

export interface SignalContextValue {
  font: UseFontReturn;
  /**
   * Arbitrary consumer-provided data accessible anywhere inside the provider.
   * Pass via `ExotelThemeProvider`'s `contextData` prop.
   */
  data: Record<string, unknown>;
  micPermissionState: PermissionState;
}

const SignalContext = createContext<SignalContextValue | null>(null);

const FONT_STORAGE_KEY = "exotel-font";

function getStoredFont(fallback: FontKey): FontKey {
  try {
    const stored = localStorage.getItem(FONT_STORAGE_KEY);
    if (stored === "noto-sans" || stored === "ibm-plex-sans") return stored;
  } catch {
    /* SSR or private browsing */
  }
  return fallback;
}

export interface SignalContextProviderProps {
  children: ReactNode;
  defaultFont?: FontKey;
  data?: Record<string, unknown>;
}

export function SignalContextProvider({
  children,
  defaultFont = DEFAULT_FONT,
  data = {},
}: SignalContextProviderProps) {
  const [fontKey, setFontKey] = useState<FontKey>(() =>
    getStoredFont(defaultFont),
  );

  const setFont = (key: FontKey) => {
    setFontKey(key);
    try {
      localStorage.setItem(FONT_STORAGE_KEY, key);
    } catch {
      /* ignore */
    }
  };

  const [micPermissionState, setMicPermissionState] =
    useState<PermissionState>("prompt");

  useEffect(() => {
    let unsubscribe: (() => void) | false = false;

    (async () => {
      const permissionState = await getMicPermission();
      setMicPermissionState(permissionState);

      unsubscribe = await subscribeToMicPermission(function (this: PermissionStatus) {
        setMicPermissionState(this.state);
      });
    })();

    return () => {
      if (typeof unsubscribe === "function") unsubscribe();
    };
  }, []);

  const font = useMemo<UseFontReturn>(
    () => ({ fontKey, setFont }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [fontKey],
  );

  const value = useMemo<SignalContextValue>(
    () => ({ font, data, micPermissionState }),
    [font, data, micPermissionState],
  );

  return (
    <SignalContext.Provider value={value}>{children}</SignalContext.Provider>
  );
}

/**
 * Access the Signal Design System context from anywhere inside `<ExotelThemeProvider>`.
 *
 * Returns font state and any custom data passed via the `contextData` prop.
 */
export function useSignal(): SignalContextValue {
  const ctx = useContext(SignalContext);
  if (!ctx) {
    throw new Error("useSignal() must be used inside <ExotelThemeProvider>");
  }
  return ctx;
}

/**
 * Shorthand hook to access font state.
 * Equivalent to `useSignal().font`.
 */
export function useFont(): UseFontReturn {
  return useSignal().font;
}
