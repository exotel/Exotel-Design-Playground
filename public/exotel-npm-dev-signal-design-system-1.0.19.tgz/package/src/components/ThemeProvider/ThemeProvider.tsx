/**
 * ExotelThemeProvider, useThemeMode & useFont
 *
 * Usage in a consumer app:
 * ```tsx
 * import { ExotelThemeProvider, useThemeMode, useFont, useSignal } from '@exotel/design-system';
 *
 * function App() {
 *   return (
 *     <ExotelThemeProvider defaultMode="light" contextData={{ tenant: 'acme' }}>
 *       <ThemeToggle />
 *       <FontToggle />
 *       <AppContent />
 *     </ExotelThemeProvider>
 *   );
 * }
 *
 * function ThemeToggle() {
 *   const { mode, setMode, toggleMode } = useThemeMode();
 *   return <button onClick={toggleMode}>Current: {mode}</button>;
 * }
 *
 * function FontToggle() {
 *   const { fontKey, setFont } = useFont();
 *   return (
 *     <button onClick={() => setFont(fontKey === 'noto-sans' ? 'ibm-plex-sans' : 'noto-sans')}>
 *       Current font: {fontKey}
 *     </button>
 *   );
 * }
 *
 * function AppContent() {
 *   const { data } = useSignal();
 *   return <span>Tenant: {data.tenant as string}</span>;
 * }
 * ```
 */

import { useMemo, useEffect } from "react";
import type { ReactNode } from "react";
import { ThemeProvider, useColorScheme } from "@mui/material/styles";
import type { ThemeOptions } from "@mui/material/styles";
import CssBaseline from "@mui/material/CssBaseline";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { createExotelTheme, DEFAULT_FONT } from "../../theme";
import type { FontKey } from "../../theme";
import { SignalContextProvider, useSignal } from "./SignalContext";

export type ThemeMode = "light" | "dark" | "system";

export interface ExotelThemeProviderProps {
  children: ReactNode;
  /**
   * The initial color mode applied on first visit (before any user toggle).
   * - `'light'`  — start in light mode (default)
   * - `'dark'`   — start in dark mode
   * - `'system'` — follow the user's OS preference
   *
   * After the user changes the mode via `useThemeMode().setMode()`,
   * their choice is persisted and takes priority over this value.
   */
  defaultMode?: ThemeMode;
  /**
   * Initial font. Defaults to `"noto-sans"`.
   * Can be changed at runtime via `useFont().setFont()`.
   */
  defaultFont?: FontKey;
  /**
   * Locale string passed to the dayjs date adapter (e.g. "en", "de", "ja").
   * Controls formatting for all date/time picker components.
   */
  adapterLocale?: string;
  /**
   * Partial theme overrides deep-merged on top of the base Exotel theme.
   * Use this to extend palette colors, add component overrides, or
   * adjust typography without forking the design system theme.
   */
  themeOverrides?: ThemeOptions;
  /**
   * Arbitrary data accessible anywhere via `useSignal().data`.
   * Use this to pass global app-level context (tenant info, feature flags,
   * permissions, etc.) without creating additional providers.
   */
  contextData?: Record<string, unknown>;
}

/** Public hook return type for `useThemeMode`. */
export interface UseThemeModeReturn {
  /** Current resolved mode (`'light'` or `'dark'`). `undefined` during SSR. */
  mode: ThemeMode;
  /** Set the mode explicitly. */
  setMode: (mode: ThemeMode) => void;
  /** Toggle between light and dark. */
  toggleMode: () => void;
}

// ---------------------------------------------------------------------------
// Internal: syncs the defaultMode prop into MUI on mount
// ---------------------------------------------------------------------------

function InitialModeSync({ defaultMode }: { defaultMode: ThemeMode }) {
  const { setMode } = useColorScheme();
  useEffect(() => {
    setMode(defaultMode);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return null;
}

// ---------------------------------------------------------------------------
// Internal: reads fontKey from SignalContext and renders MUI ThemeProvider
// ---------------------------------------------------------------------------

const MODE_STORAGE_KEY = "exotel-mode";

interface ThemeShellProps {
  children: ReactNode;
  defaultMode: ThemeMode;
  themeOverrides?: ThemeOptions;
  adapterLocale?: string;
}

function ThemeShell({
  children,
  defaultMode,
  themeOverrides,
  adapterLocale,
}: ThemeShellProps) {
  const { font: { fontKey } } = useSignal();

  const theme = useMemo(
    () => createExotelTheme(fontKey, themeOverrides),
    [fontKey, themeOverrides],
  );

  return (
    <ThemeProvider
      theme={theme}
      defaultMode={defaultMode}
      modeStorageKey={MODE_STORAGE_KEY}
      noSsr
    >
      <InitialModeSync defaultMode={defaultMode} />
      <CssBaseline />
      <LocalizationProvider
        dateAdapter={AdapterDayjs}
        adapterLocale={adapterLocale}
      >
        {children}
      </LocalizationProvider>
    </ThemeProvider>
  );
}

// ---------------------------------------------------------------------------
// ExotelThemeProvider
// ---------------------------------------------------------------------------

export function ExotelThemeProvider({
  children,
  defaultMode = "light",
  defaultFont = DEFAULT_FONT,
  adapterLocale,
  themeOverrides,
  contextData = {},
}: ExotelThemeProviderProps) {
  return (
    <SignalContextProvider defaultFont={defaultFont} data={contextData}>
      <ThemeShell
        defaultMode={defaultMode}
        themeOverrides={themeOverrides}
        adapterLocale={adapterLocale}
      >
        {children}
      </ThemeShell>
    </SignalContextProvider>
  );
}
