/**
 * Icon Component
 *
 * Exotel-approved icon component that wraps Phosphor Icons.
 * Provides a consistent, string-based API for using icons across Exotel applications.
 *
 * Usage:
 * ```tsx
 * import { Icon } from '@exotel/design-system';
 *
 * <Icon name="phone" />
 * <Icon name="warning" weight="bold" />
 * <Icon name="check-circle" size="sm" />
 * ```
 */

import { forwardRef } from 'react';
import type { IconProps as PhosphorIconProps, IconWeight } from '@phosphor-icons/react';
import { iconRegistry, type IconName } from './iconRegistry';

export type IconSize = 'xs' | 'sm' | 'md' | 'lg';
export type IconWeightOption = 'regular' | 'bold' | 'fill' | 'light';

const sizeMap: Record<IconSize, number> = {
  xs: 16,
  sm: 20,
  md: 24,
  lg: 32,
};

const weightMap: Record<IconWeightOption, IconWeight> = {
  regular: 'regular',
  bold: 'bold',
  fill: 'fill',
  light: 'thin',
};

export interface IconProps extends Omit<PhosphorIconProps, 'size' | 'weight' | 'ref'> {
  /** The name of the icon to display. */
  name: IconName;
  /**
   * Size of the icon.
   * @default 'md'
   */
  size?: IconSize | number;
  /**
   * Weight/style of the icon.
   * @default 'regular'
   */
  weight?: IconWeightOption;
  /** Color of the icon. Defaults to theme text color. */
  color?: string;
}

export const Icon = forwardRef<SVGSVGElement, IconProps>(
  ({ name, size = 'md', weight = 'regular', color, style, ...props }, ref) => {
    const IconComponent = iconRegistry[name];

    if (!IconComponent) {
      console.warn(
        `Icon "${name}" not found in registry. Available icons: ${Object.keys(iconRegistry).join(', ')}`,
      );
      return null;
    }

    const iconSize = typeof size === 'string' ? sizeMap[size] : size;

    return (
      <IconComponent
        ref={ref}
        size={iconSize}
        weight={weightMap[weight]}
        color={color ?? 'currentColor'}
        style={{ display: 'block', ...style }}
        {...props}
      />
    );
  },
);

Icon.displayName = 'Icon';
