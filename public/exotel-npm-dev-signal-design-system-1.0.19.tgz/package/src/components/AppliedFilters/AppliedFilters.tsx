/**
 * AppliedFilters Component
 * 
 * Displays applied filters as chips with remove functionality,
 * "Clear All" button, and overflow handling with popup.
 */

import React, { useState, useRef } from 'react';
import { Chip } from '../Chip';
import { Button } from '../Button';
import { X } from '@phosphor-icons/react';
import { Box } from '../Box';
import { Paper } from '../Paper';
import { Popover } from '../Popover';
import { Typography } from '../Typography';
import { Divider } from '../Divider';

export interface AppliedFilter {
  /**
   * Unique identifier for the filter
   */
  id: string;
  /**
   * Filter label (e.g., "Campaign", "Status")
   */
  label: string;
  /**
   * Filter value(s) to display
   */
  value: string | string[];
  /**
   * Callback when filter is removed (optional if onRemove prop is provided at component level)
   */
  onRemove?: () => void;
}

export interface AppliedFiltersProps {
  /**
   * Array of applied filters
   */
  filters: AppliedFilter[];
  /**
   * Callback when "Clear All" is clicked
   */
  onClearAll: () => void;
  /**
   * Callback when an individual filter is removed (receives filterId)
   * If not provided, will use the onRemove callback from each filter object
   */
  onRemove?: (filterId: string) => void;
  /**
   * Maximum number of filters to show before truncating
   */
  maxVisible?: number;
  /**
   * Whether to show the component at all
   */
  show?: boolean;
}

export const AppliedFilters: React.FC<AppliedFiltersProps> = ({
  filters,
  onClearAll,
  onRemove,
  maxVisible = 4,
  show = true,
}) => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [isHoveringChip, setIsHoveringChip] = useState(false);
  const [isHoveringPopover, setIsHoveringPopover] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  if (!show || filters.length === 0) {
    return null;
  }

  const visibleFilters = filters.slice(0, maxVisible);
  const hiddenFilters = filters.slice(maxVisible);
  const hasHiddenFilters = hiddenFilters.length > 0;

  const open = (isHoveringChip || isHoveringPopover) && Boolean(anchorEl);

  const handleMoreClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
    setIsHoveringChip(true);
  };

  const handleChipMouseEnter = (event: React.MouseEvent<HTMLElement>) => {
    if (hasHiddenFilters) {
      setAnchorEl(event.currentTarget);
      setIsHoveringChip(true);
    }
  };

  const handleChipMouseLeave = () => {
    setIsHoveringChip(false);
  };

  const handlePopoverMouseEnter = () => {
    setIsHoveringPopover(true);
  };

  const handlePopoverMouseLeave = () => {
    setIsHoveringPopover(false);
  };

  const handleClose = () => {
    setIsHoveringChip(false);
    setIsHoveringPopover(false);
    setAnchorEl(null);
  };

  const handleFilterRemove = (filter: AppliedFilter) => {
    if (onRemove) {
      onRemove(filter.id);
    } else if (filter.onRemove) {
      filter.onRemove();
    }
  };

  const formatFilterValue = (value: string | string[]): string => {
    if (Array.isArray(value)) {
      if (value.length === 0) return '';
      if (value.length === 1) return value[0];
      return `${value[0]} +${value.length - 1}`;
    }
    return value;
  };

  const renderFilterChip = (filter: AppliedFilter, showFullValue: boolean = false) => {
    const displayValue = showFullValue && Array.isArray(filter.value)
      ? filter.value.join(', ')
      : formatFilterValue(filter.value);

    return (
      <Chip
        key={filter.id}
        label={`${filter.label}: ${displayValue}`}
        onDelete={() => handleFilterRemove(filter)}
        size="small"
      />
    );
  };

  return (
    <Box
      ref={containerRef}
      display="flex"
      alignItems="center"
      flexWrap="wrap"
      gap={1}
      pb={1}
    >
      <Typography
        variant="body2"
        fontWeight={600}
        color="text.secondary"
      >
        Applied Filters
      </Typography>

      {visibleFilters.map((filter) => renderFilterChip(filter))}

      {hasHiddenFilters && (
        <>
          <Chip
            label={`+${hiddenFilters.length} More`}
            size="small"
            onMouseEnter={handleChipMouseEnter}
            onMouseLeave={handleChipMouseLeave}
            onClick={handleMoreClick}
            variant='outlined'
          />
          <Popover
            open={open}
            anchorEl={anchorEl}
            onClose={handleClose}
            anchorOrigin={{
              vertical: 'bottom',
              horizontal: 'left',
            }}
            transformOrigin={{
              vertical: 'top',
              horizontal: 'left',
            }}
            slotProps={{
              paper: {
                onMouseEnter: handlePopoverMouseEnter,
                onMouseLeave: handlePopoverMouseLeave,
                sx: {
                  mt: 1,
                  minWidth: 300,
                  maxWidth: 500,
                  pointerEvents: 'auto',
                },
              } as any,
            }}
            sx={{
              pointerEvents: 'none',
            }}
          >
            <Paper elevation={4} sx={{ p: 2 }}>
              <Typography variant="label2" fontWeight={600} mb={1.5}>
                All Applied Filters
              </Typography>
              <Divider sx={{ mb: 1.5 }} />
              <Box display="flex" flexDirection="column" gap={1}>
                {filters.map((filter) => (
                  <Box
                    key={filter.id}
                    display="flex"
                    alignItems="center"
                    justifyContent="space-between"
                    py={0.5}
                  >
                    <Typography variant="body2">
                      <strong>{filter.label}:</strong>{' '}
                      {Array.isArray(filter.value)
                        ? filter.value.join(', ')
                        : filter.value}
                    </Typography>
                    <Box
                      component="button"
                      onClick={filter.onRemove}
                      sx={{
                        border: 'none',
                        background: 'transparent',
                        cursor: 'pointer',
                        display: 'flex',
                        alignItems: 'center',
                        padding: 0.5,
                        borderRadius: 0.5,
                        '&:hover': {
                          backgroundColor: 'action.hover',
                        },
                      }}
                    >
                      <X size={16} weight="bold" />
                    </Box>
                  </Box>
                ))}
              </Box>
            </Paper>
          </Popover>
        </>
      )}

      <Button
        variant="outlined"
        size="small"
        color='error'
        onClick={onClearAll}
      >
        Clear All
      </Button>
    </Box>
  );
};
