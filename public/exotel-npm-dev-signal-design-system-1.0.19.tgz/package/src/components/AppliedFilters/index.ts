/**
 * AppliedFilters Component
 * 
 * Displays applied filters with clear all functionality
 */

export { AppliedFilters } from './AppliedFilters';
export type { AppliedFiltersProps, AppliedFilter } from './AppliedFilters';
