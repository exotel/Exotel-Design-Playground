/**
 * FormField Component
 * 
 * Exotel-approved form field component with external labels.
 * Replaces floating label pattern with stable, external label positioning.
 * 
 * Usage:
 * ```tsx
 * import { FormField } from '@exotel/design-system';
 * 
 * <FormField
 *   label="Email"
 *   placeholder="Enter your email"
 *   helperText="We'll never share your email"
 *   required
 * />
 * ```
 */

import {
  FormControl,
  FormLabel,
  FormHelperText,
  OutlinedInput,
  InputAdornment,
} from '@mui/material';
import { forwardRef } from 'react';
import { resolveFieldPlaceholder } from '../../functions/resolveFieldPlaceholder';

export interface FormFieldProps {
  /**
   * The label text displayed above the input
   */
  label?: string;
  
  /**
   * The placeholder text inside the input
   */
  placeholder?: string;
  
  /**
   * Helper text displayed below the input
   */
  helperText?: React.ReactNode;
  
  /**
   * Error message (sets error state)
   */
  error?: boolean;
  
  /**
   * Whether the field is required
   */
  required?: boolean;
  
  /**
   * Whether the field is disabled
   */
  disabled?: boolean;
  
  /**
   * The size of the input
   * @default 'medium'
   */
  size?: 'small' | 'medium' | 'large';
  
  /**
   * The input type
   * @default 'text'
   */
  type?: string;
  
  /**
   * The input value
   */
  value?: string | number;
  
  /**
   * Default value for uncontrolled input
   */
  defaultValue?: string | number;
  
  /**
   * Change handler
   */
  onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
  
  /**
   * Start adornment (e.g., icon or prefix)
   */
  startAdornment?: React.ReactNode;
  
  /**
   * End adornment (e.g., icon or suffix)
   */
  endAdornment?: React.ReactNode;
  
  /**
   * Whether input is full width
   */
  fullWidth?: boolean;
  
  /**
   * Additional props for the input element
   */
  inputProps?: React.InputHTMLAttributes<HTMLInputElement>;
  
  /**
   * Additional props for FormControl
   */
  FormControlProps?: React.ComponentProps<typeof FormControl>;
  
  /**
   * Additional props for FormLabel
   */
  FormLabelProps?: React.ComponentProps<typeof FormLabel>;
  
  /**
   * Additional props for OutlinedInput
   */
  InputProps?: React.ComponentProps<typeof OutlinedInput>;
  
  /**
   * Additional props for FormHelperText
   */
  FormHelperTextProps?: React.ComponentProps<typeof FormHelperText>;
}

/**
 * FormField component
 * 
 * A form field with external label positioning.
 * Uses MUI FormControl, FormLabel, OutlinedInput, and FormHelperText.
 */
export const FormField = forwardRef<HTMLInputElement, FormFieldProps>(
  (
    {
      label,
      placeholder,
      helperText,
      error = false,
      required = false,
      disabled = false,
      size = 'medium',
      type = 'text',
      value,
      defaultValue,
      onChange,
      startAdornment,
      endAdornment,
      fullWidth = false,
      inputProps,
      FormControlProps,
      FormLabelProps,
      InputProps,
      FormHelperTextProps,
    },
    ref
  ) => {
    const resolvedPlaceholder = resolveFieldPlaceholder(label, placeholder, 'text');

    // Build InputProps with adornments
    const inputPropsWithAdornments: React.ComponentProps<typeof OutlinedInput> = {
      ...InputProps,
      startAdornment: startAdornment ? (
        <InputAdornment position="start">{startAdornment}</InputAdornment>
      ) : InputProps?.startAdornment,
      endAdornment: endAdornment ? (
        <InputAdornment position="end">{endAdornment}</InputAdornment>
      ) : InputProps?.endAdornment,
    };

    return (
      <FormControl
        fullWidth={fullWidth}
        error={error}
        disabled={disabled}
        required={required}
        {...FormControlProps}
      >
        {label && (
          <FormLabel required={required} {...FormLabelProps}>
            {label}
          </FormLabel>
        )}
        <OutlinedInput
          ref={ref}
          size={size}
          type={type}
          value={value}
          defaultValue={defaultValue}
          onChange={onChange}
          placeholder={resolvedPlaceholder}
          disabled={disabled}
          inputProps={inputProps}
          {...inputPropsWithAdornments}
        />
        {helperText && (
          <FormHelperText {...FormHelperTextProps}>
            {helperText}
          </FormHelperText>
        )}
      </FormControl>
    );
  }
);

FormField.displayName = 'FormField';
