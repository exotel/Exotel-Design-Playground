/**
 * DateTimePicker Component
 *
 * Exotel-approved date-time picker component that wraps MUI X DateTimePicker.
 * Relies on the LocalizationProvider in ExotelThemeProvider.
 */

import { DateTimePicker as MuiDateTimePicker, type DateTimePickerProps as MuiDateTimePickerProps } from '@mui/x-date-pickers/DateTimePicker';
import { forwardRef, useMemo } from 'react';
import { mergePickerTextFieldSlotProps } from '../../functions/mergePickerTextFieldSlotProps';
import { FieldWrapper } from '../FieldLabel';

export interface DateTimePickerProps extends Omit<MuiDateTimePickerProps, 'ref'> {
  /** The size of the picker input. Matches TextField sizes. */
  size?: 'small' | 'medium' | 'large';
  /** Placeholder text inside the input. Derived from `label` when omitted. */
  placeholder?: string;
}

export const DateTimePicker = forwardRef<HTMLDivElement, DateTimePickerProps>(
  (props, ref) => {
    const { label, size = 'medium', placeholder, slotProps, ...rest } = props;

    const mergedSlotProps = useMemo(
      () => mergePickerTextFieldSlotProps(label, size, placeholder, slotProps),
      [label, size, placeholder, slotProps],
    );

    return (
      <FieldWrapper label={label}>
        <MuiDateTimePicker ref={ref} slotProps={mergedSlotProps} {...rest} />
      </FieldWrapper>
    );
  }
);

DateTimePicker.displayName = 'DateTimePicker';
