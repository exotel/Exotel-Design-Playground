import { Icon } from "../../Icon";
import { IconButton } from "../../IconButton"

interface VoiceInputProps {
    disabled?: boolean;
    editableRef?: React.RefObject<HTMLDivElement>;
}

const VoiceInput = ({ disabled, editableRef }: VoiceInputProps) => {

    const handleVoiceInput = () => {
        // @ts-ignore
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition) {
            console.error('SpeechRecognition is not supported in this browser');
            return;
        }
        const recognition = new SpeechRecognition();
        recognition.lang = 'en-US';
        recognition.continuous = false;
        recognition.onresult = (event: any) => {
            const result = event.results[0][0].transcript;
            const currentText = editableRef?.current?.textContent ?? '';
            if (!editableRef?.current) return;
            editableRef.current.textContent = currentText + (currentText.at(-1) === ' ' || currentText.length === 0 ? result : (' ' + result));
        }
        recognition.onspeechend = () => {
            recognition.stop();
        };
        recognition.start();
    }

    return (
        <IconButton onClick={handleVoiceInput} size="small" disabled={disabled} aria-label="Voice input">
            <Icon name="microphone" size="sm" />
        </IconButton>
    )
}

export default VoiceInput;
