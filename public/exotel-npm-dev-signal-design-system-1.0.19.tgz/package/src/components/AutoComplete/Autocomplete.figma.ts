// url=https://www.figma.com/design/CiTSqZD3DKtMu91owRSkZW/Signal-Design-System?node-id=6570-49856
// source=src/components/AutoComplete/AutoComplete.tsx
// component=Autocomplete
import figma from 'figma';

const instance = figma.selectedInstance;

/** Figma <Autocomplete> exposes Multiple Value and Open on the root component. */
const multiple = instance.getEnum('Multiple Value', {
  False: false,
  True: true,
});

const open = instance.getEnum('Open', {
  False: false,
  True: true,
});

export default {
  example: figma.code`
    <Autocomplete
      id="autocomplete-demo"
      label="Label"
      multiple={${multiple}}
      open={${open}}
      options={[
        { label: 'Option 1' },
        { label: 'Option 2' },
        { label: 'Option 3' },
      ]}
      getOptionLabel={(option) => option.label}
    />
  `,
  imports: ['import { Autocomplete } from "@exotel-npm-dev/signal-design-system"'],
  id: 'autocomplete',
  metadata: {
    nestable: true,
  },
};
