/**
 * ListDivider Component
 * 
 * Exotel-approved list divider component that wraps MUI's Divider.
 * This is a convenience export for use within Lists.
 */

import MuiDivider, { type DividerProps as MuiDividerProps } from '@mui/material/Divider';
import { forwardRef } from 'react';

export interface ListDividerProps extends Omit<MuiDividerProps, 'ref'> {
  children?: React.ReactNode;
}

export const ListDivider = forwardRef<HTMLHRElement, ListDividerProps>(
  (props, ref) => <MuiDivider ref={ref} {...props} />
);

ListDivider.displayName = 'ListDivider';
