/**
 * ListItemSecondaryAction Component
 * 
 * Exotel-approved list item secondary action component that wraps MUI's ListItemSecondaryAction.
 */

import MuiListItemSecondaryAction, { type ListItemSecondaryActionProps as MuiListItemSecondaryActionProps } from '@mui/material/ListItemSecondaryAction';
import { forwardRef } from 'react';

export interface ListItemSecondaryActionProps extends Omit<MuiListItemSecondaryActionProps, 'ref'> {
  children?: React.ReactNode;
}

export const ListItemSecondaryAction = forwardRef<HTMLDivElement, ListItemSecondaryActionProps>(
  (props, ref) => <MuiListItemSecondaryAction ref={ref} {...props} />
);

ListItemSecondaryAction.displayName = 'ListItemSecondaryAction';
