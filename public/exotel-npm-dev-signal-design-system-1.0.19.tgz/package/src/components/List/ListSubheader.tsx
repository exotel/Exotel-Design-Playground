/**
 * ListSubheader Component
 * 
 * Exotel-approved list subheader component that wraps MUI's ListSubheader.
 */

import MuiListSubheader, { type ListSubheaderProps as MuiListSubheaderProps } from '@mui/material/ListSubheader';
import { forwardRef } from 'react';

export interface ListSubheaderProps extends Omit<MuiListSubheaderProps, 'ref'> {
  children?: React.ReactNode;
}

export const ListSubheader = forwardRef<HTMLLIElement, ListSubheaderProps>(
  (props, ref) => <MuiListSubheader ref={ref} {...props} />
);

ListSubheader.displayName = 'ListSubheader';
