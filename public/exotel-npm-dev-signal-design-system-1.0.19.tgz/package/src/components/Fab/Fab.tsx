/**
 * Fab (FloatingActionButton) Component
 * 
 * Exotel-approved floating action button component that wraps MUI's Fab.
 */

import MuiFab, { type FabProps as MuiFabProps } from '@mui/material/Fab';
import { forwardRef } from 'react';

export interface FabProps extends Omit<MuiFabProps, 'ref'> {
  children?: React.ReactNode;
}

export const Fab = forwardRef<HTMLButtonElement, FabProps>(
  (props, ref) => <MuiFab ref={ref} {...props} />
);

Fab.displayName = 'Fab';
