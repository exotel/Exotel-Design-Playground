import type { ReactNode, CSSProperties } from 'react';
import type {
  ReactFlowProps,
  Node,
  Edge,
  NodeTypes,
  EdgeTypes,
  ColorMode,
} from '@xyflow/react';

// ---------------------------------------------------------------------------
// Node data types for pre-built node components
// ---------------------------------------------------------------------------

export interface ActionNodeData extends Record<string, unknown> {
  label: string;
  description?: string;
  icon?: string;
  status?: 'default' | 'success' | 'error' | 'warning' | 'info';
}

export interface ConditionNodeData extends Record<string, unknown> {
  label: string;
  description?: string;
  conditions?: string[];
}

export interface StartEndNodeData extends Record<string, unknown> {
  label: string;
  variant?: 'start' | 'end';
}

export interface GroupNodeData extends Record<string, unknown> {
  label: string;
}

export type FlowBuilderNodeData =
  | ActionNodeData
  | ConditionNodeData
  | StartEndNodeData
  | GroupNodeData
  | Record<string, unknown>;

// ---------------------------------------------------------------------------
// Edge data types
// ---------------------------------------------------------------------------

export interface ConditionalEdgeData extends Record<string, unknown> {
  label?: string;
  condition?: string;
}

// ---------------------------------------------------------------------------
// FlowBuilder component props
// ---------------------------------------------------------------------------

export interface FlowBuilderProps
  extends Omit<ReactFlowProps, 'colorMode'> {
  nodes: Node[];
  edges: Edge[];

  /** Show the minimap panel. @default false */
  showMinimap?: boolean;

  /** Show the zoom/fit-view controls panel. @default true */
  showControls?: boolean;

  /** Show the dot-grid background. @default true */
  showBackground?: boolean;

  /**
   * Color mode override. When omitted the wrapper reads the current
   * Exotel theme mode automatically (light / dark).
   */
  colorMode?: ColorMode;

  /** Extra CSS class on the wrapper div. */
  className?: string;

  /** Inline style on the wrapper div (height/width). */
  style?: CSSProperties;

  /** Merge additional node types with the built-in set. */
  nodeTypes?: NodeTypes;

  /** Merge additional edge types with the built-in set. */
  edgeTypes?: EdgeTypes;

  /** Content rendered inside the ReactFlow container (panels, toolbars, etc.). */
  children?: ReactNode;
}
