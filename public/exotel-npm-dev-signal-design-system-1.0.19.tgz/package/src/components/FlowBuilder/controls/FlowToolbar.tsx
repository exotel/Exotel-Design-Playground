import { memo, type ReactNode } from 'react';
import { Panel, type PanelPosition } from '@xyflow/react';
import { Box } from '../../../components';
import { styled } from '@mui/material/styles';

export interface FlowToolbarProps {
  /** Position of the toolbar panel inside the flow canvas. @default 'top-left' */
  position?: PanelPosition;
  children: ReactNode;
}

const ToolbarRoot = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  gap: theme.spacing(0.5),
  padding: theme.spacing(0.5),
  borderRadius: theme.shape.borderRadius,
  backgroundColor: theme.palette.background.paper,
  border: `1px solid ${theme.palette.divider}`,
  boxShadow: theme.shadows[1],
}));

/**
 * A floating toolbar panel that sits inside the flow canvas.
 * Pass DS `<IconButton>` or `<Button>` children for actions
 * like "Add Node", "Undo", "Redo", etc.
 */
function FlowToolbarComponent({ position = 'top-left', children }: FlowToolbarProps) {
  return (
    <Panel position={position}>
      <ToolbarRoot>{children}</ToolbarRoot>
    </Panel>
  );
}

export const FlowToolbar = memo(FlowToolbarComponent);
