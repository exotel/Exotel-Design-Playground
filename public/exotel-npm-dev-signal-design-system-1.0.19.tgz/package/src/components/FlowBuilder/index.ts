/**
 * FlowBuilder Component Exports
 *
 * Exotel Design System wrapper around React Flow (@xyflow/react).
 * Provides themed node/edge types and convenience hooks.
 */

// Main component
export { FlowBuilder } from './FlowBuilder';

// Types
export type {
  FlowBuilderProps,
  ActionNodeData,
  ConditionNodeData,
  StartEndNodeData,
  GroupNodeData,
  FlowBuilderNodeData,
  ConditionalEdgeData,
} from './types';

// Pre-built nodes
export { ActionNode } from './nodes';
export { ConditionNode } from './nodes';
export { StartEndNode } from './nodes';
export { GroupNode } from './nodes';

// Pre-built edges
export { DefaultEdge } from './edges';
export { ConditionalEdge } from './edges';

// Controls
export { FlowControls } from './controls';
export type { FlowControlsProps } from './controls';
export { FlowToolbar } from './controls';
export type { FlowToolbarProps } from './controls';

// Hooks
export { useFlowBuilder } from './hooks';
export type { UseFlowBuilderOptions, UseFlowBuilderReturn } from './hooks';
export { useFlowTheme } from './hooks';
export type { UseFlowThemeReturn } from './hooks';

// Theme utility
export { getFlowThemeVars } from './theme';

// Re-export commonly used React Flow types and utilities so consumers
// don't need to add @xyflow/react as a direct dependency for basic usage.
export {
  Handle,
  Position,
  MarkerType,
  Panel,
  BaseEdge,
  EdgeLabelRenderer,
  getBezierPath,
  getSmoothStepPath,
  getStraightPath,
  useNodesState,
  useEdgesState,
  addEdge,
  applyNodeChanges,
  applyEdgeChanges,
  ReactFlowProvider,
  useReactFlow,
} from '@xyflow/react';

export type {
  Node,
  Edge,
  Connection,
  NodeTypes,
  EdgeTypes,
  NodeProps,
  EdgeProps,
  OnNodesChange,
  OnEdgesChange,
  OnConnect,
  ReactFlowInstance,
  ColorMode,
} from '@xyflow/react';
