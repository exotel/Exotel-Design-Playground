import { useMemo } from 'react';
import { useTheme } from '@mui/material/styles';
import type { ColorMode } from '@xyflow/react';
import { getFlowThemeVars } from '../theme';

export interface UseFlowThemeReturn {
  /** CSS variables to spread on the ReactFlow wrapper style. */
  themeVars: Record<string, string>;
  /** Resolved React Flow colorMode derived from the MUI theme. */
  colorMode: ColorMode;
}

/**
 * Reads the active Exotel MUI theme and returns:
 * 1. A CSS-variable map to apply on the ReactFlow wrapper, and
 * 2. The React Flow `colorMode` matching the current theme mode.
 */
export function useFlowTheme(): UseFlowThemeReturn {
  const theme = useTheme();

  const themeVars = useMemo(() => getFlowThemeVars(theme), [theme]);

  const colorMode: ColorMode =
    theme.palette.mode === 'dark' ? 'dark' : 'light';

  return { themeVars, colorMode };
}
