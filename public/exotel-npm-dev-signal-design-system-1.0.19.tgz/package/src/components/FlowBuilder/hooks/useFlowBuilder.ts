import { useCallback, useState } from 'react';
import {
  applyNodeChanges,
  applyEdgeChanges,
  addEdge,
  type Node,
  type Edge,
  type OnNodesChange,
  type OnEdgesChange,
  type OnConnect,
  type Connection,
  type NodeChange,
  type EdgeChange,
} from '@xyflow/react';

export interface UseFlowBuilderOptions {
  initialNodes?: Node[];
  initialEdges?: Edge[];
}

export interface UseFlowBuilderReturn {
  nodes: Node[];
  edges: Edge[];
  setNodes: React.Dispatch<React.SetStateAction<Node[]>>;
  setEdges: React.Dispatch<React.SetStateAction<Edge[]>>;
  onNodesChange: OnNodesChange;
  onEdgesChange: OnEdgesChange;
  onConnect: OnConnect;
}

/**
 * Convenience hook that wires up React Flow's controlled-state
 * pattern with `applyNodeChanges`, `applyEdgeChanges`, and `addEdge`.
 *
 * ```tsx
 * const flow = useFlowBuilder({ initialNodes, initialEdges });
 * <FlowBuilder {...flow} />
 * ```
 */
export function useFlowBuilder({
  initialNodes = [],
  initialEdges = [],
}: UseFlowBuilderOptions = {}): UseFlowBuilderReturn {
  const [nodes, setNodes] = useState<Node[]>(initialNodes);
  const [edges, setEdges] = useState<Edge[]>(initialEdges);

  const onNodesChange: OnNodesChange = useCallback(
    (changes: NodeChange[]) =>
      setNodes((prev) => applyNodeChanges(changes, prev)),
    [],
  );

  const onEdgesChange: OnEdgesChange = useCallback(
    (changes: EdgeChange[]) =>
      setEdges((prev) => applyEdgeChanges(changes, prev)),
    [],
  );

  const onConnect: OnConnect = useCallback(
    (connection: Connection) =>
      setEdges((prev) => addEdge(connection, prev)),
    [],
  );

  return { nodes, edges, setNodes, setEdges, onNodesChange, onEdgesChange, onConnect };
}
