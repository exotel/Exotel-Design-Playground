import { memo } from 'react';
import {
  BaseEdge,
  EdgeLabelRenderer,
  getSmoothStepPath,
  type EdgeProps,
} from '@xyflow/react';
import { Box, Typography } from '../../../components';
import type { ConditionalEdgeData } from '../types';

function ConditionalEdgeComponent({
  id,
  sourceX,
  sourceY,
  targetX,
  targetY,
  sourcePosition,
  targetPosition,
  style,
  markerEnd,
  data,
}: EdgeProps) {
  const { label, condition } = (data ?? {}) as ConditionalEdgeData;
  const displayLabel = label ?? condition;

  const [edgePath, labelX, labelY] = getSmoothStepPath({
    sourceX,
    sourceY,
    targetX,
    targetY,
    sourcePosition,
    targetPosition,
    borderRadius: 8,
  });

  return (
    <>
      <BaseEdge id={id} path={edgePath} style={style} markerEnd={markerEnd} />
      {displayLabel && (
        <EdgeLabelRenderer>
          <Box
            px={1}
            py={0.25}
            borderRadius={1}
            bgcolor="background.paper"
            border="1px solid"
            borderColor="divider"
            boxShadow={1}
            className="nodrag nopan"
            sx={{
              position: 'absolute',
              transform: `translate(-50%, -50%) translate(${labelX}px, ${labelY}px)`,
              pointerEvents: 'all',
            }}
          >
            <Typography variant="body3" color="text.secondary" whiteSpace="nowrap">
              {displayLabel}
            </Typography>
          </Box>
        </EdgeLabelRenderer>
      )}
    </>
  );
}

export const ConditionalEdge = memo(ConditionalEdgeComponent);
