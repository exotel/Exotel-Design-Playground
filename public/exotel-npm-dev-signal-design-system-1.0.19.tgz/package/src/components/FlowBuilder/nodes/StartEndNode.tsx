import { memo } from 'react';
import { Handle, Position, type NodeProps } from '@xyflow/react';
import { Box, Typography } from '../../../components';
import { styled } from '@mui/material/styles';
import type { StartEndNodeData } from '../types';

interface StyledRootProps {
  ownerState: { selected: boolean; variant: 'start' | 'end' };
}

const Root = styled(Box, {
  shouldForwardProp: (p) => p !== 'ownerState',
})<StyledRootProps>(({ theme, ownerState }) => {
  const isStart = ownerState.variant === 'start';
  const accentColor = isStart
    ? theme.palette.success.main
    : theme.palette.error.main;

  return {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: theme.spacing(1),
    padding: theme.spacing(0.75, 2),
    minWidth: 100,
    borderRadius: 100,
    border: `2px solid ${ownerState.selected ? theme.palette.primary.main : accentColor}`,
    backgroundColor: theme.palette.background.paper,
    boxShadow: ownerState.selected ? theme.shadows[4] : theme.shadows[1],
    transition: theme.transitions.create(['box-shadow', 'border-color'], {
      duration: theme.transitions.duration.short,
    }),
    '&:hover': {
      boxShadow: theme.shadows[3],
    },
  };
});

const Dot = styled(Box)<{ ownerState: { variant: 'start' | 'end' } }>(
  ({ theme, ownerState }) => ({
    width: 10,
    height: 10,
    borderRadius: '50%',
    backgroundColor:
      ownerState.variant === 'start'
        ? theme.palette.success.main
        : theme.palette.error.main,
    flexShrink: 0,
  }),
);

function StartEndNodeComponent({ data, selected = false }: NodeProps) {
  const { label, variant = 'start' } = data as StartEndNodeData;

  return (
    <>
      {variant === 'end' && <Handle type="target" position={Position.Top} />}
      {variant === 'start' && <Handle type="target" position={Position.Top} style={{ visibility: 'hidden' }} />}
      <Root ownerState={{ selected, variant }}>
        <Dot ownerState={{ variant }} />
        <Typography variant="label2" color="text.primary">
          {label}
        </Typography>
      </Root>
      {variant === 'start' && <Handle type="source" position={Position.Bottom} />}
      {variant === 'end' && <Handle type="source" position={Position.Bottom} style={{ visibility: 'hidden' }} />}
    </>
  );
}

export const StartEndNode = memo(StartEndNodeComponent);
