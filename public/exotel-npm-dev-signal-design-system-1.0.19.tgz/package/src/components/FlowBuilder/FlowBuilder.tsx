import { useMemo } from 'react';
import {
  ReactFlow,
  Background,
  MiniMap,
  type NodeTypes,
  type EdgeTypes,
} from '@xyflow/react';

import '@xyflow/react/dist/style.css';

import { useFlowTheme } from './hooks/useFlowTheme';
import { FlowControls } from './controls/FlowControls';
import { ActionNode } from './nodes/ActionNode';
import { ConditionNode } from './nodes/ConditionNode';
import { StartEndNode } from './nodes/StartEndNode';
import { GroupNode } from './nodes/GroupNode';
import { DefaultEdge } from './edges/DefaultEdge';
import { ConditionalEdge } from './edges/ConditionalEdge';
import type { FlowBuilderProps } from './types';

const BUILT_IN_NODE_TYPES: NodeTypes = {
  action: ActionNode,
  condition: ConditionNode,
  startEnd: StartEndNode,
  group: GroupNode,
};

const BUILT_IN_EDGE_TYPES: EdgeTypes = {
  default: DefaultEdge,
  conditional: ConditionalEdge,
};

/**
 * FlowBuilder — Exotel Design System wrapper around React Flow.
 *
 * Thin abstraction that:
 * - Forwards all props to the underlying `<ReactFlow />`
 * - Applies Exotel theme tokens via CSS variables (light/dark auto-switch)
 * - Provides pre-built, themed node and edge types
 * - Exposes convenience props (`showMinimap`, `showControls`, `showBackground`)
 */
function FlowBuilderComponent({
  showMinimap = false,
  showControls = true,
  showBackground = true,
  colorMode: colorModeProp,
  nodeTypes: nodeTypesProp,
  edgeTypes: edgeTypesProp,
  style,
  className,
  children,
  ...rest
}: FlowBuilderProps) {
  const { themeVars, colorMode: derivedColorMode } = useFlowTheme();
  const resolvedColorMode = colorModeProp ?? derivedColorMode;

  const mergedNodeTypes = useMemo<NodeTypes>(
    () => ({ ...BUILT_IN_NODE_TYPES, ...nodeTypesProp }),
    [nodeTypesProp],
  );

  const mergedEdgeTypes = useMemo<EdgeTypes>(
    () => ({ ...BUILT_IN_EDGE_TYPES, ...edgeTypesProp }),
    [edgeTypesProp],
  );

  return (
    <div
      className={className}
      style={{
        width: '100%',
        height: '100%',
        ...themeVars,
        ...style,
      }}
    >
      <ReactFlow
        colorMode={resolvedColorMode}
        nodeTypes={mergedNodeTypes}
        edgeTypes={mergedEdgeTypes}
        fitView
        {...rest}
      >
        {showBackground && <Background />}
        {showMinimap && <MiniMap />}
        {showControls && <FlowControls />}
        {children}
      </ReactFlow>
    </div>
  );
}

export { FlowBuilderComponent as FlowBuilder };
