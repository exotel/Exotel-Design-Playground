import type { Theme } from '@mui/material/styles';
import { alpha } from '@mui/material/styles';

/**
 * Maps Exotel MUI theme tokens to React Flow CSS variables.
 * Applied as inline `style` on the ReactFlow wrapper so that
 * light ↔ dark switches propagate automatically.
 */
export function getFlowThemeVars(theme: Theme): Record<string, string> {
  const p = theme.palette;

  return {
    '--xy-node-color-default': p.text.primary,
    '--xy-node-background-color-default': p.background.paper,
    '--xy-node-border-default': `1px solid ${p.divider}`,
    '--xy-node-boxshadow-hover-default': theme.shadows[2],
    '--xy-node-boxshadow-selected-default': `0 0 0 2px ${p.primary.main}`,
    '--xy-node-group-background-color-default': alpha(p.action.hover, 0.25),

    '--xy-edge-stroke-default': p.grey[400],
    '--xy-edge-stroke-width-default': '1.5',
    '--xy-edge-stroke-selected-default': p.primary.main,

    '--xy-connectionline-stroke-default': p.primary.light,
    '--xy-connectionline-stroke-width-default': '2',

    '--xy-handle-background-color-default': p.primary.main,
    '--xy-handle-border-color-default': p.background.paper,

    '--xy-minimap-background-color-default': p.background.default,

    '--xy-background-pattern-dots-color-default': p.grey[300],
    '--xy-background-pattern-line-color-default': p.grey[200],
    '--xy-background-pattern-cross-color-default': p.grey[200],

    '--xy-controls-button-background-color-default': p.background.paper,
    '--xy-controls-button-background-color-hover-default': p.action.hover,
    '--xy-controls-button-color-default': p.text.primary,
    '--xy-controls-button-color-hover-default': p.text.primary,
    '--xy-controls-button-border-color-default': p.divider,
    '--xy-controls-box-shadow-default': theme.shadows[1],

    '--xy-selection-background-color-default': alpha(p.primary.main, 0.08),
    '--xy-selection-border-default': `1px dotted ${alpha(p.primary.main, 0.8)}`,

    '--xy-attribution-background-color-default': alpha(p.background.paper, 0.5),

    '--xy-resize-background-color-default': p.primary.main,
  };
}
