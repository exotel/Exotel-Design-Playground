import type { HTMLAttributeReferrerPolicy, IframeHTMLAttributes, ReactNode, Ref } from 'react';
import type { SxProps, Theme } from '@mui/material/styles';

export interface AgenticCardProps {
  /**
   * Title displayed in the gray header bar.
   */
  title: string;
  /**
   * Body content — rich text, images, or any React node.
   */
  children?: ReactNode;
  /**
   * Action element rendered to the right of the title in the header.
   * Typically a small outlined button (e.g. "Detailed Report").
   */
  headerAction?: ReactNode;
  /**
   * Action buttons rendered right-aligned in the footer.
   * When provided, a divider separates the footer from the body.
   */
  actions?: ReactNode;
  /**
   * Image source rendered between the header and body/footer.
   * Use for visual previews such as journey flow diagrams.
   */
  imageSrc?: string;
  /**
   * Alt text for the image.
   * @default ''
   */
  imageAlt?: string;
  /**
   * URL for an iframe rendered between the header and body/footer.
   * Shows a non-interactive preview by default; the user can expand
   * it to interact with the iframe content.
   */
  iframeSrc?: string;
  /**
   * Title attribute for the iframe (accessibility).
   * @default ''
   */
  iframeTitle?: string;
  /**
   * Height of the iframe preview in collapsed mode.
   * Expanding opens a fullscreen overlay covering the entire window.
   * @default 200
   */
  iframePreviewHeight?: number;
  /**
   * Ref forwarded to the underlying `<iframe>` element. A single iframe instance
   * is shared between the inline preview and the fullscreen overlay, so this is a
   * stable handle for cross-origin communication, e.g.
   * `iframeRef.current?.contentWindow?.postMessage(message, targetOrigin)`.
   */
  iframeRef?: Ref<HTMLIFrameElement>;
  /**
   * Called on each iframe load/navigation with the iframe element. Use this to
   * post an auth token to authenticated content once the frame is ready:
   * `onIframeLoad={(iframe) => iframe.contentWindow?.postMessage(token, targetOrigin)}`.
   */
  onIframeLoad?: (iframe: HTMLIFrameElement) => void;
  /**
   * Value for the iframe `sandbox` attribute. Omitted by default (the frame runs
   * with full permissions). For authenticated cross-origin content that needs
   * cookies/storage, include `allow-same-origin` (and usually `allow-scripts`),
   * e.g. `"allow-scripts allow-same-origin allow-forms allow-popups"`.
   */
  iframeSandbox?: string;
  /**
   * Value for the iframe `allow` attribute (Permissions Policy),
   * e.g. `"clipboard-write; microphone; camera"`.
   */
  iframeAllow?: string;
  /**
   * Value for the iframe `referrerPolicy` attribute.
   */
  iframeReferrerPolicy?: HTMLAttributeReferrerPolicy;
  /**
   * Escape hatch for any additional native iframe attributes
   * (e.g. `name`, `loading`, `credentialless`). Merged last, so it can override
   * the attributes above.
   */
  iframeProps?: IframeHTMLAttributes<HTMLIFrameElement>;
  /**
   * Called when copy is clicked. Renders a feedback strip below the card when provided.
   */
  onCopy?: () => void;
  /**
   * Props forwarded to the FeedbackActions component below the card.
   * Omit to hide the feedback buttons entirely.
   */
  feedbackProps?: Omit<FeedbackActionsProps, 'sx'>;
  /**
   * Override styles for the root container.
   */
  sx?: SxProps<Theme>;
}

export interface MessageActionsProps {
  /**
   * Called when copy is clicked.
   */
  onCopy?: () => void;
  /**
   * Props forwarded to the FeedbackActions component.
   * Omit to hide the feedback buttons entirely.
   */
  feedbackProps?: Omit<FeedbackActionsProps, 'sx'>;
  /**
   * Override styles.
   */
  sx?: SxProps<Theme>;
}

export interface FeedbackReason {
  id: string;
  label: string;
}

export type FeedbackReaction = 'positive' | 'negative';

export interface FeedbackSubmission {
  reaction: FeedbackReaction;
  reasons: string[];
  otherText?: string;
}

export interface FeedbackActionsProps {
  /**
   * Positive reasons shown when the user clicks thumbs-up.
   * @default built-in list
   */
  positiveReasons?: FeedbackReason[];
  /**
   * Negative reasons shown when the user clicks thumbs-down.
   * @default built-in list
   */
  negativeReasons?: FeedbackReason[];
  /**
   * Called immediately when the user clicks like or dislike.
   */
  onReactionChange?: (reaction: FeedbackReaction | null) => void;
  /**
   * Called when the user submits additional feedback reasons.
   */
  onSubmit?: (feedback: FeedbackSubmission) => void;
  /**
   * Override styles for the root container.
   */
  sx?: SxProps<Theme>;
}
