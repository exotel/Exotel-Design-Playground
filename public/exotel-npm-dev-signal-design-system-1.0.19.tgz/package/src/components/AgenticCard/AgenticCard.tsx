import { forwardRef, useState, useRef } from 'react';
import type { CSSProperties } from 'react';
import Fade from '@mui/material/Fade';
import { alpha, useTheme } from '@mui/material/styles';
import { Box, Typography, Divider, IconButton, Icon } from '../../components';
import { MessageActions } from './MessageActions';
import type { AgenticCardProps } from './types';

/**
 * AgenticCard — a structured content card used in agentic chat flows.
 *
 * Renders a bordered card with a gray title header, a body area for
 * rich content or images, and an optional action footer with buttons.
 *
 * ```tsx
 * <AgenticCard
 *   title="Campaign Blueprint"
 *   actions={
 *     <Button variant="contained">Start Building The Journey</Button>
 *   }
 * >
 *   <Typography variant="body2">Plan details here…</Typography>
 * </AgenticCard>
 * ```
 */
export const AgenticCard = forwardRef<HTMLDivElement, AgenticCardProps>(
  (
    {
      title,
      children,
      headerAction,
      actions,
      imageSrc,
      imageAlt = '',
      iframeSrc,
      iframeTitle = '',
      iframePreviewHeight = 200,
      iframeRef,
      onIframeLoad,
      iframeSandbox,
      iframeAllow,
      iframeReferrerPolicy,
      iframeProps,
      onCopy,
      feedbackProps,
      sx,
    },
    ref,
  ) => {
    const showMessageActions = onCopy || feedbackProps;
    const theme = useTheme();

    const [fullscreen, setFullscreen] = useState(false);
    const [overlayStyle, setOverlayStyle] = useState<CSSProperties | null>(null);
    const overlayRef = useRef<HTMLDivElement>(null);
    const slotRef = useRef<HTMLDivElement>(null);
    const animating = overlayStyle !== null;

    const flip = (next: boolean) => {
      const from = overlayRef.current!.getBoundingClientRect();
      const to = next
        ? { top: 0, left: 0, width: window.innerWidth, height: window.innerHeight }
        : slotRef.current!.getBoundingClientRect();
      const base = { position: 'fixed', zIndex: theme.zIndex.modal } as const;

      setFullscreen(next);
      setOverlayStyle({ ...base, top: from.top, left: from.left, width: from.width, height: from.height });
      requestAnimationFrame(() =>
        requestAnimationFrame(() =>
          setOverlayStyle({
            ...base,
            top: to.top,
            left: to.left,
            width: to.width,
            height: to.height,
            transition: `all ${theme.transitions.duration.standard}ms ${theme.transitions.easing.easeInOut}`,
          }),
        ),
      );
    };

    return (
      <Box
        ref={ref}
        display="flex"
        flexDirection="column"
        alignItems="stretch"
        sx={sx}
      >
        <Box
          display="flex"
          flexDirection="column"
          bgcolor="background.paper"
          border={1}
          borderColor="divider"
          overflow="hidden"
          sx={{
            borderRadius: '8px',
            boxShadow: (theme) =>
              `0px 2px 4px -2px ${alpha(theme.palette.common.black, 0.06)}, 0px 4px 8px -2px ${alpha(theme.palette.common.black, 0.1)}`,
          }}
        >
        <Box
          display="flex"
          alignItems="center"
          justifyContent="space-between"
          minHeight={39}
          px={1}
          py={0.75}
          bgcolor="surface.elevation0"
          sx={{
            borderTopLeftRadius: '8px',
            borderTopRightRadius: '8px',
          }}
        >
          <Typography
            variant="subtitle2"
            sx={{
              flex: 1,
              minWidth: 0,
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap',
              fontWeight: 500,
              color: 'text.primary',
            }}
          >
            {title}
          </Typography>
          {headerAction && (
            <Box display="flex" alignItems="center" ml={1} flexShrink={0}>
              {headerAction}
            </Box>
          )}
        </Box>

        {imageSrc && (
          <Box
            component="img"
            src={imageSrc}
            alt={imageAlt}
            sx={{
              width: '100%',
              display: 'block',
              objectFit: 'cover',
            }}
          />
        )}

        {iframeSrc && (
          <Box
            ref={slotRef}
            sx={{ position: 'relative', height: iframePreviewHeight, overflow: 'hidden' }}
          >
            <Box
              ref={overlayRef}
              onTransitionEnd={(event) => {
                if (event.propertyName === 'width') setOverlayStyle(null);
              }}
              style={overlayStyle ?? undefined}
              sx={{
                display: 'flex',
                flexDirection: 'column',
                bgcolor: 'background.paper',
                overflow: 'hidden',
                ...(animating
                  ? {}
                  : fullscreen
                    ? { position: 'fixed', inset: 0, zIndex: 'modal' }
                    : { position: 'absolute', inset: 0 }),
              }}
            >
              <Fade in={fullscreen} unmountOnExit>
                <Box
                  display="flex"
                  alignItems="center"
                  justifyContent="space-between"
                  px={2}
                  py={1}
                  bgcolor="surface.elevation0"
                  borderBottom={1}
                  borderColor="divider"
                  sx={{ flexShrink: 0 }}
                >
                  <Typography variant="subtitle2" fontWeight={500} color="text.primary">
                    {iframeTitle || title}
                  </Typography>
                  <IconButton size="small" onClick={() => flip(false)} aria-label="Close fullscreen">
                    <Icon name="x" size="sm" />
                  </IconButton>
                </Box>
              </Fade>

              <iframe
                ref={iframeRef}
                src={iframeSrc}
                title={iframeTitle}
                onLoad={(event) => onIframeLoad?.(event.currentTarget)}
                sandbox={iframeSandbox}
                allow={iframeAllow}
                referrerPolicy={iframeReferrerPolicy}
                style={{
                  flex: 1,
                  minHeight: 0,
                  width: '100%',
                  border: 0,
                  display: 'block',
                  pointerEvents: fullscreen && !animating ? 'auto' : 'none',
                }}
                {...iframeProps}
              />

              {!fullscreen && !animating && (
                <Box
                  onClick={() => flip(true)}
                  sx={{
                    position: 'absolute',
                    inset: 0,
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'flex-end',
                    justifyContent: 'center',
                    pb: 1.5,
                    background: (t) =>
                      `linear-gradient(to bottom, transparent 60%, ${alpha(t.palette.common.black, 0.20)} 100%)`,
                    '&:hover': {
                      background: (t) =>
                        `linear-gradient(to bottom, transparent 40%, ${alpha(t.palette.common.black, 0.30)} 100%)`,
                    },
                  }}
                >
                  <Box
                    sx={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 0.5,
                      px: 1.5,
                      py: 0.5,
                      borderRadius: '16px',
                      bgcolor: 'background.paper',
                      border: 1,
                      borderColor: 'divider',
                      typography: 'caption',
                      color: 'text.secondary',
                      boxShadow: 1,
                    }}
                  >
                    <Icon name="arrows-out" size="xs" />
                    Click to interact
                  </Box>
                </Box>
              )}
            </Box>
          </Box>
        )}

        {children && (
          <Box
            px={1}
            py={1.5}
            bgcolor="background.paper"
            color="text.primary"
            sx={{
              typography: 'body2',
              wordBreak: 'break-word',
              '& ul, & ol': { m: 0, pl: 2.5 },
              '& li': { mb: 0.25 },
              '& p': { m: 0, lineHeight: 1.6 },
            }}
          >
            {children}
          </Box>
        )}

        {actions && (
          <>
            <Divider />
            <Box
              display="flex"
              alignItems="center"
              justifyContent="flex-end"
              gap={1}
              px={1}
              py={1.5}
            >
              {actions}
            </Box>
          </>
        )}
        </Box>
        {showMessageActions && (
          <MessageActions onCopy={onCopy} feedbackProps={feedbackProps} />
        )}
      </Box>
    );
  },
);

AgenticCard.displayName = 'AgenticCard';
