import { forwardRef, useCallback, useRef, useState } from 'react';
import { Box, Button, Checkbox, TextField, Icon, IconButton, Popover, Typography } from '../../components';
import type { FeedbackActionsProps, FeedbackReason, FeedbackReaction } from './types';

const DEFAULT_POSITIVE_REASONS: FeedbackReason[] = [
  { id: 'accurate', label: 'Accurate' },
  { id: 'actionable', label: 'Actionable' },
  { id: 'new-info', label: 'Told me something new' },
  { id: 'well-explained', label: 'Well explained' },
  { id: 'right-metric', label: 'Right metric or KPI' },
];

const DEFAULT_NEGATIVE_REASONS: FeedbackReason[] = [
  { id: 'inaccurate', label: "Inaccurate — doesn't match my data" },
  { id: 'not-actionable', label: 'Not actionable' },
  { id: 'already-knew', label: 'Already knew this' },
  { id: 'unclear', label: 'Unclear or confusing' },
  { id: 'wrong-metric', label: 'Wrong metric or KPI referenced' },
];

const THUMB_SX = { padding: '6px', borderRadius: '4px' } as const;

const THUMB_ACTIVE_SX = {
  positive: { ...THUMB_SX, color: 'rgb(60, 122, 88)', backgroundColor: 'rgba(6, 147, 81, 0.1)' },
  negative: { ...THUMB_SX, color: 'rgb(160, 78, 73)', backgroundColor: 'rgb(245, 233, 232)' },
} as const;

const REASON_ROW_SX = {
  display: 'flex',
  alignItems: 'center',
  gap: 1,
  py: 0.75,
  px: 1,
  borderRadius: '8px',
  cursor: 'pointer',
  transition: 'background-color 150ms',
  '&:hover': { backgroundColor: 'action.hover' },
} as const;

const POPOVER_PAPER_SX = {
  mt: 1,
  width: 280,
  borderRadius: '16px',
  boxShadow: 'rgba(10, 13, 18, 0.03) 0px 8px 8px -4px, rgba(10, 13, 18, 0.08) 0px 20px 24px -4px',
} as const;

interface Snapshot {
  reaction: FeedbackReaction | null;
  reasons: string[];
  otherSelected: boolean;
  otherText: string;
}

const INITIAL_SNAPSHOT: Snapshot = { reaction: null, reasons: [], otherSelected: false, otherText: '' };

export const FeedbackActions = forwardRef<HTMLDivElement, FeedbackActionsProps>(
  ({ positiveReasons = DEFAULT_POSITIVE_REASONS, negativeReasons = DEFAULT_NEGATIVE_REASONS, onReactionChange, onSubmit, sx }, ref) => {
    const [reaction, setReaction] = useState<FeedbackReaction | null>(null);
    const [selectedReasons, setSelectedReasons] = useState<string[]>([]);
    const [otherSelected, setOtherSelected] = useState(false);
    const [otherText, setOtherText] = useState('');
    const [popoverOpen, setPopoverOpen] = useState(false);

    const thumbUpRef = useRef<HTMLButtonElement | null>(null);
    const thumbDownRef = useRef<HTMLButtonElement | null>(null);
    const snapshotRef = useRef<Snapshot>({ ...INITIAL_SNAPSHOT });

    const reasons = reaction === 'positive' ? positiveReasons : negativeReasons;
    const popoverAnchor = reaction === 'positive' ? thumbUpRef.current : thumbDownRef.current;
    const hasSelection = selectedReasons.length > 0 || otherSelected;

    const handleReactionClick = useCallback(
      (next: FeedbackReaction) => {
        if (reaction === next) {
          setReaction(null);
          setSelectedReasons([]);
          setOtherSelected(false);
          setOtherText('');
          setPopoverOpen(false);
          snapshotRef.current = { ...INITIAL_SNAPSHOT };
          onReactionChange?.(null);
          return;
        }
        setReaction(next);
        setSelectedReasons([]);
        setOtherSelected(false);
        setOtherText('');
        setPopoverOpen(true);
        snapshotRef.current = { reaction: next, reasons: [], otherSelected: false, otherText: '' };
        onReactionChange?.(next);
      },
      [reaction, onReactionChange],
    );

    const handleToggleReason = useCallback((reasonId: string) => {
      setSelectedReasons((prev) =>
        prev.includes(reasonId) ? prev.filter((r) => r !== reasonId) : [...prev, reasonId],
      );
    }, []);

    const handleSubmit = useCallback(() => {
      if (!reaction) return;
      onSubmit?.({
        reaction,
        reasons: selectedReasons,
        otherText: otherSelected ? otherText : undefined,
      });
      snapshotRef.current = { reaction, reasons: selectedReasons, otherSelected, otherText };
      setPopoverOpen(false);
    }, [reaction, selectedReasons, otherText, otherSelected, onSubmit]);

    const handleEditClick = useCallback(() => {
      snapshotRef.current = { reaction, reasons: selectedReasons, otherSelected, otherText };
      setPopoverOpen(true);
    }, [reaction, selectedReasons, otherSelected, otherText]);

    const handleClose = useCallback(() => {
      const snap = snapshotRef.current;
      setReaction(snap.reaction);
      setSelectedReasons(snap.reasons);
      setOtherSelected(snap.otherSelected);
      setOtherText(snap.otherText);
      setPopoverOpen(false);
    }, []);

    return (
      <Box ref={ref} display="inline-flex" alignItems="center" gap="2px" sx={sx}>
        <IconButton
          ref={(el: HTMLButtonElement | null) => { if (el) thumbUpRef.current = el; }}
          size="small"
          onClick={() => handleReactionClick('positive')}
          aria-label="Helpful"
          sx={reaction === 'positive' ? THUMB_ACTIVE_SX.positive : THUMB_SX}
        >
          <Icon name="thumbs-up" size="xs" />
        </IconButton>

        <IconButton
          ref={(el: HTMLButtonElement | null) => { if (el) thumbDownRef.current = el; }}
          size="small"
          onClick={() => handleReactionClick('negative')}
          aria-label="Not helpful"
          sx={reaction === 'negative' ? THUMB_ACTIVE_SX.negative : THUMB_SX}
        >
          <Icon name="thumbs-down" size="xs" mirrored />
        </IconButton>

        {reaction && (
          <IconButton
            size="small"
            onClick={handleEditClick}
            aria-label="Edit feedback"
            sx={THUMB_SX}
          >
            <Icon name="pencil-line" size="xs" />
          </IconButton>
        )}

        <Popover
          open={popoverOpen}
          anchorEl={popoverAnchor}
          onClose={handleClose}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
          transformOrigin={{ vertical: 'top', horizontal: 'right' }}
          slotProps={{ paper: { sx: POPOVER_PAPER_SX } }}
        >
          <Box sx={{ p: 2 }}>
            <Typography variant="label2" sx={{ mb: 0.5, color: 'rgba(0, 0, 0, 0.65)' }}>
              {reaction === 'positive' ? 'What worked well?' : 'What went wrong?'}
            </Typography>

            <Box display="flex" flexDirection="column">
              {reasons.map((reason) => (
                <Box key={reason.id} component="label" sx={REASON_ROW_SX}>
                  <Checkbox
                    checked={selectedReasons.includes(reason.id)}
                    onChange={() => handleToggleReason(reason.id)}
                    size="small"
                    sx={{ p: 0 }}
                  />
                  <Typography variant="body2">{reason.label}</Typography>
                </Box>
              ))}
            </Box>

            <Box component="label" sx={REASON_ROW_SX}>
              <Checkbox
                checked={otherSelected}
                onChange={() => setOtherSelected((prev) => !prev)}
                size="small"
                sx={{ p: 0 }}
              />
              <Typography variant="body2">
                {reaction === 'positive' ? 'Other' : 'Other issue'}
              </Typography>
            </Box>

            {otherSelected && (
              <TextField
                placeholder="Tell us more..."
                value={otherText}
                onChange={(e) => setOtherText(e.target.value)}
                multiline
                minRows={2}
                maxRows={4}
                fullWidth
                sx={{ mt: 1.5 }}
              />
            )}

            <Button
              variant="contained"
              fullWidth
              onClick={handleSubmit}
              disabled={!hasSelection}
              sx={{ mt: 2, borderRadius: '8px', padding: '6px 12px' }}
            >
              Submit
            </Button>
          </Box>
        </Popover>
      </Box>
    );
  },
);

FeedbackActions.displayName = 'FeedbackActions';
