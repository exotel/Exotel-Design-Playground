import { forwardRef } from 'react';
import { Box, Icon, IconButton } from '../../components';
import { FeedbackActions } from './FeedbackActions';
import type { MessageActionsProps } from './types';

/**
 * MessageActions — copy + feedback strip for agent messages.
 */
export const MessageActions = forwardRef<HTMLDivElement, MessageActionsProps>(
  ({ onCopy, feedbackProps, sx }, ref) => {
    const hasActions = onCopy || feedbackProps;
    if (!hasActions) return null;

    return (
      <Box ref={ref} display="flex" alignItems="center" gap={1} sx={sx}>
        {onCopy && (
          <IconButton size="small" onClick={onCopy} aria-label="Copy">
            <Icon name="copy" size="xs" />
          </IconButton>
        )}
        {feedbackProps && <FeedbackActions {...feedbackProps} />}
      </Box>
    );
  },
);

MessageActions.displayName = 'MessageActions';
