/**
 * Badge Component
 *
 * Exotel-approved badge component that wraps MUI's Badge.
 * Supports a custom `tonal` variant (Signal Design System): alpha-tinted background
 * with semantic foreground text, per Figma Badge component spec.
 */

import MuiBadge, { type BadgeProps as MuiBadgeProps } from '@mui/material/Badge';
import { type SxProps, type Theme } from '@mui/material/styles';
import { forwardRef } from 'react';
import { resolveTonalColor } from '../../theme/tonal';

function tonalBadgeSx(theme: Theme, color: MuiBadgeProps['color']): object {
  const tokens = resolveTonalColor(theme, color);

  const baseBadge = {
    fontWeight: theme.typography.fontWeightMedium,
    fontSize: '0.75rem',
    lineHeight: '20px',
    backgroundColor: tokens.bg,
    color: tokens.text,
  };

  return {
    '& .MuiBadge-badge': baseBadge,
  };
}

export interface BadgeProps extends Omit<MuiBadgeProps, 'ref' | 'variant'> {
  /**
   * MUI `standard` and `dot`, plus Exotel `tonal` (alpha-tinted surface + hue-matched label text).
   */
  variant?: 'standard' | 'dot' | 'tonal';
}

function mergeSx(
  tonal: boolean,
  badgeColor: MuiBadgeProps['color'],
  userSx: SxProps<Theme> | undefined,
): SxProps<Theme> | undefined {
  if (!tonal && userSx === undefined) {
    return undefined;
  }

  const sxFn = (theme: Theme) => {
    const tonalStyles = tonal ? tonalBadgeSx(theme, badgeColor) : {};
    const resolved =
      typeof userSx === 'function' ? userSx(theme) : userSx;
    if (Array.isArray(resolved)) {
      return [tonalStyles, ...resolved] as SxProps<Theme>;
    }
    return { ...tonalStyles, ...resolved };
  };

  return sxFn as SxProps<Theme>;
}

export const Badge = forwardRef<HTMLDivElement, BadgeProps>(
  ({ variant = 'standard', color = 'default', sx, ...props }, ref) => {
    const tonal = variant === 'tonal';
    const muiVariant = tonal ? 'standard' : variant;

    return (
      <MuiBadge
        ref={ref}
        variant={muiVariant}
        color={tonal ? 'default' : color}
        {...(tonal ? { 'data-variant': 'tonal' as const } : {})}
        {...props}
        sx={mergeSx(tonal, color, sx)}
      />
    );
  },
);

Badge.displayName = 'Badge';
