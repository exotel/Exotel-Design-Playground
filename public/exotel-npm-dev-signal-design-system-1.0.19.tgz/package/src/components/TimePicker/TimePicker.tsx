/**
 * TimePicker Component
 *
 * Exotel-approved time picker component that wraps MUI X TimePicker.
 * Relies on the LocalizationProvider in ExotelThemeProvider.
 */

import { TimePicker as MuiTimePicker, type TimePickerProps as MuiTimePickerProps } from '@mui/x-date-pickers/TimePicker';
import { forwardRef, useMemo } from 'react';
import { mergePickerTextFieldSlotProps } from '../../functions/mergePickerTextFieldSlotProps';
import { FieldWrapper } from '../FieldLabel';

export interface TimePickerProps extends Omit<MuiTimePickerProps, 'ref'> {
  /** The size of the picker input. Matches TextField sizes. */
  size?: 'small' | 'medium' | 'large';
  /** Placeholder text inside the input. Derived from `label` when omitted. */
  placeholder?: string;
}

export const TimePicker = forwardRef<HTMLDivElement, TimePickerProps>(
  (props, ref) => {
    const { label, size = 'medium', placeholder, slotProps, ...rest } = props;

    const mergedSlotProps = useMemo(
      () => mergePickerTextFieldSlotProps(label, size, placeholder, slotProps),
      [label, size, placeholder, slotProps],
    );

    return (
      <FieldWrapper label={label}>
        <MuiTimePicker ref={ref} slotProps={mergedSlotProps} {...rest} />
      </FieldWrapper>
    );
  }
);

TimePicker.displayName = 'TimePicker';
