/**
 * Card Component
 * 
 * Exotel-approved card component that wraps MUI's Card.
 * Provides consistent styling and behavior across Exotel applications.
 * 
 * Usage:
 * ```tsx
 * import { Card } from '@exotel/design-system';
 * 
 * <Card>
 *   <CardContent>Content here</CardContent>
 * </Card>
 * ```
 */

import MuiCard, { type CardProps as MuiCardProps } from '@mui/material/Card';
import { forwardRef } from 'react';

/**
 * Card component props
 * Re-exports MUI CardProps while hiding MUI-specific naming
 */
export interface CardProps extends Omit<MuiCardProps, 'ref'> {
  /**
   * The content of the card
   */
  children?: React.ReactNode;
}

/**
 * Card component
 * 
 * Wraps MUI's Card component with Exotel-specific defaults and styling.
 * All MUI Card props are supported.
 */
export const Card = forwardRef<HTMLDivElement, CardProps>(
  (props, ref) => {
    return <MuiCard ref={ref} {...props} />;
  }
);

Card.displayName = 'Card';
