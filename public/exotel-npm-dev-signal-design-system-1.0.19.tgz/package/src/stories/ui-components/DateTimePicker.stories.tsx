import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import dayjs, { type Dayjs } from 'dayjs';
import { DateTimePicker, type DateTimePickerProps } from '../../components';

const meta: Meta<typeof DateTimePicker> = {
  title: 'Date & Time Pickers/DateTimePicker',
  component: DateTimePicker,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          "Exotel-approved date-time picker that wraps MUI X DateTimePicker. Combines date and time selection in a single component. Includes a built-in LocalizationProvider with dayjs.",
      },
    },
  },
  argTypes: {
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
      description: 'The size of the picker input',
      table: {
        type: { summary: "'small' | 'medium' | 'large'" },
        defaultValue: { summary: "'medium'" },
      },
    },
    label: {
      control: 'text',
      description: 'External label rendered above the picker',
      table: { type: { summary: 'ReactNode' } },
    },
    disabled: {
      control: 'boolean',
      description: 'If true, the picker is disabled',
      table: { type: { summary: 'boolean' }, defaultValue: { summary: 'false' } },
    },
    readOnly: {
      control: 'boolean',
      description: 'If true, the picker is read-only',
      table: { type: { summary: 'boolean' }, defaultValue: { summary: 'false' } },
    },
    disableFuture: {
      control: 'boolean',
      description: 'If true, future dates are disabled',
      table: { type: { summary: 'boolean' }, defaultValue: { summary: 'false' } },
    },
    disablePast: {
      control: 'boolean',
      description: 'If true, past dates are disabled',
      table: { type: { summary: 'boolean' }, defaultValue: { summary: 'false' } },
    },
    ampm: {
      control: 'boolean',
      description: 'If true, uses 12-hour format with AM/PM',
      table: { type: { summary: 'boolean' }, defaultValue: { summary: 'true' } },
    },
  },
};

export default meta;
type Story = StoryObj<typeof DateTimePicker>;

/**
 * Basic date-time picker with a label.
 */
export const Basic: Story = {
  render: () => <DateTimePicker label="Select date & time" />,
};

/**
 * All three sizes — small (32px), medium (40px), and large (50px) — matching TextField.
 */
export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16, width: 300 }}>
      <DateTimePicker label="Small" size="small" />
      <DateTimePicker label="Medium" size="medium" />
      <DateTimePicker label="Large" size="large" />
    </div>
  ),
};

/**
 * Controlled date-time picker with React state.
 */
export const Controlled: Story = {
  render: () => {
    const [value, setValue] = useState<Dayjs | null>(dayjs());
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16, width: 300 }}>
        <DateTimePicker label="Date & time" value={value} onChange={(newValue) => setValue(newValue)} />
        <div style={{ fontSize: 14, color: '#666' }}>
          Selected: {value ? value.format('MMMM D, YYYY hh:mm A') : 'None'}
        </div>
      </div>
    );
  },
};

/**
 * Without an external label.
 */
export const WithoutLabel: Story = {
  render: () => <DateTimePicker />,
};

/**
 * Disabled state.
 */
export const Disabled: Story = {
  render: () => <DateTimePicker label="Disabled" disabled defaultValue={dayjs()} />,
};

/**
 * Read-only state.
 */
export const ReadOnly: Story = {
  render: () => <DateTimePicker label="Read only" readOnly defaultValue={dayjs()} />,
};

/**
 * Only future dates are selectable.
 */
export const DisablePast: Story = {
  render: () => <DateTimePicker label="Future only" disablePast />,
};

/**
 * 24-hour format (no AM/PM).
 */
export const TwentyFourHour: Story = {
  render: () => <DateTimePicker label="24-hour format" ampm={false} />,
};

/**
 * Custom display format.
 */
export const CustomFormat: Story = {
  render: () => <DateTimePicker label="Custom format" format="DD/MM/YYYY HH:mm" ampm={false} />,
};

/**
 * Default action bar with Clear, Cancel, Today, and Accept actions.
 */
export const ActionBar: Story = {
  render: () => (
    <DateTimePicker
      label="With action bar"
      slotProps={{
        actionBar: {
          actions: ['clear', 'cancel', 'today', 'accept'],
        },
      }}
    />
  ),
};


/**
 * Interactive playground with all controls.
 */
export const Interactive: Story = {
  args: {
    label: 'Pick date & time',
    size: 'medium',
    disabled: false,
    readOnly: false,
    disableFuture: false,
    disablePast: false,
    ampm: true,
  },
  render: (args: DateTimePickerProps) => <DateTimePicker {...args} />,
};
