import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { AgenticSteps, StepHeader, AgenticStep, Box, Button, Typography } from '../../components';

const meta: Meta<typeof AgenticSteps> = {
  title: 'AI-SUITE (Beta)/AgenticSteps',
  component: AgenticSteps,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'Agentic Steps displays AI processing stages with a collapsible StepHeader and individual Steps, each supporting loading, success, and failure states.',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof AgenticSteps>;

/**
 * Loading state — StepHeader shows animated dots, collapsed with no visible steps.
 * Matches the Figma "Thinking" initial state.
 */
export const Loading: Story = {
  render: () => (
    <Box sx={{ width: 684 }}>
      <AgenticSteps>
        <StepHeader title="Thinking" status="loading" defaultExpanded={false} />
      </AgenticSteps>
    </Box>
  ),
};

/**
 * Loading with steps — StepHeader expanded, showing steps in progress.
 * Matches the Figma expanded "Thinking" with "Analysing Request" step.
 */
export const LoadingWithSteps: Story = {
  render: () => (
    <Box sx={{ width: 684 }}>
      <AgenticSteps>
        <StepHeader title="Thinking" status="loading">
          <AgenticStep id="step-1" title="Analysing Request" status="loading" />
        </StepHeader>
      </AgenticSteps>
    </Box>
  ),
};

/**
 * Step with expanded result content — the step shows detailed analysis output.
 * Matches the Figma design with bullet-point analysis results.
 */
export const StepWithResultContent: Story = {
  render: () => (
    <Box sx={{ width: 684 }}>
      <AgenticSteps>
        <StepHeader title="Thinking" status="loading">
          <AgenticStep
            id="step-1"
            title="Analysing Request"
            status="success"
            defaultExpanded
            resultContent={
              <>
                <p>Evaluating core business objectives, guardrails, and scope boundaries...</p>
                <ul>
                  <li>
                    Goal Extraction: Funnel recovery for HDFC Securities Demat Account opening.
                  </li>
                  <li>
                    Performance Baseline: Current conversion: 12% → Target conversion: 20% (+8% Lift
                    target).
                  </li>
                  <li>Financial Constraints: Absolute budget ceiling allocated at ₹8 per lead.</li>
                  <li>
                    Regulatory Boundaries: TRAI compliance — strict filter required for National
                    Consumer Preference Register (NCPR) DND records on promotional SMS pathways.
                    <ul>
                      <li>
                        Operational timing windows: Voice restricted to 09:00 AM - 07:00 PM IST;
                        Digital (SMS/WhatsApp) restricted to 09:00 AM - 08:00 PM IST.
                      </li>
                    </ul>
                  </li>
                  <li>
                    Missing Parameters Detected: Journey exit timeout duration not specified for
                    cold/unresponsive cohorts.
                  </li>
                </ul>
                <p>
                  Analysis concluded. Handing off to orchestrator for clarification prompt
                  generation...
                </p>
              </>
            }
          />
          <AgenticStep id="step-2" title="Building Execution Plan" status="loading" />
        </StepHeader>
      </AgenticSteps>
    </Box>
  ),
};

/**
 * Success state — StepHeader shows a green check icon, collapsed.
 * Matches the Figma "Thinking" completed state.
 */
export const Success: Story = {
  render: () => (
    <Box sx={{ width: 684 }}>
      <AgenticSteps>
        <StepHeader title="Thinking" status="success" defaultExpanded={false} />
      </AgenticSteps>
    </Box>
  ),
};

/**
 * Success with all steps completed and expanded.
 */
export const SuccessExpanded: Story = {
  render: () => (
    <Box sx={{ width: 684 }}>
      <AgenticSteps>
        <StepHeader title="Thinking" status="success">
          <AgenticStep
            id="step-1"
            title="Analysing Request"
            status="success"
            resultContent={
              <>
                <p>Evaluating core business objectives, guardrails, and scope boundaries...</p>
                <ul>
                  <li>Goal Extraction: Funnel recovery for Demat Account opening.</li>
                  <li>Performance Baseline: Current conversion: 12% → Target: 20%.</li>
                  <li>Financial Constraints: Budget ceiling at ₹8 per lead.</li>
                </ul>
                <p>Analysis concluded.</p>
              </>
            }
          />
          <AgenticStep
            id="step-2"
            title="Building Execution Plan"
            status="success"
            resultContent={
              <p>
                Execution plan generated with 3 stages: SMS outreach → WhatsApp follow-up → Voice
                callback.
              </p>
            }
          />
        </StepHeader>
      </AgenticSteps>
    </Box>
  ),
};

/**
 * Failure state — StepHeader shows an error icon.
 */
export const Failure: Story = {
  render: () => (
    <Box sx={{ width: 684 }}>
      <AgenticSteps>
        <StepHeader title="Thinking" status="failure" defaultExpanded={false} />
      </AgenticSteps>
    </Box>
  ),
};

/**
 * Failure with step detail — one step failed while another succeeded.
 */
export const FailureWithSteps: Story = {
  render: () => (
    <Box sx={{ width: 684 }}>
      <AgenticSteps>
        <StepHeader title="Thinking" status="failure">
          <AgenticStep
            id="step-1"
            title="Analysing Request"
            status="success"
            resultContent={<p>Analysis completed successfully.</p>}
          />
          <AgenticStep
            id="step-2"
            title="Building Execution Plan"
            status="failure"
            defaultExpanded
            resultContent={
              <Typography color="error" variant="body2">
                Failed to generate execution plan. Insufficient data for audience segmentation.
              </Typography>
            }
          />
        </StepHeader>
      </AgenticSteps>
    </Box>
  ),
};

/**
 * Interactive demo — toggle step status and expand/collapse states.
 */
export const Interactive: Story = {
  render: () => {
    const [headerStatus, setHeaderStatus] = useState<'loading' | 'success' | 'failure'>('loading');
    const [step1Status, setStep1Status] = useState<'loading' | 'success' | 'failure'>('loading');
    const [step2Status, setStep2Status] = useState<'loading' | 'success' | 'failure'>('loading');

    return (
      <Box sx={{ width: 684, display: 'flex', flexDirection: 'column', gap: 3 }}>
        <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
          <Typography variant="body2" sx={{ width: '100%', fontWeight: 600 }}>
            Header Status:
          </Typography>
          <Button
            size="small"
            variant={headerStatus === 'loading' ? 'contained' : 'outlined'}
            onClick={() => setHeaderStatus('loading')}
          >
            Loading
          </Button>
          <Button
            size="small"
            variant={headerStatus === 'success' ? 'contained' : 'outlined'}
            color="success"
            onClick={() => setHeaderStatus('success')}
          >
            Success
          </Button>
          <Button
            size="small"
            variant={headerStatus === 'failure' ? 'contained' : 'outlined'}
            color="error"
            onClick={() => setHeaderStatus('failure')}
          >
            Failure
          </Button>
        </Box>
        <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
          <Typography variant="body2" sx={{ width: '100%', fontWeight: 600 }}>
            Step 1 Status:
          </Typography>
          <Button
            size="small"
            variant={step1Status === 'loading' ? 'contained' : 'outlined'}
            onClick={() => setStep1Status('loading')}
          >
            Loading
          </Button>
          <Button
            size="small"
            variant={step1Status === 'success' ? 'contained' : 'outlined'}
            color="success"
            onClick={() => setStep1Status('success')}
          >
            Success
          </Button>
          <Button
            size="small"
            variant={step1Status === 'failure' ? 'contained' : 'outlined'}
            color="error"
            onClick={() => setStep1Status('failure')}
          >
            Failure
          </Button>
        </Box>
        <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
          <Typography variant="body2" sx={{ width: '100%', fontWeight: 600 }}>
            Step 2 Status:
          </Typography>
          <Button
            size="small"
            variant={step2Status === 'loading' ? 'contained' : 'outlined'}
            onClick={() => setStep2Status('loading')}
          >
            Loading
          </Button>
          <Button
            size="small"
            variant={step2Status === 'success' ? 'contained' : 'outlined'}
            color="success"
            onClick={() => setStep2Status('success')}
          >
            Success
          </Button>
          <Button
            size="small"
            variant={step2Status === 'failure' ? 'contained' : 'outlined'}
            color="error"
            onClick={() => setStep2Status('failure')}
          >
            Failure
          </Button>
        </Box>

        <AgenticSteps>
          <StepHeader title="Thinking" status={headerStatus}>
            <AgenticStep
              id="step-1"
              title="Analysing Request"
              status={step1Status}
              resultContent={
                <>
                  <p>Evaluating core business objectives, guardrails, and scope boundaries...</p>
                  <ul>
                    <li>Goal Extraction: Funnel recovery for Demat Account opening.</li>
                    <li>Performance Baseline: 12% → 20% target conversion.</li>
                    <li>Budget ceiling: ₹8 per lead.</li>
                  </ul>
                  <p>Analysis concluded.</p>
                </>
              }
            />
            <AgenticStep
              id="step-2"
              title="Building Execution Plan"
              status={step2Status}
              resultContent={
                <p>
                  3-stage execution plan: SMS outreach → WhatsApp follow-up → Voice callback for
                  high-intent leads.
                </p>
              }
            />
          </StepHeader>
        </AgenticSteps>
      </Box>
    );
  },
};

/**
 * Multiple headers — shows multiple sequential thinking phases.
 */
export const MultipleHeaders: Story = {
  render: () => (
    <Box sx={{ width: 684, display: 'flex', flexDirection: 'column', gap: 2 }}>
      <AgenticSteps>
        <StepHeader title="Understanding Requirements" status="success" defaultExpanded={false} />
      </AgenticSteps>
      <AgenticSteps>
        <StepHeader title="Building Campaign" status="loading">
          <AgenticStep
            id="step-1"
            title="Selecting Channels"
            status="success"
            resultContent={<p>SMS + WhatsApp selected based on budget and reach analysis.</p>}
          />
          <AgenticStep id="step-2" title="Generating Templates" status="loading" />
        </StepHeader>
      </AgenticSteps>
    </Box>
  ),
};
