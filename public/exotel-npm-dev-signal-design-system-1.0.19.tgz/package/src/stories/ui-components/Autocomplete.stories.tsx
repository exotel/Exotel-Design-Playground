import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { Autocomplete, type AutocompleteProps } from '../../components';

const topFilms = [
  { label: 'The Shawshank Redemption', year: 1994 },
  { label: 'The Godfather', year: 1972 },
  { label: 'The Dark Knight', year: 2008 },
  { label: 'Pulp Fiction', year: 1994 },
  { label: 'Forrest Gump', year: 1994 },
  { label: 'Inception', year: 2010 },
  { label: 'The Matrix', year: 1999 },
  { label: 'Interstellar', year: 2014 },
  { label: 'Fight Club', year: 1999 },
  { label: 'The Lord of the Rings: The Return of the King', year: 2003 },
];

const meta: Meta<typeof Autocomplete> = {
  title: 'UI Components/Autocomplete',
  component: Autocomplete,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component: 'Exotel-approved autocomplete component that wraps MUI\'s Autocomplete. Only supports outlined variant and renders an external label above the input.',
      },
    },
  },
  argTypes: {
    label: {
      control: 'text',
      description: 'The label content displayed above the input',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    size: {
      control: 'select',
      options: ['small', 'medium'],
      description: 'The size of the component',
      table: {
        type: { summary: "'small' | 'medium'" },
        defaultValue: { summary: "'medium'" },
      },
    },
    disabled: {
      control: 'boolean',
      description: 'If true, the component is disabled',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    loading: {
      control: 'boolean',
      description: 'If true, the component displays a loading state',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    multiple: {
      control: 'boolean',
      description: 'If true, multiple values can be selected',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    freeSolo: {
      control: 'boolean',
      description: 'If true, the user can type a value not in the options',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    disableClearable: {
      control: 'boolean',
      description: 'If true, the clear button is hidden',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    fullWidth: {
      control: 'boolean',
      description: 'If true, the component takes up the full width',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Autocomplete>;

/**
 * Basic autocomplete with a label
 */
export const Basic: Story = {
  render: () => (
    <Autocomplete
      label="Movie"
      options={topFilms}
      sx={{ width: 300 }}
    />
  ),
};

/**
 * Without label
 */
export const WithoutLabel: Story = {
  render: () => (
    <Autocomplete
      options={topFilms}
      sx={{ width: 300 }}
    />
  ),
};

/**
 * Different sizes
 */
export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', width: '300px' }}>
      <Autocomplete label="Small" options={topFilms} size="small" />
      <Autocomplete label="Medium" options={topFilms} size="medium" />
      <Autocomplete label="Large" options={topFilms} size="large" />
    </div>
  ),
};

/**
 * Multiple selection
 */
export const Multiple: Story = {
  render: () => {
    const [value, setValue] = useState<typeof topFilms>([]);
    return (
      <Autocomplete
        multiple
        label="Movies"
        options={topFilms}
        value={value}
        onChange={(_event: any, newValue: any) => setValue(newValue)}
        sx={{ width: 400 }}
      />
    );
  },
};

/**
 * Free solo allows arbitrary text input
 */
export const FreeSolo: Story = {
  render: () => (
    <Autocomplete
      freeSolo
      label="Type or select"
      options={topFilms.map((option) => option.label)}
      sx={{ width: 300 }}
    />
  ),
};

/**
 * Disabled state
 */
export const Disabled: Story = {
  render: () => (
    <Autocomplete
      disabled
      label="Disabled"
      options={topFilms}
      value={topFilms[0]}
      sx={{ width: 300 }}
    />
  ),
};

/**
 * Disable clearable hides the clear button
 */
export const DisableClearable: Story = {
  render: () => (
    <Autocomplete
      disableClearable
      label="Cannot clear"
      options={topFilms}
      value={topFilms[0]}
      sx={{ width: 300 }}
    />
  ),
};

/**
 * Grouped options by first letter
 */
export const Grouped: Story = {
  render: () => (
    <Autocomplete
      label="Grouped"
      options={topFilms.sort((a, b) => a.label[0].localeCompare(b.label[0]))}
      groupBy={(option: any) => option.label[0]}
      getOptionLabel={(option: any) => option.label}
      sx={{ width: 300 }}
    />
  ),
};

/**
 * Controlled autocomplete
 */
export const Controlled: Story = {
  render: () => {
    const [value, setValue] = useState<typeof topFilms[0] | null>(null);
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', width: '300px' }}>
        <Autocomplete
          label="Controlled"
          value={value}
          onChange={(_event: any, newValue: any) => setValue(newValue)}
          options={topFilms}
        />
        <div style={{ fontSize: '14px', color: '#666' }}>
          Selected: {value ? value.label : 'None'}
        </div>
      </div>
    );
  },
};

/**
 * Interactive autocomplete with all controls
 */
export const Interactive: Story = {
  args: {
    label: 'Interactive',
    options: topFilms,
    size: 'medium',
    disabled: false,
    loading: false,
    multiple: false,
    freeSolo: false,
    disableClearable: false,
  },
  render: (args: AutocompleteProps) => (
    <Autocomplete {...args} sx={{ width: 300 }} />
  ),
};
