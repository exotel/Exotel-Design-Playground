import type { Meta, StoryObj } from '@storybook/react';
import { Icon } from '../../components';

const meta: Meta<typeof Icon> = {
  title: 'UI Components/Icon',
  component: Icon,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component: 'Exotel-approved icon component that wraps Phosphor Icons. Provides a consistent, string-based API for using icons across Exotel applications.',
      },
    },
  },
  argTypes: {
    name: {
      control: 'select',
      options: [
        'phone', 'warning', 'check-circle', 'x-circle', 'info', 'question',
        'arrow-left', 'arrow-right', 'arrow-up', 'arrow-down',
        'caret-left', 'caret-right', 'caret-up', 'caret-down',
        'trash', 'edit', 'plus', 'minus', 'x', 'check',
        'mail', 'bell', 'chat', 'menu', 'search', 'filter',
        'settings', 'user', 'lock', 'unlock', 'eye', 'eye-slash',
        'circle', 'circle-fill'
      ],
      description: 'The name of the icon to display',
      table: {
        type: { summary: 'IconName' },
      },
    },
    size: {
      control: 'select',
      options: ['xs', 'sm', 'md', 'lg'],
      description: 'Size of the icon',
      table: {
        type: { summary: "'xs' | 'sm' | 'md' | 'lg' | number" },
        defaultValue: { summary: "'md'" },
      },
    },
    weight: {
      control: 'select',
      options: ['regular', 'bold', 'fill', 'light'],
      description: 'Weight/style of the icon',
      table: {
        type: { summary: "'regular' | 'bold' | 'fill' | 'light'" },
        defaultValue: { summary: "'regular'" },
      },
    },
    color: {
      control: 'color',
      description: 'Color of the icon. Defaults to theme text color.',
      table: {
        type: { summary: 'string' },
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Icon>;

/**
 * Basic icon
 */
export const Basic: Story = {
  args: {
    name: 'phone',
    size: 'md',
    weight: 'regular',
  },
};

/**
 * Different sizes
 */
export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
      <Icon name="phone" size="xs" />
      <Icon name="phone" size="sm" />
      <Icon name="phone" size="md" />
      <Icon name="phone" size="lg" />
    </div>
  ),
};

/**
 * Different weights
 */
export const Weights: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
      <Icon name="warning" weight="light" />
      <Icon name="warning" weight="regular" />
      <Icon name="warning" weight="bold" />
      <Icon name="warning" weight="fill" />
    </div>
  ),
};

/**
 * Different colors
 */
export const Colors: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
      <Icon name="check-circle" color="#4caf50" />
      <Icon name="x-circle" color="#d32f2f" />
      <Icon name="info" color="#0288d1" />
      <Icon name="warning" color="#ed6c02" />
    </div>
  ),
};

/**
 * Common icons showcase
 */
export const CommonIcons: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
      <Icon name="phone" />
      <Icon name="mail" />
      <Icon name="user" />
      <Icon name="settings" />
      <Icon name="search" />
      <Icon name="menu" />
      <Icon name="check" />
      <Icon name="x" />
      <Icon name="plus" />
      <Icon name="minus" />
      <Icon name="trash" />
      <Icon name="edit" />
    </div>
  ),
};

/**
 * Navigation icons
 */
export const NavigationIcons: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
      <Icon name="arrow-left" />
      <Icon name="arrow-right" />
      <Icon name="arrow-up" />
      <Icon name="arrow-down" />
      <Icon name="caret-left" />
      <Icon name="caret-right" />
      <Icon name="caret-up" />
      <Icon name="caret-down" />
    </div>
  ),
};

/**
 * Interactive icon with all controls
 */
export const Interactive: Story = {
  args: {
    name: 'phone',
    size: 'md',
    weight: 'regular',
    color: undefined,
  },
};
