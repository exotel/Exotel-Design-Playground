import type { Meta, StoryObj } from '@storybook/react';
import { Typography } from '../../components';

const meta: Meta<typeof Typography> = {
  title: 'UI Components/Typography',
  component: Typography,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component: 'Exotel-approved typography component that wraps MUI\'s Typography. Provides consistent text styling across Exotel applications.',
      },
    },
  },
  argTypes: {
    variant: {
      control: 'select',
      options: [
        'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
        'title1', 'title2', 'title3',
        'label1', 'label2', 'label3',
        'body1', 'body2', 'body3',
        'caption', 'overline',
      ],
      description: 'The typography variant to use.',
      table: {
        type: { summary: 'Typography variant token' },
        defaultValue: { summary: "'body1'" },
      },
    },
    color: {
      control: 'select',
      options: ['initial', 'inherit', 'primary', 'secondary', 'text.primary', 'text.secondary', 'text.disabled', 'error'],
      description: 'The color of the text',
      table: {
        type: { summary: "'initial' | 'inherit' | 'primary' | 'secondary' | 'text.primary' | 'text.secondary' | 'text.disabled' | 'error'" },
        defaultValue: { summary: "'text.primary'" },
      },
    },
    align: {
      control: 'select',
      options: ['inherit', 'left', 'center', 'right', 'justify'],
      description: 'Set the text-align on the component',
      table: {
        type: { summary: "'inherit' | 'left' | 'center' | 'right' | 'justify'" },
        defaultValue: { summary: "'inherit'" },
      },
    },
    gutterBottom: {
      control: 'boolean',
      description: 'If true, the text will have a bottom margin',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    noWrap: {
      control: 'boolean',
      description: 'If true, the text will not wrap',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Typography>;

export const TypographySystem: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px', maxWidth: '800px' }}>
      <section>
        <Typography variant="h3" gutterBottom>Headings</Typography>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', paddingLeft: '16px' }}>
          <Typography variant="h1">Heading 1 - 60px / Bold (700)</Typography>
          <Typography variant="h2">Heading 2 - 48px / Bold (700)</Typography>
          <Typography variant="h3">Heading 3 - 32px / Bold (700)</Typography>
          <Typography variant="h4">Heading 4 - 24px / Bold (700)</Typography>
          <Typography variant="h5">Heading 5 - 20px / Bold (700)</Typography>
          <Typography variant="h6">Heading 6 - 16px / Bold (700)</Typography>
        </div>
      </section>

      <section>
        <Typography variant="h3" gutterBottom>Titles</Typography>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', paddingLeft: '16px' }}>
          <Typography variant="title3">Title 3 - 16px / SemiBold (600)</Typography>
          <Typography variant="title2">Title 2 - 14px / SemiBold (600)</Typography>
          <Typography variant="title1">Title 1 - 12px / SemiBold (600)</Typography>
        </div>
      </section>

      <section>
        <Typography variant="h3" gutterBottom>Labels</Typography>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', paddingLeft: '16px' }}>
          <Typography variant="label3">Label 3 - 16px / Medium (500)</Typography>
          <Typography variant="label2">Label 2 - 14px / Medium (500)</Typography>
          <Typography variant="label1">Label 1 - 12px / Medium (500)</Typography>
        </div>
      </section>

      <section>
        <Typography variant="h3" gutterBottom>Body Text</Typography>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', paddingLeft: '16px' }}>
          <Typography variant="body1">Body 1 - 16px / Regular (400)</Typography>
          <Typography variant="body2">Body 2 - 14px / Regular (400)</Typography>
          <Typography variant="body3">Body 3 - 12px / Regular (400)</Typography>
        </div>
      </section>

      <section>
        <Typography variant="h3" gutterBottom>Caption &amp; Overline</Typography>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', paddingLeft: '16px' }}>
          <Typography variant="caption">Caption - 12px / Regular (400)</Typography>
          <Typography variant="overline">Overline - 12px / Regular (400) / Uppercase</Typography>
        </div>
      </section>

    </div>
  ),
};

export const AllVariants: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
      <Typography variant="h1">Heading 1</Typography>
      <Typography variant="h2">Heading 2</Typography>
      <Typography variant="h3">Heading 3</Typography>
      <Typography variant="h4">Heading 4</Typography>
      <Typography variant="h5">Heading 5</Typography>
      <Typography variant="h6">Heading 6</Typography>
      <Typography variant="title3">Title 3</Typography>
      <Typography variant="title2">Title 2</Typography>
      <Typography variant="title1">Title 1</Typography>
      <Typography variant="label3">Label 3</Typography>
      <Typography variant="label2">Label 2</Typography>
      <Typography variant="label1">Label 1</Typography>
      <Typography variant="body1">Body 1</Typography>
      <Typography variant="body2">Body 2</Typography>
      <Typography variant="body3">Body 3</Typography>
      <Typography variant="caption">Caption</Typography>
      <Typography variant="overline">Overline</Typography>
    </div>
  ),
};

export const Colors: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
      <Typography color="text.primary">Primary text</Typography>
      <Typography color="text.secondary">Secondary text</Typography>
      <Typography color="text.disabled">Disabled text</Typography>
      <Typography color="primary">Primary color</Typography>
      <Typography color="secondary">Secondary color</Typography>
      <Typography color="error">Error color</Typography>
    </div>
  ),
};

export const Alignment: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', width: '300px' }}>
      <Typography align="left">Left aligned text</Typography>
      <Typography align="center">Center aligned text</Typography>
      <Typography align="right">Right aligned text</Typography>
      <Typography align="justify">
        Justified text that spreads across the full width of the container.
      </Typography>
    </div>
  ),
};

export const Headings: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <Typography variant="h1">Heading 1 - 60px / Bold</Typography>
      <Typography variant="h2">Heading 2 - 48px / Bold</Typography>
      <Typography variant="h3">Heading 3 - 32px / Bold</Typography>
      <Typography variant="h4">Heading 4 - 24px / Bold</Typography>
      <Typography variant="h5">Heading 5 - 20px / Bold</Typography>
      <Typography variant="h6">Heading 6 - 16px / Bold</Typography>
    </div>
  ),
};

export const Titles: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <Typography variant="title3">Title 3 - 16px / SemiBold (600)</Typography>
      <Typography variant="title2">Title 2 - 14px / SemiBold (600)</Typography>
      <Typography variant="title1">Title 1 - 12px / SemiBold (600)</Typography>
    </div>
  ),
};

export const Labels: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <Typography variant="label3">Label 3 - 16px / Medium (500)</Typography>
      <Typography variant="label2">Label 2 - 14px / Medium (500)</Typography>
      <Typography variant="label1">Label 1 - 12px / Medium (500)</Typography>
    </div>
  ),
};

export const BodyText: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', maxWidth: '600px' }}>
      <Typography variant="body1">
        Body 1 (16px / Regular) - This is the default body text style. Use for paragraphs and general content.
      </Typography>
      <Typography variant="body2">
        Body 2 (14px / Regular) - This is a smaller body text style. Use for secondary content or compact layouts.
      </Typography>
      <Typography variant="body3">
        Body 3 (12px / Regular) - This is the smallest body text. Use sparingly for very compact content.
      </Typography>
    </div>
  ),
};

export const Interactive: Story = {
  args: {
    children: 'Typography text',
    variant: 'body1',
    color: 'text.primary',
    align: 'inherit',
    gutterBottom: false,
    noWrap: false,
  },
};
