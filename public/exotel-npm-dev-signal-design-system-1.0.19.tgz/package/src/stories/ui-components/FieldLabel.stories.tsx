import type { Meta, StoryObj } from '@storybook/react';
import { FieldWrapper, TextField } from '../../components';

const meta: Meta<typeof FieldWrapper> = {
  title: 'UI Components/FieldWrapper',
  component: FieldWrapper,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'Shared wrapper that renders an external label above any field component. Used by TextField, Autocomplete, and all date/time pickers.',
      },
    },
  },

  argTypes: {
    label: {
      control: 'text',
      description: 'The label content. When falsy the label row is omitted.',
    },
    htmlFor: {
      control: 'text',
      description: 'Associates the label with an input via its id.',
    },
    required: {
      control: 'boolean',
      description: 'If true, a red asterisk is appended to the label.',
      table: { defaultValue: { summary: 'false' } },
    },
  },
};

export default meta;
type Story = StoryObj<typeof FieldWrapper>;

export const Default: Story = {
  args: {
    label: 'Email address',
    htmlFor: 'email-input',
  },
  render: (args) => (
    <FieldWrapper {...args}>
      <TextField id="email-input" placeholder="you@example.com" size="small" />
    </FieldWrapper>
  ),
};

export const Required: Story = {
  args: {
    label: 'Full name',
    htmlFor: 'name-input',
    required: true,
  },
  render: (args) => (
    <FieldWrapper {...args}>
      <TextField id="name-input" placeholder="John Doe" size="small" />
    </FieldWrapper>
  ),
};

export const NoLabel: Story = {
  args: {
    label: undefined,
  },
  render: (args) => (
    <FieldWrapper {...args}>
      <TextField placeholder="No external label" size="small" />
    </FieldWrapper>
  ),
};
