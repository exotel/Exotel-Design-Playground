import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import dayjs, { type Dayjs } from 'dayjs';
import { DateRangePicker, type DateRangePickerProps } from '../../components';
import type { DateRange } from '@mui/x-date-pickers-pro';
import type { DateRangeShortcut } from '../../components/DateRangePicker/dateRangeShortcuts';

const meta: Meta<typeof DateRangePicker> = {
  title: 'Date & Time Pickers/DateRangePicker',
  component: DateRangePicker,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          "Exotel-approved date range picker that wraps MUI X DateRangePicker (pro). Allows selection of a start and end date. Includes a built-in LocalizationProvider with dayjs.",
      },
    },
  },
  argTypes: {
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
      description: 'The size of the picker input',
      table: {
        type: { summary: "'small' | 'medium' | 'large'" },
        defaultValue: { summary: "'medium'" },
      },
    },
    label: {
      control: 'text',
      description: 'External label rendered above the picker',
      table: { type: { summary: 'ReactNode' } },
    },
    disabled: {
      control: 'boolean',
      description: 'If true, the picker is disabled',
      table: { type: { summary: 'boolean' }, defaultValue: { summary: 'false' } },
    },
    readOnly: {
      control: 'boolean',
      description: 'If true, the picker is read-only',
      table: { type: { summary: 'boolean' }, defaultValue: { summary: 'false' } },
    },
    disableFuture: {
      control: 'boolean',
      description: 'If true, future dates are disabled',
      table: { type: { summary: 'boolean' }, defaultValue: { summary: 'false' } },
    },
    disablePast: {
      control: 'boolean',
      description: 'If true, past dates are disabled',
      table: { type: { summary: 'boolean' }, defaultValue: { summary: 'false' } },
    },
    calendars: {
      control: { type: 'number', min: 1, max: 3 },
      description: 'Number of calendars rendered',
      table: { type: { summary: '1 | 2 | 3' }, defaultValue: { summary: '2' } },
    },
  },
};

export default meta;
type Story = StoryObj<typeof DateRangePicker>;

/**
 * Basic date range picker with a label.
 */
export const Basic: Story = {
  render: () => <DateRangePicker label="Select date range" />,
};

/**
 * All three sizes — small (32px), medium (40px), and large (50px) — matching TextField.
 */
export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16, minWidth: 500 }}>
      <DateRangePicker label="Small" size="small" />
      <DateRangePicker label="Medium" size="medium" />
      <DateRangePicker label="Large" size="large" />
    </div>
  ),
};

/**
 * Controlled date range picker with React state.
 */
export const Controlled: Story = {
  render: () => {
    const [value, setValue] = useState<DateRange<Dayjs>>([null, null]);
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16, minWidth: 500 }}>
        <DateRangePicker label="Date range" value={value} onChange={(newValue) => setValue(newValue)} />
        <div style={{ fontSize: 14, color: '#666' }}>
          Start: {value[0] ? value[0].format('MMMM D, YYYY') : 'None'}
          {' — '}
          End: {value[1] ? value[1].format('MMMM D, YYYY') : 'None'}
        </div>
      </div>
    );
  },
};

/**
 * Without an external label.
 */
export const WithoutLabel: Story = {
  render: () => <DateRangePicker />,
};

/**
 * Disabled state.
 */
export const Disabled: Story = {
  render: () => (
    <DateRangePicker
      label="Disabled"
      disabled
      defaultValue={[dayjs(), dayjs().add(7, 'day')]}
    />
  ),
};

/**
 * Read-only state.
 */
export const ReadOnly: Story = {
  render: () => (
    <DateRangePicker
      label="Read only"
      readOnly
      defaultValue={[dayjs(), dayjs().add(7, 'day')]}
    />
  ),
};

/**
 * Only future dates are selectable.
 */
export const DisablePast: Story = {
  render: () => <DateRangePicker label="Future dates only" disablePast />,
};

/**
 * Single calendar instead of the default two.
 */
export const SingleCalendar: Story = {
  render: () => <DateRangePicker label="Single calendar" calendars={1} />,
};

/**
 * Restrict to a specific date window.
 */
export const MinMaxDate: Story = {
  render: () => (
    <DateRangePicker
      label="This month only"
      minDate={dayjs().startOf('month')}
      maxDate={dayjs().endOf('month')}
    />
  ),
};

/**
 * With built-in default shortcuts panel (Today, Yesterday, Last 7 Days, etc.).
 * Simply pass `shortcuts` to enable.
 */
export const WithoutShortcuts: Story = {
  render: () => (
    <DateRangePicker label="Without shortcuts" shortcuts={false} />
  ),
};

/**
 * With custom shortcuts array for full control over the shortcuts panel.
 */
export const WithCustomShortcuts: Story = {
  render: () => {
    const customShortcuts: DateRangeShortcut[] = [
      { label: 'Today', getValue: () => [dayjs().startOf('day'), dayjs().endOf('day')] },
      { label: 'This week', getValue: () => [dayjs().startOf('week'), dayjs().endOf('week')] },
      { label: 'This month', getValue: () => [dayjs().startOf('month'), dayjs().endOf('month')] },
    ];
    return (
      <DateRangePicker label="With custom shortcuts" shortcuts={customShortcuts} />
    );
  },
};

/**
 * Default action bar with Cancel and Accept actions.
 */
export const ActionBar: Story = {
  render: () => (
    <DateRangePicker
      label="With action bar"
      slotProps={{
        actionBar: {
          actions: ['clear', 'cancel', 'accept'],
        },
      }}
    />
  ),
};


/**
 * Interactive playground with all controls.
 */
export const Interactive: Story = {
  args: {
    label: 'Pick a range',
    size: 'medium',
    disabled: false,
    readOnly: false,
    disableFuture: false,
    disablePast: false,
    calendars: 2,
  },
  render: (args: DateRangePickerProps) => <DateRangePicker {...args} />,
};
