import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { AvatarMenu } from '../../components';
import type { AvatarMenuGroup, AvatarMenuFooterInfo, ThemeMode } from '../../components';

const PRIMARY_GROUP: AvatarMenuGroup = {
  id: 'primary',
  items: [
    { id: 'item1', label: 'Menu Item 1', onClick: () => console.log('item1') },
    { id: 'item2', label: 'Menu Item 2', onClick: () => console.log('item2') },
    { id: 'item3', label: 'Menu Item 3', onClick: () => console.log('item3') },
  ],
};

const SECONDARY_GROUP: AvatarMenuGroup = {
  id: 'secondary',
  items: [
    { id: 'error-logs', label: 'Send Error Logs', onClick: () => console.log('error-logs') },
    { id: 'shortcuts', label: 'Keyboard Shortcuts', onClick: () => console.log('shortcuts') },
  ],
};

const FOOTER_INFO: AvatarMenuFooterInfo[] = [
  { label: 'Last Login', value: 'Jun 21 at 08:37' },
  { label: 'Version', value: '6.0' },
];

const meta: Meta<typeof AvatarMenu> = {
  title: 'UI Components/AvatarMenu',
  component: AvatarMenu,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'Avatar trigger (with online badge) that opens a structured dropdown. Supply `menuGroups` — an array of item groups each separated by a divider. The header, Theme and Logout rows are built-in constants. Static footer rows (last login, version, etc.) are provided via `footerInfo: { label, value }[]`.',
      },
    },
  },
  argTypes: {
    avatarName: {
      control: 'text',
      description: 'Full name — initials and avatar colour are derived automatically.',
    },
  },
};

export default meta;
type Story = StoryObj<typeof AvatarMenu>;

export const Default: Story = {
  render: (args) => {
    const [selectedTheme, setSelectedTheme] = useState<ThemeMode>('system');
    return (
      <AvatarMenu
        {...args}
        selectedTheme={selectedTheme}
        onThemeChange={(mode) => { setSelectedTheme(mode); console.log('theme changed:', mode); }}
      />
    );
  },
  args: {
    avatarName: 'Anjali Srivastava',
    menuGroups: [PRIMARY_GROUP, SECONDARY_GROUP],
    footerInfo: FOOTER_INFO,
    onLogout: () => console.log('logout'),
    selectedTheme: 'system',
    onThemeChange: () => {},
  },
};

export const LightThemeSelected: Story = {
  name: 'Light theme pre-selected',
  args: {
    avatarName: 'Olivia Pope',
    menuGroups: [PRIMARY_GROUP, SECONDARY_GROUP],
    footerInfo: FOOTER_INFO,
    selectedTheme: 'light',
    onThemeChange: (mode) => console.log('theme:', mode),
    onLogout: () => console.log('logout'),
  },
};

export const ThreeGroups: Story = {
  name: 'Three groups',
  render: (args) => {
    const [selectedTheme, setSelectedTheme] = useState<ThemeMode>('dark');
    return (
      <AvatarMenu
        {...args}
        selectedTheme={selectedTheme}
        onThemeChange={(mode) => { setSelectedTheme(mode); console.log('theme:', mode); }}
      />
    );
  },
  args: {
    avatarName: 'Rudraksh Prasanth',
    menuGroups: [
      {
        id: 'g1',
        items: [
          { id: 'item1', label: 'Menu Item 1', onClick: () => console.log('item1') },
          { id: 'item2', label: 'Menu Item 2', onClick: () => console.log('item2') },
          { id: 'item3', label: 'Menu Item 3', onClick: () => console.log('item3') },
        ],
      },
      {
        id: 'g2',
        items: [
          { id: 'error-logs', label: 'Send Error Logs', onClick: () => console.log('error-logs') },
          { id: 'shortcuts', label: 'Keyboard Shortcuts', onClick: () => console.log('shortcuts') },
        ],
      },
    ],
    footerInfo: [
      { label: 'Last Login', value: 'Mar 23 at 11:00' },
      { label: 'Version', value: '6.0' },
    ],
    selectedTheme: 'dark',
    onThemeChange: () => {},
    onLogout: () => console.log('logout'),
  },
};
