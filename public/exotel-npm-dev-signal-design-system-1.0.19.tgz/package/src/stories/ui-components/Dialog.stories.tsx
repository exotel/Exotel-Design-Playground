import type { Meta, StoryObj } from '@storybook/react';
import { Dialog, Button, Typography, Box, TextField, Radio, FormControl, IconButton } from '../../components';
import { DialogTitle, DialogContent, DialogActions, RadioGroup, FormControlLabel, Divider } from '@mui/material';
import { Icon } from '../../components';
import { useState } from 'react';

const meta: Meta<typeof Dialog> = {
  title: 'UI Components/Dialog',
  component: Dialog,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'Exotel-approved dialog component that wraps MUI\'s Dialog. Supports structured layout with Header/Body/Footer pattern using DialogTitle, DialogContent, and DialogActions.',
      },
    },
  },
  argTypes: {
    open: {
      control: 'boolean',
      description: 'If true, the dialog is open',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    fullWidth: {
      control: 'boolean',
      description: 'If true, the dialog stretches to maxWidth',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    maxWidth: {
      control: 'select',
      options: ['xs', 'sm', 'md', 'lg', 'xl', false],
      description: 'Determine the max-width of the dialog',
      table: {
        type: { summary: "'xs' | 'sm' | 'md' | 'lg' | 'xl' | false" },
        defaultValue: { summary: "'sm'" },
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Dialog>;

/**
 * Basic dialog with structured layout
 */
export const Basic: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    return (
      <Box>
        <Button onClick={() => setOpen(true)}>Open Dialog</Button>
        <Dialog open={open} onClose={() => setOpen(false)} maxWidth="sm" fullWidth>
          <DialogTitle>
            Heading
            <IconButton
              edge="end"
              onClick={() => setOpen(false)}
              aria-label="close dialog"
              size="small"
              sx={{
                color: 'text.primary',
                '& svg': {
                  color: 'inherit',
                },
              }}
            >
              <Icon name="x" size="sm" />
            </IconButton>
          </DialogTitle>
          <DialogContent dividers>
            <Typography variant="body2">
              This is the body content of the dialog. You can add any content here,
              such as forms, lists, or other components.
            </Typography>
          </DialogContent>
          <DialogActions>
            <Button variant="contained" onClick={() => setOpen(false)}>
              Save and Dial
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
    );
  },
};

/**
 * Dialog with form content (matching Figma design)
 */
export const WithForm: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    const [channel, setChannel] = useState('whatsapp');
    const [number, setNumber] = useState('9876543210');
    const [template, setTemplate] = useState('Hi {Customer name} can we connect ?');

    return (
      <Box>
        <Button onClick={() => setOpen(true)}>Open Form Dialog</Button>
        <Dialog open={open} onClose={() => setOpen(false)} maxWidth="sm" fullWidth>
          <DialogTitle>
            Heading
            <IconButton
              edge="end"
              onClick={() => setOpen(false)}
              aria-label="close dialog"
              size="small"
              sx={{
                color: 'text.primary',
                '& svg': {
                  color: 'inherit',
                },
              }}
            >
              <Icon name="x" size="sm" />
            </IconButton>
          </DialogTitle>
          <DialogContent dividers>
            {/* Channel Selection */}
            <Box sx={{ mb: 3 }}>
              <Typography variant="body2" sx={{ mb: 2, fontWeight: 500 }}>
                Channel
              </Typography>
              <FormControl>
                <RadioGroup
                  value={channel}
                  onChange={(e) => setChannel(e.target.value)}
                  row
                >
                  <FormControlLabel value="call" control={<Radio />} label="Call" />
                  <FormControlLabel
                    value="whatsapp"
                    control={<Radio />}
                    label="WhatsApp Chat"
                  />
                </RadioGroup>
              </FormControl>
            </Box>

            {/* Note */}
            <Box
              sx={{
                p: 2,
                mb: 3,
                backgroundColor: 'action.hover',
                borderRadius: 1,
              }}
            >
              <Typography variant="body3" color="text.secondary">
                Note : Please ensure the selected number is available on WhatsApp
              </Typography>
            </Box>

            {/* Number Input */}
            <Box sx={{ mb: 3 }}>
              <TextField
                fullWidth
                label="Enter or select number"
                value={number}
                onChange={(e) => setNumber(e.target.value)}
              />
            </Box>

            {/* Template Text Area */}
            <Box>
              <TextField
                fullWidth
                label="Select Template"
                multiline
                rows={4}
                value={template}
                onChange={(e) => setTemplate(e.target.value)}
              />
            </Box>
          </DialogContent>
          <DialogActions>
            <Button variant="contained" onClick={() => setOpen(false)}>
              Save and Dial
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
    );
  },
};

/**
 * Dialog with long, scrollable body
 */
export const ScrollableBody: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    return (
      <Box>
        <Button onClick={() => setOpen(true)}>Open Scrollable Dialog</Button>
        <Dialog open={open} onClose={() => setOpen(false)} maxWidth="sm" fullWidth>
          <DialogTitle>
            Long Content Example
            <IconButton
              edge="end"
              onClick={() => setOpen(false)}
              aria-label="close dialog"
              size="small"
              sx={{
                color: 'text.primary',
                '& svg': {
                  color: 'inherit',
                },
              }}
            >
              <Icon name="x" size="sm" />
            </IconButton>
          </DialogTitle>
          <DialogContent dividers>
            {Array.from({ length: 50 }, (_, i) => (
              <Typography key={i} variant="body2" sx={{ mb: 2 }}>
                This is paragraph {i + 1}. The body section should scroll when
                content overflows, while the header and footer remain fixed.
              </Typography>
            ))}
          </DialogContent>
          <DialogActions>
            <Button variant="contained" onClick={() => setOpen(false)}>
              Save
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
    );
  },
};

/**
 * Dialog without header
 */
export const WithoutHeader: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    return (
      <Box>
        <Button onClick={() => setOpen(true)}>Open Dialog (No Header)</Button>
        <Dialog open={open} onClose={() => setOpen(false)} maxWidth="sm" fullWidth>
          <DialogContent dividers>
            <Typography variant="body2">
              This dialog does not have a header. The close button is not rendered
              when the header is hidden. Users must use the footer action or click
              outside to close.
            </Typography>
          </DialogContent>
          <DialogActions>
            <Button variant="contained" onClick={() => setOpen(false)}>
              Continue
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
    );
  },
};

/**
 * Dialog without footer
 */
export const WithoutFooter: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    return (
      <Box>
        <Button onClick={() => setOpen(true)}>Open Dialog (No Footer)</Button>
        <Dialog open={open} onClose={() => setOpen(false)} maxWidth="sm" fullWidth>
          <DialogTitle>
            Information Dialog
            <IconButton
              edge="end"
              onClick={() => setOpen(false)}
              aria-label="close dialog"
              size="small"
              sx={{
                color: 'text.primary',
                '& svg': {
                  color: 'inherit',
                },
              }}
            >
              <Icon name="x" size="sm" />
            </IconButton>
          </DialogTitle>
          <DialogContent dividers>
            <Typography variant="body2">
              This dialog does not have a footer. It's useful for informational
              dialogs where the only action is to close via the header close button
              or backdrop click.
            </Typography>
          </DialogContent>
        </Dialog>
      </Box>
    );
  },
};

/**
 * Dialog with multiple footer actions
 */
export const MultipleFooterActions: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    return (
      <Box>
        <Button onClick={() => setOpen(true)}>Open Dialog (Multiple Actions)</Button>
        <Dialog open={open} onClose={() => setOpen(false)} maxWidth="sm" fullWidth>
          <DialogTitle>
            Confirm Action
            <IconButton
              edge="end"
              onClick={() => setOpen(false)}
              aria-label="close dialog"
              size="small"
              sx={{
                color: 'text.primary',
                '& svg': {
                  color: 'inherit',
                },
              }}
            >
              <Icon name="x" size="sm" />
            </IconButton>
          </DialogTitle>
          <DialogContent dividers>
            <Typography variant="body2">
              This dialog has multiple actions in the footer. Notice there's no
              default Cancel button - the close (×) button is the primary dismissal
              action.
            </Typography>
          </DialogContent>
          <DialogActions>
            <Button variant="outlined" color="error" onClick={() => setOpen(false)}>
              Delete
            </Button>
            <Button variant="contained" onClick={() => setOpen(false)}>
              Save Changes
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
    );
  },
};

/**
 * Small dialog with minimal content
 */
export const SmallDialog: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    return (
      <Box>
        <Button onClick={() => setOpen(true)}>Open Small Dialog</Button>
        <Dialog open={open} onClose={() => setOpen(false)} maxWidth="sm" fullWidth>
          <DialogTitle>
            Confirmation
            <IconButton
              edge="end"
              onClick={() => setOpen(false)}
              aria-label="close dialog"
              size="small"
              sx={{
                color: 'text.primary',
                '& svg': {
                  color: 'inherit',
                },
              }}
            >
              <Icon name="x" size="sm" />
            </IconButton>
          </DialogTitle>
          <DialogContent dividers>
            <Typography variant="body2">
              Are you sure you want to proceed with this action?
            </Typography>
          </DialogContent>
          <DialogActions>
            <Button variant="contained" onClick={() => setOpen(false)}>
              Confirm
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
    );
  },
};

/**
 * Legacy dialog (backward compatibility)
 */
export const Legacy: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    return (
      <Box>
        <Button onClick={() => setOpen(true)}>Open Legacy Dialog</Button>
        <Dialog open={open} onClose={() => setOpen(false)}>
          <Box sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Legacy Dialog
            </Typography>
            <Typography variant="body2">
              This is a legacy dialog without structured layout. All existing
              Dialog usage patterns continue to work.
            </Typography>
            <Box sx={{ mt: 2, display: 'flex', justifyContent: 'flex-end', gap: 2 }}>
              <Button variant="outlined" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button variant="contained" onClick={() => setOpen(false)}>
                OK
              </Button>
            </Box>
          </Box>
        </Dialog>
      </Box>
    );
  },
};
