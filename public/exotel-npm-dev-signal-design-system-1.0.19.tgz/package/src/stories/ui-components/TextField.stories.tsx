/**
 * TextField Component Stories
 *
 * Stories for the Exotel TextField component that wraps MUI's TextField.
 */

import type { Meta, StoryObj } from '@storybook/react';
import { InputAdornment } from '@mui/material';
import { TextField, Icon } from '../../components';

const meta: Meta<typeof TextField> = {
  title: 'UI Components/TextField',
  component: TextField,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'Exotel-approved text field component with label above the input, wrapping MUI\'s TextField.',
      },
    },
  },
  argTypes: {
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
      description: 'The size of the component',
      table: {
        type: { summary: "'small' | 'medium' | 'large'" },
        defaultValue: { summary: "'medium'" },
      },
    },
    disabled: {
      control: 'boolean',
      description: 'If true, the component is disabled',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    required: {
      control: 'boolean',
      description: 'If true, the label is displayed as required',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    error: {
      control: 'boolean',
      description: 'If true, the label is displayed in an error state',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    fullWidth: {
      control: 'boolean',
      description: 'If true, the input will take up the full width of its container',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    showLabel: {
      control: 'boolean',
      description: 'If true, the label is displayed',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'true' },
      },
    },
    label: {
      control: 'text',
      description: 'The label content',
    },
    placeholder: {
      control: 'text',
      description: 'The short hint displayed in the input before the user enters a value',
    },
    helperText: {
      control: 'text',
      description: 'The helper text content',
    },
    // React-node props — keep out of Controls to avoid Storybook freeze on serialize/diff
    slotProps: { control: false, table: { disable: true } },
    InputProps: { control: false, table: { disable: true } },
    inputProps: { control: false, table: { disable: true } },
    SelectProps: { control: false, table: { disable: true } },
    children: { control: false, table: { disable: true } },
  },
};

export default meta;
type Story = StoryObj<typeof TextField>;

/**
 * Basic text field
 */
export const Basic: Story = {
  args: {
    label: 'Label',
  },
};

/**
 * Different sizes
 */
export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', width: '300px' }}>
      <TextField label="Small" size="small" />
      <TextField label="Medium" size="medium" />
      <TextField label="Large" size="large" />
    </div>
  ),
};

/**
 * With helper text
 */
export const HelperText: Story = {
  args: {
    label: 'Email',
    helperText: 'Enter your email address',
  },
};

/**
 * Disabled, error, and required states
 */
export const DisabledErrorRequired: Story = {
  name: 'Disabled, Error, Required',
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', width: '300px' }}>
      <TextField label="Disabled" disabled defaultValue="Disabled value" />
      <TextField label="Email" error helperText="Invalid email address" />
      <TextField label="Required Field" required />
    </div>
  ),
};

/**
 * With start and end icons
 */
export const WithStartAndEndIcons: Story = {
  name: 'With Start and End Icons',
  render: () => (
    <div style={{ width: '300px' }}>
      <TextField
        label="Search"
        slotProps={{
          input: {
            startAdornment: (
              <InputAdornment position="start">
                <Icon name="magnifying-glass" size="sm" />
              </InputAdornment>
            ),
            endAdornment: (
              <InputAdornment position="end">
                <Icon name="x" size="sm" />
              </InputAdornment>
            ),
          },
        }}
      />
    </div>
  ),
};

/**
 * Multiline input (textarea)
 */
export const Multiline: Story = {
  argTypes: {
    multiline: { table: { disable: true } },
    size: { table: { disable: true } },
    rows: {
      control: 'number',
      description: 'Fixed number of rows',
    },
    minRows: {
      control: 'number',
      description: 'Minimum number of rows (auto-grow mode)',
    },
    maxRows: {
      control: 'number',
      description: 'Maximum number of rows (auto-grow mode)',
    },
  },
  args: {
    label: 'Description',
    placeholder: 'Enter a description...',
    minRows: 2,
    disabled: false,
    error: false,
    required: false,
    fullWidth: false,
    helperText: '',
  },
  render: (args) => (
    <div style={{ width: '350px' }}>
      <TextField multiline {...args} />
    </div>
  ),
};

/**
 * Interactive text field with Storybook controls.
 * Icon adornments are demoed in WithStartAndEndIcons — do not inject
 * React nodes into slotProps from Controls (that freezes Storybook).
 */
export const Interactive: Story = {
  args: {
    label: 'Label',
    size: 'medium',
    disabled: false,
    required: false,
    error: false,
    fullWidth: false,
    showLabel: true,
    placeholder: '',
    helperText: '',
  },
};
