import { useRef } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Box, Button, Stack, Typography } from '../../components';
import { Lottie, useLottie } from '../../lottie';
import type { LottieRefCurrentProps } from '../../lottie';
import refreshAnimation from '../../assets/icons8-refresh.json';

const meta: Meta<typeof Lottie> = {
  title: 'Lottie/Lottie',
  component: Lottie,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'Render [Lottie](https://airbnb.io/lottie/) (After Effects / Bodymovin) animations. ' +
          'This is a re-export of [`lottie-react`](https://lottiereact.com/) shipped as a ' +
          'separate entry point so it stays out of the main bundle.\n\n' +
          '### Install\n' +
          '```bash\nnpm install @exotel-npm-dev/signal-design-system\n```\n' +
          '`lottie-react` and `lottie-web` come bundled with this entry — no extra install needed.\n\n' +
          '### Import\n' +
          '```tsx\n' +
          "import { Lottie, useLottie, useLottieInteractivity } from '@exotel-npm-dev/signal-design-system/lottie';\n" +
          "import type { LottieRefCurrentProps } from '@exotel-npm-dev/signal-design-system/lottie';\n" +
          '```\n\n' +
          '### Basic usage\n' +
          '```tsx\n' +
          "import animationData from './my-animation.json';\n\n" +
          'function Loader() {\n' +
          '  return <Lottie animationData={animationData} loop autoplay style={{ width: 160, height: 160 }} />;\n' +
          '}\n' +
          '```\n\n' +
          '### Controlling playback imperatively\n' +
          'Pass a `lottieRef` to call `play()`, `pause()`, `stop()`, `setSpeed()`, `setDirection()`, ' +
          '`goToAndStop()` and more (see the **Playback controls** story).\n\n' +
          '### `useLottie` hook\n' +
          'For full control, the `useLottie` hook returns the rendered `View` plus the same control ' +
          'methods (see the **useLottie hook** story).\n\n' +
          '**Exports:** `Lottie` (default component), `LottiePlayer` (underlying lottie-web player), ' +
          '`useLottie`, `useLottieInteractivity`, and all related types.',
      },
    },
  },
  argTypes: {
    loop: {
      control: 'boolean',
      description: 'Repeat the animation when it finishes.',
      table: { category: 'Playback' },
    },
    autoplay: {
      control: 'boolean',
      description: 'Start playing as soon as it mounts.',
      table: { category: 'Playback' },
    },
    animationData: {
      control: false,
      description: 'Parsed Lottie JSON animation data.',
      table: { category: 'Content' },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Lottie>;

export const Basic: Story = {
  name: 'Basic',
  args: {
    loop: true,
    autoplay: true,
  },
  render: (args) => (
    <Lottie
      animationData={refreshAnimation}
      loop={args.loop}
      autoplay={args.autoplay}
      style={{ width: 160, height: 160 }}
    />
  ),
};

function PlaybackControlsDemo() {
  const lottieRef = useRef<LottieRefCurrentProps>(null);

  return (
    <Stack spacing={2} alignItems="center">
      <Lottie
        lottieRef={lottieRef}
        animationData={refreshAnimation}
        loop
        autoplay={false}
        style={{ width: 160, height: 160 }}
      />
      <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap justifyContent="center">
        <Button variant="contained" onClick={() => lottieRef.current?.play()}>
          Play
        </Button>
        <Button variant="outlined" onClick={() => lottieRef.current?.pause()}>
          Pause
        </Button>
        <Button variant="outlined" onClick={() => lottieRef.current?.stop()}>
          Stop
        </Button>
        <Button variant="outlined" onClick={() => lottieRef.current?.setSpeed(2)}>
          2× speed
        </Button>
        <Button variant="outlined" onClick={() => lottieRef.current?.setSpeed(1)}>
          1× speed
        </Button>
        <Button variant="outlined" onClick={() => lottieRef.current?.setDirection(-1)}>
          Reverse
        </Button>
        <Button variant="outlined" onClick={() => lottieRef.current?.setDirection(1)}>
          Forward
        </Button>
      </Stack>
    </Stack>
  );
}

export const PlaybackControls: Story = {
  name: 'Playback controls (lottieRef)',
  parameters: {
    docs: {
      description: {
        story:
          'Drive the animation imperatively via `lottieRef`. The ref exposes `play`, `pause`, ' +
          '`stop`, `setSpeed`, `setDirection`, `goToAndStop`, `goToAndPlay`, and `getDuration`.',
      },
    },
  },
  render: () => <PlaybackControlsDemo />,
};

function UseLottieHookDemo() {
  const { View, play, pause, stop, setSpeed } = useLottie(
    {
      animationData: refreshAnimation,
      loop: true,
      autoplay: false,
    },
    { width: 160, height: 160 },
  );

  return (
    <Stack spacing={2} alignItems="center">
      <Typography variant="body2" color="text.secondary">
        Rendered from the <code>useLottie</code> hook&apos;s <code>View</code>.
      </Typography>
      {View}
      <Stack direction="row" spacing={1} justifyContent="center">
        <Button variant="contained" onClick={() => play()}>
          Play
        </Button>
        <Button variant="outlined" onClick={() => pause()}>
          Pause
        </Button>
        <Button variant="outlined" onClick={() => stop()}>
          Stop
        </Button>
        <Button variant="outlined" onClick={() => setSpeed(1.5)}>
          1.5× speed
        </Button>
      </Stack>
    </Stack>
  );
}

export const UseLottieHook: Story = {
  name: 'useLottie hook',
  parameters: {
    docs: {
      description: {
        story:
          'The `useLottie(options, style?)` hook returns the rendered `View` element plus the same ' +
          'control methods as `lottieRef`, useful when you want to compose the animation inline.',
      },
    },
  },
  render: () => <UseLottieHookDemo />,
};

export const Static: Story = {
  name: 'Static (no autoplay / no loop)',
  parameters: {
    docs: {
      description: {
        story: 'A paused, single-frame render — `autoplay={false}` and `loop={false}`.',
      },
    },
  },
  render: () => (
    <Box sx={{ display: 'flex', justifyContent: 'center' }}>
      <Lottie
        animationData={refreshAnimation}
        loop={false}
        autoplay={false}
        style={{ width: 120, height: 120 }}
      />
    </Box>
  ),
};
