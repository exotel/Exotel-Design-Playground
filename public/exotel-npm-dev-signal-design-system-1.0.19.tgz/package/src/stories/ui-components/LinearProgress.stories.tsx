import type { Meta, StoryObj } from '@storybook/react';
import { LinearProgress, Box, Typography } from '../../components';

const meta: Meta<typeof LinearProgress> = {
  title: 'UI Components/LinearProgress',
  component: LinearProgress,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'Exotel-approved linear progress indicator that wraps MUI\'s LinearProgress. Displays progress as a horizontal bar.',
      },
    },
  },

  argTypes: {
    variant: {
      control: 'select',
      options: ['determinate', 'indeterminate', 'buffer', 'query'],
      description: 'The variant to use',
      table: { defaultValue: { summary: "'indeterminate'" } },
    },
    value: {
      control: { type: 'range', min: 0, max: 100 },
      description: 'Value between 0 and 100 (for determinate/buffer variants)',
    },
    valueBuffer: {
      control: { type: 'range', min: 0, max: 100 },
      description: 'Value for the buffer bar (buffer variant only)',
    },
    color: {
      control: 'select',
      options: ['primary', 'secondary', 'error', 'info', 'success', 'warning', 'inherit'],
      description: 'The color of the component',
      table: { defaultValue: { summary: "'primary'" } },
    },
  },
  decorators: [
    (Story) => (
      <Box sx={{ width: 400 }}>
        <Story />
      </Box>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof LinearProgress>;

export const Indeterminate: Story = {
  args: {
    variant: 'indeterminate',
  },
};

export const Determinate: Story = {
  args: {
    variant: 'determinate',
    value: 60,
  },
};

export const Buffer: Story = {
  args: {
    variant: 'buffer',
    value: 40,
    valueBuffer: 70,
  },
};

export const Colors: Story = {
  render: () => (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      <LinearProgress color="primary" />
      <LinearProgress color="secondary" />
      <LinearProgress color="success" />
      <LinearProgress color="error" />
      <LinearProgress color="warning" />
      <LinearProgress color="info" />
    </Box>
  ),
};

export const WithLabel: Story = {
  render: () => (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Typography variant="body2" color="text.secondary">Uploading...</Typography>
        <Typography variant="body2" color="text.secondary">75%</Typography>
      </Box>
      <LinearProgress variant="determinate" value={75} />
    </Box>
  ),
};
