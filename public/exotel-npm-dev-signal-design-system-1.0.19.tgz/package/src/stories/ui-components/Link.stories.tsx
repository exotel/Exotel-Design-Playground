import type { Meta, StoryObj } from '@storybook/react';
import { Link } from '../../components';

const meta: Meta<typeof Link> = {
  title: 'UI Components/Link',
  component: Link,
  parameters: { layout: 'centered' },
};

export default meta;
type Story = StoryObj<typeof Link>;

export const Basic: Story = { args: { href: '#', children: 'Link' } };
export const UnderlineNone: Story = { args: { href: '#', underline: 'none', children: 'No underline' } };
