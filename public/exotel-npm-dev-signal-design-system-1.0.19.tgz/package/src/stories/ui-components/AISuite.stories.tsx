import { useCallback, useMemo, useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import {
  AISuite,
  AgenticStep,
  AgenticSteps,
  Box,
  Button,
  Drawer,
  Popover,
  StepHeader,
  StructuredDialog,
  Typography,
  type AISuiteMessage,
  type MessageComposerOption,
} from '../../components';

const USER_PROMPT =
  'We have a large pool of prospects who started the demat account opening process on our app and website but dropped off. Some filled the form, some just browsed. We want to re-engage them and convert them into completed account openings. We typically see about a 12% conversion rate on these leads. I want to push that towards 20%. Budget is around ₹8 per lead for outreach. Channels: SMS, WhatsApp, and voice if needed. No calls before 9 AM or after 7 PM. Strictly no outreach to DND numbers for promotional content.';

const COMPOSER_OPTIONS: MessageComposerOption[] = [
  { id: 'a', label: "Let's do a compressed 7-day sprint, then return cold leads to nurture" },
  { id: 'b', label: 'Stick to the standard 10-day window to maximize conversion time' },
  { id: 'c', label: 'Let AI Decide' },
];

const SAMPLE_MESSAGES: AISuiteMessage[] = [
  {
    id: 'panel-user',
    type: 'user-text',
    content: 'Re-engage dropped-off demat leads via SMS + WhatsApp within a ₹8/lead budget.',
    onCopy: () => {},
  },
  {
    id: 'panel-steps',
    type: 'agentic-steps',
    content: (
      <AgenticSteps>
        <StepHeader title="Thinking" status="success" defaultExpanded={false} />
      </AgenticSteps>
    ),
  },
  {
    id: 'panel-assistant',
    type: 'assistant-text',
    content:
      'Here is a 7-day sprint targeting a 12% → 20% conversion lift while staying within your ₹8/lead budget and DND guardrails.',
    onCopy: () => {},
    feedbackProps: {
      onReactionChange: (r) => console.log('Reaction:', r),
      onSubmit: (fb) => console.log('Feedback:', fb),
    },
  },
];

const SUGGESTIONS = [
  {
    id: 's1',
    label: 'Re-engage dropped-off demat account leads via SMS + WhatsApp',
  },
  {
    id: 's2',
    label: 'Build a 7-day conversion sprint for cold prospects',
  },
  {
    id: 's3',
    label: 'Design a voicebot follow-up for high-intent leads',
  },
  {
    id: 's4',
    label: 'Create a TRAI-compliant promotional SMS campaign',
  },
];

const meta: Meta<typeof AISuite> = {
  title: 'AI-SUITE (Beta)/AISuite',
  component: AISuite,
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        component:
          'AISuite is the full agentic chat layout. It composes user and assistant messages, AgenticSteps, AgenticCard, MessageComposer, and ChatInputBox into a scrollable thread with a fixed input footer.',
      },
    },
  },
  decorators: [
    (Story) => (
      <Box sx={{ height: '100vh', bgcolor: 'surface.elevation0' }}>
        <Story />
      </Box>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof AISuite>;

/**
 * Empty landing state — hero copy, input, and quick-start suggestions.
 * Matches the Figma "Business Journey Agent" initial screen.
 */
export const EmptyState: Story = {
  render: () => {
    const [value, setValue] = useState('');

    return (
      <AISuite
        chatInput={{
          value,
          onChange: setValue,
          placeholder: 'Build or ask anything. Type / for commands',
          showVoiceInput: true,
          maxLength: 200,
          onSend: () => setValue(''),
        }}
        suggestions={SUGGESTIONS.map((s) => ({
          ...s,
          onClick: () => setValue(s.label),
        }))}
        disclaimer={{ onFeedbackClick: () => {} }}
      />
    );
  },
};

/**
 * End-to-end campaign conversation — user prompt, thinking steps,
 * clarification text, MessageComposer, user reply, and Campaign Blueprint card.
 * Matches the Figma Campaigns Agentic UI flow.
 */
export const CampaignConversation: Story = {
  render: () => {
    const [inputValue, setInputValue] = useState('');
    const [composerVisible, setComposerVisible] = useState(true);

    const messages = useMemo<AISuiteMessage[]>(
      () => [
        {
          id: 'user-1',
          type: 'user-text',
          content: USER_PROMPT,
          onCopy: () => {},
        },
        {
          id: 'steps-1',
          type: 'agentic-steps',
          content: (
            <AgenticSteps>
              <StepHeader title="Thinking" status="success" defaultExpanded={false} />
            </AgenticSteps>
          ),
        },
        {
          id: 'assistant-1',
          type: 'assistant-text',
          content: (
            <>
              I have ingested your requirements and initiated the planning engine. To ensure the
              journey drops cold leads at the right time, I need one quick clarification:
              <br />
              <br />
              What is your preferred maximum journey duration per lead?
            </>
          ),
          onCopy: () => {},
          feedbackProps: {
            onReactionChange: (r) => console.log('Reaction:', r),
            onSubmit: (fb) => console.log('Feedback:', fb),
          },
        },
        ...(composerVisible
          ? [
              {
                id: 'composer-1',
                type: 'message-composer' as const,
                composer: {
                  question: 'What is your preferred maximum journey duration per lead?',
                  options: COMPOSER_OPTIONS,
                  currentIndex: 1,
                  totalCount: 1,
                  onSelect: () => setComposerVisible(false),
                  onClose: () => setComposerVisible(false),
                },
              },
            ]
          : []),
        {
          id: 'user-2',
          type: 'user-text',
          content: "Let's do a compressed 7-day sprint, then return cold leads to nurture",
        },
        {
          id: 'steps-2',
          type: 'agentic-steps',
          content: (
            <AgenticSteps>
              <StepHeader title="Thinking" status="success">
                <AgenticStep
                  id="step-1"
                  title="Analysing Request"
                  status="success"
                  resultContent={
                    <>
                      <p>Evaluating core business objectives, guardrails, and scope boundaries...</p>
                      <ul>
                        <li>Goal Extraction: Funnel recovery for Demat Account opening.</li>
                        <li>Performance Baseline: 12% → 20% target conversion.</li>
                        <li>Budget ceiling: ₹8 per lead.</li>
                      </ul>
                    </>
                  }
                />
                <AgenticStep
                  id="step-2"
                  title="Building Execution Plan"
                  status="success"
                  resultContent={
                    <p>
                      3-stage execution plan: SMS outreach → WhatsApp follow-up → Voice callback for
                      high-intent leads.
                    </p>
                  }
                />
              </StepHeader>
            </AgenticSteps>
          ),
        },
        {
          id: 'card-1',
          type: 'agentic-card',
          card: {
            title: 'Campaign Blueprint',
            actions: (
              <Button variant="contained" size="medium">
                Start Building The Journey
              </Button>
            ),
            children: (
              <>
                <Typography variant="body2" fontWeight="bold" gutterBottom>
                  1. Core Parameters &amp; Targets
                </Typography>
                <ul>
                  <li>Primary Objective: Drive application conversion from 12% baseline to ≥20%.</li>
                  <li>Audience Segmentation: 45,736 validated leads synced from Salesforce CRM.</li>
                  <li>
                    DND Safeguard: 3,156 active DND users isolated strictly to transactional-only
                    routes.
                  </li>
                  <li>
                    Campaign Lifespan: 7-day sprint max per lead, with an automated return to the
                    nurture pool on Day 8.
                  </li>
                </ul>
                <Typography variant="body2" fontWeight="bold" gutterBottom sx={{ mt: 2 }}>
                  2. Omnichannel Flow Execution Steps
                </Typography>
                <ul>
                  <li>Day 0 (SMS): Send personalized reminder with an app deep-link.</li>
                  <li>Day 1 (WhatsApp Multi-Path): Branch by drop-off stage with SMS fallback.</li>
                  <li>Day 3 (Voicebot): Interactive outbound call to capture intent.</li>
                  <li>Day 5 (Preview Dialer): Pass high-priority leads to live agents.</li>
                </ul>
                <Typography variant="body2" sx={{ mt: 2 }}>
                  How would you like to proceed?
                </Typography>
              </>
            ),
          },
          onCopy: () => {},
          feedbackProps: {
            onReactionChange: (r) => console.log('Reaction:', r),
            onSubmit: (fb) => console.log('Feedback:', fb),
          },
        },
      ],
      [composerVisible],
    );

    return (
      <AISuite
        messages={messages}
        chatInput={{
          value: inputValue,
          onChange: setInputValue,
          placeholder: 'Build or ask anything. Type / for commands',
          showVoiceInput: true,
          maxLength: 200,
          onSend: () => setInputValue(''),
        }}
        disclaimer={{ onFeedbackClick: () => {} }}
      />
    );
  },
};

/**
 * Interactive demo — simulates a live thread that grows as the user sends messages.
 */
export const Interactive: Story = {
  render: () => {
    const [inputValue, setInputValue] = useState('');
    const [messages, setMessages] = useState<AISuiteMessage[]>([]);
    const [thinking, setThinking] = useState(false);

    const handleSend = useCallback((text: string) => {
      if (!text.trim()) return;

      const userMessage: AISuiteMessage = {
        id: `user-${Date.now()}`,
        type: 'user-text',
        content: text.trim(),
        onCopy: () => {},
      };

      setMessages((prev) => [...prev, userMessage]);
      setInputValue('');
      setThinking(true);

      window.setTimeout(() => {
        setThinking(false);
        setMessages((prev) => [
          ...prev,
          {
            id: `steps-${Date.now()}`,
            type: 'agentic-steps',
            content: (
              <AgenticSteps>
                <StepHeader title="Thinking" status="success" defaultExpanded={false} />
              </AgenticSteps>
            ),
          },
          {
            id: `assistant-${Date.now()}`,
            type: 'assistant-text',
            content: `Got it — I'll use "${text.trim()}" as the starting point for your campaign plan.`,
            onCopy: () => {},
            feedbackProps: {
              onReactionChange: (r) => console.log('Reaction:', r),
              onSubmit: (fb) => console.log('Feedback:', fb),
            },
          },
        ]);
      }, 1200);
    }, []);

    const liveMessages = useMemo(() => {
      if (!thinking) return messages;

      return [
        ...messages,
        {
          id: 'thinking-live',
          type: 'agentic-steps' as const,
          content: (
            <AgenticSteps>
              <StepHeader title="Thinking" status="loading" defaultExpanded={false} />
            </AgenticSteps>
          ),
        },
      ];
    }, [messages, thinking]);

    return (
      <AISuite
        messages={liveMessages}
        chatInput={{
          value: inputValue,
          onChange: setInputValue,
          label: thinking ? 'Thinking...' : undefined,
          placeholder: 'Describe your campaign goal, audience, or constraints…',
          showVoiceInput: true,
          maxLength: 500,
          sendDisabled: thinking,
          onSend: (text) => handleSend(text),
        }}
        suggestions={
          messages.length === 0
            ? SUGGESTIONS.map((s) => ({
                ...s,
                onClick: () => handleSend(s.label),
              }))
            : undefined
        }
        disclaimer={{ onFeedbackClick: () => {} }}
      />
    );
  },
};

/**
 * Embedded in a narrow left panel beside a workspace canvas — mirrors the
 * Campaigns Agentic UI split view. AISuite fills the panel width; the message
 * column collapses from its centered max-width to full width automatically.
 */
export const InSidePanel: Story = {
  parameters: { layout: 'fullscreen' },
  render: () => {
    const [value, setValue] = useState('');

    return (
      <Box display="flex" height="100vh" bgcolor="surface.elevation1">
        <Box
          width={380}
          flexShrink={0}
          borderRight={1}
          borderColor="divider"
          bgcolor="surface.elevation0"
        >
          <AISuite
            messages={SAMPLE_MESSAGES}
            chatInput={{
              value,
              onChange: setValue,
              placeholder: 'Build or ask anything…',
              showVoiceInput: true,
              onSend: () => setValue(''),
            }}
            disclaimer={{ show: false }}
          />
        </Box>
        <Box
          flex={1}
          display="flex"
          alignItems="center"
          justifyContent="center"
          color="text.secondary"
        >
          <Typography variant="body2">Workspace canvas</Typography>
        </Box>
      </Box>
    );
  },
};

/**
 * Embedded in a modal — a StructuredDialog supplies the header (title + close
 * button); AISuite fills the body. The same pattern works for popover / drawer.
 */
export const InDialog: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    const [value, setValue] = useState('');

    return (
      <Box display="flex" alignItems="center" justifyContent="center" minHeight="100vh" p={2}>
        <Button variant="contained" onClick={() => setOpen(true)}>
          Open AI assistant
        </Button>
        <StructuredDialog
          open={open}
          onClose={() => setOpen(false)}
          title="AI Assistant"
          maxWidth="md"
          fullWidth
        >
          <Box height="70vh" sx={{ mx: -2, my: -3 }}>
            <AISuite
              messages={SAMPLE_MESSAGES}
              chatInput={{
                value,
                onChange: setValue,
                placeholder: 'Build or ask anything…',
                onSend: () => setValue(''),
              }}
              disclaimer={{ onFeedbackClick: () => {} }}
            />
          </Box>
        </StructuredDialog>
      </Box>
    );
  },
};

/**
 * Anchored to a trigger in a popover — the wrapper gives the popover paper a
 * fixed width and height, and AISuite fills it. Suited to a compact,
 * quick-access assistant.
 */
export const InPopover: Story = {
  render: () => {
    const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
    const [value, setValue] = useState('');

    return (
      <Box display="flex" alignItems="center" justifyContent="center" minHeight="100vh" p={2}>
        <Button
          variant="contained"
          onClick={(e) => setAnchorEl(e.currentTarget)}
          sx={{ mt: 60 }}
        >
          Ask AI
        </Button>
        <Popover
          open={Boolean(anchorEl)}
          anchorEl={anchorEl}
          onClose={() => setAnchorEl(null)}
          anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
          transformOrigin={{ vertical: 'bottom', horizontal: 'right' }}
          PaperProps={{ sx: { width: 420, height: 560 } }}
        >
          <AISuite
            messages={SAMPLE_MESSAGES}
            chatInput={{
              value,
              onChange: setValue,
              placeholder: 'Build or ask anything…',
              onSend: () => setValue(''),
            }}
            disclaimer={{ show: false }}
          />
        </Popover>
      </Box>
    );
  },
};

/**
 * Embedded in a right-anchored drawer. The drawer supplies the full-height
 * paper; AISuite fills the drawer body.
 */
export const InDrawer: Story = {
  render: () => {
    const [open, setOpen] = useState(false);
    const [value, setValue] = useState('');

    return (
      <Box display="flex" alignItems="center" justifyContent="center" minHeight="100vh" p={2}>
        <Button variant="contained" onClick={() => setOpen(true)}>
          Open AI assistant
        </Button>
        <Drawer
          anchor="right"
          open={open}
          onClose={() => setOpen(false)}
          title="AI Assistant"
          PaperProps={{ sx: { width: { xs: '100%', sm: 480 } } }}
        >
          <AISuite
            messages={SAMPLE_MESSAGES}
            chatInput={{
              value,
              onChange: setValue,
              placeholder: 'Build or ask anything…',
              onSend: () => setValue(''),
            }}
            disclaimer={{ show: false }}
          />
        </Drawer>
      </Box>
    );
  },
};
