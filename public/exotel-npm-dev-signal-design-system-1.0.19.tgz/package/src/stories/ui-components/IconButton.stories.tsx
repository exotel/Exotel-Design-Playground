import type { Meta, StoryObj } from '@storybook/react';
import { IconButton, Icon } from '../../components';
import { Stack, Typography } from '@mui/material';

const meta: Meta<typeof IconButton> = {
  title: 'UI Components/IconButton',
  component: IconButton,
  parameters: { layout: 'centered' },
  argTypes: {
    shape: {
      control: 'radio',
      options: ['square', 'circle'],
    },
    variant: {
      control: 'radio',
      options: ['text', 'outlined', 'contained'],
    },
    color: {
      control: 'select',
      options: ['default', 'primary', 'secondary', 'error', 'warning', 'info', 'success'],
    },
  },
};

export default meta;
type Story = StoryObj<typeof IconButton>;

export const Basic: Story = {
  args: {
    children: <Icon name="trash" />,
  },
};

export const Shapes: Story = {
  render: () => (
    <Stack direction="row" spacing={2} alignItems="center">
      <Stack alignItems="center" spacing={1}>
        <IconButton shape="square">
          <Icon name="gear" />
        </IconButton>
        <Typography variant="caption">Square (default)</Typography>
      </Stack>
      <Stack alignItems="center" spacing={1}>
        <IconButton shape="circle">
          <Icon name="gear" />
        </IconButton>
        <Typography variant="caption">Circle</Typography>
      </Stack>
    </Stack>
  ),
};

export const Variants: Story = {
  render: () => (
    <Stack direction="row" spacing={2} alignItems="center">
      <Stack alignItems="center" spacing={1}>
        <IconButton variant="text">
          <Icon name="gear" />
        </IconButton>
        <Typography variant="caption">Text (default)</Typography>
      </Stack>
      <Stack alignItems="center" spacing={1}>
        <IconButton variant="outlined">
          <Icon name="gear" />
        </IconButton>
        <Typography variant="caption">Outlined</Typography>
      </Stack>
      <Stack alignItems="center" spacing={1}>
        <IconButton variant="contained">
          <Icon name="gear" />
        </IconButton>
        <Typography variant="caption">Contained</Typography>
      </Stack>
    </Stack>
  ),
};

export const ShapeWithVariants: Story = {
  render: () => (
    <Stack spacing={3}>
      <Stack spacing={1}>
        <Typography variant="title2">Square</Typography>
        <Stack direction="row" spacing={2}>
          <IconButton shape="square" variant="text" color="primary">
            <Icon name="gear" />
          </IconButton>
          <IconButton shape="square" variant="outlined" color="primary">
            <Icon name="gear" />
          </IconButton>
          <IconButton shape="square" variant="contained" color="primary">
            <Icon name="gear" />
          </IconButton>
        </Stack>
      </Stack>
      <Stack spacing={1}>
        <Typography variant="title2">Circle</Typography>
        <Stack direction="row" spacing={2}>
          <IconButton shape="circle" variant="text" color="primary">
            <Icon name="gear" />
          </IconButton>
          <IconButton shape="circle" variant="outlined" color="primary">
            <Icon name="gear" />
          </IconButton>
          <IconButton shape="circle" variant="contained" color="primary">
            <Icon name="gear" />
          </IconButton>
        </Stack>
      </Stack>
    </Stack>
  ),
};

export const ColorVariants: Story = {
  render: () => {
    const colors = ['primary', 'secondary', 'error', 'warning', 'info', 'success'] as const;
    return (
      <Stack spacing={3}>
        {(['text', 'outlined', 'contained'] as const).map((variant) => (
          <Stack key={variant} spacing={1}>
            <Typography variant="title2" textTransform="capitalize">{variant}</Typography>
            <Stack direction="row" spacing={2}>
              {colors.map((color) => (
                <IconButton key={color} variant={variant} color={color}>
                  <Icon name="gear" />
                </IconButton>
              ))}
            </Stack>
          </Stack>
        ))}
      </Stack>
    );
  },
};

export const Sizes: Story = {
  render: () => (
    <Stack spacing={3}>
      {(['text', 'outlined', 'contained'] as const).map((variant) => (
        <Stack key={variant} spacing={1}>
          <Typography variant="title2" textTransform="capitalize">{variant}</Typography>
          <Stack direction="row" spacing={2} alignItems="center">
            {(['small', 'medium', 'large'] as const).map((size) => (
              <Stack key={size} alignItems="center" spacing={1}>
                <IconButton variant={variant} size={size} color="primary">
                  <Icon name="gear" />
                </IconButton>
                <Typography variant="caption">{size}</Typography>
              </Stack>
            ))}
          </Stack>
        </Stack>
      ))}
    </Stack>
  ),
};

export const Disabled: Story = {
  render: () => (
    <Stack direction="row" spacing={2} alignItems="center">
      <IconButton variant="text" disabled>
        <Icon name="gear" />
      </IconButton>
      <IconButton variant="outlined" disabled>
        <Icon name="gear" />
      </IconButton>
      <IconButton variant="contained" disabled>
        <Icon name="gear" />
      </IconButton>
    </Stack>
  ),
};
