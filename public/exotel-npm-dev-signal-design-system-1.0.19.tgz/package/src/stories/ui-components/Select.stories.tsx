import type { Meta, StoryObj } from '@storybook/react';
import { Select } from '../../components';
import { MenuItem } from '@mui/material';
import { useState } from 'react';

const meta: Meta<typeof Select> = {
  title: 'UI Components/Select',
  component: Select,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          "Exotel-approved select component. Only supports the outlined variant and renders an external label above the input, consistent with Autocomplete.",
      },
    },
  },
  argTypes: {
    label: {
      control: 'text',
      description: 'The label content displayed above the input',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    size: {
      control: 'select',
      options: ['small', 'medium', 'large'],
      description: 'The size of the component',
      table: {
        type: { summary: "'small' | 'medium' | 'large'" },
        defaultValue: { summary: "'medium'" },
      },
    },
    disabled: {
      control: 'boolean',
      description: 'If true, the component is disabled',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    error: {
      control: 'boolean',
      description: 'If true, the component is displayed in an error state',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    fullWidth: {
      control: 'boolean',
      description: 'If true, the select will take up the full width of its container',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    required: {
      control: 'boolean',
      description: 'If true, the label is displayed as required',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    helperText: {
      control: 'text',
      description: 'Helper text displayed below the input',
      table: {
        type: { summary: 'ReactNode' },
      },
    },
    placeholder: {
      control: 'text',
      description: 'Placeholder when no value is selected. Derived from label when omitted.',
      table: {
        type: { summary: 'string' },
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Select>;

/**
 * Basic select with external label
 */
export const Basic: Story = {
  render: () => {
    const [value, setValue] = useState('');
    return (
      <Select
        label="Age"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        sx={{ minWidth: 200 }}
      >
        <MenuItem value={10}>Ten</MenuItem>
        <MenuItem value={20}>Twenty</MenuItem>
        <MenuItem value={30}>Thirty</MenuItem>
      </Select>
    );
  },
};

/**
 * Different sizes
 */
export const Sizes: Story = {
  render: () => {
    const [value1, setValue1] = useState('');
    const [value2, setValue2] = useState('');
    const [value3, setValue3] = useState('');
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', width: '300px' }}>
        <Select
          label="Small"
          size="small"
          value={value1}
          onChange={(e) => setValue1(e.target.value)}
        >
          <MenuItem value={10}>Option 1</MenuItem>
          <MenuItem value={20}>Option 2</MenuItem>
        </Select>
        <Select
          label="Medium"
          size="medium"
          value={value2}
          onChange={(e) => setValue2(e.target.value)}
        >
          <MenuItem value={10}>Option 1</MenuItem>
          <MenuItem value={20}>Option 2</MenuItem>
        </Select>
        <Select
          label="Large"
          size="large"
          value={value3}
          onChange={(e) => setValue3(e.target.value)}
        >
          <MenuItem value={10}>Option 1</MenuItem>
          <MenuItem value={20}>Option 2</MenuItem>
        </Select>
      </div>
    );
  },
};

/**
 * Error state
 */
export const Error: Story = {
  render: () => {
    const [value, setValue] = useState('');
    return (
      <Select
        label="Age"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        error
        helperText="Please select an age"
        sx={{ minWidth: 200 }}
      >
        <MenuItem value={10}>Ten</MenuItem>
        <MenuItem value={20}>Twenty</MenuItem>
        <MenuItem value={30}>Thirty</MenuItem>
      </Select>
    );
  },
};

/**
 * Disabled state
 */
export const Disabled: Story = {
  render: () => (
    <Select label="Age" value={10} disabled sx={{ minWidth: 200 }}>
      <MenuItem value={10}>Ten</MenuItem>
      <MenuItem value={20}>Twenty</MenuItem>
      <MenuItem value={30}>Thirty</MenuItem>
    </Select>
  ),
};

/**
 * Full width
 */
export const FullWidth: Story = {
  render: () => {
    const [value, setValue] = useState('');
    return (
      <div style={{ width: '360px' }}>
        <Select
          label="Age"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          fullWidth
        >
          <MenuItem value={10}>Ten</MenuItem>
          <MenuItem value={20}>Twenty</MenuItem>
          <MenuItem value={30}>Thirty</MenuItem>
        </Select>
      </div>
    );
  },
};

/**
 * Custom placeholder
 */
export const WithPlaceholder: Story = {
  render: () => {
    const [value, setValue] = useState('');
    return (
      <Select
        label="Status"
        placeholder="Choose a status"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        sx={{ minWidth: 200 }}
      >
        <MenuItem value="open">Open</MenuItem>
        <MenuItem value="closed">Closed</MenuItem>
      </Select>
    );
  },
};
