import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { MessageComposer, Box, Typography } from '../../components';
import type { MessageComposerOption } from '../../components';

const meta: Meta<typeof MessageComposer> = {
  title: 'AI-SUITE (Beta)/MessageComposer',
  component: MessageComposer,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'MessageComposer is an inline clarification prompt for agentic flows. It shows a question, lettered quick-reply options, an optional free-text input, and a keyboard-hint footer. Use the arrow keys to navigate options, Enter to select, or type to submit free text.',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof MessageComposer>;

const OPTIONS: MessageComposerOption[] = [
  { id: 'a', label: "Let's do a compressed 7-day sprint, then return cold leads to nurture" },
  { id: 'b', label: 'Stick to the standard 10-day window to maximize conversion time' },
  { id: 'c', label: 'Let AI Decide' },
];

/**
 * Default — matches the Figma "Message Composer" with three options,
 * pagination header, free-text input, and keyboard hints.
 */
export const Default: Story = {
  render: () => (
    <Box sx={{ width: 684 }}>
      <MessageComposer
        question="What is your preferred maximum journey duration per lead?"
        options={OPTIONS}
        currentIndex={1}
        totalCount={1}
        onClose={() => {}}
      />
    </Box>
  ),
};

/**
 * Without the free-text input — options only.
 */
export const OptionsOnly: Story = {
  render: () => (
    <Box sx={{ width: 684 }}>
      <MessageComposer
        question="Which channel should we prioritise for follow-ups?"
        options={[
          { id: 'sms', label: 'SMS' },
          { id: 'wa', label: 'WhatsApp' },
          { id: 'voice', label: 'Voice callback' },
        ]}
        showInput={false}
        onClose={() => {}}
      />
    </Box>
  ),
};

/**
 * Multi-step sequence — pagination controls let the user move between prompts.
 */
export const Paginated: Story = {
  render: () => {
    const prompts = [
      {
        question: 'What is your preferred maximum journey duration per lead?',
        options: OPTIONS,
      },
      {
        question: 'What is the absolute budget ceiling per lead?',
        options: [
          { id: '5', label: '₹5 per lead' },
          { id: '8', label: '₹8 per lead' },
          { id: 'ai', label: 'Let AI optimise within ₹10' },
        ],
      },
    ];
    const [index, setIndex] = useState(0);
    const current = prompts[index];

    return (
      <Box sx={{ width: 684 }}>
        <MessageComposer
          key={index}
          question={current.question}
          options={current.options}
          currentIndex={index + 1}
          totalCount={prompts.length}
          onPrev={index > 0 ? () => setIndex((i) => i - 1) : undefined}
          onNext={index < prompts.length - 1 ? () => setIndex((i) => i + 1) : undefined}
          onClose={() => {}}
        />
      </Box>
    );
  },
};

/**
 * Interactive — logs selection and free-text submission.
 */
export const Interactive: Story = {
  render: () => {
    const [result, setResult] = useState<string>('No response yet');

    return (
      <Box sx={{ width: 684, display: 'flex', flexDirection: 'column', gap: 2 }}>
        <MessageComposer
          question="What is your preferred maximum journey duration per lead?"
          options={OPTIONS}
          currentIndex={1}
          totalCount={1}
          onSelect={(option) => setResult(`Selected: ${option.label}`)}
          onSubmit={(text) => setResult(`Submitted: ${text}`)}
          onClose={() => setResult('Dismissed')}
        />
        <Typography variant="body2" sx={{ color: 'text.secondary' }}>
          {result}
        </Typography>
      </Box>
    );
  },
};
