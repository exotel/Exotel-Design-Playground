import { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { PageHeader } from '../../components';

const meta: Meta<typeof PageHeader> = {
  title: 'UI Components/PageHeader',
  component: PageHeader,
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component: 'Page header component with title, optional subtitle, search, toggle button group, and action buttons.',
      },
    },
  },
  argTypes: {
    title: {
      control: 'text',
      description: 'The page title',
    },
    subtitle: {
      control: 'text',
      description: 'Optional subtitle below the title',
    },
    showSearch: {
      control: 'boolean',
      description: 'Whether to show the search field',
    },
    searchType: {
      control: 'select',
      options: ['basic', 'advanced'],
      description: 'Type of search input',
      table: {
        type: { summary: "'basic' | 'advanced'" },
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof PageHeader>;

export const Default: Story = {
  args: {
    title: 'Channel Configuration',
  },
};

export const WithSubtitle: Story = {
  args: {
    title: 'Channel Configuration',
    subtitle: 'Select communication channel and configure channel settings',
  },
};

export const WithActions: Story = {
  args: {
    title: 'Channel Configuration',
    subtitle: 'Select communication channel and configure channel settings',
    actions: [
      { id: 'export', children: 'Export', variant: 'outlined' },
      { id: 'add', children: 'Add Contact', variant: 'contained' },
    ],
  },
};

export const WithSearch: Story = {
  args: {
    title: 'Channel Configuration',
    showSearch: true,
    searchType: 'basic',
    onBasicSearch: (v) => console.log('Search value:', v),
  },
};

export const WithSearchAndActions: Story = {
  args: {
    title: 'Channel Configuration',
    subtitle: 'Select communication channel and configure channel settings',
    showSearch: true,
    searchType: 'basic',
    onBasicSearch: (v) => console.log('Search value:', v),
    actions: [
      { id: 'export', children: 'Export', variant: 'outlined' },
      { id: 'add', children: 'Add Contact', variant: 'contained' },
    ],
  },
};

export const WithIconActions: Story = {
  args: {
    title: 'Channel Configuration',
    subtitle: 'Select communication channel and configure channel settings',
    showSearch: true,
    searchType: 'basic',
    onBasicSearch: (v) => console.log('Search value:', v),
    actions: [
      { id: 'filter', children: 'Filter', variant: 'outlined', startIconProps: { name: 'funnel' } },
      { id: 'create', children: 'Create Campaign', variant: 'contained', startIconProps: { name: 'plus' } },
      { id: 'export', children: 'Export', variant: 'outlined', startIconProps: { name: 'export' } },
      { id: 'import', children: 'Import', variant: 'outlined', startIconProps: { name: 'download-simple' } },
    ],
  },
};

export const TitleOnly: Story = {
  args: {
    title: 'Settings',
  },
};

export const WithToggleButtonGroup: Story = {
  render: () => {
    const [view, setView] = useState('list');
    return (
      <PageHeader
        title="Campaigns (04)"
        showSearch
        searchType="basic"
        onBasicSearch={(v) => console.log('Search:', v)}
        toggleButtonGroup={{
          value: view,
          onChange: setView,
          options: [
            { value: 'list', iconName: 'list-bullets', ariaLabel: 'List view' },
            { value: 'table', iconName: 'table', ariaLabel: 'Table view' },
          ],
        }}
        actions={[
          { id: 'new', children: 'New Campaign', variant: 'contained', startIconProps: { name: 'plus' } },
        ]}
      />
    );
  },
};

export const WithToggleAndOverflowActions: Story = {
  render: () => {
    const [view, setView] = useState('table');
    return (
      <PageHeader
        title="Campaigns (04)"
        subtitle="Manage all your campaigns"
        showSearch
        searchType="basic"
        onBasicSearch={(v) => console.log('Search:', v)}
        toggleButtonGroup={{
          value: view,
          onChange: setView,
          options: [
            { value: 'list', iconName: 'list-bullets', ariaLabel: 'List view' },
            { value: 'table', iconName: 'table', ariaLabel: 'Table view' },
          ],
        }}
        actions={[
          { id: 'new', children: 'New Campaign', variant: 'contained', startIconProps: { name: 'plus' } },
          { id: 'export', children: 'Export', variant: 'outlined', startIconProps: { name: 'export' } },
          { id: 'import', children: 'Import', variant: 'outlined', startIconProps: { name: 'download-simple' } },
        ]}
      />
    );
  },
};
