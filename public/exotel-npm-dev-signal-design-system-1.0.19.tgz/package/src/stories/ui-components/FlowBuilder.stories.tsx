import { useCallback } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import { Box } from '../../components';
import {
  FlowBuilder,
  FlowToolbar,
  useFlowBuilder,
  type Node,
  type Edge,
} from '../../components/FlowBuilder';
import { ReactFlowProvider } from '@xyflow/react';

// ---------------------------------------------------------------------------
// Sample data
// ---------------------------------------------------------------------------

const sampleNodes: Node[] = [
  {
    id: 'start',
    type: 'startEnd',
    position: { x: 250, y: 0 },
    data: { label: 'Start', variant: 'start' },
  },
  {
    id: 'action-1',
    type: 'action',
    position: { x: 200, y: 100 },
    data: { label: 'Greet Customer', description: 'Play welcome message', icon: '👋' },
  },
  {
    id: 'condition-1',
    type: 'condition',
    position: { x: 180, y: 220 },
    data: {
      label: 'VIP Customer?',
      description: 'Check loyalty tier',
      conditions: ['Tier Gold', 'Tier Silver'],
    },
  },
  {
    id: 'action-2',
    type: 'action',
    position: { x: 50, y: 380 },
    data: {
      label: 'Priority Queue',
      description: 'Route to VIP support',
      icon: '⭐',
      status: 'success',
    },
  },
  {
    id: 'action-3',
    type: 'action',
    position: { x: 350, y: 380 },
    data: {
      label: 'Standard Queue',
      description: 'Route to general support',
      icon: '📞',
      status: 'info',
    },
  },
  {
    id: 'end',
    type: 'startEnd',
    position: { x: 250, y: 520 },
    data: { label: 'End', variant: 'end' },
  },
];

const sampleEdges: Edge[] = [
  { id: 'e-start-action1', source: 'start', target: 'action-1' },
  { id: 'e-action1-cond1', source: 'action-1', target: 'condition-1' },
  {
    id: 'e-cond1-action2',
    source: 'condition-1',
    sourceHandle: 'yes',
    target: 'action-2',
    type: 'conditional',
    data: { label: 'Yes' },
  },
  {
    id: 'e-cond1-action3',
    source: 'condition-1',
    sourceHandle: 'no',
    target: 'action-3',
    type: 'conditional',
    data: { label: 'No' },
  },
  { id: 'e-action2-end', source: 'action-2', target: 'end' },
  { id: 'e-action3-end', source: 'action-3', target: 'end' },
];

// ---------------------------------------------------------------------------
// Meta
// ---------------------------------------------------------------------------

const meta: Meta<typeof FlowBuilder> = {
  title: 'Flow Builder/FlowBuilder',
  component: FlowBuilder,
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        component:
          'A thin wrapper around [React Flow](https://reactflow.dev/) that applies Exotel theme tokens and ' +
          'provides pre-built node/edge types for IVR, call-flow, and workflow builders.\n\n' +
          '```tsx\nimport { FlowBuilder, useFlowBuilder } from \'@exotel-npm-dev/signal-design-system/flow-builder\';\n```\n\n' +
          '`@xyflow/react` is bundled — no extra install needed.',
      },
    },
  },
  argTypes: {
    showMinimap: {
      control: 'boolean',
      description: 'Show the minimap panel',
      table: { category: 'Wrapper-Specific Props' },
    },
    showControls: {
      control: 'boolean',
      description: 'Show the zoom/fit-view controls panel',
      table: { category: 'Wrapper-Specific Props' },
    },
    showBackground: {
      control: 'boolean',
      description: 'Show the dot-grid background',
      table: { category: 'Wrapper-Specific Props' },
    },
    colorMode: {
      control: 'select',
      options: ['light', 'dark', 'system'],
      description: 'Color mode override — defaults to current Exotel theme mode',
      table: { category: 'Wrapper-Specific Props' },
    },
  },
  decorators: [
    (Story) => (
      <Box sx={{ width: '100%', height: '100vh' }}>
        <ReactFlowProvider>
          <Story />
        </ReactFlowProvider>
      </Box>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof FlowBuilder>;

// ---------------------------------------------------------------------------
// Stories
// ---------------------------------------------------------------------------

export const Basic: Story = {
  name: 'Basic',
  args: {
    showMinimap: false,
    showControls: true,
    showBackground: true,
  },
  render: (args) => {
    const flow = useFlowBuilder({
      initialNodes: sampleNodes,
      initialEdges: sampleEdges,
    });
    return <FlowBuilder {...args} {...flow} />;
  },
};

export const WithMinimap: Story = {
  name: 'With Minimap',
  args: {
    showMinimap: true,
    showControls: true,
    showBackground: true,
  },
  render: (args) => {
    const flow = useFlowBuilder({
      initialNodes: sampleNodes,
      initialEdges: sampleEdges,
    });
    return <FlowBuilder {...args} {...flow} />;
  },
};

export const WithToolbar: Story = {
  name: 'With Toolbar',
  render: () => {
    const flow = useFlowBuilder({
      initialNodes: sampleNodes,
      initialEdges: sampleEdges,
    });

    const addNode = useCallback(() => {
      const id = `new-${Date.now()}`;
      flow.setNodes((prev) => [
        ...prev,
        {
          id,
          type: 'action',
          position: { x: Math.random() * 400, y: Math.random() * 400 },
          data: { label: 'New Node', description: 'Added via toolbar' },
        },
      ]);
    }, [flow.setNodes]);

    return (
      <FlowBuilder {...flow} showMinimap>
        <FlowToolbar>
          <button onClick={addNode} style={{ cursor: 'pointer', padding: '4px 12px', borderRadius: 6, border: '1px solid #ccc', background: '#fff' }}>
            + Add Node
          </button>
        </FlowToolbar>
      </FlowBuilder>
    );
  },
};

export const ReadOnly: Story = {
  name: 'Read Only',
  render: () => {
    const flow = useFlowBuilder({
      initialNodes: sampleNodes,
      initialEdges: sampleEdges,
    });
    return (
      <FlowBuilder
        {...flow}
        nodesDraggable={false}
        nodesConnectable={false}
        elementsSelectable={false}
        showControls={false}
      />
    );
  },
};

export const NodeShowcase: Story = {
  name: 'Node Showcase',
  render: () => {
    const showcaseNodes: Node[] = [
      {
        id: 'start',
        type: 'startEnd',
        position: { x: 250, y: 0 },
        data: { label: 'Start', variant: 'start' },
      },
      {
        id: 'action-default',
        type: 'action',
        position: { x: 50, y: 100 },
        data: { label: 'Default Action', description: 'No status', icon: '📋' },
      },
      {
        id: 'action-success',
        type: 'action',
        position: { x: 300, y: 100 },
        data: { label: 'Success Action', description: 'Status: success', icon: '✅', status: 'success' },
      },
      {
        id: 'action-error',
        type: 'action',
        position: { x: 550, y: 100 },
        data: { label: 'Error Action', description: 'Status: error', icon: '❌', status: 'error' },
      },
      {
        id: 'action-warning',
        type: 'action',
        position: { x: 50, y: 230 },
        data: { label: 'Warning Action', description: 'Status: warning', icon: '⚠️', status: 'warning' },
      },
      {
        id: 'action-info',
        type: 'action',
        position: { x: 300, y: 230 },
        data: { label: 'Info Action', description: 'Status: info', icon: 'ℹ️', status: 'info' },
      },
      {
        id: 'condition',
        type: 'condition',
        position: { x: 200, y: 360 },
        data: { label: 'Decision', description: 'Branch logic', conditions: ['Option A', 'Option B'] },
      },
      {
        id: 'end',
        type: 'startEnd',
        position: { x: 250, y: 520 },
        data: { label: 'End', variant: 'end' },
      },
    ];

    const flow = useFlowBuilder({ initialNodes: showcaseNodes, initialEdges: [] });
    return <FlowBuilder {...flow} showControls />;
  },
};

export const ComplexFlow: Story = {
  name: 'Complex IVR Flow',
  render: () => {
    const nodes: Node[] = [
      { id: '1', type: 'startEnd', position: { x: 300, y: 0 }, data: { label: 'Incoming Call', variant: 'start' } },
      { id: '2', type: 'action', position: { x: 260, y: 100 }, data: { label: 'Play Welcome', description: 'IVR greeting', icon: '🔊' } },
      { id: '3', type: 'condition', position: { x: 240, y: 220 }, data: { label: 'Language', description: 'DTMF input', conditions: ['English', 'Hindi'] } },
      { id: '4', type: 'action', position: { x: 50, y: 380 }, data: { label: 'English Menu', icon: '🇬🇧', status: 'info' } },
      { id: '5', type: 'action', position: { x: 450, y: 380 }, data: { label: 'Hindi Menu', icon: '🇮🇳', status: 'info' } },
      { id: '6', type: 'condition', position: { x: 20, y: 500 }, data: { label: 'Department?', conditions: ['Sales', 'Support'] } },
      { id: '7', type: 'action', position: { x: -120, y: 650 }, data: { label: 'Sales Queue', icon: '💰', status: 'success' } },
      { id: '8', type: 'action', position: { x: 130, y: 650 }, data: { label: 'Support Queue', icon: '🛠️', status: 'warning' } },
      { id: '9', type: 'action', position: { x: 420, y: 500 }, data: { label: 'Hindi Support', icon: '🛠️', status: 'warning' } },
      { id: '10', type: 'startEnd', position: { x: 250, y: 800 }, data: { label: 'Call Ended', variant: 'end' } },
    ];

    const edges: Edge[] = [
      { id: 'e1', source: '1', target: '2' },
      { id: 'e2', source: '2', target: '3' },
      { id: 'e3', source: '3', sourceHandle: 'yes', target: '4', type: 'conditional', data: { label: 'English' } },
      { id: 'e4', source: '3', sourceHandle: 'no', target: '5', type: 'conditional', data: { label: 'Hindi' } },
      { id: 'e5', source: '4', target: '6' },
      { id: 'e6', source: '6', sourceHandle: 'yes', target: '7', type: 'conditional', data: { label: 'Sales' } },
      { id: 'e7', source: '6', sourceHandle: 'no', target: '8', type: 'conditional', data: { label: 'Support' } },
      { id: 'e8', source: '5', target: '9' },
      { id: 'e9', source: '7', target: '10' },
      { id: 'e10', source: '8', target: '10' },
      { id: 'e11', source: '9', target: '10' },
    ];

    const flow = useFlowBuilder({ initialNodes: nodes, initialEdges: edges });
    return <FlowBuilder {...flow} showMinimap showControls />;
  },
};
