import type { Meta, StoryObj } from '@storybook/react';
import { AppLauncher, Icon } from '../../components';
import type { Product } from '../../components';

function makeProducts(): Product[] {
  return [
    { id: 'home', name: 'Home', icon: <Icon name="house" size="md" />, section: 'home', order: 0, onProductClick: () => console.log('home') },
    { id: 'exolite', name: 'Exolite', icon: <Icon name="squares-four" size="md" />, section: 'products', order: 0, onProductClick: () => console.log('exolite') },
    { id: 'ecc', name: 'Enterprise contact centre', icon: <Icon name="headset" size="md" />, section: 'products', order: 1, onProductClick: () => console.log('ecc') },
    { id: 'voicebot', name: 'Voicebot', icon: <Icon name="phone" size="md" />, section: 'products', isTrial: true, order: 2, onProductClick: () => console.log('voicebot') },
    { id: 'chatbot', name: 'Chatbot', icon: <Icon name="chat" size="md" />, section: 'products', order: 3, onProductClick: () => console.log('chatbot') },
    { id: 'agentstream', name: 'AgentStream', icon: <Icon name="chart-bar" size="md" />, section: 'recommended', order: 0, onProductClick: () => console.log('agentstream') },
    { id: 'campaigns', name: 'Campaigns', icon: <Icon name="chart-line" size="md" />, section: 'recommended', order: 1, onProductClick: () => console.log('campaigns') },
    { id: 'engage', name: 'Engage', icon: <Icon name="envelope" size="md" />, section: 'explore', order: 0, onProductClick: () => console.log('engage') },
    { id: 'all', name: 'All Exotel Solutions', icon: <Icon name="columns" size="md" />, section: 'explore', order: 1, onProductClick: () => console.log('all') },
  ];
}

const DEFAULT_PRODUCTS = makeProducts();

const meta: Meta<typeof AppLauncher> = {
  title: 'UI Components/AppLauncher',
  component: AppLauncher,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'Pure render-only App Launcher. Host provides products (id, name, icon, section, order, isTrial). Emits onProductClick(product); host owns navigation and behavior.',
      },
    },
  },
  argTypes: {
    type: {
      control: 'radio',
      options: ['default', 'sectioned'],
      description: 'Layout: flat list or sectioned with subheaders',
    },
    products: {
      control: 'object',
      description: 'Product list (host-owned). Each: id, name, icon, section, order?, isTrial?, iconBgColor?',
    },
    iconName: {
      control: 'select',
      options: ['squares-four', 'house', 'list', 'menu', 'columns'],
      description: 'Icon name for the launcher trigger button (passed from parent)',
    },
  },
};

export default meta;

type Story = StoryObj<typeof AppLauncher>;

export const DefaultMode: Story = {
  args: {
    type: 'default',
    products: DEFAULT_PRODUCTS,
  },
};

export const SectionedMode: Story = {
  args: {
    type: 'sectioned',
    products: DEFAULT_PRODUCTS,
  },
};
