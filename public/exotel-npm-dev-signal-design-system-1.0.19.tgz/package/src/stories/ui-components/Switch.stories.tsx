import type { Meta, StoryObj } from '@storybook/react';
import { Switch } from '../../components';
import { useState } from 'react';

const meta: Meta<typeof Switch> = {
  title: 'UI Components/Switch',
  component: Switch,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component: 'Exotel-approved switch component that wraps MUI\'s Switch. Used for binary on/off states.',
      },
    },
  },
  argTypes: {
    color: {
      control: 'select',
      options: ['default', 'primary', 'secondary', 'error', 'info', 'success', 'warning'],
      description: 'The color of the component',
      table: {
        type: { summary: "'default' | 'primary' | 'secondary' | 'error' | 'info' | 'success' | 'warning'" },
        defaultValue: { summary: "'primary'" },
      },
    },
    size: {
      control: 'select',
      options: ['small', 'medium'],
      description: 'The size of the component',
      table: {
        type: { summary: "'small' | 'medium'" },
        defaultValue: { summary: "'medium'" },
      },
    },
    disabled: {
      control: 'boolean',
      description: 'If true, the component is disabled',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    checked: {
      control: 'boolean',
      description: 'If true, the component is checked',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Switch>;

/**
 * Unchecked switch
 */
export const Unchecked: Story = {
  args: {
    checked: false,
  },
};

/**
 * Checked switch
 */
export const Checked: Story = {
  args: {
    checked: true,
  },
};

/**
 * Different colors
 */
export const Colors: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
      <Switch checked color="default" />
      <Switch checked color="primary" />
      <Switch checked color="secondary" />
      <Switch checked color="success" />
      <Switch checked color="error" />
      <Switch checked color="info" />
      <Switch checked color="warning" />
    </div>
  ),
};

/**
 * Different sizes
 */
export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
      <Switch checked size="small" />
      <Switch checked size="medium" />
    </div>
  ),
};

/**
 * With label
 */
export const WithLabel: Story = {
  render: () => {
    const [checked, setChecked] = useState(false);
    return (
      <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
        <Switch
          checked={checked}
          onChange={(e) => setChecked(e.target.checked)}
        />
        <span>Enable notifications</span>
      </label>
    );
  },
};

/**
 * Disabled state
 */
export const Disabled: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
      <Switch disabled />
      <Switch disabled checked />
    </div>
  ),
};

/**
 * Interactive switch with all controls
 */
export const Interactive: Story = {
  args: {
    checked: false,
    color: 'primary',
    size: 'medium',
    disabled: false,
  },
  render: (args) => {
    const [checked, setChecked] = useState(args.checked);
    return (
      <Switch
        {...args}
        checked={checked}
        onChange={(e) => setChecked(e.target.checked)}
      />
    );
  },
};
