/**
 * @exotel/design-system
 * 
 * Main entry point for the Exotel Design System package.
 * 
 * This file exports all public APIs of the design system:
 * - Components: Reusable UI components built on top of MUI
 * - Theme: Exotel's design tokens and theme configuration
 * 
 * This package wraps MUI (Material-UI) without modifying it,
 * providing Exotel-specific components and theming.
 */

// MUI type augmentations — side-effect import guarantees the `declare module`
// blocks ship in the package's .d.ts output regardless of tree-shaking.
import './theme/mui-augmentation';

// Export all components
export * from './components';

// Export theme configuration
export * from './theme';

// Export functions
export * from './functions';

// Export configs
export * from './configs';
