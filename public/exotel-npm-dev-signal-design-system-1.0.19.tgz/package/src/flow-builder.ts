/**
 * @exotel-npm-dev/signal-design-system/flow-builder
 *
 * Separate entry point for the FlowBuilder component and utilities.
 * This keeps @xyflow/react out of the main bundle — consumers only
 * pay the cost when they import from this path.
 *
 * Usage:
 *   import { FlowBuilder, useFlowBuilder, ActionNode } from '@exotel-npm-dev/signal-design-system/flow-builder';
 */
export * from './components/FlowBuilder';
