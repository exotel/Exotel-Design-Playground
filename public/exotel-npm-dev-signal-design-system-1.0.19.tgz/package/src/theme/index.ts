/**
 * Theme Directory
 * 
 * This directory contains Exotel's design system theme configuration.
 * 
 * Purpose:
 * - Define Exotel's design tokens (colors, typography, spacing, etc.)
 * - Configure MUI theme with Exotel-specific values
 * - Provide theme utilities and helpers
 * - Export theme for consumption by components and applications
 * 
 * Structure:
 * - theme.ts: Main theme configuration using MUI's createTheme
 * - tokens.ts: Design tokens (colors, typography scales, spacing, etc.)
 * - types.ts: TypeScript types for theme customization
 * 
 * The theme should:
 * - Wrap and extend MUI's default theme
 * - Follow Exotel's brand guidelines
 * - Be fully typed with TypeScript
 * - Support light/dark mode (if needed)
 */

// MUI augmentations — the named re-exports create a proper import chain in the
// generated .d.ts so `declare module` blocks are always loaded by consumers.
import './mui-augmentation';
export type {
  SurfaceElevations,
  CustomPalette,
  AppLauncherTrialChip,
  AppLauncherPalette,
  ExotelPaletteExtensions,
  ExotelPaletteOptionsExtensions,
  ExotelTypographyExtensions,
  ExotelTypographyOptionsExtensions,
  ExotelTypographyPropsExtensions,
  ExotelChipVariantExtensions,
  ExotelButtonSizeExtensions,
  ExotelTextFieldSizeExtensions,
  ExotelInputBaseSizeExtensions,
} from './mui-augmentation';

// Export theme configuration
export { exotelTheme, createExotelTheme, FONT_OPTIONS, DEFAULT_FONT } from './theme';
export type { FontKey } from './theme';
