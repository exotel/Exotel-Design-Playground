/**
 * Exotel Design System Theme
 *
 * This file contains the main theme configuration for the Exotel Design System.
 * It wraps MUI's createTheme with Exotel-specific design tokens.
 *
 * The theme will be extended as the design system grows to include:
 * - Color palette (primary, secondary, error, warning, info, success)
 * - Typography scale
 * - Spacing system
 * - Component overrides
 * - Custom design tokens
 */

import "./mui-augmentation";
import { extendTheme, alpha, type Shadows } from "@mui/material/styles";
import {
  createTonalSurfaceStyles,
  resolveTonalColor,
  type TonalPalette,
  type TonalSemanticColor,
} from "./tonal";
// This is required to augment the theme with DataGrid component customizations
import type {} from "@mui/x-data-grid-pro/themeAugmentation";
import NotoSansTtf from "../assets/NotoSans-VariableFont_wdth,wght.ttf";
import IBMPlexSansTtf from "../assets/IBMPlexSans-VariableFont_wdth,wght.ttf";
import type { ThemeOptions } from "@mui/material/styles";
/**
 * COMPLETE MUI Theme Configuration with CSS Variables
 *
 * This file contains all theme tokens consumed by MUI components.
 * Uses MUI's CSS Variables (CssVarsProvider) for native dark mode support.
 *
 * All sections are explicitly defined even if they match MUI defaults to ensure
 * visibility and easy customization.
 */

export const FONT_OPTIONS = {
  "noto-sans": { family: "Noto Sans", src: NotoSansTtf },
  "ibm-plex-sans": { family: "IBM Plex Sans", src: IBMPlexSansTtf },
} as const;

export type FontKey = keyof typeof FONT_OPTIONS;

export const DEFAULT_FONT: FontKey = "noto-sans";

/**
 * Creates the Exotel theme using MUI CSS Variables
 * Uses extendTheme with colorSchemes for native dark mode support
 * @returns MUI Theme instance with CSS Variables
 */
const fontWeights = {
  light: 300,
  regular: 400,
  medium: 500,
  semiBold: 600,
  bold: 700,
} as const;

// Material color ramps — sourced from design tokens (mode-independent scales)
const indigo = {
  50: "#e8eaf6",
  100: "#c5cae9",
  200: "#9fa8da",
  300: "#7986cb",
  400: "#5c6bc0",
  500: "#3f51b5",
  600: "#3949ab",
  700: "#303f9f",
  800: "#283593",
  900: "#1a237e",
  A100: "#8c9eff",
  A200: "#536dfe",
  A400: "#3d5afe",
  A700: "#304ffe",
} as const;

const purple = {
  50: "#fcfaff",
  100: "#f9f5ff",
  200: "#f4ebff",
  300: "#e9d7fe",
  400: "#d6bbfb",
  500: "#b692f6",
  600: "#9e77ed",
  700: "#7f56d9",
  800: "#6941c6",
  900: "#53389e",
  A100: "#ea80fc",
  A200: "#e040fb",
  A400: "#d500f9",
  A700: "#aa00ff",
} as const;

const red = {
  50: "#fffbfa",
  100: "#fef3f2",
  200: "#fee4e2",
  300: "#fecdca",
  400: "#fda29b",
  500: "#f97066",
  600: "#f04438",
  700: "#d92d20",
  800: "#b42318",
  900: "#7a271a",
  A100: "#ff8a80",
  A200: "#ff5252",
  A400: "#ff1744",
  A700: "#d50000",
} as const;

const yellow = {
  50: "#fffcf5",
  100: "#fffaeb",
  200: "#fef0c7",
  300: "#fedf89",
  400: "#fec84b",
  500: "#fdb022",
  600: "#f79009",
  700: "#dc6803",
  800: "#b54708",
  900: "#93370d",
  A100: "#ffff8d",
  A200: "#ffff00",
  A400: "#ffea00",
  A700: "#ffd600",
} as const;

const lightBlue = {
  50: "#e1f5fe",
  100: "#b3e5fc",
  200: "#81d4fa",
  300: "#4fc3f7",
  400: "#29b6f6",
  500: "#03a9f4",
  600: "#039be5",
  700: "#0288d1",
  800: "#0277bd",
  900: "#01579b",
  A100: "#80d8ff",
  A200: "#40c4ff",
  A400: "#00b0ff",
  A700: "#0091ea",
} as const;

const green = {
  50: "#e8f5e9",
  100: "#c8e6c9",
  200: "#a5d6a7",
  300: "#81c784",
  400: "#66bb6a",
  500: "#4caf50",
  600: "#43a047",
  700: "#388e3c",
  800: "#2e7d32",
  900: "#1b5e20",
  A100: "#b9f6ca",
  A200: "#69f0ae",
  A400: "#00e676",
  A700: "#00c853",
} as const;

const grey = {
  50: "#fafafa",
  100: "#f5f5f5",
  200: "#eeeeee",
  300: "#e0e0e0",
  400: "#bdbdbd",
  500: "#9e9e9e",
  600: "#757575",
  700: "#616161",
  800: "#424242",
  900: "#212121",
  A100: "#f5f5f5",
  A200: "#eeeeee",
  A400: "#bdbdbd",
  A700: "#616161",
} as const;

/** Contained button brand colors — identical in light and dark mode. */
const BRAND_CONTAINED = {
  primary: { main: indigo[600], dark: indigo[800], contrastText: "#ffffff" },
  secondary: { main: purple[700], dark: purple[800], contrastText: "#ffffff" },
  error: { main: red[700], dark: red[800], contrastText: "#ffffff" },
  warning: { main: yellow[800], dark: yellow[900], contrastText: "#ffffff" },
  info: { main: lightBlue[700], dark: lightBlue[900], contrastText: "#ffffff" },
  success: { main: green[800], dark: green[900], contrastText: "#ffffff" },
} as const;

type BrandContainedColor = keyof typeof BRAND_CONTAINED;

/** Override MUI contained CSS vars so dark mode keeps light-mode brand fills. */
function createBrandContainedCssVarOverrides(color: BrandContainedColor) {
  const palette = BRAND_CONTAINED[color];
  return {
    "--variant-containedBg": palette.main,
    "--variant-containedColor": palette.contrastText,
    "@media (hover: hover)": {
      "&:hover": {
        "--variant-containedBg": palette.dark,
      },
    },
  };
}

const BRAND_CONTAINED_COLORS = [
  "primary",
  "secondary",
  "error",
  "warning",
  "info",
  "success",
] as const;

/** Solid tonal surfaces — light scheme (no alpha transparency). */
const LIGHT_TONAL_PALETTE: TonalPalette = {
  default: {
    bg: grey[200],
    text: grey[800],
    hoverBg: grey[300],
    disabledBg: grey[100],
  },
  primary: {
    bg: indigo[50],
    text: indigo[800],
    hoverBg: indigo[100],
    disabledBg: indigo[50],
  },
  secondary: {
    bg: purple[50],
    text: purple[800],
    hoverBg: purple[100],
    disabledBg: purple[50],
  },
  error: {
    bg: red[50],
    text: red[800],
    hoverBg: red[100],
    disabledBg: red[50],
  },
  warning: {
    bg: yellow[50],
    text: yellow[800],
    hoverBg: yellow[100],
    disabledBg: yellow[50],
  },
  info: {
    bg: lightBlue[50],
    text: lightBlue[900],
    hoverBg: lightBlue[100],
    disabledBg: lightBlue[50],
  },
  success: {
    bg: green[50],
    text: green[900],
    hoverBg: green[100],
    disabledBg: green[50],
  },
};

// Surface layers (light):
//   elevation0 — Canvas: outer gutter (#f1f1f1)
//   elevation1 — Shell:   nav, main column, app chrome (#fdfdfd)
//   elevation2 — Raised:  cards, inputs, Paper (#ffffff)
//   elevation3–24 — MUI overlay ladder (unchanged)
const lightSurface = {
  elevation0: "#f1f1f1",
  elevation1: "#fdfdfd",
  elevation2: "#ffffff",
  elevation3: "#ffffff",
  elevation4: "#ffffff",
  elevation5: "#ffffff",
  elevation6: "#ffffff",
  elevation7: "#ffffff",
  elevation8: "#ffffff",
  elevation9: "#ffffff",
  elevation10: "#ffffff",
  elevation11: "#ffffff",
  elevation12: "#ffffff",
  elevation13: "#ffffff",
  elevation14: "#ffffff",
  elevation15: "#ffffff",
  elevation16: "#ffffff",
  elevation17: "#ffffff",
  elevation18: "#ffffff",
  elevation19: "#ffffff",
  elevation20: "#ffffff",
  elevation21: "#ffffff",
  elevation22: "#ffffff",
  elevation23: "#ffffff",
  elevation24: "#ffffff",
} as const;

// Surface layers (dark):
//   elevation0 — Canvas: outer gutter (#121212)
//   elevation1 — Shell:   nav, main column, app chrome (#1e1e1e)
//   elevation2 — Raised:  cards, inputs, Paper (#232323)
//   elevation3–24 — MUI overlay ladder (unchanged)
const darkSurface = {
  elevation0: "#121212",
  elevation1: "#1e1e1e",
  elevation2: "#232323",
  elevation3: "#252525",
  elevation4: "#272727",
  elevation5: "#2a2a2a",
  elevation6: "#2c2c2c",
  elevation7: "#2c2c2c",
  elevation8: "#2e2e2e",
  elevation9: "#2e2e2e",
  elevation10: "#313131",
  elevation11: "#313131",
  elevation12: "#333333",
  elevation13: "#333333",
  elevation14: "#333333",
  elevation15: "#333333",
  elevation16: "#363636",
  elevation17: "#363636",
  elevation18: "#363636",
  elevation19: "#363636",
  elevation20: "#383838",
  elevation21: "#383838",
  elevation22: "#383838",
  elevation23: "#383838",
  elevation24: "#383838",
} as const;

// Shadow levels (Figma effectStyles elevation/1–5):
//   1 — inputs, outlined buttons, default Paper/Card
//   2 — outlined hover / subtle lift
//   3 — interactive hover (nodes, chips)
//   4 — Dialog, Drawer
//   5 — Menu, Popover, Select/MultiSelect dropdowns, pickers
//   6–24 — clamped to 5 (MUI API compat only)
const SHADOW_ELEVATION = {
  1: "0px 1px 2px 0px rgba(10, 13, 18, 0.05)",
  2: "0px 1px 2px 0px rgba(10, 13, 18, 0.06), 0px 1px 3px 0px rgba(10, 13, 18, 0.1)",
  3: "0px 2px 4px -2px rgba(0, 0, 0, 0.06), 0px 4px 8px -2px rgba(10, 13, 18, 0.1)",
  4: "0px 4px 6px -2px rgba(10, 13, 18, 0.03), 0px 12px 16px -4px rgba(10, 13, 18, 0.08)",
  5: "0px 8px 8px -4px rgba(10, 13, 18, 0.03), 0px 20px 24px -4px rgba(10, 13, 18, 0.08)",
} as const;

function createMuiShadows(): Shadows {
  const max = SHADOW_ELEVATION[5];
  return [
    "none",
    SHADOW_ELEVATION[1],
    SHADOW_ELEVATION[2],
    SHADOW_ELEVATION[3],
    SHADOW_ELEVATION[4],
    SHADOW_ELEVATION[5],
    ...Array(19).fill(max),
  ] as Shadows;
}

// =============================================================================
// SHARED STYLE HELPERS — used by both MuiButton and MuiIconButton.
// Edit once → every component that calls these helpers updates automatically.
// =============================================================================

/**
 * Soft-outlined style: divider-colored border in light and dark mode.
 * Sets `--variant-outlinedBorder` so MUI Button outlined strokes stay visible in dark mode.
 * The caller is responsible for adding `border: "1px solid"` when needed
 * (MUI Button's outlined slot already has the border; IconButton does not).
 */
function createSharedOutlinedStyles(themeInstance: any) {
  const borderColor =
    (themeInstance.vars?.palette?.divider as string) ||
    themeInstance.palette.divider;
  const isDark = themeInstance.palette.mode === "dark";
  // alpha() cannot process CSS variables (e.g. var(--mui-palette-divider))
  const disabledBorder = isDark
    ? "rgba(255, 255, 255, 0.06)"
    : "rgba(0, 0, 0, 0.04)";
  const hoverBackground = isDark
    ? "rgba(255, 255, 255, 0.04)"
    : "rgba(0, 0, 0, 0.04)";

  return {
    "--variant-outlinedBorder": borderColor,
    borderColor,
    backgroundColor: "transparent",
    ...(!isDark && { boxShadow: themeInstance.shadows[1] }),
    "@media (hover: hover)": {
      "&:hover": {
        "--variant-outlinedBorder": borderColor,
        borderColor,
        ...(!isDark && { boxShadow: themeInstance.shadows[2] }),
        backgroundColor: hoverBackground,
      },
    },
    "&:active": { boxShadow: "none" },
    "&:disabled": {
      boxShadow: "none",
      "--variant-outlinedBorder": disabledBorder,
      borderColor: disabledBorder,
    },
  };
}

/**
 * Contained style: filled background, contrast text, no elevation.
 *
 * @param palette  A specific color palette (e.g. `theme.palette.primary`).
 *                 Pass `undefined` for the default (no-color) contained look.
 */
function createSharedContainedStyles(themeInstance: any, palette?: any) {
  const noShadow = { boxShadow: "none" } as const;

  if (!palette) {
    return {
      ...noShadow,
      backgroundColor:
        (themeInstance.vars?.palette?.action?.selected as string) ||
        themeInstance.palette.action.selected,
      color:
        (themeInstance.vars?.palette?.text?.primary as string) ||
        themeInstance.palette.text.primary,
      "&:hover": {
        ...noShadow,
        backgroundColor:
          (themeInstance.vars?.palette?.action?.focus as string) ||
          themeInstance.palette.action.focus,
      },
      "&:disabled": {
        ...noShadow,
        backgroundColor:
          (themeInstance.vars?.palette?.action?.disabledBackground as string) ||
          themeInstance.palette.action.disabledBackground,
        color:
          (themeInstance.vars?.palette?.action?.disabled as string) ||
          themeInstance.palette.action.disabled,
      },
    };
  }

  return {
    ...noShadow,
    backgroundColor: palette.main,
    color: palette.contrastText,
    "&:hover": {
      ...noShadow,
      backgroundColor: palette.dark,
    },
    "&:disabled": {
      ...noShadow,
      backgroundColor:
        (themeInstance.vars?.palette?.action?.disabledBackground as string) ||
        themeInstance.palette.action.disabledBackground,
      color:
        (themeInstance.vars?.palette?.action?.disabled as string) ||
        themeInstance.palette.action.disabled,
    },
  };
}

export function createExotelTheme(fontKey: FontKey = DEFAULT_FONT, themeOverrides?: ThemeOptions) {
  const activeFont = FONT_OPTIONS[fontKey];
  const theme = extendTheme({
    // Use class-based selector so dark mode is driven by a CSS class on <html>,
    // NOT by @media (prefers-color-scheme). This must be a top-level option —
    // nesting it inside `cssVariables` has no effect.
    colorSchemeSelector: "class",

    // ============================================================================
    // COLOR SCHEMES - Light and Dark mode palettes
    // ============================================================================
    // Both schemes are explicitly defined from design tokens (tokens.json).
    // Color ramps are mode-independent; semantic keys differ per scheme.

    colorSchemes: {
      light: {
        palette: {
          mode: "light",
          appLauncher: {
            trialChip: {
              bg: indigo[50],
              text: indigo[800],
            },
          },

          common: {
            black: "#000000",
            white: "#ffffff",
          },

          primary: {
            ...indigo,
            main: indigo[600],
            light: indigo[400],
            dark: indigo[800],
            contrastText: "#ffffff",
          },

          secondary: {
            ...purple,
            main: purple[700],
            light: purple[300],
            dark: purple[800],
            contrastText: "#ffffff",
          },

          error: {
            ...red,
            main: red[700],
            light: red[400],
            dark: red[800],
            contrastText: "#ffffff",
          },

          warning: {
            ...yellow,
            main: yellow[800],
            light: yellow[500],
            dark: yellow[900],
            contrastText: "#ffffff",
          },

          info: {
            ...lightBlue,
            main: lightBlue[700],
            light: lightBlue[500],
            dark: lightBlue[900],
            contrastText: "#ffffff",
          },

          success: {
            ...green,
            main: green[800],
            light: green[500],
            dark: green[900],
            contrastText: "#ffffff",
          },

          grey: { ...grey },

          text: {
            primary: "rgba(0, 0, 0, 0.87)",
            secondary: "rgba(0, 0, 0, 0.65)",
            disabled: "rgba(0, 0, 0, 0.38)",
          },

          divider: "rgba(0, 0, 0, 0.12)",

          background: {
            default: lightSurface.elevation0,
            paper: lightSurface.elevation2,
          },

          action: {
            active: "rgba(0, 0, 0, 0.57)",
            hover: "rgba(0, 0, 0, 0.04)",
            hoverOpacity: 0.04,
            selected: "rgba(0, 0, 0, 0.08)",
            selectedOpacity: 0.08,
            disabled: "rgba(0, 0, 0, 0.26)",
            disabledBackground: "rgba(0, 0, 0, 0.12)",
            disabledOpacity: 0.38,
            focus: "rgba(0, 0, 0, 0.12)",
            focusOpacity: 0.12,
            activatedOpacity: 0.12,
          },

          contrastThreshold: 3,
          tonalOffset: 0.2,

          surface: { ...lightSurface },
          // Light tonal: solid palette tokens (no alpha). See LIGHT_TONAL_PALETTE.
          tonal: LIGHT_TONAL_PALETTE,
          custom: {
            highlight: indigo[50],
          },
        },
      },
      dark: {
        palette: {
          mode: "dark",
          appLauncher: {
            trialChip: {
              bg: "#2e3148",
              text: indigo[200],
            },
          },

          common: {
            black: "#000000",
            white: "#ffffff",
          },

          primary: {
            ...indigo,
            main: indigo[200],
            light: indigo[50],
            dark: indigo[400],
            contrastText: "rgba(0, 0, 0, 0.87)",
          },

          secondary: {
            ...purple,
            main: purple[400],
            light: purple[50],
            dark: purple[600],
            contrastText: "rgba(0, 0, 0, 0.87)",
          },

          error: {
            ...red,
            main: red[500],
            light: red[300],
            dark: red[700],
            contrastText: "#000000",
          },

          warning: {
            ...yellow,
            main: yellow[400],
            light: yellow[300],
            dark: yellow[700],
            contrastText: "rgba(0, 0, 0, 0.87)",
          },

          info: {
            ...lightBlue,
            main: lightBlue[400],
            light: lightBlue[300],
            dark: lightBlue[700],
            contrastText: "rgba(0, 0, 0, 0.87)",
          },

          success: {
            ...green,
            main: green[400],
            light: green[300],
            dark: green[700],
            contrastText: "rgba(0, 0, 0, 0.87)",
          },

          grey: { ...grey },

          text: {
            primary: "#ffffff",
            secondary: "rgba(255, 255, 255, 0.7)",
            disabled: "rgba(255, 255, 255, 0.38)",
          },

          divider: "rgba(255, 255, 255, 0.12)",

          background: {
            default: darkSurface.elevation0,
            paper: darkSurface.elevation2,
          },

          action: {
            active: "rgba(255, 255, 255, 0.87)",
            hover: "rgba(255, 255, 255, 0.08)",
            hoverOpacity: 0.08,
            selected: "rgba(255, 255, 255, 0.16)",
            selectedOpacity: 0.16,
            disabled: "rgba(255, 255, 255, 0.3)",
            disabledBackground: "rgba(255, 255, 255, 0.12)",
            disabledOpacity: 0.38,
            focus: "rgba(255, 255, 255, 0.12)",
            focusOpacity: 0.12,
            activatedOpacity: 0.12,
          },

          contrastThreshold: 3,
          tonalOffset: 0.2,

          surface: { ...darkSurface },
          // Dark tonal: alpha-tinted backgrounds + TONAL_TEXT_RAMP foreground.
          tonalSurface: {
            backgroundOpacity: 0.32,
            hoverOpacityDelta: 0.08,
          },
          custom: {
            highlight: "#2A2F4A",
          },
        },
      },
    },

    // ============================================================================
    // TYPOGRAPHY - Font system for all text
    // ============================================================================
    // Typography is shared across both light and dark modes
    // Changing typography affects: All Typography components, Button text, Input labels,
    // Card headers, Dialog titles, and all text rendering.
    typography: {
      // Base font family - Applied to all text unless overridden
      fontFamily: `"${activeFont.family}", "Inter", "Roboto", sans-serif`,

      // Base font size in pixels
      fontSize: 14,

      // Font weight options
      fontWeightLight: fontWeights.light,
      fontWeightRegular: fontWeights.regular,
      fontWeightMedium: fontWeights.medium,
      fontWeightSemiBold: fontWeights.semiBold,
      fontWeightBold: fontWeights.bold,

      // HTML root font size (used for rem calculations)
      htmlFontSize: 16,

      // Typography variants - Exotel Design System rules
      h1: {
        fontWeight: fontWeights.bold,
        fontSize: "60px",
        lineHeight: 1.17,
        letterSpacing: "-1.5px",
        textDecoration: "none",
      },
      h2: {
        fontWeight: fontWeights.bold,
        fontSize: "48px",
        lineHeight: 1.2,
        letterSpacing: "-0.5px",
        textDecoration: "none",
      },
      h3: {
        fontWeight: fontWeights.bold,
        fontSize: "32px",
        lineHeight: 1.17,
        letterSpacing: "0px",
        textDecoration: "none",
      },
      h4: {
        fontWeight: fontWeights.bold,
        fontSize: "24px",
        lineHeight: 1.24,
        letterSpacing: "0.25px",
        textDecoration: "none",
      },
      h5: {
        fontWeight: fontWeights.bold,
        fontSize: "20px",
        lineHeight: 1.33,
        letterSpacing: "0px",
        textDecoration: "none",
      },
      h6: {
        fontWeight: fontWeights.bold,
        fontSize: "16px",
        lineHeight: 1.6,
        letterSpacing: "0.15px",
        textDecoration: "none",
      },

      // Title variants
      title1: {
        fontWeight: fontWeights.semiBold,
        fontSize: "12px",
        lineHeight: 1.57,
        letterSpacing: "0.1px",
        textDecoration: "none",
      },
      title2: {
        fontWeight: fontWeights.semiBold,
        fontSize: "14px",
        lineHeight: 1.57,
        letterSpacing: "0.1px",
        textDecoration: "none",
      },
      title3: {
        fontWeight: fontWeights.semiBold,
        fontSize: "16px",
        lineHeight: 1.75,
        letterSpacing: "0.15px",
        textDecoration: "none",
      },

      // Label variants
      label1: {
        fontWeight: fontWeights.medium,
        fontSize: "12px",
        lineHeight: 1.57,
        letterSpacing: "0.1px",
        textDecoration: "none",
      },
      label2: {
        fontWeight: fontWeights.medium,
        fontSize: "14px",
        lineHeight: 1.57,
        letterSpacing: "0.1px",
        textDecoration: "none",
      },
      label3: {
        fontWeight: fontWeights.medium,
        fontSize: "16px",
        lineHeight: 1.75,
        letterSpacing: "0.15px",
        textDecoration: "none",
      },

      // Body variants
      body1: {
        fontWeight: fontWeights.regular,
        fontSize: "16px",
        lineHeight: 1.5,
        letterSpacing: "0.15px",
        textDecoration: "none",
      },
      body2: {
        fontWeight: fontWeights.regular,
        fontSize: "14px",
        lineHeight: 1.43,
        letterSpacing: "0.17px",
        textDecoration: "none",
      },
      body3: {
        fontWeight: fontWeights.regular,
        fontSize: "12px",
        lineHeight: 1.32,
        letterSpacing: "0px",
        textDecoration: "none",
      },

      // Meta variants
      caption: {
        fontWeight: fontWeights.regular,
        fontSize: "12px",
        lineHeight: 1.66,
        letterSpacing: "0.4px",
        textDecoration: "none",
      },
      overline: {
        fontWeight: fontWeights.regular,
        fontSize: "12px",
        lineHeight: 2.66,
        letterSpacing: "1px",
        textDecoration: "none",
        textTransform: "uppercase",
      },
    },

    // ============================================================================
    // SPACING - Consistent spacing system
    // ============================================================================
    // Changing spacing affects: Margins, paddings, gaps in all components.
    // Default is 8px per unit (e.g., spacing(2) = 16px)
    // Material Design uses an 8dp grid system for visual balance.
    spacing: 8, // Base spacing unit in pixels

    // ============================================================================
    // BREAKPOINTS - Responsive design breakpoints
    // ============================================================================
    // Changing breakpoints affects: Grid layout, responsive typography, component visibility.
    // Used by: Grid, Hidden, useMediaQuery, sx prop responsive values
    breakpoints: {
      values: {
        xs: 0, // Extra small devices (phones)
        sm: 600, // Small devices (tablets)
        md: 900, // Medium devices (small laptops)
        lg: 1200, // Large devices (desktops)
        xl: 1536, // Extra large devices (large desktops)
      },
      unit: "px", // Unit for breakpoint values
      step: 5, // Step value for exclusive breakpoints (max-width calculations)
    },

    // ============================================================================
    // SHAPE - Border radius and shape customization
    // ============================================================================
    // Changing shape affects: Border radius of Buttons, Cards, Paper, Dialogs, TextFields, etc.
    shape: {
      borderRadius: 8, // Default border radius in pixels
    },

    // ============================================================================
    // SHADOWS - Figma elevation/1–5 (indices 6–24 clamp to level 5)
    // ============================================================================
    shadows: createMuiShadows(),

    // ============================================================================
    // Z-INDEX - Layering system
    // ============================================================================
    // Changing zIndex affects: Component stacking order (which components appear on top).
    // Higher values appear above lower values. Used for modals, tooltips, drawers, etc.
    zIndex: {
      mobileStepper: 1000, // Mobile stepper component
      fab: 1050, // Floating Action Button
      speedDial: 1050, // Speed Dial component
      appBar: 1100, // AppBar component
      drawer: 1200, // Drawer component
      modal: 1300, // Modal/Dialog component
      snackbar: 1400, // Snackbar component
      tooltip: 1500, // Tooltip component (highest)
    },

    // ============================================================================
    // TRANSITIONS - Animation timing and easing
    // ============================================================================
    // Changing transitions affects: Animation speed and easing curves for all animated components.
    // Used by: Collapse, Fade, Grow, Slide, Zoom, and all transition animations.
    transitions: {
      // Easing curves - Control how animations accelerate/decelerate
      easing: {
        // Most common easing curve - smooth acceleration and deceleration
        easeInOut: "cubic-bezier(0.4, 0, 0.2, 1)",
        // Objects enter screen at full velocity, slowly decelerate
        easeOut: "cubic-bezier(0.0, 0, 0.2, 1)",
        // Objects leave screen at full velocity, no deceleration
        easeIn: "cubic-bezier(0.4, 0, 1, 1)",
        // Sharp curve for objects that may return to screen
        sharp: "cubic-bezier(0.4, 0, 0.6, 1)",
      },
      // Duration values in milliseconds
      duration: {
        shortest: 150, // Fastest transitions
        shorter: 200,
        short: 250,
        standard: 300, // Most common duration
        complex: 375, // Complex animations
        enteringScreen: 225, // When something enters screen
        leavingScreen: 195, // When something leaves screen
      },
    },

    // ============================================================================
    // COMPONENTS - Component default props and style overrides
    // ============================================================================
    // Changing components affects: Default props and global styles for specific components.
    // Use defaultProps to change default prop values globally.
    // Use styleOverrides to change default styles globally.
    components: {
      MuiCssBaseline: {
        styleOverrides: Object.values(FONT_OPTIONS)
          .map(
            (f) => `
          @font-face {
            font-family: '${f.family}';
            font-style: normal;
            font-display: swap;
            font-weight: 100 900;
            src: local('${f.family}'), url(${f.src}) format('truetype');
            unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF;
          }`
          )
          .join("\n"),
      },
      MuiAvatar: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            backgroundColor:
              (themeInstance.vars?.palette?.action?.active as string) ||
              themeInstance.palette.action.active,
          }),
        },
      },

      // Button component customization
      MuiButton: {
        defaultProps: {
          // Uncomment to change default Button props globally:
          // variant: 'contained', // 'text' | 'outlined' | 'contained'
          // color: 'primary', // 'inherit' | 'primary' | 'secondary' | 'success' | 'error' | 'info' | 'warning'
          // size: 'medium', // 'small' | 'medium' | 'large' | 'extraLarge'
          disableElevation: true,
          // disableRipple: false,
        },
        // Size-specific variants - Dimensions from Figma design
        // Using padding-based approach instead of fixed height for better icon handling
        variants: [
          {
            props: { size: "extraLarge" },
            style: ({ theme }) => {
              // Target height: 44px
              // Font size: 16px, line-height: 1.5 = 24px
              // Vertical padding: (44 - 24) / 2 = 10px per side
              return {
                padding: "10px 24px",
                minHeight: 44,
                borderRadius: "8px",
                ...theme.typography.label3,
              };
            },
          },
          {
            props: { size: "large" },
            style: ({ theme }) => {
              // Target height: 40px
              // Font size: 14px, line-height: 1.5 = 21px
              // Vertical padding: (40 - 21) / 2 = 9.5px per side (round to 10px)
              return {
                padding: "10px 20px",
                minHeight: 40,
                borderRadius: "8px",
                ...theme.typography.label2,
              };
            },
          },
          {
            props: { size: "medium" },
            style: ({ theme }) => {
              // Target height: 32px
              // Font size: 14px, line-height: 1.5 = 21px
              // Vertical padding: (32 - 21) / 2 = 5.5px per side (round to 6px)
              return {
                padding: "6px 12px",
                minHeight: 32,
                borderRadius: "8px",
                ...theme.typography.label2,
              };
            },
          },
          {
            props: { size: "small" },
            style: ({ theme }) => {
              // Target height: 24px
              // Font size: 12px, line-height: 1.5 = 18px
              // Vertical padding: (24 - 18) / 2 = 3px per side
              // Horizontal padding: 8px for proper icon spacing
              return {
                padding: "3px 8px",
                minHeight: 24,
                borderRadius: "6px",
                ...theme.typography.label1,
              };
            },
          },
        ],
        styleOverrides: {
          root: ({ theme: themeInstance }) => {
            const createTonalStyles = (color: TonalSemanticColor) =>
              createTonalSurfaceStyles(
                resolveTonalColor(themeInstance, color),
                themeInstance.palette.action.disabled,
              );

            const brandContainedStyles = Object.fromEntries(
              BRAND_CONTAINED_COLORS.map((c) => [
                `&.MuiButton-contained.MuiButton-color${c.charAt(0).toUpperCase() + c.slice(1)}`,
                createBrandContainedCssVarOverrides(c),
              ]),
            );

            const dividerColor =
              (themeInstance.vars?.palette?.divider as string) ||
              themeInstance.palette.divider;

            const outlinedDividerBorder = {
              "--variant-outlinedBorder": dividerColor,
              borderColor: dividerColor,
              "@media (hover: hover)": {
                "&:hover": {
                  "--variant-outlinedBorder": dividerColor,
                  borderColor: dividerColor,
                },
              },
            };

            // Typography is now handled by size-specific variants above
            // Only apply base styles that are not size-dependent
            return {
              // Disable uppercase transformation (applies to all sizes)
              textTransform: "none",

              // Keep outlined stroke on divider in dark mode (overrides MUI per-color border vars)
              "&.MuiButton-outlined": outlinedDividerBorder,

              // Contained icons inherit contrast text from brand contained overrides
              "&.MuiButton-contained .MuiButton-startIcon, &.MuiButton-contained .MuiButton-endIcon":
                {
                  color: "inherit",
                },

              ...brandContainedStyles,

              // Skeuomorphic raised effect for contained buttons (excludes tonal).
              // Three-layer shadow: inner rim, bottom lip, and drop shadow.
              // ::before adds a top-edge specular highlight that fades toward
              // the bottom via a mask-image gradient.
              '&.MuiButton-contained:not([data-variant="tonal"])': (() => {
                const skeuoShadow =
                  "inset 0 0 0 1px rgba(0, 0, 0, 0.18), inset 0 -2px 0 0 rgba(0, 0, 0, 0.05), 0 1px 2px 0 rgba(0, 0, 0, 0.05)";
                return {
                  boxShadow: skeuoShadow,
                  "&::before": {
                    content: '""',
                    position: "absolute",
                    inset: "1px",
                    borderRadius: "inherit",
                    border: "1px solid rgba(255, 255, 255, 0.12)",
                    pointerEvents: "none",
                    maskImage:
                      "linear-gradient(to bottom, #000 0%, transparent 100%)",
                    WebkitMaskImage:
                      "linear-gradient(to bottom, #000 0%, transparent 100%)",
                  },
                  "@media (hover: hover)": {
                    "&:hover": { boxShadow: skeuoShadow },
                  },
                  "&:active": { boxShadow: skeuoShadow },
                  "&.Mui-focusVisible": { boxShadow: skeuoShadow },
                  "&.Mui-disabled": {
                    boxShadow: "none",
                    "&::before": { display: "none" },
                  },
                };
              })(),

              // Icon spacing - ensure proper gap between icon and text
              "& .MuiButton-startIcon": {
                marginLeft: 0,
                marginRight: "8px",
              },
              "& .MuiButton-endIcon": {
                marginLeft: "8px",
                marginRight: 0,
              },
              // Smaller icon spacing and size for small buttons
              "&.MuiButton-sizeSmall .MuiButton-startIcon": {
                marginRight: "4px",
                fontSize: "16px", // 16x16px icon size for small buttons
                "& svg": {
                  width: "16px",
                  height: "16px",
                },
              },
              "&.MuiButton-sizeSmall .MuiButton-endIcon": {
                marginLeft: "4px",
                fontSize: "16px", // 16x16px icon size for small buttons
                "& svg": {
                  width: "16px",
                  height: "16px",
                },
              },

              // Tonal button styles - target via data-variant attribute and MUI color classes
              // These work independently of size variants
              '&[data-variant="tonal"].MuiButton-colorPrimary':
                createTonalStyles("primary"),
              '&[data-variant="tonal"].MuiButton-colorSecondary':
                createTonalStyles("secondary"),
              '&[data-variant="tonal"].MuiButton-colorError':
                createTonalStyles("error"),
              '&[data-variant="tonal"].MuiButton-colorSuccess':
                createTonalStyles("success"),
              '&[data-variant="tonal"].MuiButton-colorWarning':
                createTonalStyles("warning"),
              '&[data-variant="tonal"].MuiButton-colorInfo':
                createTonalStyles("info"),
            };
          },
          // Soft Outlined Button variant styling — delegates to shared helper
          // so IconButton outlined uses the exact same styles.
          outlined: ({ theme: themeInstance }) =>
            createSharedOutlinedStyles(themeInstance),
          startIcon: {
            color: "inherit !important",
          },
          endIcon: {
            color: "inherit !important",
          },
        },
      },

      // Tabs container customization
      MuiTabs: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => {
            const br = Number(themeInstance.shape.borderRadius) || 8;
            return {
              '&[data-variant="topIcon"]': {
                "& .MuiTab-root": {
                  gap: themeInstance.spacing(0.5),
                  "& .MuiTab-iconWrapper": {
                    marginBottom: 0,
                  },
                },
                "& .MuiTabs-indicator": {
                  backgroundColor: "transparent",
                  height: 3,
                  "&::before": {
                    content: '""',
                    display: "block",
                    position: "absolute",
                    left: 16,
                    right: 16,
                    top: 0,
                    bottom: 0,
                    borderRadius: `${br}px ${br}px 0 0`,
                    backgroundColor:
                      (themeInstance.vars?.palette?.primary?.main as string) ||
                      themeInstance.palette.primary.main,
                  },
                },
              },

              '&[data-variant="button"]': {
                backgroundColor:
                  (themeInstance.vars?.palette?.action?.hover as string) ||
                  themeInstance.palette.action.hover,
                borderRadius: br,
                padding: "4px",
                minHeight: 40,
                "& .MuiTabs-indicator": {
                  height: "100%",
                  bottom: 0,
                  borderRadius: `${br - 2}px`,
                  backgroundColor:
                    (themeInstance.vars?.palette?.background?.paper as string) ||
                    themeInstance.palette.background.paper,
                  boxShadow: themeInstance.shadows[1],
                  zIndex: 0,
                },
                "& .MuiTabs-flexContainer": {
                  gap: "4px",
                  position: "relative",
                  zIndex: 1,
                },
                "& .MuiTab-root": {
                  minHeight: 32,
                  height: 32,
                  borderRadius: `${br - 2}px`,
                  padding: "6px 16px",
                  zIndex: 1,
                  color:
                    (themeInstance.vars?.palette?.text?.primary as string) ||
                    themeInstance.palette.text.primary,
                  opacity: 1,
                  transition: themeInstance.transitions.create(
                    ["color"],
                    { duration: themeInstance.transitions.duration.short },
                  ),
                  "& .MuiTouchRipple-root": {
                    display: "none",
                  },
                  "&.Mui-selected": {
                    color:
                      (themeInstance.vars?.palette?.primary?.main as string) ||
                      themeInstance.palette.primary.main,
                  },
                  "&:hover:not(.Mui-selected)": {
                    backgroundColor: alpha(
                      themeInstance.palette.action.hover,
                      themeInstance.palette.action.hoverOpacity * 2,
                    ),
                    borderRadius: `${br - 2}px`,
                  },
                },
              },
            };
          },
        },
      },

      // Tab component customization
      MuiTab: {
        styleOverrides: {
          root: {
            textTransform: "none",
            "& .MuiBadge-root": {
              display: "inline-flex",
              alignItems: "center",
              gap: "4px",
              "& .MuiBadge-badge": {
                position: "static",
                transform: "none",
              },
            },
            "&.MuiTab-labelIcon": {
              minHeight: "auto",
              "& .MuiTab-wrapper": {
                flexDirection: "row",
                alignItems: "center",
                gap: "8px",
              },
              "& .MuiTab-iconWrapper": {
                marginRight: "8px",
                marginBottom: 0,
                display: "flex",
                alignItems: "center",
              },
            },
          },
          labelIcon: {
            paddingBlock: '14px'
          }
        },
      },

      // Menu component customization
      MuiMenu: {
        defaultProps: {
          elevation: 5,
          dense: true,
        },
        styleOverrides: {
          paper: ({ theme: themeInstance }) => ({
            padding: themeInstance.spacing(0.5),
            borderRadius: themeInstance.shape.borderRadius,
            overflow: 'hidden',
            border: `1px solid ${
              (themeInstance.vars?.palette?.divider as string) ||
              themeInstance.palette.divider
            }`,
          }),
          list: {
            padding: 0,
          },
        },
      },

      // MenuItem component customization — dense adjusts spacing only; label stays body2 (14px)
      MuiMenuItem: {
        styleOverrides: {
          root: ({ theme: themeInstance, ownerState }) => ({
            borderRadius: themeInstance.shape.borderRadius,
            marginBlock: 0,
            ...themeInstance.typography.body2,
            ...(ownerState.dense
              ? {
                  minHeight: 32,
                  paddingTop: themeInstance.spacing(0.5),
                  paddingBottom: themeInstance.spacing(0.5),
                }
              : {}),
          }),
        },
      },

      // ListItemIcon component customization
      MuiListItemIcon: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            minWidth: themeInstance.spacing(4), // 32px for icon spacing
          }),
        },
      },

      // ListItemText component customization
      MuiListItemText: {
        styleOverrides: {
          root: {
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
          },
          primary: ({ theme: themeInstance }) => ({
            ...themeInstance.typography.body2,
          }),
          secondary: ({ theme: themeInstance }) => ({
            ...themeInstance.typography.body3,
          }),
        },
      },

      // // ListItemButton component customization
      MuiListItemButton: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            padding: themeInstance.spacing(0.5, 1),
            borderRadius: themeInstance.shape.borderRadius,
            marginBlock: themeInstance.spacing(0.5),
            // Selected state
            "&.Mui-selected": {
              backgroundColor: themeInstance.vars?.palette?.custom?.highlight,
              "&:hover": {
                backgroundColor: themeInstance.vars?.palette?.custom?.highlight,
              },
            },
          })
        },
      },

      // Dialog component customization
      MuiDialog: {
        defaultProps: {
          elevation: 4,
        },
        styleOverrides: {
          paper: ({ theme: themeInstance }) => ({
            // Border radius matches Exotel system
            borderRadius: themeInstance.shape.borderRadius,
            // No custom shadows - use MUI defaults
            // Max height handled by Dialog component (responsive)
            // Flex layout ensures Header/Footer stay fixed, Body scrolls
            display: "flex",
            flexDirection: "column",
          }),
        },
      },

      // InputBase component (base for all input components)
      // Size-based height and padding lives here so it applies to every variant
      // (Outlined, Filled, Standard) and to picker text fields.
      MuiInputBase: {
        styleOverrides: {
          root: ({ theme: themeInstance, ownerState }) => {
            const size = (ownerState as any)?.size || "medium";

            const heightMap: Record<string, number> = {
              small: 32,
              medium: 40,
              large: 50,
            };

            const targetHeight = heightMap[size] || heightMap.medium;

            const lineHeight = 16;
            const border = 2; // 1px top + 1px bottom
            const verticalPadding = (targetHeight - border - lineHeight) / 2;

            const horizontalPadding = themeInstance.spacing(1.5); // 12px

            return {
              boxShadow: themeInstance.shadows[1],
              fontWeight: fontWeights.medium,
              color:
                (themeInstance.vars?.palette?.text?.primary as string) ||
                themeInstance.palette.text.primary,
              height: ownerState.multiline ? "auto" : `${targetHeight}px`,
              minHeight: ownerState.multiline ? "auto" : `${targetHeight}px`,
              maxHeight: ownerState.multiline ? "auto" : `${targetHeight}px`,
              paddingTop: `${verticalPadding}px`,
              paddingBottom: `${verticalPadding}px`,
              paddingLeft: horizontalPadding + " !important",
              paddingRight: horizontalPadding,
              boxSizing: "border-box",
              "& .MuiInputBase-input": {
                padding: 0,
              },
            };
          },
          input: ({ theme: themeInstance, ownerState }) => ({
            fontSize:
              ownerState.size === "small"
                ? themeInstance.typography?.body3?.fontSize
                : ownerState.size === "large"
                  ? themeInstance.typography?.body1?.fontSize
                  : themeInstance.typography?.body2?.fontSize,
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
            "&::placeholder": {
              color:
                (themeInstance.vars?.palette?.text?.secondary as string) ||
                themeInstance.palette.text.secondary,
              opacity: 0.7,
            },
          }),
        },
      },

      // DialogTitle component customization
      MuiDialogTitle: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            // Typography uses Exotel heading tokens
            fontSize: themeInstance.typography.h6.fontSize,
            fontWeight: themeInstance.typography.h6.fontWeight,
            lineHeight: themeInstance.typography.h6.lineHeight,
            // Match Drawer header styling exactly
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            minHeight: 40,
            padding: themeInstance.spacing(1, 2),
            borderBottom: `1px solid ${themeInstance.palette.divider}`,
            backgroundColor: themeInstance.palette.action.hover,
            flexShrink: 0,
          }),
        },
      },

      // DialogContent component customization
      MuiDialogContent: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            // Padding for structured layout
            padding: themeInstance.spacing(3, 2),
            paddingTop: `${themeInstance.spacing(3)} !important`,
            // Ensure proper scrolling behavior - only Body scrolls
            overflowY: "auto",
            flex: 1,
            display: "flex",
            flexDirection: "column",
            backgroundColor: "background.paper",
            // When dividers prop is used, maintain padding but remove default border styling
            // Dividers are handled by DialogTitle (borderBottom) and DialogActions (borderTop)
            "&.MuiDialogContent-dividers": {
              paddingTop: themeInstance.spacing(3),
              paddingBottom: themeInstance.spacing(3),
              borderTop: "none",
              borderBottom: "none",
            },
          }),
        },
      },

      // DialogActions component customization
      MuiDialogActions: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-end",
            gap: themeInstance.spacing(2),
            minHeight: 64,
            padding: themeInstance.spacing(1, 2),
            borderTop: `1px solid ${themeInstance.palette.divider}`,
            backgroundColor: themeInstance.palette.background.paper,
            flexShrink: 0,
            ".MuiPickersLayout-root &": {
              backgroundColor: "transparent",
              minHeight: "auto",
            },
          }),
        },
      },

      // Drawer component customization
      MuiDrawer: {
        defaultProps: {
          elevation: 4,
        },
        styleOverrides: {
          paper: ({ theme: themeInstance }) => ({
            // Drawer width should respect existing Exotel sizing rules
            // Default width for temporary drawers
            width: "100%",
            maxWidth: 600,
            // Border radius matches Exotel system
            borderRadius: 0,
            // No custom shadows - use MUI defaults
            // Background uses theme surface token (handled by component)
          }),
          paperAnchorLeft: {
            // Left anchor specific styles if needed
          },
          paperAnchorRight: {
            // Right anchor specific styles if needed
          },
          paperAnchorTop: {
            // Top anchor specific styles if needed
          },
          paperAnchorBottom: {
            // Bottom anchor specific styles if needed
          },
        },
      },

      // TextField component customization
      // Only supporting outlined variant
      MuiTextField: {
        defaultProps: {
          variant: "outlined", // Default to outlined only
        },
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            // Ensure text field uses theme colors
            "& .MuiInputBase-root": {
              backgroundColor:
                (themeInstance.vars?.palette?.background?.paper as string) ||
                themeInstance.palette.background.paper,
              color:
                (themeInstance.vars?.palette?.text?.primary as string) ||
                themeInstance.palette.text.primary,
              gap: themeInstance.spacing(0.75),
            },
          }),
        },
      },

      // InputLabel component customization
      // Adjust unshrunk label font-size while preserving shrunk label visual size
      MuiInputLabel: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => {
            const unshrunkFontSize = themeInstance.typography.label1.fontSize;
            const baseFontSize = parseFloat(String(unshrunkFontSize));
            const targetShrunkPx = parseFloat(
              String(themeInstance.typography.label1.fontSize),
            );
            const shrunkScale =
              baseFontSize > 0 ? targetShrunkPx / baseFontSize : 1;

            return {
              color:
                (themeInstance.vars?.palette?.text?.secondary as string) ||
                themeInstance.palette.text.secondary,
              "&.Mui-focused": {
                color:
                  (themeInstance.vars?.palette?.primary?.main as string) ||
                  themeInstance.palette.primary.main,
              },
              fontSize: unshrunkFontSize,
              // Preserve MUI's shrink transform but adjust scale proportionally
              // MUI default transform: translate(14px, -9px) scale(0.75)
              "&.MuiInputLabel-shrink": {
                transform: `translate(14px, -9px) scale(${shrunkScale})`,
                transformOrigin: "top left",
              },
            };
          },
        },
      },

      // FormLabel component customization (for external labels)
      MuiFormLabel: {
        styleOverrides: {
          root: ({ theme: themeInstance, ownerState }) => {
            // Get size from FormControl context or default to medium
            // Note: FormLabel doesn't have size prop directly, so we use default
            // Size-specific styling can be applied via FormControl if needed
            return {
              fontSize: themeInstance.typography.label1.fontSize,
              lineHeight: themeInstance.typography.label1.lineHeight,
              letterSpacing: themeInstance.typography.label1.letterSpacing,
              color: themeInstance.palette.text.secondary,
              marginBottom: themeInstance.spacing(0.5), // Space between label and input
              fontWeight: themeInstance.typography.label1.fontWeight,
              "& .MuiFormLabel-asterisk": {
              color:
                (themeInstance.vars?.palette?.error?.main as string) ||
                themeInstance.palette.error.main,
            },
            };
          },
        },
      },

      // FormHelperText component customization
      MuiFormHelperText: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            color:
              (themeInstance.vars?.palette?.text?.secondary as string) ||
              themeInstance.palette.text.secondary,
            marginTop: themeInstance.spacing(0.5), // Space between input and helper text
            marginLeft: 0,
            marginRight: 0,
            fontSize: themeInstance.typography.body3.fontSize, // 12px
          }),
        },
      },

      // OutlinedInput component customization
      // Size-based height/padding is handled by MuiInputBase above.
      // Only outlined-specific visuals (background, border colors) remain here.
      MuiOutlinedInput: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            backgroundColor:
              (themeInstance.vars?.palette?.background?.paper as string) ||
              themeInstance.palette.background.paper,
            "& .MuiOutlinedInput-notchedOutline": {
              borderColor:
                (themeInstance.vars?.palette?.divider as string) ||
                themeInstance.palette.divider,
            },
            "&:hover .MuiOutlinedInput-notchedOutline": {
              borderColor:
                (themeInstance.vars?.palette?.text?.primary as string) ||
                themeInstance.palette.text.primary,
            },
            "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
              borderColor:
                (themeInstance.vars?.palette?.primary?.main as string) ||
                themeInstance.palette.primary.main,
            },
          }),
        },
      },

      // Card component customization
      MuiCard: {
        defaultProps: {
          elevation: 1,
        },
        styleOverrides: {
          // Uncomment to override Card styles globally:
          // root: {
          //   borderRadius: theme.shape.borderRadius * 2, // Larger border radius
          // },
        },
      },

      // AppBar component customization
      MuiAppBar: {
        defaultProps: {
          // Uncomment to change default AppBar props globally:
          // position: 'static', // 'fixed' | 'absolute' | 'sticky' | 'static' | 'relative'
          // color: 'primary', // 'default' | 'inherit' | 'primary' | 'secondary' | 'transparent' | 'error' | 'info' | 'success' | 'warning'
          // elevation: 4,
        },
        styleOverrides: {
          // Uncomment to override AppBar styles globally:
          // root: {
          //   // Custom styles
          // },
        },
      },

      // Typography component customization
      MuiTypography: {
        defaultProps: {
          // Uncomment to change default Typography props globally:
          // variant: 'body1', // 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6' | 'subtitle1' | 'subtitle2' | 'body1' | 'body2' | 'button' | 'caption' | 'overline'
          // color: 'text.primary', // 'initial' | 'inherit' | 'primary' | 'secondary' | 'text.primary' | 'text.secondary' | 'text.disabled' | 'error'
        },
        styleOverrides: {
          // Uncomment to override Typography styles globally:
          // root: {
          //   // Custom styles
          // },
        },
      },

      // DataGrid component customization (MUI X)
      MuiDataGrid: {
        defaultProps: {
          // Default props are handled in DataTable component wrapper
        },
        styleOverrides: {
          root: ({ theme: themeInstance }) => {
            const borderColor =
              (themeInstance?.vars?.palette?.divider as string) ||
              themeInstance.palette.divider;
            const borderRadius = themeInstance.shape.borderRadius;
            return {
              border: "none",
              '& .MuiDataGrid-scrollShadow': {
                display: 'none',
              },
              '& .MuiDataGrid-main': {
                backgroundColor:
                  themeInstance?.vars?.palette?.surface?.elevation1,
                borderTop: `1px solid ${borderColor}`,
                borderLeft: `1px solid ${borderColor}`,
                borderRight: `1px solid ${borderColor}`,
                borderTopLeftRadius: `${borderRadius}px`,
                borderTopRightRadius: `${borderRadius}px`,
              },
              '& .MuiDataGrid-footerContainer': {
                borderLeft: `1px solid ${borderColor}`,
                borderRight: `1px solid ${borderColor}`,
                borderBottom: `1px solid ${borderColor}`,
                borderBottomLeftRadius: `${borderRadius}px`,
                borderBottomRightRadius: `${borderRadius}px`,
                overflow: 'hidden',
              },
            };
          },
          columnHeaders: ({ theme: themeInstance }) => ({
            backgroundColor: themeInstance?.vars?.palette?.surface?.elevation0,
            '& .MuiDataGrid-filler': {
              backgroundColor: themeInstance?.vars?.palette?.surface?.elevation0 + ' !important',
            },
            '& .MuiDataGrid-row--borderBottom': {
              height: '40px !important',
            }
          }),
          columnHeader: ({ theme: themeInstance }) => ({
            backgroundColor: themeInstance?.vars?.palette?.surface?.elevation0,
            borderBottom: 'none !important',
          }),
          cell: {},
          "cell--pinnedLeft": ({ theme: themeInstance }) => ({
            backgroundColor: themeInstance?.vars?.palette?.surface?.elevation1,
          }),
          "cell--pinnedRight": ({ theme: themeInstance }) => ({
            backgroundColor: themeInstance?.vars?.palette?.surface?.elevation1,
          }),
          "filler--pinnedLeft": ({ theme: themeInstance }) => ({
            backgroundColor: themeInstance?.vars?.palette?.surface?.elevation1,
          }),
          "filler--pinnedRight": ({ theme: themeInstance }) => ({
            backgroundColor: themeInstance?.vars?.palette?.surface?.elevation1,
          }),
          row: {},
          toolbar: () => ({
            border: "none",
            padding: "0px",
            flex: "none",
            display: "block",
          }),
          iconButtonContainer: {},
          menu: {},
          panelWrapper: ({ theme: themeInstance }) => ({
            backgroundColor: themeInstance.vars?.palette?.background?.paper,
            backgroundImage: 'var(--mui-overlays-8)',
          }),
          overlayWrapper: {
            top: 0
          }
        },
      },

      // IconButton component customization
      // Supports shape (circle, square) and variant (text, outlined, contained).
      // Uses the same shared helpers as MuiButton so style changes propagate to both.
      MuiIconButton: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => {
            const colors = ["primary", "secondary", "error", "warning", "info", "success"] as const;

            const textColorStyles = Object.fromEntries(
              colors.map((c) => {
                const palette = themeInstance.palette[c];
                const vars = themeInstance.vars?.palette?.[c];
                return [
                  `&.MuiIconButton-color${c.charAt(0).toUpperCase() + c.slice(1)}`,
                  {
                    color: (vars?.main as string) || palette.main,
                    "&:hover": { backgroundColor: alpha(palette.main, 0.08) },
                  },
                ];
              }),
            );

            const outlinedColorStyles = Object.fromEntries(
              colors.map((c) => {
                const palette = themeInstance.palette[c];
                const vars = themeInstance.vars?.palette?.[c];
                return [
                  `&.MuiIconButton-color${c.charAt(0).toUpperCase() + c.slice(1)}`,
                  {
                    color: (vars?.main as string) || palette.main,
                    "&:hover": { backgroundColor: alpha(palette.main, 0.08) },
                  },
                ];
              }),
            );

            const containedColorStyles = Object.fromEntries(
              colors.map((c) => [
                `&.MuiIconButton-color${c.charAt(0).toUpperCase() + c.slice(1)}`,
                createSharedContainedStyles(themeInstance, BRAND_CONTAINED[c]),
              ]),
            );

            return {
              borderRadius: themeInstance.shape.borderRadius,
              color:
                (themeInstance.vars?.palette?.text?.primary as string) ||
                themeInstance.palette.text.primary,
              "&:hover": {
                backgroundColor:
                  (themeInstance.vars?.palette?.action?.hover as string) ||
                  themeInstance.palette.action.hover,
              },
              "&:disabled": {
                color:
                  (themeInstance.vars?.palette?.action?.disabled as string) ||
                  themeInstance.palette.action.disabled,
              },

              // --- Shape ---
              '&[data-shape="circle"]': { borderRadius: "50%" },
              '&[data-shape="square"]': { borderRadius: themeInstance.shape.borderRadius },

              // --- Variant: text (default) ---
              ...textColorStyles,

              // --- Variant: outlined (same helper as MuiButton.outlined) ---
              '&[data-variant="outlined"]': {
                border: "1px solid",
                ...createSharedOutlinedStyles(themeInstance),
                ...outlinedColorStyles,
              },

              // --- Variant: contained (same helper as MuiButton contained) ---
              '&[data-variant="contained"]': {
                ...createSharedContainedStyles(themeInstance),
                ...containedColorStyles,
              },
            };
          },
        },
      },

      // Paper component customization
      // Paper is used by many components (Popover, Menu, Select dropdown, DatePicker, etc.)
      // CRITICAL: Must use CSS variables for automatic light/dark mode adaptation
      MuiPaper: {
        defaultProps: {
          elevation: 1,
        },
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            // Use CSS variables for automatic light/dark adaptation
            backgroundColor:
              (themeInstance.vars?.palette?.background?.paper as string) ||
              themeInstance.palette.background.paper,
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
            '&.MuiPickerPopper-paper': {
              borderRadius: themeInstance.shape.borderRadius,
              overflow: 'hidden',
            }
            // Border for better visibility in dark mode (optional, can be removed if not needed)
            // borderColor: (themeInstance.vars?.palette?.divider as string) || themeInstance.palette.divider,
          }),
        },
      },

      // Popover component customization
      // Used by Select, MultiSelect, DatePicker dropdowns
      MuiPopover: {
        defaultProps: {
          elevation: 5,
        },
        styleOverrides: {
          paper: ({ theme: themeInstance }) => ({
            // Use CSS variables for automatic light/dark adaptation
            backgroundColor:
              (themeInstance.vars?.palette?.background?.paper as string) ||
              themeInstance.palette.background.paper,
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
            boxShadow: themeInstance.shadows[5],
            borderRadius: themeInstance.shape.borderRadius,
            border: `1px solid ${
              (themeInstance.vars?.palette?.divider as string) ||
              themeInstance.palette.divider
            }`,
          }),
        },
      },

      // Select component customization
      // Ensures dropdown menu has correct background in dark mode
      MuiSelect: {
        styleOverrides: {
          // The select input field itself
          select: ({ theme: themeInstance }) => ({
            backgroundColor: "transparent", // Let TextField handle background
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
          }),
        },
      },

      // Pickers Popper (dropdown container)
      MuiPickersPopper: {
        styleOverrides: {
          paper: ({ theme: themeInstance }) => ({
            backgroundColor:
              (themeInstance.vars?.palette?.background?.paper as string) ||
              themeInstance.palette.background.paper,
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
            boxShadow: themeInstance.shadows[5],
          }),
        },
      },

      // Pickers Layout (main calendar container)
      MuiPickersLayout: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            backgroundColor:
              (themeInstance.vars?.palette?.background?.paper as string) ||
              themeInstance.palette.background.paper,
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
          }),
          contentWrapper: ({ theme: themeInstance }) => ({
            backgroundColor:
              (themeInstance.vars?.palette?.background?.paper as string) ||
              themeInstance.palette.background.paper,
          }),
        },
      },

      // Date Calendar (single calendar view)
      MuiDateCalendar: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            backgroundColor:
              (themeInstance.vars?.palette?.background?.paper as string) ||
              themeInstance.palette.background.paper,
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
          }),
        },
      },

      // Date Range Calendar (dual calendar view for date range picker)
      MuiDateRangeCalendar: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            backgroundColor:
              (themeInstance.vars?.palette?.background?.paper as string) ||
              themeInstance.palette.background.paper,
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
          }),
        },
      },

      // Calendar header (month/year selector)
      MuiPickersCalendarHeader: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
          }),
          labelContainer: ({ theme: themeInstance }) => ({
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
          }),
        },
      },

      // Individual day cells in calendar
      MuiPickersDay: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
            backgroundColor: "transparent",
            "&:hover": {
              backgroundColor:
                (themeInstance.vars?.palette?.action?.hover as string) ||
                themeInstance.palette.action.hover,
            },
            "&.Mui-selected": {
              backgroundColor:
                (themeInstance.vars?.palette?.primary?.main as string) ||
                themeInstance.palette.primary.main,
              color:
                (themeInstance.vars?.palette?.primary
                  ?.contrastText as string) ||
                themeInstance.palette.primary.contrastText,
              "&:hover": {
                backgroundColor:
                  (themeInstance.vars?.palette?.primary?.dark as string) ||
                  themeInstance.palette.primary.dark,
              },
            },
          }),
        },
      },

      // Day of week labels (Mon, Tue, Wed, etc.)
      MuiDayCalendar: {
        styleOverrides: {
          weekDayLabel: ({ theme: themeInstance }) => ({
            color:
              (themeInstance.vars?.palette?.text?.secondary as string) ||
              themeInstance.palette.text.secondary,
          }),
        },
      },

      // Month/Year picker views
      MuiPickersYear: {
        styleOverrides: {
          yearButton: ({ theme: themeInstance }) => ({
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
            "&:hover": {
              backgroundColor:
                (themeInstance.vars?.palette?.action?.hover as string) ||
                themeInstance.palette.action.hover,
            },
            "&.Mui-selected": {
              backgroundColor:
                (themeInstance.vars?.palette?.primary?.main as string) ||
                themeInstance.palette.primary.main,
              color:
                (themeInstance.vars?.palette?.primary
                  ?.contrastText as string) ||
                themeInstance.palette.primary.contrastText,
            },
          }),
        },
      },

      MuiPickersMonth: {
        styleOverrides: {
          monthButton: ({ theme: themeInstance }) => ({
            color:
              (themeInstance.vars?.palette?.text?.primary as string) ||
              themeInstance.palette.text.primary,
            "&:hover": {
              backgroundColor:
                (themeInstance.vars?.palette?.action?.hover as string) ||
                themeInstance.palette.action.hover,
            },
            "&.Mui-selected": {
              backgroundColor:
                (themeInstance.vars?.palette?.primary?.main as string) ||
                themeInstance.palette.primary.main,
              color:
                (themeInstance.vars?.palette?.primary
                  ?.contrastText as string) ||
                themeInstance.palette.primary.contrastText,
            },
          }),
        },
      },

      // Shortcuts panel (Today, Yesterday, Last 7 days, etc.)
      MuiPickersShortcuts: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            backgroundColor:
              (themeInstance.vars?.palette?.background?.paper as string) ||
              themeInstance.palette.background.paper,
            borderRight: `1px solid ${(themeInstance.vars?.palette?.divider as string) || themeInstance.palette.divider}`,
          }),
        },
      },

      // Action bar (Cancel/Accept buttons)
      MuiPickersActionBar: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            backgroundColor: 'transparent',
            borderTop: `1px solid ${(themeInstance.vars?.palette?.divider as string) || themeInstance.palette.divider}`,
          }),
        },
      },

      MuiAlert: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => {
            const standardSeverities = [
              "success",
              "error",
              "warning",
              "info",
            ] as const;

            return Object.fromEntries(
              standardSeverities.map((severity) => {
                const tokens = resolveTonalColor(themeInstance, severity);
                const colorClass = `MuiAlert-color${severity.charAt(0).toUpperCase() + severity.slice(1)}`;
                return [
                  `&.MuiAlert-standard.${colorClass}`,
                  { backgroundColor: tokens.bg },
                ];
              }),
            );
          },
        },
      },

      MuiAccordion: {
        defaultProps: {
          disableGutters: true,
          elevation: 0,
        },
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            "&.Mui-expanded": {
              margin: 0,
            },
            "&.Mui-expanded::before": {
              opacity: 1,
            },
            "&.Mui-expanded + .MuiAccordion-root::before": {
              display: "block",
              opacity: 1,
            },
            "&::before": {
              backgroundColor:
                (themeInstance.vars?.palette?.divider as string) ||
                themeInstance.palette.divider,
            },
          }),
        },
      },

      MuiChip: {
        styleOverrides: {
          root: ({ theme: themeInstance }) => ({
            borderRadius: themeInstance.shape.borderRadius,
            fontWeight: fontWeights.medium,
            lineHeight: 1.38,
            letterSpacing: '0.16px',
            "&.MuiChip-filled": {
              border: "none",
            },
            "&.MuiChip-outlined": {
              border: "1px solid currentColor",
            },
          }),
        },
      },
    },
  }, themeOverrides);

  // Return the theme (extendTheme already creates it)
  return theme;
}

// Export the theme
export const exotelTheme = createExotelTheme();
