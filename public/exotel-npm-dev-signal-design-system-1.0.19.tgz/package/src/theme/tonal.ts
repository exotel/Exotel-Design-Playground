import { alpha, type Theme } from '@mui/material/styles';

export type TonalSemanticColor =
  | 'default'
  | 'primary'
  | 'secondary'
  | 'error'
  | 'warning'
  | 'info'
  | 'success';

export interface TonalColorTokens {
  bg: string;
  text: string;
  hoverBg: string;
  disabledBg: string;
}

export type TonalPalette = Record<TonalSemanticColor, TonalColorTokens>;

export interface TonalSurfaceConfig {
  /** Alpha multiplier on semantic `main` for dark-mode tonal background (0.32). */
  backgroundOpacity: number;
  /** Additional alpha applied on hover, capped at 1. */
  hoverOpacityDelta: number;
}

/** Dark-mode palette ramp index for tonal foreground text. */
export const TONAL_TEXT_RAMP: Record<
  Exclude<TonalSemanticColor, 'default'>,
  200 | 400 | 500
> = {
  primary: 200,
  secondary: 400,
  success: 400,
  warning: 400,
  info: 400,
  error: 500,
};

function resolveDarkTonalText(theme: Theme, key: TonalSemanticColor): string {
  if (key === 'default') {
    return theme.palette.common.white;
  }

  const rampStep = TONAL_TEXT_RAMP[key];
  const palette = theme.palette[key] as Record<number, string>;
  return palette[rampStep];
}

function resolveLightTonal(
  theme: Theme,
  key: TonalSemanticColor,
): TonalColorTokens {
  const tonal = theme.palette.tonal;
  if (!tonal) {
    throw new Error('Light mode requires palette.tonal (LIGHT_TONAL_PALETTE).');
  }
  return tonal[key] ?? tonal.default;
}

function resolveDarkTonal(
  theme: Theme,
  key: TonalSemanticColor,
): TonalColorTokens {
  const tonalSurface = theme.palette.tonalSurface;
  if (!tonalSurface) {
    throw new Error('Dark mode requires palette.tonalSurface.');
  }

  const { backgroundOpacity, hoverOpacityDelta } = tonalSurface;
  const hoverOpacity = Math.min(backgroundOpacity + hoverOpacityDelta, 1);
  const disabledOpacity = backgroundOpacity * 0.5;

  if (key === 'default') {
    const main = theme.palette.grey[500];

    return {
      bg: alpha(main, backgroundOpacity),
      text: resolveDarkTonalText(theme, key),
      hoverBg: alpha(main, hoverOpacity),
      disabledBg: alpha(main, disabledOpacity),
    };
  }

  const palette = theme.palette[key];
  const main = palette.main;

  return {
    bg: alpha(main, backgroundOpacity),
    text: resolveDarkTonalText(theme, key),
    hoverBg: alpha(main, hoverOpacity),
    disabledBg: alpha(main, disabledOpacity),
  };
}

/** Resolve tonal surface tokens for Chip, Badge, tonal Button, and standard Alert. */
export function resolveTonalColor(
  theme: Theme,
  color?: string | null,
): TonalColorTokens {
  const key: TonalSemanticColor =
    !color || color === 'default' ? 'default' : (color as TonalSemanticColor);

  return theme.palette.mode === 'light'
    ? resolveLightTonal(theme, key)
    : resolveDarkTonal(theme, key);
}

/** Shared sx for solid (light) or alpha-tinted (dark) tonal surfaces. */
export function createTonalSurfaceStyles(
  tokens: TonalColorTokens,
  disabledText: string,
) {
  return {
    backgroundColor: tokens.bg,
    color: tokens.text,
    boxShadow: 'none',
    '&:hover': {
      backgroundColor: tokens.hoverBg,
      boxShadow: 'none',
    },
    '&:disabled': {
      backgroundColor: tokens.disabledBg,
      color: disabledText,
    },
  };
}
