import { LicenseInfo } from '@mui/x-license';

export const setMuiLicenseKey = (key: string) => {
  LicenseInfo.setLicenseKey(key);
};
